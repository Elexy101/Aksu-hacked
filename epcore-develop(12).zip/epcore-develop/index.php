<?php
//@@@@@@@@@@@ IMPORTANT @@@@@@@@@@@@@
//For an update on the server make sure you load new copy or clear the cache

session_start();
include "epapi/api.php";
/* if(isset($EPCONFIG) && trim($EPCONFIG)){
  if(!file_exists($EPCONFIG))$EPCONFIG = "epapi/config.json";
}else{
  $EPCONFIG = "epapi/config.json";
} */
$EPCONFIG = file_exists("config.json")?"config.json":"epapi/config.json";
$epapi = new epapi($EPCONFIG);
$epapi->OnErrorRedirect(); //if epapi creation failed

/* $textarr = [
  "Name"=>"Abayomi",
  "Age"=>30,
  "Food"=>["Rice", 'Beans', "Yame"],
  "Work"=>["Prof"=>"Software","Free"=>"Ministry","Food"=>"gggg"],
  "Family"=>[
    ["Bori","Titi"],
    ["Kike","King"],
    ["Dorcas","Bayo"]
  ],
  "Group"=>[
  ["Church"=>[
    ["Name"=>"Living Faith Church",
    "City"=>
    [["CityName"=>"Ifa Atai"],["CityName"=>"Ifa Atai 2"]]
    ],
    ["Name"=>"Kingdom Minders","City"=>[["CityName"=>"Ifa Atai3"],["CityName"=>"Ifa Atai 4"]]]
  ]
],
["Church"=>[
  ["Name"=>"Living Faith Church g2",
  "City"=>
  [["CityName"=>"Ifa Ataig2"],["CityName"=>"Ifa Atai 2g2"]]
  ],
  ["Name"=>"Kingdom Mindersg2","City"=>[["CityName"=>"Ifa Atai3g2"],["CityName"=>"Ifa Atai 4g2"]]]
]
]]
];
$epapi->WriteStart([],$textarr); */
//$dirarr = explode("epcore",__DIR__);
//exit($dirarr[0]);
//print_r($_SERVER);
//exit;

$school = $epapi->Request(["RequestID"=>"R001,R004","Param"=>'{"Scope":"LOGIN"}']);
//exit(json_encode($school));
$epapi->OnErrorRedirect();
$epapi->WriteStart();
  //$colorScheme = explode(";",$school['ColorScheme']);
  //$forcolor = isset($colorScheme[1])?"rgb(".$colorScheme[1].")":"#F26C20";
 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{R001:
    <title>{{Name}}</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="{{Description}}">
    <meta name="robots" content="{{Name}}" />
    <meta name="googlebot" content="{{Name}}" />
    <meta name="keywords"
        content="{{Name}} {{Abbreviation}} school eduporta academa university institution college taquatech polytechnic academy academa">
    <meta name="author" content="{{Name}}">
    <script>
    function SupportES6() {
        "use strict";

        if (typeof Symbol == "undefined") return false;
        try {
            eval("class Foo {}");
            eval("var bar = (x) => x+1");
        } catch (e) {
            return false;
        }

        return true;
    }

    if (!SupportES6()) {
        window.location =
            "<?php echo $epapi->Config['Core'] ?>error.php?Error_Code=-4&Error_Message=Upgrade Your Browser";
    }
    </script>

    <!-- <link href="https://fonts.googleapis.com/css?family=Exo+2:300|Encode+Sans+Condensed" rel="stylesheet" type="text/css" media="all" /> -->
    <script async src="https://cdnjs.cloudflare.com/ajax/libs/progressbar.js/1.0.1/progressbar.min.js"></script>
    <link href="<?php echo $epapi->Config['Core'] ?>css/w3.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $epapi->Config['Core'] ?>css/gen.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $epapi->Config['Core'] ?>css/bbwa.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $epapi->Config['Core'] ?>css/animated.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $epapi->Config['Require'] ?>Animate/animate.css" rel="stylesheet" type="text/css"
        media="all" />
    <!-- <link href="<?php echo $epapi->Config['Core'] ?>css/login.css" rel="stylesheet" type="text/css" media="all" /> -->
    <link href="<?php echo $epapi->Config['Core'] ?>css/main.css" rel="stylesheet" type="text/css" media="all" />
    <link href="<?php echo $epapi->Config['Require'] ?>mobiriseicons/24 px/mobirise/style.css" rel="stylesheet" />
    <link href="<?php echo $epapi->Config['Require'] ?>FA515/css/all.min.css" rel="stylesheet" type="text/css"
        media="all" />
    <link href="<?php echo $epapi->Config['Core'] ?>css/formelement.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="manifest" href="./manifest.json">
    <link href="https://fonts.googleapis.com/css2?family=Didact+Gothic&display=swap" rel="stylesheet">
    <!-- STEP 2: UNCOMMENT THE IOS SUPPORT ON LINES 20 - 22 -->

    <!-- IOS SUPPORT -->
    <link rel="apple-touch-icon" href="./icons/apple-touch-icon.png">
    <meta name="apple-mobile-web-app-status-bar" content="{{AppThemeColor}}">
    <meta name="theme-color" content="{{AppThemeColor}}">
    <script defer src="<?php echo $epapi->Config['Core'] ?>general/TaquaLB/Basic/Basic.js"></script>
    <script defer src="<?php echo $epapi->Config['Core'] ?>js/aimlite.js" aim-jsonly="true"></script>
    <script defer type="text/javascript" src="./config.json"></script>
    <script defer src="<?php echo $epapi->Config['Core'] ?>epapi/api.js"></script>
    <script defer src="<?php echo $epapi->Config['Core'] ?>js/bbwa.js"></script>
    <script defer src="<?php echo $epapi->Config['Core'] ?>js/formelement.js"></script>
    <script async src="<?php echo $epapi->Config['Core'] ?>js/html2canvas.min.js"></script>
    <link href="<?php echo $epapi->Config['Core'] ?>general/TaquaLB/DateTimePicker/DateTimePicker.css" rel="stylesheet"
        type="text/css" media="all" />
    <script defer src="<?php echo $epapi->Config['Core'] ?>general/TaquaLB/DateTimePicker/DateTimePicker.js"></script>

    <!-- Access Ajax Lite from the eduporta epconfig TaquaLB File formelement.css -->

    <script>
    var transInterval = {{WallDelay}};

    function Capture() {
        html2canvas(document.body).then(canvas => {
            document.body.appendChild(canvas)
        });
    }
    <?php if(isset($_GET['a']) && isset($_GET['p']) && isset($_GET['r']) && isset($_GET['n']) && isset($_GET['k']) && isset($_GET['m']) && isset($_GET['t']) && $_GET['t']="ref"){ ?>
    var DefaultAction = {
        ApplyID: <?php echo $_GET['a'] ?>,
        PageNum: <?php echo $_GET['p'] ?>,
        RID: '<?php echo $_GET['r'] ?>',
        Param: {
            UniqueName: '<?php echo $_GET['n'] ?>',
            UniqueKey: '<?php echo $_GET['k'] ?>',
            __EPAPI_MAPPING__: "<?php echo $_GET['m'] ?>"
        }
    }
    <?php  } ?>
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Encode+Sans+Condensed:wght@300;400;500&display=swap"
        rel="stylesheet">
    <style>
    /* @import "https://fonts.googleapis.com/css?family=Exo+2:300|Encode+Sans+Condensed"; */
    .appcolor {
        color: rgb({{ForeColor}}) !important;
    }

    .gen-btn {
        border-color: #FFF;
        transition: background-color 0.6s, border-color 0.7s;
    }

    .preview-mode .ind-menu-bx .ind-menu-bx-logo{
        background-color:transparent !important;
    }

    .preview-mode .ind-menu-bx .ind-menu-bx-logo.card-1-1{
        box-shadow:none
    }

    .gen-btn:hover,
    .appbgcolor,
    .bbwa-button,
    .appbggradient,
    .appbgcolorfade,
    .menu-bx-page-ind-bx .menu-bx-page-ind-bx-item.active, .new-school-portal, .liststruc .struclist, .gridstruc .strucgrid, .grid2struc .strucgrid2  {

        /* border:solid thin rgb({{ForeColor}}) !important; */
        background-color: rgb({{ForeColor}}) !important;
        color: #FFF !important;
        transition: background-color 0.6s,
        border-color 0.7s !important;
        text-shadow: 1px 1px 1px rgb(24, 24, 24);
        text-shadow: 1px 1px 1px rgba(24, 24, 24, 0.533);
    }

  

    .spinner-container .path {
        stroke:rgba({{ForeColor}}, 0.7);
    }

    .appbgcolorfade, .new-school-portal {
        background-color: rgba( {{ForeColor}}, 0.1) !important;

        border:solid thin rgba( {{ForeColor}}, 0.3) !important;
    }

    .appbggradient {
        /*background-color:transparent !important;
   background-image: linear-gradient(to left, rgb({{LightForeColor}}), rgb({{ForeColor}}), rgb({{ForeColor}}), rgb({{ForeColor}})); */
        background-image: url(<?php echo $epapi->Config['Core'] ?>images/pages/headbg.png);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;

        border: none !important;

        background-color: rgb( {{ForeColor}}, .6) !important;
    }

    /* Large */
    @media (min-width:993px) {

        .preview-mode .ind-menu-bx:hover,
        .preview-mode .ind-menu-bx:hover,.preview-mode .struc-col .active:hover {
            transition: width 0.4s, background-color 0.6s, border-color 0.7s !important;

            border-color: rgb({{ForeColor}}) !important;

            background-color: rgb({{ForeColor}}) !important;
            color: #FFF !important;

        }
    }

    .errInline {
        border:dotted thin rgb( {{ForeColor}}) !important;

    }

    .appcolor-hover:hover,
    .bbwa-checkbox input:checked+.bbwa-checkbox-logo i {
        color: rgb( {{ForeColor}}) !important;
        transition: color 0.6s !important;
    }

    .bbwa-anim-inds .active {

        /* background-color: rgba(19, 93, 230, 0.7); */
        background-color: rgb( {{ForeColor}});
        transition: background-color 1s;
    }

    .active-serachbx .bbwa-anim-search-logo {
        /* color: rgb({{ForeColor}}) !important; */
    }

    /*.menu-popup */
    .menu-popup-cont .head .menus-group button:first-child {
        background-color: rgb( {{ForeColor}}) !important;
    }

    .winbkbtnicon {
        display: inline-block;
        vertical-align: middle;
        margin-right: 10px
    }

    .winbkbtntxt {
        display: inline-block;
        vertical-align: middle
    }

    /* Small */
    @media (max-width:600px) {
        .menu-popup-cont .head .menus-group button:first-child {
            background-color: inherit !important;
            border-right: none !important;
            padding: 5px 10px 5px 0px !important;
        }

        .menu-popup-cont .head {
            padding: 5px 0px !important;
        }

        .menu-popup-cont .body {
            height: calc(100% - 51px);
        }

        .winbkbtnicon {
            display: none;
        }

        .winbkbtntxt {
            font-size: 1.3em;
            font-weight: 600;
        }

        .menu-popup-cont .head {
            background-color: inherit;
            border-bottom: none;
            box-shadow: 0 4px 2px -2px #111;
        }

        .menu-popup-cont .head:hover {
            background-color: inherit;
        }
    }

    .bbwa-linkbox input:checked+a {
        border-bottom:solid thin rgb( {{ForeColor}}) !important;
    }
    </style>

</head>

<body class="bbwa-login-">


    <!-- </div> -->


    <!-- Alert box -->
    <div class="alert-cover">
        <!-- <div class="ordersys-alert w3-card w3-animate-opacity">
    <div id="alertcont" class="alert-cont"><i class="fas fa-shopping-cart appcolor alert-logo"></i><span class="alert-txt">Item Added to Cart 1<span></div><button onclick="this.parentElement.classList.add('w3-hide')" style="" class="bbwa-btn smaller gen-text-shadow bbwa-icon-only w3-right"><i class="fas fa-times fa-fw"></i></button>
    <div style="clear:both"></div>
</div>
<div class="ordersys-alert w3-card w3-animate-opacity">
    <div id="alertcont" class="alert-cont"><i class="fas fa-shopping-cart appcolor alert-logo"></i><span class="alert-txt">Item Added to Cart 2<span></div><button onclick="this.parentElement.classList.add('w3-hide')" style="" class="bbwa-btn smaller gen-text-shadow bbwa-icon-only w3-right"><i class="fas fa-times fa-fw"></i></button>
    <div style="clear:both"></div>
</div> -->
    </div>
    <!-- Big Banner With Anim - bbwa closebtn fade-white-text-->
    <div class="bbwa-main w3-card" id="bbwa-main-1">

        <div class="bbwa-banners">
            {{Wallpapers:
    <div class="bbwa-banner fadeOut unloaded animated" data-bg-image="{{WallImage}}" style="background-color:
            rgb(<?php echo mt_rand(0,255).",". mt_rand(0,255).",". mt_rand(0,255); ?>)">&nbsp;</div>
        :Wallpapers}}
        <!-- <div class="bbwa-banner fadeOut" style="background-image: url(images/bbwa/bbwa2.jpg)">&nbsp;</div> -->
        <!-- <div class="bbwa-banner w3-hide w3-animate-opacity" style="background-image: url(images/bbwa/bbwa2.jpg);">&nbsp;</div> -->

    </div>

    

  
  <div class="left-side">

      <!-- Login -->
    <div class="bbwa-login-bx w3-display-middle animated forwards fast">
        <div class="animate-normal fadeIn">
            <!-- Details Box -->
            <div class="school-det-bx gen-text-shadow" id="login-main-bx">
                <img src="{{Logo}}" alt="Logo" />
                <div class="schnme">{{Name}}</div>
                <div class="logintxt appbgcolor">Sign In</div>
                
                <div class="tcolline-line-outer-h bbwa-demacator animate-normal">
                    <div class="tcolline-line-inner-h"></div>
                </div>
                <div class="login-user-det">
                    <div class="login-user-img-cont">
                        <div class="login-user-img w3-card" id="stud-passp"
                            style="background-image:url({{__Core__}}images/bbwa/logo.png)"></div>
                    </div>
                    <div class="login-user-det-cont">
                        <!-- <div class="usnme">Welcome</div> -->
                        <div class="regno" id="usnme"></div>
                        <div class="dept" id="regno"></div>
                    </div>
                </div>
                <form name="login-form" action="javascript:void(0)">
                    <div class="bbwa-anim-searchbx onebtn usname-tb w3-card ">
                        <div class="bbwa-anim-search-logo "><i class="mbri-user w3-display-middle gen-text-shadow"></i>
                        </div>
                        <input class="bbwa-anim-search-input animate-normal fadeIn" name="main-uname" id="main-uname"
                            placeholder="Registration Number"
                            onfocus="this.parentElement.className += ' active-serachbx'"
                            onblur="this.parentElement.className = this.parentElement.className.replace(' active-serachbx','')"><input
                            type="password" class="bbwa-anim-search-input animate-normal fadeIn" name="main-passw"
                            id="main-passw" placeholder="Access Code or Password"
                            onfocus="this.parentElement.className += ' active-serachbx'"
                            onblur="this.parentElement.className = this.parentElement.className.replace(' active-serachbx','')">
                        <button id="login-ver-btn" class="bbwa-anim-search-btn appcolor-hover"
                            onclick="Login.Verify(this)"><i class="fas fa-arrow-right w3-display-middle"></i></button>

                    </div>
                    <!--  <div class="bbwa-anim-searchbx onebtn passw-tb w3-card">
                   <div class="bbwa-anim-search-logo"><i class="fas fa-unlock w3-display-middle"></i></div>
                   <input type="password" class="bbwa-anim-search-input" name="main-passw"  id="main-passw" placeholder="Access Code or Password" onfocus="this.parentElement.className += ' active-serachbx'" onblur="this.parentElement.className = this.parentElement.className.replace(' active-serachbx','')">
                   <button class="bbwa-anim-search-btn appcolor-hover" onclick="alert('aaa')"><i class="fas fa-arrow-right w3-display-middle"></i></button> 
                   
           </div>-->
                </form>
                <div class="bbwa-btn-bx">
                    <button onclick="Login.Close()" name="tohome"
                        class="bbwa-btn gen-text-shadow bbwa-icon-only- w3-left btn-home"><i
                            class="mbri-home"></i><span>Home</span></button>
                    <button onclick="Login.Reset()" name="backop"
                        class="bbwa-btn gen-text-shadow bbwa-icon-only- w3-left btn-back"><i
                            class="mbri-arrow-prev"></i><span>Back</span></button>
                    <button name="toapply" class="bbwa-btn gen-text-shadow bbwa-icon-only- w3-right"><i
                            class="mbri-user"></i><span>Guest</span></button>
                    <button
                        onclick="Application.Load({ApplyGID:'1_2',AutoLoad:'true',Minimize:'false',Home:'true',Logout:'false',Guest:'true'})"
                        class="bbwa-btn gen-text-shadow bbwa-icon-only- w3-right"><i
                            class="mbri-edit"></i><span>Enrol</span></button>
                    <div style="clear:both"></div>
                </div>

            </div>
            <!-- Details Box -->

        </div>
        <!-- Login -->


    </div>
    <!-- Login End -->

    <div class="new-school-bx">
            <div class="new-school-img"><img alt="{{Abbreviation}}" src="{{Logo}}" /></div>
            <div class="new-school-body">
                <div class="new-school-abbr">{{Abbreviation}}</div>
                <div class="new-school-name">{{Name}}</div>
                <div class="new-school-portal card-2" style="display:none">Student Desk</div>
            </div>
    </div>

    <div class="bbwa-anim-inds bbwa-first-cont animate-normal">
        <!-- <div class="bbwa-anim-ind">&nbsp;</div> <div class="bbwa-anim-ind active">&nbsp;</div> -->
    </div>

    <button class="new-explore-btn">START NOW</button>

     <div class="w3-hide" id="startmk">
     <div class="img card-3 appbgcolor zoomInShort2 delay-0-2s animated fast">
         <img class="zoomInShort animated fast delay-0-3s" src="<?php echo $epapi->Config['Core'] ?>images/App/welcome.png" alt="Welcome" />
        </div>
        <div class="start-title fadeIn animated fast delay-0-5s"><div>{{Abbreviation}}</div><div class="appbgcolor">Student Desk</div></div>
            <div class="start-cont">
                
            <div id="loginmbtn" onclick="Login.Open();MessageBox.ClosePopup();" class="bbwa-textbox zoomInShort animated delay-0-4s w3-padding w3-round-small w3-display-container bbwa-boxbtn start-btn"  title="">
                <i class=" fas fa-user-lock bxbtn-logo"></i>
                <div style="vertical-align: middle;display: inline-block;max-width: calc(100% - 30px);">
    <div class="bbwa-boxbtn-title">Login</div>
    <div class="bbwa-boxbtn-data"></div>
</div>
</div>


<div id="enrlbtn" onclick="Application.Load({ApplyGID:'1',AutoLoad:'true',Minimize:'false',Home:'true',Logout:'false',Login:'true',Logo:'fas fa-address-book'});MessageBox.ClosePopup();" class="bbwa-textbox zoomInShort animated delay-0-6s w3-padding w3-round-small w3-display-container bbwa-boxbtn start-btn"  title="">
                <i class=" fas fa-user-plus bxbtn-logo"></i>
                <div style="vertical-align: middle;display: inline-block;max-width: calc(100% - 30px);">
    <div class="bbwa-boxbtn-title">Enrol</div>
    <div class="bbwa-boxbtn-data"></div>
</div>
</div>


            </div>
            <div style="height:20px"></div>
            <div class="loginhmfoot fadeIn animated fast delay-0-6s"> &copy; {{Abbreviation}} <?php echo date('Y') ?> All right reserved</div>
     </div>


    <div class="bbwa-sponsors" id="screen-footer">
        <div class="bbwa-sponsors-img"><a href="#"><img src="{{Logo}}" /></a><a href="#"><img style="height:23px" src="{{__Core__}}images/App/Images/eduporta.png" /></a></div>
        <div class="footer-note gen-text-shadow" onclick="">&copy; {{Abbreviation}} <?php echo date('Y') ?> | {{Phone}}
            |
            {{Email}} {{FooterNote}} </div>

    </div>
    <!-- <a href="#" class="bbwa-arrow-left w3-display-left"><i class="fas fa-chevron-left"></i></a>
   <a href="#" class="bbwa-arrow-right w3-display-right"><i class="fas fa-chevron-right"></i></a> -->
    <!-- <a href="#" class="bbwa-arrow w3-display-bottommiddle w3-large"><i class="fas fa-angle-double-down"></i></a> --> 
</div>

    <!-- Contents -->
    <div class="right-side gen-text-shadow w3-display-container bbwa-exit shownew" id="bbwa-main-2">
        <div class="slantbx "></div>
        <div class="slantbx slant2"></div>
        {{Wallpapers:
   <div class="bbwa-indcont w3-hide animate-normal bbwa-first-cont" style="">
          <h1 class="bbwa-title fadeInDown-" >{{WallTitle}}</h1>
        <div class="bbwa-body fadeInUp-">{{WallContent}}</div>
        <div class="bbwa-note fadeInUp- bbwa-buttonbx"></div>
    </div>
    :Wallpapers}}
    </div>

    <div style="clear:both" ></div>

    

    </div>
    :R001}}

    <?php  
$epapi->WriteEnd();
?>

    <!-- Big Banner With Anim - bbwa -->
    <?php if(isset($_SESSION['LoginName']) && trim($_SESSION['LoginName']) != ""){
  ?>

    <input type="hidden" value="<?php echo $_SESSION['LoginName'] ?>" id="logSes" />


    <?php
} 
// echo json_encode($_SESSION);
?>

    <!--  Default Markups -->
    <!--  ****************************** -->
    <!-- Placeholder Markup -->
    <div id="ep-placeholder-cont" class="w3-hide">
        <div class="fadeIn animate-normal indpage ph-template">
            <!-- Logo Title -->
            <a href="javascript:void(0)" onclick="" class="pitem applybtn w3-medium">
                <div class="logodesign"></div>
                <div class="detdesign">
                    <div class="bbwa-groupbox" style="padding:0px" id="">
                        <div class="bbwa-textbox  ph-item"></div>
                    </div>
                </div>
            </a>

            <!-- Title Details -->
            <div class="bbwa-groupbox w3-margin-top" style="padding:0px" id="">
                <div class="bbwa-textbox  ph-item"></div>
                <div class="bbwa-textbox  ph-item"></div>
            </div><!-- Line -->
            <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px">
                <div class="tcolline-line-inner-h"
                    style="width: 70%;left: 15%;box-shadow: 0px 0px 30px 20px #979797;background:#979797"></div>
            </div>
            <div class="w3-row">
                <div class="w3-col m12">
                    <!-- Header Box -->
                    <div class="bbwa-groupbox" id="">
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                    </div>
                    <!-- Big Boxes -->
                    <div class="w3-row ph-iconbox">
                        <div class="w3-col m6 l4 s6 indpaybx">
                            <div class="bbwa-iconbox bbwa-iconbox-ph ph-item" onclick=""></div>
                        </div>
                        <div class="w3-col m6 l4 s6 indpaybx">
                            <div class="bbwa-iconbox bbwa-iconbox-ph ph-item" onclick=""></div>
                        </div>
                        <div class="w3-col m6 l4 s6 indpaybx">
                            <div class="bbwa-iconbox bbwa-iconbox-ph ph-item" onclick=""></div>
                        </div>
                        <div class="w3-col m6 l4 s6 indpaybx w3-hide-large">
                            <div class="bbwa-iconbox bbwa-iconbox-ph ph-item" onclick=""></div>
                        </div>
                    </div>
                    <!-- Text Boxes -->
                    <div class="bbwa-groupbox ph-textbox" id="">
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                    </div>
                    <!-- Button -->
                    <div class="bbwa-groupbox" id="">
                        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Placeholder Markup End-->

    <!-- Window Markup -->
    <div id="ep-window-cont" class="w3-hide">
        <div class="menu-popup-cont w3-card {{OpenFrom}}  ph-pause" data-logo="{{Logo}}"
            onclick="Application.MakeActive(this)" id="menu-popup{{PAGEID}}">
            <div class="w3-display-topmiddle popupsizer Top lineE w3-hide-small" style=""></div>
            <div class="w3-display-bottommiddle popupsizer Bottom lineE w3-hide-small" style=""></div>
            <div class="w3-display-left popupsizer vertical Left lineE w3-hide-small" style=""></div>
            <div class="w3-display-right popupsizer vertical Right lineE w3-hide-small" style=""></div>
            <div class="w3-hide-large w3-hide-medium moreoptions" style="display:none" id="moreop{{PAGEID}}">
                <div class="innermore w3-card fadeInDown animated">

                    <!-- <div class="bbwa-checkbox indlistit Moreoptionclick  fadeInDown animated delay-0-3s">
      <input type="checkbox" class="Moreoptionclick" id="autoopenapply" onchange="" name="bbwa-checkbox" {{favourite}} />
      <div class="bbwa-checkbox-logo Moreoptionclick"><i class="fas fa-check Moreoptionclick" style="font-size:0.9em"></i></div>
      <div class="bbwa-checkbox-text Moreoptionclick">Favourite</div>
    </div> -->

                    <div class="bbwa-checkbox indlistit Moreoptionclick  fadeInDown animated delay-0-3s">
                        <input type="checkbox" class="Moreoptionclick" id="darkthemechange"
                            onchange="Application.SwitchMode(this)"
                            name="bbwa-checkbox" {{darkmode}} />
                        <div class="bbwa-checkbox-logo Moreoptionclick"><i class="fas fa-check Moreoptionclick"
                                style="font-size:0.9em"></i></div>
                        <div class="bbwa-checkbox-text Moreoptionclick">Dark Mode</div>
                    </div>

                    <button name="closebtn2smk" class="indlistit fadeInDown animated delay-0-2s {{Logout}}"
                        title="Logout" onclick="Login.Logout()" class=""><span class="fas fa-power-off"></span>
                        Logout</button>

                </div>
            </div>
            <div class="head w3-hide-small w3-hide-medium headwin">
                <button name="menubtnnm" class=" menubtn" onclick="Application.LoadPrevPage(this)"><i
                        class="fas fa-arrow-left w3-large"></i></button>
                <!--  <button name="minbtn" onclick="Application.Minimize(this.parentElement.parentElement)" class="w3-hide-large w3-hide-medium minimizebtn"><span class="fas fa-arrow-left w3-large"></span> </button> -->
                <!--  -->
                <div class="mainlogo w3-hide"><i class="{{Logo}} w3-display-middle"></i></div>
                <div class="menus-group">
                    <!-- {{AppGroup: -->
                    <button name="appbtn" onclick="Application.ActivateGroup(this,'{{PAGEID}}')"
                        class="animate-normal fadeIn popup-real-menu"><i class="{{Logo}} w3-xlarge winbkbtnicon" style=""></i> <span class="grpwinbkbtntxt winbkbtntxt groupdistxt{{PAGEID}}" >{{Name}}</span> <span class="curwinbkbtntxt winbkbtntxt curentdistxt{{PAGEID}}" >{{Name}}c</span></button>
                    <!-- :AppGroup}} -->
                </div>
                <div class="menus-group3">
                    <!--  <button name="" onclick="this.parentElement.parentElement.parentElement.parentElement.classList.toggle('menu-popup-drop')" class="animate-normal fadeIn popup-real-menu popup-menu-display-btn arrowbtn w3-hide-large w3-hide-medium appbgcolor"><i class="fas fa-caret-down popup-menu-display-btn"></i></button> -->
                </div>

                <div class="menus-group2" style="">
                    <button name="closebtn2" title="Close"
                        onclick="Application.Close(this.parentElement.parentElement.parentElement)"
                        class="animate-normal fadeIn popup-real-menu w3-hover-red  w3-right w3-hide-small"><span
                            class="mbri-close"></span></button>
                    <button name="maxbtn2" title="Maximize"
                        onclick="Application.Maximize(this.parentElement.parentElement.parentElement)"
                        class="animate-normal fadeIn popup-real-menu w3-hide-small w3-hover-opacity w3-hide-medium w3-right"><span
                            class="mbri-browse"></span></button>
                    <button name="minbtn2" title="Minimize"
                        onclick="Application.Minimize(this.parentElement.parentElement.parentElement)"
                        class="animate-normal fadeIn popup-real-menu w3-right w3-hover-opacity {{Minimize}} w3-hide-small"><span
                            class="mbri-down"></span> </button>
                    <!--  <button name="minbtn3" title="More" onclick="" class="animate-normal fadeIn popup-real-menu w3-hide-large w3-hide-medium w3-right "><span class="mbri-more-vertical"></span></button> -->
                </div>
            </div>

            <div class="head w3-hide-large">
                <button name="menubtnnm" class=" menubtn" onclick="Application.LoadPrevPage(this)"><i
                        class="fas fa-arrow-left w3-large"></i></button>
                <button name="minbtn" onclick="Application.Minimize(this.parentElement.parentElement)"
                    class="w3-hide-large w3-hide-medium minimizebtn"><span class="fas fa-arrow-left w3-large"></span>
                </button>
                <!--  -->
                <div class="mainlogo w3-hide"><i class="{{Logo}} w3-display-middle"></i></div>
                <div class="menus-group">
                    <!-- {{AppGroup: -->
                    <button name="appbtn" onclick="Application.ActivateGroup(this,'{{PAGEID}}')"
                        class="animate-normal fadeIn popup-real-menu"><i class="{{Logo}} w3-xlarge winbkbtnicon" style=""></i> <span class="grpwinbkbtntxt winbkbtntxt groupdistxt{{PAGEID}}"  style="">{{Name}}</span> <span class="curwinbkbtntxt winbkbtntxt curentdistxt{{PAGEID}}" style="">{{Name}}c</span></button>
                    <!-- :AppGroup}} -->
                </div>
                <div class="menus-group3">
                    <!--  <button name="" onclick="this.parentElement.parentElement.parentElement.parentElement.classList.toggle('menu-popup-drop')" class="animate-normal fadeIn popup-real-menu popup-menu-display-btn arrowbtn w3-hide-large w3-hide-medium appbgcolor"><i class="fas fa-caret-down popup-menu-display-btn"></i></button> -->
                </div>

                <div class="menus-group2" style="">
                    <!-- <button name="closebtn2" title="Close" onclick="Application.Close(this.parentElement.parentElement.parentElement)" class="animate-normal fadeIn popup-real-menu w3-hover-red  w3-right w3-hide-small"><span class="mbri-close"></span></button>
    <button name="maxbtn2"  title="Maximize" onclick="Application.Maximize(this.parentElement.parentElement.parentElement)" class="animate-normal fadeIn popup-real-menu w3-hide-small w3-hover-opacity w3-hide-medium w3-right"><span class="mbri-browse"></span></button> -->
    <button name="minbtn2" title="Minimize" onclick="Application.Minimize(this.parentElement.parentElement.parentElement)" class="animate-normal fadeIn popup-real-menu w3-right w3-hover-opacity {{Minimize}} w3-hide-small w3-hide-large"><span class="mbri-down"></span> </button>
                    <button name="minbtn3" title="More"
                        onclick="document.getElementById('moreop{{PAGEID}}').style.display = 'block';"
                        class="animate-normal fadeIn popup-real-menu w3-hide-large w3-hide-medium w3-right Moreoptionclick"><span
                            class="fas fa-ellipsis-v Moreoptionclick"></span></button>
                </div>
            </div>
            <!-- Popup body -->
            <div class="body small-screen" id="win-body-cont{{PAGEID}}">
                <div class="body-cont bdcont" id="">
                    <div class="body-cont-title">
                        <div class="bbwa-groupbox" style="padding:0px" id="">
                            <div class="bbwa-textbox  ph-item " style="margin-left:0px"></div>
                        </div>
                    </div>
                    <div class="w3-row struc-row">
                        <div class="w3-col l4 struc-col back-btn">
                            <div class="ind-menu-bx" onclick="">
                                <div class="ind-menu-bx-logo pitem" style="margin:0px">
                                    <div class="logodesign"></div>
                                </div>
                                <div class="ind-menu-bx-cont bbwa-groupbox">
                                    <!-- <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div> -->
                                    <div class="ph-item  bbwa-textbox"></div>
                                    <div class="bbwa-textbox-ph  ph-item  bbwa-textbox"></div>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                        </div>

                        <div class="w3-col l4 struc-col">
                            <div class="ind-menu-bx" onclick="">
                                <div class="ind-menu-bx-logo pitem" style="margin:0px">
                                    <div class="logodesign"></div>
                                </div>
                                <div class="ind-menu-bx-cont bbwa-groupbox">
                                    <!-- <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div> -->
                                    <div class="ph-item  bbwa-textbox"></div>
                                    <div class="bbwa-textbox-ph  ph-item  bbwa-textbox"></div>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                        </div>

                        <div class="w3-col l4 struc-col">
                            <div class="ind-menu-bx" onclick="">
                                <div class="ind-menu-bx-logo pitem" style="margin:0px">
                                    <div class="logodesign"></div>
                                </div>
                                <div class="ind-menu-bx-cont bbwa-groupbox">
                                    <!-- <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div> -->
                                    <div class="ph-item  bbwa-textbox"></div>
                                    <div class="bbwa-textbox-ph  ph-item  bbwa-textbox"></div>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                        </div>

                        <div class="w3-col l4 struc-col">
                            <div class="ind-menu-bx" onclick="">
                                <div class="ind-menu-bx-logo pitem" style="margin:0px">
                                    <div class="logodesign"></div>
                                </div>
                                <div class="ind-menu-bx-cont bbwa-groupbox">
                                    <!-- <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div> -->
                                    <div class="ph-item  bbwa-textbox"></div>
                                    <div class="bbwa-textbox-ph  ph-item  bbwa-textbox"></div>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                        </div>

                        <div class="w3-col l4 struc-col">
                            <div class="ind-menu-bx" onclick="">
                                <div class="ind-menu-bx-logo pitem" style="margin:0px">
                                    <div class="logodesign"></div>
                                </div>
                                <div class="ind-menu-bx-cont bbwa-groupbox">
                                    <!-- <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div> -->
                                    <div class="ph-item  bbwa-textbox"></div>
                                    <div class="bbwa-textbox-ph  ph-item  bbwa-textbox"></div>
                                </div>
                                <div style="clear:both"></div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>

            <!-- Popup Footer -->
            <div class="footer w3-hide-small">
                <div class="footer-cont">
                    <div class="bbwa-checkbox">
                        <input type="checkbox" id="autoopenapply"
                            onchange="Application.SwitchMode(this)"
                            name="bbwa-checkbox" {{darkmode}} name="bbwa-checkbox" />
                        <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div>
                        <div class="bbwa-checkbox-text">Dark Mode</div>
                    </div>
                </div>
                <div class="footer-link">
                    <a href="javascript:void(0)" class="{{Home}}"
                        onclick="Application.CloseAll();Login.Close()">Home</a>
                    <a href="javascript:void(0)" class="{{Login}}"
                        onclick="Application.CloseAll();Login.Open()">Login</a>
                    <a href="javascript:void(0)" class="{{Logout}}" onclick="Login.Logout()"><span
                            class="fas fa-power-off"></span> Logout</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Window Markup End-->


    <!--  ****************************** -->
    <!--  Default Markups Ends -->

    </div>
    </div>
    <script>
    //nbbwa = new bbwa('bbwa-main-1');nbbwa.Start();
    </script>
    <!-- STEP 3: UNCOMMENT THIS SCRIPT lines 35 to 41  -->
    <script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js')
            .then(regObj => console.log("Service worker registered"))
            .catch(err => console.log("An error occured", err))
    }


    /*  var button = document.getElementById('guestbtn');
     
     button.addEventListener('click',function(e){
      
       Notification.requestPermission().then(function(result){
         alert(result);
            if(result === 'granted'){
              alert('Notify')
            }
       });
     }); */
    </script>
</body>

</html>