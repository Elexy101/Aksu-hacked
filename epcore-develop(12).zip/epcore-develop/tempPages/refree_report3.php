<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{SurName}} {{FirstName}} {{OtherNames}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},7,{RegNo:'{{R010:{{RegNo}}:R010}}',UniqueID:'{{UniqueID}}'})" >
        <div class="w3-col m12">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
    <h1 class="bbwa-groupbox-title">Please comment on the candidate strengths and potential for completing a postgraduate degree at AKSU</h1>
    
    <div class="bbwa-textbox" style="max-width:none">
            <i class="bbwa-textbox-logo mbri-edit"></i><textarea  name="Comment_Refree_Cand" id="Comment_Refree_Cand" placeholder="Type Comment Here" class="bbwa-textbox-input gen-text-shadow" ></textarea>
          </div>

  
</div>


<div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
    <h1 class="bbwa-groupbox-title">Recommendation</h1>

    <div class="bbwa-checkbox-group" style="max-width:none">
            <div class="w3-row">
            <div class="w3-col m4">
            <div class="bbwa-checkbox">
          <input type="radio" id="StrongRecommend_Cand" onchange="" name="bbwa-checkbox-rec" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Strongly Recommended</span></div>
         </div></div>

              <div class="w3-col m4">
          <div class="bbwa-checkbox">
          <input type="radio" id="Recommend_Cand" onchange="" name="bbwa-checkbox-rec" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Recommended</span></div>
         </div>
           </div>

           <div class="w3-col m4">
          <div class="bbwa-checkbox">
          <input type="radio" id="NotRecommend_Cand" onchange="" name="bbwa-checkbox-rec" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Not Recommended</span></div>
         </div>
           </div>
</div>
</div>


</div>


     

   <input type="hidden" id="Enable_Referee" value="0" /> <!--  -->
      {{R010:
      <input id="SurName_Referee" value="{{SurName}}" type="hidden" />
      <input id="FirstName_Referee" value="{{FirstName}}" type="hidden" />
      <input id="OtherNames_Referee" value="{{OtherNames}}" type="hidden" />
      :R010}}
      <input id="FromName_Referee" value="noreply" type="hidden" />
      <input id="Subject_Referee" value="Online Referee Form" type="hidden" />
      <input id="Mail_Referee" value="../../portals/tempPages/mailhtmlfinish.html" type="hidden" />
      <input id="__EPAPI_MAPPING__" value="UniqueName=ToAddress" type="hidden" />
    
 <button class="bbwa-button tooltip w3-margin-top" tooltip="Finish"><i class="fas fa-check"></i><span>Finish</span></button>
   
     
    
    </form>
    </div>
    </div>