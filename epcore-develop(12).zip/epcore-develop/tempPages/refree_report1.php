<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} - {{R010:{{SurName}} {{FirstName}} {{OtherNames}}:R010}}</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
{{R010:
       <div class="w3-row">
       <!-- Application.FormRequest(this,'{{SubmitRID}}') -->
        <form name="payreq" id="payreq" action="javascript:void(0)"  onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},5,{RegNo:'{{R010:{{RegNo}}:R010}}',UniqueID:'{{UniqueID}}'})" >
    <div class="w3-col l6">
    <!-- <div class ="bbwa-groupbox">
         <h1 class="bbwa-groupbox-title">Payment Details</h1>

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div> -->
    
       <div class ="bbwa-groupbox" id="">
         <h1 class="bbwa-groupbox-title">How long have you known {{SurName}} {{FirstName}} {{OtherNames}}?</h1>
         
         <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-80px">
         <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-calendar"></i>
        <select name="Known_Cand" id="Known_Cand">
        <option value="1">Less than a year</option>
          <option value="1">Less than a year</option>
          <option value="2">1 - 4 years</option>
          <option value="3">More than 4 years</option>
        </select>
      </div>

    </div>

    <div class ="bbwa-groupbox" id="">
         <h1 class="bbwa-groupbox-title">In what capacity did you get to know {{SurName}} {{FirstName}} {{OtherNames}} ?</h1>
         
         <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-110px">
         <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-edit2"></i>
        <select name="KnownCapacity_Cand" id="KnownCapacity_Cand">
        <option value="Lecturer">Lecturer</option>
          <option value="Lecturer">Lecturer</option>
          <option value="Supervisor">Supervisor</option>
          <option value="Professional Colleague">Professional Colleague</option>
          <option value="Employer">Employer</option>
          <option value="Others">Others</option>
          
         
          <!-- <option {{Selected}} value="{{StateID}}">{{StateName}}</option> -->
          
          
        </select>
      </div>

    </div>
    
    </div>

    <div class="w3-col l6">
    <div class ="bbwa-groupbox" id="">
         <h1 class="bbwa-groupbox-title">Please answer YES by checking the box</h1>
    <div class="bbwa-checkbox-group">
          <div class="bbwa-checkbox">
          <input type="checkbox" id="Moral_Cand" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center w3-medium"><!-- <i class="bbwa-textbox-logo fas fa-female w3-medium" style="vertical-align:middle"></i> --> <span>Is {{SurName}} {{FirstName}} {{OtherNames}} morally sound ?</span></div>
         </div>
           </div>

           <div class="bbwa-checkbox-group">
          <div class="bbwa-checkbox">
          <input type="checkbox" id="Emotional_Cand" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center w3-medium"><!-- <i class="bbwa-textbox-logo fas fa-female w3-medium" style="vertical-align:middle"></i> --> <span>Is {{SurName}} {{FirstName}} {{OtherNames}} emotionally stable ?</span></div>
         </div>
           </div>

           <div class="bbwa-checkbox-group">
          <div class="bbwa-checkbox">
          <input type="checkbox" id="Physical_Cand" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center w3-medium"><!-- <i class="bbwa-textbox-logo fas fa-female w3-medium" style="vertical-align:middle"></i> --> <span>Is {{SurName}} {{FirstName}} {{OtherNames}} physically stable ?</span></div>
         </div>
           </div>


           <div class="bbwa-checkbox-group">
          <div class="bbwa-checkbox">
          <input type="checkbox" id="Social_Cand" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center w3-medium"><!-- <i class="bbwa-textbox-logo fas fa-female w3-medium" style="vertical-align:middle"></i> --> <span>Is {{SurName}} {{FirstName}} {{OtherNames}} socially responsible ?</span></div>
         </div>
           </div>



</div>
:R010}} 
<button class="bbwa-button tooltip"  tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>
     </div>
     

          

       </div>


    </div>
    </form>
    </div>
    </div>