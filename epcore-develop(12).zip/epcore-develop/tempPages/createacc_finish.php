<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}}</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
       <!-- Application.FormRequest(this,'{{SubmitRID}}') -->
        <form name="createacc_verify" id="createacc_verify" action="javascript:void(0)" onsubmit="" >
    <div class="w3-col m12">
    {{R010:
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" style="max-width:400px;margin:auto" id="">
    <div class="w3-row">
     <div class="w3-col s4"> 
     <div class="bbwa-passport bbwa-textbox">
      <!-- <div class="bbw-passport-change appcolor"><i class="fas fa-images fa-fw"></i></div> -->
        <img src="{{Passport}}" />
        <img src="images/bbwa/logo.png" />
      </div> </div>
     <div class="w3-col s8">
      <div class="w3-large appcolor">{{SurName}} {{FirstName}} {{OtherNames}}</div>
      <div class="w3-large">{{FacultyName}}</div>
      <div class="w3-large">{{ProgrammeName}}</div>
      </div>
    </div>
    
      <div class="w3-margin-top w3-border-top w3-border-bottom w3-padding w3-center" style="border-color:#333 !important"><span class="w3-large appcolor">{{NRegNo}}</span><br/>Portal User Name</div>

      <p class="w3-margin-top">Congratulation!! your school portal account is created.<br/> Kindly check your mail for your login credentials to your Desk. </p>
      <!-- <div class="w3-medium">Username: <span class="appcolor">{{R010:{{RegNo}}:R010}}</span></div>
      <div class="w3-medium">Access code: <span class="appcolor">hfrhdjjfj</span></div> -->
      </div>
      <div class="w3-center">
 <button class="bbwa-button tooltip" style="width:auto;display:inline-block" onclick="_Printer.Load({{NRedirectData}})"  tooltip="Reprint Registration Confirmation Slip"><i class="fas fa-check-circle"></i><span>Reprint Confirmation Slip</span></button> <button class="bbwa-button tooltip"   style="width:auto;display:inline-block" onclick="_Printer.Load({{ARedirectData}})"  tooltip="Print Admission Letter"><i class="fas fa-file"></i><span>Print Admission Letter</span></button>
 </div>
    </div>
     :R010}}
    
    </form>
    </div>
    </div>