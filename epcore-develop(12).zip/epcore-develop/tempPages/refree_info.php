<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} (Candidate - {{R010:{{SurName}} {{FirstName}} {{OtherNames}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>

       <div class="w3-row">
       <!-- Application.FormRequest(this,'{{SubmitRID}}') -->
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},4,{RegNo:'{{R010:{{RegNo}}:R010}}',UniqueID:'{{UniqueID}}'})" >
    <div class="w3-col l6">
    <!-- <div class ="bbwa-groupbox">
         <h1 class="bbwa-groupbox-title">Payment Details</h1>

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div> -->
       <div class ="bbwa-groupbox" id="">
         <!-- <h1 class="bbwa-groupbox-title">Payement Details</h1> -->
         
         
          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-user"></i><input name="RefereeFullName_Cand" id="RefereeFullName_Cand" placeholder="Full Name (Surname first)" class="bbwa-textbox-input gen-text-shadow" required value="" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-sale"></i><input name="RefereeRank_Cand" id="RefereeRank_Cand" placeholder="Title/Rank" class="bbwa-textbox-input gen-text-shadow" value="" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-idea"></i><input name="RefereeOccupation_Cand" id="RefereeOccupation_Cand" placeholder="Occupation" class="bbwa-textbox-input gen-text-shadow" value="" />
          </div>

          
          
          <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-university"></i><input name="input-elem" placeholder="Fullname" class="bbwa-textbox-input gen-text-shadow" />
          </div> -->

         

          

    </div>
    
    </div>
     <div class="w3-col l6">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
         
    <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-mobile"></i><input name="Referee_Phone_Cand" required id="RefereePhone_Cand" placeholder="Phone Number" class="bbwa-textbox-input gen-text-shadow" value="" />
          </div>

          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-letter"></i><input  name="Referee_Email_Cand" required id="RefereeEmail_Cand" placeholder="Email Address" class="bbwa-textbox-input gen-text-shadow" value="" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-map-pin"></i><textarea  name="Referee_Address_Cand" id="RefereeAddress_Cand" placeholder="Mailling Address" class="bbwa-textbox-input gen-text-shadow" ></textarea>
          </div>
          
          <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-home"></i><textarea  name="Address_Cand" id="Address_Cand" placeholder="Home Address" class="bbwa-textbox-input gen-text-shadow" >{{Address}}</textarea>
          </div>
          <input id="RegLevel" value="4" type="hidden" /> -->
          <button class="bbwa-button tooltip" tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>

       </div>


    </div>
    </form>
    </div>
    </div>