<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},7,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'})" >
        <div class="w3-col m12">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
    <h1 class="bbwa-groupbox-title">Scanned copies of all your credentials including NYSC Discharge/Exemption/Exclusion Certificate.  <span class="appcolor">*20KB - 100KB*</span></h1>
          <div class="bbwa-textbox w3-padding loadimgs" style="" id="scancredential">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
          Scanned Document will display here. (Use ctrl+click to select multiple files)</div>
          <button type="button" class="bbwa-button normal tooltip bbwa-icon-only form-file-btn" data-required="Credentials_Cand"  tooltip="Select Scanned copies of all your Credentials" onclick="_BrowseInto('scancredential',{FileID:'Credentials_Cand',MinSize:20480,MaxSize:1001024,Accept:'image/*',OnError:errorpw,Multiple:true})" ><i class="mbri-to-local-drive"></i><span>Select Credentials</span></button>
          <span style="clear:left;display:block"></span>
       </div>
    

       <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
    <h1 class="bbwa-groupbox-title">One page Summary of your proposed research (PhD applicants only) <span class="appcolor">*20KB - 100KB*</span></h1>
    <div class="bbwa-textbox w3-padding loadimgs" style="" id='scanres'>File will display here. (Use ctrl+click to select multiple files)</div>
   
          <button type="button" class="bbwa-button normal tooltip bbwa-icon-only" tooltip="Select One page Summary of your Proposed Research" onclick="_BrowseInto('scanres',{FileID:'OtherCredentials_Cand',MinSize:20480,MaxSize:1001024,Accept:'',OnError:errorpw,Multiple:true})" ><i class="mbri-to-local-drive"></i><span>Select Proposed Research</span></button>
          <span style="clear:left;display:block"></span>
       </div>
       <input id="RegLevel" value="6" type="hidden" />

    </div>

   
    
 <button class="bbwa-button tooltip w3-margin-top" tooltip="Finish Registration"><i class="fas fa-check"></i><span>Finish</span></button>
   
     
    
    </form>
    </div>
    </div>