<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>

<div class="menu-bx-cont-title appcolor">{{Name}}</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
       <!-- Application.FormRequest(this,'{{SubmitRID}}') -->
        <form name="createacc_verify" id="createacc_verify" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},2,{})" >
    <div class="w3-col m12">
    
       <div class ="bbwa-groupbox" id="">
         <!-- <h1 class="bbwa-groupbox-title">Payement Details</h1> -->
         
         
          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-user"></i><input name="RegNo_Cand" id="RegNo_Cand" type="email" placeholder="Candidate Email Address" class="bbwa-textbox-input is-email gen-text-shadow" required value="" />
          </div>


    </div>
    
    </div>
    <!-- <input id="__EPAPI_MAPPING__" value="Cand_Email=RegNo" type="hidden" /> -->

          <button class="bbwa-button tooltip"  tooltip="Verify"><i class="fas fa-check"></i><span>Verify</span></button>

       </div>


    </div>
    </form>
    </div>
    </div>