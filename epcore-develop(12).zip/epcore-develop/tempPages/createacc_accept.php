<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},3,{})" >
{{R010:
        <div class="w3-col l6">
      <div class="bbwa-passport bbwa-textbox">
      <!-- <div class="bbw-passport-change appcolor"><i class="fas fa-images fa-fw"></i></div> -->
        <img src="{{Passport}}" />
        <img src="images/bbwa/logo.png" />
      </div>
    </div>
    
    <div class="w3-col l6">
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
      <div class="w3-xlarge appcolor" style="max-width:400px;margin:auto">{{SurName}} {{FirstName}} {{OtherNames}}</div>
      <div class="w3-large" style="max-width:400px;margin:auto">{{FacultyName}}</div>
      <div class="w3-large" style="max-width:400px;margin:auto">{{ProgrammeName}}</div>
      <p class="w3-margin-top" style="max-width:400px;margin:auto">Kindly accept this admission by clicking the button below</p>
      <input type="hidden" name="RegNo_CandV" id="RegNo_CandV" value="{{R010:{{RegNo}}:R010}}" />
      <!-- <div class="w3-medium">Username: <span class="appcolor">{{R010:{{RegNo}}:R010}}</span></div>
      <div class="w3-medium">Access code: <span class="appcolor">hfrhdjjfj</span></div> -->
      <button class="bbwa-button tooltip"  tooltip="I accept this admission"><i class="fas fa-check"></i><span>Yes, i accept this Admission</span></button>
      </div>
      
 
    </div>
     :R010}}
    
    </form>
    </div>
    </div>