<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{SurName}} {{FirstName}} {{OtherNames}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},6,{RegNo:'{{R010:{{RegNo}}:R010}}',UniqueID:'{{UniqueID}}'})" >
        <div class="w3-col m12">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
    <!-- <h1 class="bbwa-groupbox-title">Scanned copies of all your credentials including NYSC Discharge/Exemption/Exclusion Certificate.  <span class="appcolor">*20KB - 100KB*</span></h1> -->
    
    <?php
   $strengths = [
       ["Intellectual ability","Intellect"],
       ["Background Preparation","Background"],
       ["Originality and Initiative","OriginInit"],
       ["Ability to think critically","Critical"],
       ["Industry and Perseverance","Industry"],
       ["Interpersonal Skill","Skill"],
       ["Ability to work independently","WorkInd"],
       ["Ability for teamwork","TeamWork"],
       ["Ability to work under pressure","WorkPressure"],
       ["Ability to communicate in English (oral)","CommEnglishOral"],
       ["Ability to communicate in English (written)","CommEnglishWritten"],
   ];
foreach($strengths as $inds){
?>

    <div class="bbwa-checkbox-group" style="max-width:none">
            <div class="w3-row">
            <div class="w3-col m3"><?php echo $inds[0] ?></div>

              <div class="w3-col m2">
          <div class="bbwa-checkbox">
          <input type="radio" id="<?php echo $inds[1] ?>_Ex_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Excellent</span></div>
         </div>
           </div>

           <div class="w3-col m2">
          <div class="bbwa-checkbox">
          <input type="radio" id="<?php echo $inds[1] ?>_Vg_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Very Good</span></div>
         </div>
           </div>

<div class="w3-col m1">
<div class="bbwa-checkbox">
<input type="radio" id="<?php echo $inds[1] ?>_Gd_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
<div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Good</span></div>
</div>
</div>

<div class="w3-col m1">
<div class="bbwa-checkbox">
<input type="radio" id="<?php echo $inds[1] ?>_Fr_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
<div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Fair</span></div>
</div>
</div>

<div class="w3-col m1">
<div class="bbwa-checkbox">
<input type="radio" id="<?php echo $inds[1] ?>_Pr_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
<div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Poor</span></div>
</div>
</div>

<div class="w3-col m2">
<div class="bbwa-checkbox">
<input type="radio" checked id="<?php echo $inds[1] ?>_Ub_Cand" onchange="" class="checked-only" name="bbwa-checkbox<?php echo $inds[1] ?>" />
<div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><!-- <i class="bbwa-textbox-logo fas fa-male w3-medium" style="vertical-align:middle"></i> --> <span style="vertical-align:middle">Unable to Observe</span></div>
</div>
</div>

          

         
        </div>
       </div>

<?php } ?>
  



     

   
    
 <button class="bbwa-button tooltip w3-margin-top" tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>
   
</div>  
    
    </form>
    </div>
    </div>