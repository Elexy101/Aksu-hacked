<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
       <!-- Application.FormRequest(this,'{{SubmitRID}}') -->
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},3,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'})" >
    <div class="w3-col l6">
    <!-- <div class ="bbwa-groupbox">
         <h1 class="bbwa-groupbox-title">Payment Details</h1>

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div> -->
       <div class ="bbwa-groupbox" id="">
         <!-- <h1 class="bbwa-groupbox-title">Payement Details</h1> -->
         
         {{R010:
          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-user"></i><input name="FullName_Cand" id="FullName_Cand" readonly placeholder="Full Name (Surname first)" class="bbwa-textbox-input gen-text-shadow" required value="{{SurName}} {{FirstName}} {{OtherNames}}" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-user2"></i><input name="FormerName_Cand" id="FormerName_Cand" placeholder="Former Name" class="bbwa-textbox-input gen-text-shadow" value="{{FormerName}}" />
          </div>

          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-calendar"></i><input name="DOB_Cand" required id="DOB_Cand" placeholder="Date of Birth" class="bbwa-textbox-input gen-text-shadow Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px" value="{{DOB}}" readonly />
          </div>

          <div class="bbwa-checkbox-group">
            <div class="w3-row">
              <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="GenderMale_Cand" onchange="" name="bbwa-checkbox" {{GenderMale}} />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-user w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Male</span></div>
         </div>
           </div>

           <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="GenderFemale_Cand" onchange="" name="bbwa-checkbox" {{GenderFemale}} />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-user2 w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Female</span></div>
         </div>
           </div>

         
        </div>
       </div>
          
          <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-university"></i><input name="input-elem" placeholder="Fullname" class="bbwa-textbox-input gen-text-shadow" />
          </div> -->

         

          

    </div>
    
    </div>
     <div class="w3-col l6">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
         
          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-idea"></i><input name="Occupation_Cand" id="Occupation_Cand" placeholder="Occupation" class="bbwa-textbox-input gen-text-shadow" value="{{Occupation}}" />
          </div>

          <div class="bbwa-checkbox-group">
            <div class="w3-row">
              <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="StatusMarried_Cand" onchange="" name="bbwa-checkboxs" {{StatusMarried}} />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-users w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Married</span></div>
         </div>
           </div>

           <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="StatusSingle_Cand" {{StatusSingle}} onchange="" name="bbwa-checkboxs" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-user2 w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Single</span></div>
         </div>
           </div>

         
        </div>
       </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-globe"></i><input  name="CandNationality" id="Nationality_Cand" placeholder="Nationality" class="bbwa-textbox-input gen-text-shadow" value="{{Nationality}}" />
          </div>
          :R010}}
          <div>
          <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-110px">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-map-pin"></i>
  <select name="State_Cand" id="State_Cand" onchange="var selElmnt= _('State_Cand');LoadSelect(_('LGA_Cand'),'R012',{StateID:selElmnt.options[selElmnt.selectedIndex].value},{Value:'LGAID',Text:'LGAName'})">
  <!-- LoadLGA(_('State_Cand')) -->
    <option value="0">Select State of Origin</option>
    {{R011:
    <option {{Selected}} value="{{StateID}}">{{StateName}}</option>
    :R011}}
    
    <!-- <option value="1">Audi</option>
    <option value="2">BMW</option>
    <option value="3">Citroen</option>
    <option value="4">Ford</option>
    <option value="5">Honda</option>
    <option value="6">Jaguar</option>
    <option value="7">Land Rover</option>
    <option value="8">Mercedes</option>
    <option value="9">Mini</option>
    <option value="10">Nissan</option>
    <option value="11">Toyota</option>
    <option value="12">Volvo</option> -->
  </select>
</div></div>

<div class="custom-select bbwa-textbox" data-dropdown-style="margin-top:-110px">
<div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-pin"></i>
  <select name="LGA_Cand" id="LGA_Cand" title="Local Government Area">
  
    <option value="0">Select LGA</option>
    
  </select>
</div>

         <!-- onclick="Application.LoadNextPage({{ApplyID}},3,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'});" -->
<input id="RegNo" value="{{RegNo}}" type="hidden" />
<input id="RegLevel" value="2" type="hidden" />
          <button class="bbwa-button tooltip"  tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>

       </div>


    </div>
    </form>
    </div>
    </div>