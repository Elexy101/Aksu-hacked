<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} - {{R010:{{RegNo}}:R010}}</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.FormRequest(this,'{{SubmitRID}}',4)" >
    <div class="w3-col l6">
    <!-- <div class ="bbwa-groupbox">
         <h1 class="bbwa-groupbox-title">Payment Details</h1>

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div> -->
       <div class ="bbwa-groupbox" id="">
         <!-- <h1 class="bbwa-groupbox-title">Payement Details</h1> -->
         
         <div class="custom-select bbwa-textbox">
         <i class="bbwa-textbox-logo mbri-shopping-bag"></i>
  <select name="PayID" id="PayID">
  {{R006:
    <option value="{{PayID}}">{{PayName}}</option>
    :R006}}
    <!-- <option value="1">Audi</option>
    <option value="2">BMW</option>
    <option value="3">Citroen</option>
    <option value="4">Ford</option>
    <option value="5">Honda</option>
    <option value="6">Jaguar</option>
    <option value="7">Land Rover</option>
    <option value="8">Mercedes</option>
    <option value="9">Mini</option>
    <option value="10">Nissan</option>
    <option value="11">Toyota</option>
    <option value="12">Volvo</option> -->
  </select>
</div>
          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-cash"></i><input name="TotAmt" id="TotAmt" placeholder="Total Amount" class="bbwa-textbox-input gen-text-shadow" value="{{R007:{{FAmount}}:R007}} NGR" readonly />
          </div>

          <div class="bbwa-checkbox-group">
            <div class="w3-row">
              <div class="w3-col s12">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionBank" onchange="" name="bbwa-checkbox" checked />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-shopping-basket w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Bank</span></div>
         </div>
           </div>

           <div class="w3-col s4 w3-hide">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionCash" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-cash w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Cash</span></div>
         </div>
           </div>

           <div class="w3-col s6 w3-hide">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionCard" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-credit-card w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Card</span></div>
         </div>
           </div>
        </div>
       </div>
          
          <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-university"></i><input name="input-elem" placeholder="Fullname" class="bbwa-textbox-input gen-text-shadow" />
          </div> -->

         

          

    </div>
    
    </div>
     <div class="w3-col l6">
     <div class ="bbwa-groupbox">
         <!-- <h1 class="bbwa-groupbox-title">Payment Details</h1> -->

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" id="NotPaid" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide');_('PayeeFullName').focus()}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input id="Paid" type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide');_('PayRef').focus()}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div>

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="notpaid">
         {{R010:
          <div class="bbwa-textbox">
            <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-user"></i><input name="PayeeFullName" id="PayeeFullName" placeholder="Full Name" class="bbwa-textbox-input gen-text-shadow" readonly value="{{SurName}} {{FirstName}} {{OtherNames}}" />
          </div>

         <!--  <div class="bbwa-checkbox-group">
          <div class="bbwa-checkbox">
          <input type="checkbox" id="nn" onchange="" name="bbwa-checkbox" checked />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text">Display on Startup<br/>Yommy</div>
         </div>
       </div> -->

          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-letter"></i><input  name="PayeeEmail" id="PayeeEmail" placeholder="Email Address" class="bbwa-textbox-input gen-text-shadow is-email" readonly value="{{RegNo}}" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-mobile2"></i><input  name="PayeePhone" id="PayeePhone" placeholder="Phone Number" class="bbwa-textbox-input gen-text-shadow is-phone"  readonly value="{{Phone}}" />
          </div>

          :R010}}
         

          <button class="bbwa-button tooltip"  tooltip="Pay Now"><i class="mbri-cart-full"></i><span>Pay Now</span></button>
          <!-- <img src="images/bbwa/logo.png" id="setimg" style="width:200px" /> -->
          <!-- <div id="alcc"></div> -->
  <!-- <a class="w3-btn" onclick="BrowseInto('alcc',{Multiple:true,Accept:'image/*'})">BrowseFile</a> -->
       </div>

       <div class ="bbwa-groupbox w3-hide animate-normal bounceInUpElem" id="alreadypaid">
       <div class="bbwa-textbox">
       <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-setting2"></i><input name="PayRef" id="PayRef" placeholder="Payment Reference" class="bbwa-textbox-input gen-text-shadow" />
          </div>

          <button class="bbwa-button tooltip" tooltip="Verify and Continue Application"><i class="mbri-success"></i><span>Verify and Continue</span></button>
          <input type="text" style="display:none" id="ApplyID" value="{{ApplyID}}" />
          <input type="text" style="display:none" id="SemesterID" value="3" />
          <input type="text" style="display:none" id="PageNum" value="1" />
          <input id="__EPAPI_MAPPING__" value="PayeeEmail=RegNo" type="hidden" />
         
      <input id="FromName_Cretacc" value="noreply" type="hidden" />
      <input id="Subject_Referee" value="School Portal Account" type="hidden" />
      <input id="Mail_Referee" value="../../portals/tempPages/mailstudacc.html" type="hidden" />
    </div>

    </div>
    </form>
    </div>
  </div>