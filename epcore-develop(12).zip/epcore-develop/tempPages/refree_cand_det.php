<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title w3-large">Welcome <span class="appcolor">{{OtherInfo}}</span></div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>{{R010:
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.LoadNextPage({{ApplyID}},3,{RegNo:'{{RegNo}}',UniqueID:{{UniqueID}}})" >

        <div class="w3-col l6">
      <div class="bbwa-passport bbwa-textbox">
      <!-- <div class="bbw-passport-change appcolor"><i class="fas fa-images fa-fw"></i></div> -->
        <img src="{{Passport}}" />
        <img src="images/bbwa/logo.png" />
      </div>
    </div>
    
    <div class="w3-col l6">
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
      <div class="w3-xlarge appcolor">{{SurName}} {{FirstName}} {{OtherNames}}</div>
      <div class="w3-large appcolor">{{RegNo}}</div>
      <div class="w3-large">{{FacultyName}}</div>
      <div class="w3-large">{{ProgrammeName}}</div>
      <div class="w3-row w3-large w3-margin">
        <div class="w3-col s6"><i class="fas fa-fw fa-calendar appcolor"></i> <span>{{DOB}}</span></div>
        <div class="w3-col s6"><i class="fas fa-fw fa-female appcolor"></i> <span>{{Gender}}</span></div>
        <div class="w3-col s6"><i class="fas fa-fw fa-graduation-cap appcolor"></i> <span>{{Degree}}</span></div>
        <div class="w3-col s6"><i class="fas fa-fw fa-history appcolor"></i> <span>{{StudyMode}}</span></div>
        </div>
      <p class="w3-margin-top">Click the Proceed button, if candidate details is valid </p>
      <!-- <div class="w3-medium">Username: <span class="appcolor">{{R010:{{RegNo}}:R010}}</span></div>
      <div class="w3-medium">Access code: <span class="appcolor">hfrhdjjfj</span></div> -->
      </div>
      
 <button class="bbwa-button tooltip"   tooltip="Proceed to Next Page"><i class="fas fa-arrow-right"></i><span>Proceed</span></button>
    </div>
     :R010}}
    
    </form>
    </div>
    </div>