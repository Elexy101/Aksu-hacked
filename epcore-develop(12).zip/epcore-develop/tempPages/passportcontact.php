<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},5,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'})" >
        {{R010:
    <div class="w3-col l6">
      <div class="bbwa-passport bbwa-textbox">
      <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
      <div class="bbw-passport-change appcolor form-file-btn" data-required="Passport_Cand_File" onclick="_BrowseSetFile('Passport_Cand',{MinSize:20480,MaxSize:71680,Accept:'image/*',OnError:errorpw})"><i class="mbri-photo fa-fw"></i> <span>20KB - 70KB</span></div>
        <img src="{{Passport}}" id="Passport_Cand" />
        <img src="images/bbwa/logo.png" id="Passport_Cand_Def" />

      </div>
    </div>
     <div class="w3-col l6">
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-mobile"></i><input name="Phone_Cand" required id="Phone_Cand" placeholder="Candidate Phone Number" class="bbwa-textbox-input gen-text-shadow" value="{{Phone}}" />
          </div>

          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-letter"></i><input  name="Email_Cand" required id="Email_Cand" placeholder="Email Address" class="bbwa-textbox-input gen-text-shadow" value="{{Email}}" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas mbri-map-pin"></i><textarea  name="OtherAddress_Cand" id="OtherAddress_Cand" placeholder="Mailling Address" class="bbwa-textbox-input gen-text-shadow" >{{OtherAddress}}</textarea>
          </div>
          
          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-home"></i><textarea  name="Address_Cand" id="Address_Cand" placeholder="Home Address" class="bbwa-textbox-input gen-text-shadow" >{{Address}}</textarea>
          </div>
          <input id="RegLevel" value="4" type="hidden" />
          <button class="bbwa-button tooltip" tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>

       </div>
       :R010}}

    </div>
    </form>
    </div>
    </div>