<div class="bounceInRight animate-normal">
  <!-- Logo Title -->
<a href="javascript:void(0)" onclick="" class="pitem applybtn w3-medium" >
    <div class="logodesign"></div>
    <div class="detdesign">
       <div class ="bbwa-groupbox" style="padding:0px" id=""><div class="bbwa-textbox  ph-item"></div></div>
    </div>
  </a>

  <!-- Title Details -->
  <div class ="bbwa-groupbox w3-margin-top" style="padding:0px" id="">
       <div class="bbwa-textbox  ph-item"></div>
       <div class="bbwa-textbox  ph-item"></div>
</div>

<!-- Line -->
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;left: 15%;box-shadow: 0px 0px 30px 20px #979797;background:#979797"></div></div>
       <div class="w3-row">
     

    <div class="w3-col m12">
      <!-- Header Box -->
    <div class ="bbwa-groupbox" id=""><div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div></div>
        
    <!-- Big Boxes -->
    <div class="w3-row ph-big-boxes">
    <div class="w3-col m6 l4 s6 indpaybx"><div class="bbwa-iconbox bbwa-iconbox-ph ph-item"  onclick=""></div></div>
    <div class="w3-col m6 l4 s6 indpaybx"><div class="bbwa-iconbox bbwa-iconbox-ph ph-item"  onclick=""></div></div>
    <div class="w3-col m6 l4 s6 indpaybx"><div class="bbwa-iconbox bbwa-iconbox-ph ph-item"  onclick=""></div></div>
    <div class="w3-col m6 l4 s6 indpaybx"><div class="bbwa-iconbox bbwa-iconbox-ph ph-item"  onclick=""></div></div>
</div>

<!-- Text Boxes -->
       <div class ="bbwa-groupbox ph-textbox" id="">
        <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          <div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div>
          </div>

          <!-- Button -->
    <div class ="bbwa-groupbox" id=""><div class="bbwa-textbox-ph  ph-item bbwa-textbox"></div></div>
    
    </div>
   

       </div>


    </div>
    
    </div>
    </div>