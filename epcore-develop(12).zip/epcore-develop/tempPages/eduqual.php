<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row-padding">
        <form name="eduq" id="eduq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},6,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'})" >
    <div class="w3-col l6">
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="gr1">
    <h1 class="bbwa-groupbox-title">Secondary Education</h1>
          <table class="bbwa-spreadheet" border="1" bordercolor="grey" id="SecEdu_Cand">
            <!-- <thead class="">
              <tr> <th>Qualification</th> <th>Date Awarded</th> <th>Awarding Institution</th></tr>
            </thead> -->
            <tbody>
            <tr> <td><input name="aaaa" id="" value="" placeholder="Qualification" required /></td> <td><input id="" data-GroupID="gr1" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" required /></td> <td><input id="" value="" placeholder="Awarding Institution" required /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr1" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr1" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>

            </tbody>

          </table>

          
      </div>
      <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="gr2" >
    <h1 class="bbwa-groupbox-title">Tertiary Education (Polytechnic/College of Education)</h1>
          <table class="bbwa-spreadheet" border="1" bordercolor="grey" id="TerEdu_Cand">
            <!-- <thead class="">
              <tr> <th>Qualification</th> <th>Date Awarded</th> <th>Awarding Institution</th></tr>
            </thead> -->
            <tbody>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr2" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr2" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr2" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            </tbody>
          </table>

          
      </div>

     

       </div>
       <div class="w3-col l6">
       <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="gr3">
    <h1 class="bbwa-groupbox-title">University Education</h1>
          <table class="bbwa-spreadheet" border="1" bordercolor="grey"  id="UniEdu_Cand">
           <!--  <thead class="">
              <tr> <th>Qualification</th> <th>Date Awarded</th> <th>Awarding Institution</th></tr>
            </thead> -->
            <tbody>
            <tr> <td><input id="" value="" placeholder="Qualification"  /></td> <td><input id="" data-GroupID="gr3" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)"  /></td> <td><input id="" value="" placeholder="Awarding Institution"  /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr3" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            <tr> <td><input id="" value="" placeholder="Qualification" /></td> <td><input id="" data-GroupID="gr3" class="Calendar aim-calender-ctr" data-selected-class="appbgcolor"  data-today-class="appcolor" data-body-style="margin-top:-110px;z-index:200;margin-left:-100px" value="" placeholder="Date Awarded (DD/MM/YY)" /></td> <td><input id="" value="" placeholder="Awarding Institution" /></td></tr>
            </tbody>

          </table>

          
      </div>
      <div class ="bbwa-groupbox  animate-normal bounceInUpElem" style="z-index:1" id="">
    <h1 class="bbwa-groupbox-title"><span class="appcolor">REFEREES:</span> At least one should have taught you at tertiary education level.</h1>
          <table class="bbwa-spreadheet" border="1" bordercolor="grey"  id="Referee_Cand">
           <!--  <thead class="appbgcolor">
              <tr> <th>Name</th> <th>Phone</th> <th>Email</th></tr>
            </thead> -->
            <tbody>
            <tr> <td><input id="OtherInfo_Referee" value="" required placeholder="Name" /></td> <td><input id="RefereePhone" value="" placeholder="Phone" class="is-phone" required /></td> <td><input id="UniqueName_Referee" class="is-email" value="" required placeholder="E-mail" /></td></tr>
            <tr> <td><input id="OtherInfo_Referee" value="" required placeholder="Name" /></td> <td><input id="RefereePhone2" value="" placeholder="Phone" class="is-phone" required /></td> <td><input id="UniqueName_Referee" class="is-email" value="" required placeholder="E-mail" /></td></tr>
            <tr> <td><input id="OtherInfo_Referee" value="" required placeholder="Name" /></td> <td><input id="RefereePhone3" value="" placeholder="Phone" class="is-phone" required /></td> <td><input id="UniqueName_Referee" class="is-email" value="" required placeholder="E-mail" /></td></tr>
            </tbody>

          </table>

          
      </div>
      <input id="RegLevel" value="5" type="hidden" />
      <input id="UniqueDetails_Referee" value="{{RegNo}}" type="hidden" />
      {{R010:
      <input id="SurName_Referee" value="{{SurName}}" type="hidden" />
      <input id="FirstName_Referee" value="{{FirstName}}" type="hidden" />
      <input id="OtherNames_Referee" value="{{OtherNames}}" type="hidden" />
      :R010}}
      <input id="SendMailUnique_Referee" value="1" type="hidden" />
      <input id="FromName_Referee" value="noreply" type="hidden" /> 
      <input id="Subject_Referee" value="Online Referee Form" type="hidden" />
      <input id="Mail_Referee" value="../../portals/tempPages/mailhtml.html" type="hidden" />
      <input id="__EPAPI_MAPPING__" value="UniqueName=ToAddress" type="hidden" />
      <!-- <input id="__EPAPI_MAPPING__" value="OtherInfo=FromName" type="hidden" /> -->
       </div>
       <button  class="bbwa-button tooltip"  tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>
    </div>
    
    </form>
    </div>
    </div>