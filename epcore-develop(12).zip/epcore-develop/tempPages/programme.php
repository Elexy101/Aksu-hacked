<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{Name}} ({{R010:{{RegNo}}:R010}})</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="progform" id="payreq" action="javascript:void(0)" onsubmit="Application.SaveLoadNextPage(this,'{{SubmitRID}}',{{ApplyID}},4,{RegNo:'{{RegNo}}',PayRef:'{{PayRef}}',PayID:'{{PayID}}'})" >
    <div class="w3-col l6">
    <!-- <div class ="bbwa-groupbox">
         <h1 class="bbwa-groupbox-title">Payment Details</h1>

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div> -->
    
       <div class ="bbwa-groupbox" id="">
         <!-- <h1 class="bbwa-groupbox-title">Payement Details</h1> -->
         
         
         <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-110px">
         <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-extension"></i>
        <select name="FacID_Cand" id="FacID_Cand" onchange="var selElmnt= _('FacID_Cand');LoadSelect(_('ProgID_Cand'),'R015',{FacID:selElmnt.options[selElmnt.selectedIndex].value},{Value:'ProgID',Text:'ProgName'})">
        
          <option value="0">Select Faculty</option>
          {{R014:
            <option value="{{FacID}}">{{FacName}}</option>
          :R014}}
         
          <!-- <option {{Selected}} value="{{StateID}}">{{StateName}}</option> -->
          
          
        </select>
      </div>

      <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-110px">
      <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-add-submenu"></i>
        <select name="ProgID_Cand" id="ProgID_Cand" title="Department">
        
          <option value="0">Select Department</option>
         
          <!-- <option {{Selected}} value="{{StateID}}">{{StateName}}</option> -->
          
          
        </select>
      </div>

      <div class="custom-select bbwa-textbox"  data-style="" data-dropdown-style="margin-top:-110px">
      <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
         <i class="bbwa-textbox-logo mbri-add-submenu"></i>
        <select name="Degree_Cand" id="Degree_Cand" title="Degree">
        
          <option value="0">Select Degree</option>
           {{R020:
            <option value="{{DegID}}">{{DegName}}</option>
           :R020}}
          <!-- <option {{Selected}} value="{{StateID}}">{{StateName}}</option> -->
          
          
        </select>
      </div>

{{R010:
      <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-globe"></i><input  name="Degree_Cand" id="Degree_Cand" placeholder="Diploma/Degree" class="bbwa-textbox-input gen-text-shadow" value="{{Degree}}" />
          </div> -->

    </div>
    
    </div>
     <div class="w3-col l6">
     

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
         
          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-idea"></i><input name="AreaofSpecial_Cand" id="AreaofSpecial_Cand" placeholder="Area of Specialization" class="bbwa-textbox-input gen-text-shadow" value="{{AreaofSpecial}}" />
          </div>

          <div class="bbwa-checkbox-group">
            <div class="w3-row">
              <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="StudyModeFullTime_Cand" onchange="" name="bbwa-checkboxs" {{StudyModeFullTime}} />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-clock w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Full Time</span></div>
         </div>
           </div>

           <div class="w3-col s6">
          <div class="bbwa-checkbox">
          <input type="radio" id="StudyModePartTime_Cand" {{StudyModePartTime}} onchange="" name="bbwa-checkboxs" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-timer w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Part Time</span></div>
         </div> 
           </div>

         
        </div>
       </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-globe-2"></i><textarea  name="ResearchTopic_Cand" id="ResearchTopic_Cand" placeholder="Research Topic (for Phd applicants only)" class="bbwa-textbox-input gen-text-shadow" >{{ResearchTopic}}</textarea>
          </div>
          :R010}}
          <input id="RegNo" value="{{RegNo}}" type="hidden" />
          <input id="RegLevel" value="3" type="hidden" />
          <button class="bbwa-button tooltip"   tooltip="Save and Continue"><i class="fas fa-save"></i><span>Save and Continue</span></button>

       </div>


    </div>
    </form>
    </div>
    </div>