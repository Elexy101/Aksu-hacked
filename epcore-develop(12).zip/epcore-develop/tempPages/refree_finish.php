<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title w3-large">Thanks <span class="appcolor">{{OtherInfo}}</span></div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>{{R010:
       <div class="w3-row">
        <form name="payreq" id="payreq" action="javascript:void(0)"  >

        <div class="w3-col l6">
      <div class="bbwa-passport w3-center w3-padding-large bbwa-textbox">
      <!-- <div class="bbw-passport-change appcolor"><i class="fas fa-images fa-fw"></i></div> -->
        <i class="fas fa-thumbs-up w3-jumbo appcolor"></i>
      </div>
    </div>
    
    <div class="w3-col l6">
    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="">
      <div class="w3-xlarge appcolor">{{SurName}} {{FirstName}} {{OtherNames}}</div>
      <div class="w3-large appcolor">{{RegNo}}</div>
      <div class="w3-large">{{FacultyName}}</div>
      <div class="w3-large">{{ProgrammeName}}</div>
      
      <p class="w3-margin-top w3-medium">Referee Report Completed.</p>
      <!-- <div class="w3-medium">Username: <span class="appcolor">{{R010:{{RegNo}}:R010}}</span></div>
      <div class="w3-medium">Access code: <span class="appcolor">hfrhdjjfj</span></div> -->
      </div>
      
 <!-- <button class="bbwa-button tooltip"   tooltip="Print Candidate Referee Report"><i class="fas fa-print"></i><span>Print Referee Report</span></button> -->
    </div>
     :R010}}
    
    </form>
    </div>
    </div>