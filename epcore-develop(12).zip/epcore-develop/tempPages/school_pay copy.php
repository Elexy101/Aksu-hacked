<div class="bounceInRight animate-normal">
<a href="javascript:void(0)" onclick="Application.LoadPage(null,{{ApplyID}},{{ApplyGroupID}})" class="pitem applybtn w3-medium" >
  <span class="mbri-home pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{ApplyColor}} w3-display-container w3-example"><span class="w3-display-middle {{ApplyLogo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo w3-large">{{ApplyName}}</div><div class="otherinfo appcolor"></div>
    </div>
  </a>
<div class="menu-bx-cont-title appcolor">{{R002:{{SurName}} {{FirstName}} {{OtherNames}} ({{RegNo}}) :R002}}</div>
       <div class="menu-bx-cont-descr">{{Descr}}</div>
       <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;margin-bottom:10px"><div class="tcolline-line-inner-h" style="width: 70%;
left: 15%;"></div></div>
       <div class="w3-row">
        <form name="payreqd" id="payreqd" action="javascript:void(0)" onsubmit="" >
    <div class="w3-col l12">
    <div class ="bbwa-groupbox" id="">
      <!-- <h1 class="w3-center w3-xlarge appbgcolor w3-padding">{{R026:{{SesName}}:R026}} {{R027:{{Descr}}:R027}}</h1> -->
      <div class="w3-center bbwa-textbox  w3-large ">{{R026:{{SesName}}:R026}} Session | {{R027:{{Descr}}:R027}}</div>
     </div>
     <input type="hidden" name="RegNo" id="RegNo" value="{{R002:{{RegNo}}:R002}}" />
       <input type="hidden" name="NotPaid" id="NotPaid" value="1" />
       <input type="hidden" name="LevelID" id="LevelID" value="{{R027:{{Level}}:R027}}" />
            <input type="hidden" name="SemesterID" id="SemesterID" value="3" />
            <input type="hidden" name="PayID" id="PayID" value="0" />
       <!-- <div class ="bbwa-groupbox" id="">
       
       <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-flag"></i><input name="PaySes" id="PaySes" placeholder="Current Session" class="bbwa-textbox-input gen-text-shadow" value="{{R026:{{SesName}}:R026}}" readonly />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-add-submenu"></i><input name="StudLvl" id="StudLvl" placeholder="Current Level" class="bbwa-textbox-input gen-text-shadow" value="{{R027:{{Descr}}:R027}}" readonly />
            
          </div>
        
         
         <div class="custom-select bbwa-textbox">
         <i class="bbwa-textbox-logo mbri-shopping-bag"></i>
  <select name="PayID" id="PayID">
  {{R006:
    <option value="{{PayID}}">{{PayName}}</option>
    :R006}}
   
  </select>
</div>
          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-cash"></i><input name="TotAmt" id="TotAmt" placeholder="Total Amount" class="bbwa-textbox-input gen-text-shadow" value="{{R007:{{FAmount}}:R007}} NGR" readonly />
          </div>
  </div> -->

          <div class="w3-row paycont">
            {{R031:<div class="w3-col m6 l4 s6 indpaybx">
            <div class="bbwa-iconbox" onclick="_('PayID').value = '{{ID}}'; Application.FormRequest(_('payreqd'),'{{SubmitRID}}',4) " title="Pay {{ItemName}}">
             <div class="main-icon gen-text-shadow"><i class="fas {{Status}} fa-check-circle w3-text-green"></i><i class="fas {{Status}} fa-exclamation-triangle w3-text-red"></i></div>
             <div class="main-content">
               <div class=" w3-border-bottoms w3-border-dark-grey gen-nowrap gen-overflow-hidden">{{ItemName}}</div>
               <div class=" {{Status}} gen-text-shadow bar w3-card" style="border-radius:0px 0px 4px 4px; padding:8px 3px;overflow:hidden"><span class="w3-tiny">NGR</span>&nbsp;<span class="">{{FAmount}}</span>&nbsp;<span class="w3-tiny">FULL</span></div>
               
             </div>   
           </div>
            </div>:R031}}

            <!-- <div class="w3-col m6 l4 s6">
            <div class="bbwa-iconbox">
             <div class="main-icon gen-text-shadow"><i class="fas fa-exclamation-triangle w3-text-deep-orange"></i></div>
             <div class="main-content">
               <div class=" w3-border-bottoms w3-border-grey gen-nowrap gen-overflow-hidden">AKSU PG HOSTEL</div>
               <div class=" w3-deep-orange gen-text-shadow  w3-padding bar w3-card" style="border-radius:0px 0px 4px 4px"><span class="w3-tiny">NGR</span>&nbsp;<span class="">10,000</span>&nbsp;<span class="w3-tiny">FULL</span></div>
                </div>
           </div>
            </div>

            <div class="w3-col m6 l4 s6">
            <div class="bbwa-iconbox">
             <div class="main-icon gen-text-shadow"><i class="fas fa-exclamation-triangle w3-text-red"></i></div>
             <div class="main-content">
               <div class=" w3-border-bottoms w3-border-grey gen-nowrap gen-overflow-hidden">AKSU PG DEVELOPMENT FEE</div>
               <div class=" w3-red gen-text-shadow  w3-padding bar w3-card" style="border-radius:0px 0px 4px 4px"><span class="w3-tiny">NGR</span>&nbsp;<span class="">10,000</span>&nbsp;<span class="w3-tiny">FULL</span></div>
                </div>
           </div>
            </div> -->

          </div>

          <!-- <button class="bbwa-button tooltip"  tooltip="Pay Now"><i class="mbri-cart-full"></i><span>Pay Now</span></button> -->

          <!-- <div class="bbwa-checkbox-group">
            <div class="w3-row">
              <div class="w3-col s12">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionBank" onchange="" name="bbwa-checkbox" checked />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-shopping-basket w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Bank</span></div>
         </div>
           </div>

           <div class="w3-col s4 w3-hide">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionCash" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-cash w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Cash</span></div>
         </div>
           </div>

           <div class="w3-col s6 w3-hide">
          <div class="bbwa-checkbox">
          <input type="radio" id="PayOptionCard" onchange="" name="bbwa-checkbox" />
           <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text w3-center"><i class="bbwa-textbox-logo mbri-credit-card w3-medium" style="vertical-align:middle"></i> <span style="vertical-align:middle">Card</span></div>
         </div>
           </div>
        </div>
       </div> -->
          
          <!-- <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo fas fa-university"></i><input name="input-elem" placeholder="Fullname" class="bbwa-textbox-input gen-text-shadow" />
          </div> -->

         

          

   
    
    </div>
     <!-- <div class="w3-col l6">
     <div class ="bbwa-groupbox">

         <div class="bbwa-textbox w3-row bbwa-linkbox">
             <div class="w3-center w3-col s6"><input type="radio" id="NotPaid" checked onchange="if(this.checked){_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide');_('PayeeFullName').focus()}else{_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Not Yet Paid</a></div>
             <div class="w3-center w3-col s6"><input id="Paid" type="radio" onchange="if(this.checked){_('notpaid').classList.add('w3-hide');_('alreadypaid').classList.remove('w3-hide');_('PayRef').focus()}else{_('alreadypaid').classList.add('w3-hide');_('notpaid').classList.remove('w3-hide')}" name="payy" /><a href="#">Already Paid</a></div>
        </div>

    </div>

    <div class ="bbwa-groupbox  animate-normal bounceInUpElem" id="notpaid">
         {{R002:
          <div class="bbwa-textbox">
            <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-user"></i><input name="PayeeFullName" id="PayeeFullName" placeholder="Full Name" class="bbwa-textbox-input gen-text-shadow" readonly value="{{SurName}} {{FirstName}} {{OtherNames}}" />
          </div>

         

          <div class="bbwa-textbox">
          <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-letter"></i><input  name="PayeeEmail" id="PayeeEmail" placeholder="Email Address" class="bbwa-textbox-input gen-text-shadow is-email" readonly value="{{RegNo}}" />
          </div>

          <div class="bbwa-textbox">
            <i class="bbwa-textbox-logo mbri-mobile2"></i><input  name="PayeePhone" id="PayeePhone" placeholder="Phone Number" class="bbwa-textbox-input gen-text-shadow is-phone"  readonly value="{{Phone}}" />
          </div>

          :R002}}
         

          <button class="bbwa-button tooltip"  tooltip="Pay Now"><i class="mbri-cart-full"></i><span>Pay Now</span></button>
          <!- <img src="images/bbwa/logo.png" id="setimg" style="width:200px" /> ->
          <!- <div id="alcc"></div>
  <!- <a class="w3-btn" onclick="BrowseInto('alcc',{Multiple:true,Accept:'image/*'})">BrowseFile</a> ->
       </div>

       <div class ="bbwa-groupbox w3-hide animate-normal bounceInUpElem" id="alreadypaid">
       <div class="bbwa-textbox">
       <div class="required appcolor tooltip" tooltip="Required"><i class="fas fa-star"></i></div>
            <i class="bbwa-textbox-logo mbri-setting2"></i><input name="PayRef" id="PayRef" placeholder="Payment Reference" class="bbwa-textbox-input gen-text-shadow" />
          </div>

          <button class="bbwa-button tooltip" tooltip="Verify and Continue Application"><i class="mbri-success"></i><span>Verify and Continue</span></button>
          <input type="text" style="display:none" id="ApplyID" value="{{ApplyID}}" />
          <input type="text" style="display:none" id="SemesterID" value="3" />
          <input type="text" style="display:none" id="PageNum" value="1" />
          <input id="__EPAPI_MAPPING__" value="PayeeEmail=RegNo" type="hidden" />
         
      <input id="FromName_Cretacc" value="noreply" type="hidden" />
      <input id="Subject_Referee" value="School Portal Account" type="hidden" />
      <input id="Mail_Referee" value="../../portals/tempPages/mailstudacc.html" type="hidden" />
    </div>

    </div> -->
    </form>
    </div>
  </div>