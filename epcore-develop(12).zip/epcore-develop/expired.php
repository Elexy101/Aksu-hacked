<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Expired</title>
    <style>
.MainBx{
    width: 100%; height: 100vh; display: flex; align-items: center; justify-content: center; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}.ContBx{
    width: 100%; max-width: 400px; height: auto; box-sizing: border-box; padding: 30px; text-align: center;
}.ContBx img{
  max-width: 300px;
}.ContBx h1{
  font-size: 1.6em;
}.footernote{ padding: 7px;
}
    </style>
</head>
<body>
    <div class="MainBx">
    <div class="ContBx">
        <img src="images/General/try.png" alt="Logo" />
        <h1>Portal Expired</h1>
        <p>Kindly report this message to the admin</p>
        <div class="footernote">
        <a href="http://wogis.sch.ng">Go to Website</a>
    </div>
    </div>
    
    </div>
</body>
</html>