<?php
session_start();
$err = '{"Code":{{Error_Code}},"Message":"{{Error_Message}}"}';
//confirm if parameter sent
 /* if(!isset($_POST['ApplyGID']) && !isset($_POST['Scope'])){
    exit(str_replace(array('{{Error_Code}}','{{Error_Message}}'),array('10','Invalid Application'),$err));
} */ 
include "../epapi/api.php";
$LRegNo = isset($_POST['LoginName'])?$_POST['LoginName']:'';
if($LRegNo == "")exit("#");
$_SESSION = $_POST;
$_SESSION['LRegNo'] = $LRegNo;
$_SESSION['LoginName'] = $LRegNo;

//get the config file
$config = json_decode(urldecode($_POST['Config']),true);
$cmk = $config["ControlMarkup"];
//exit(str_replace(array('{{Error_Code}}','{{Error_Message}}'),array('--2',$config["ControlMarkup"]),$err));
if(substr(trim($cmk),0,strlen('epcore/')) == 'epcore/'){
  $config["ControlMarkup"] = "../".substr(trim($cmk),strlen('epcore/') - 1);
}else{
  $cmkarr = explode('/epcore/',$cmk);
if(count($cmkarr) == 2){
  $config["ControlMarkup"] = "../".$cmkarr[1];
}
}
//$_POST['LoginName'] = $LRegNo;
$epapi = new epapi($config);
$epapi->OnErrorWriteStart();
echo $err;
$epapi->OnErrorWriteExit();
$_POST['Scope'] = "MAIN";
$_POST['nopreamt'] = 1;//
$_POST['walletportalmenus'] = 1;//walletportalmenus
//request Form
$pageform = $epapi->Request(["RequestID"=>"R001,R004,R002,R039,R057,R040,R065,R066","Param"=>json_encode($_POST)]);
$epapi->OnErrorWriteStart();
echo $err;
$epapi->OnErrorWriteExit();
//$markup = $pageform['PageMarkup'];
$epapi->WriteStart();
?>
<!-- <div style="width:100%;height:100vh;position:fixed;z-index:200" class="w3-display-container">
  <div class="w3-display-middle w3-card w3-round w3-padding-large" style="background-color:#222; color:#fff; width:calc(100% - 30px); max-width:400px;" >
   <h1 class="appcolor">Hello!!!</h1>
   <p>We are currently upgrading the Student Desk<br/> try again later.</p>
   <button class="bbwa-button tooltip" onclick="window.location='?logout'"  tooltip="Logout"><i class="mbri-sign-out"></i><span>Logout</span></button>
</div>
</div> -->
<div id="main-page" style="" class="fadeIn open">
  <div id="mobilenav">
    <button type="button" onclick="_('sidebox1').classList.toggle('open')" ><div class="bar appbgcolor maimmenuctr"></div><i class="mbri-menu maimmenuctr"></i></button>
    <button type="button" onclick="document.body.classList.remove('detailsview')" class="menus" ><div class="bar appbgcolor"></div><i class="mbri-features"></i><span></span></button>
    <button type="button" onclick="document.body.classList.add('detailsview')" class="stat" ><div class="bar appbgcolor"></div><i class="mbri-browse"></i><span></span></button>
    <button type="button" class="new-" onclick="{{R066:{{notify:Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}'):notify}}:R066}}" ><div class="bar appbgcolor"></div><i class="mbri-alert"></i><span></span></button>
  </div>
  <div id="sidebox1" class="fadeInLeft  animate-fast animate-delay-low animate-fill-both">
    <div class="innercont" id="menusidebar" >
         <div class="topitems">
             <button class="maimmenuctr" onclick="this.parentElement.parentElement.parentElement.classList.toggle('open')" title="START"><div class="logo w3-display-container maimmenuctr"><span class="w3-display-middle mbri-menu maimmenuctr"></span></div><div class="title maimmenuctr">START</div></button>
         </div>
         <div class="bottomitems">
         <button class="moduledis w3-hide-large w3-hide-medium" onclick="/*this.parentElement.parentElement.parentElement.classList.remove('open');*/document.body.classList.remove('detailsview')" title="Modules & Programs"><div class="logo w3-display-container"><span class="w3-display-middle mbri-features"></span></div><div class="title">Modules & Programs</div></button>
         <button class="deskdis w3-hide-large w3-hide-medium" onclick="/*this.parentElement.parentElement.parentElement.classList.remove('open');*/document.body.classList.add('detailsview')" title="My Desk"><div class="logo w3-display-container"><span class="w3-display-middle mbri-sites"></span></div><div class="title">My Desk</div></button>
         <button class="" onclick="/*this.parentElement.parentElement.parentElement.classList.remove('open')*/" title="Settings"><div class="logo w3-display-container"><span class="w3-display-middle mbri-setting"></span></div><div class="title">Settings</div></button>
         <button class="w3-hide-small w3-hide-medium" onclick="_ToggleFullMode();/*this.parentElement.parentElement.parentElement.classList.remove('open')*/" title="Fullscreen"><div class="logo w3-display-container"><span class="w3-display-middle mbri-browse"></span></div><div class="title">Fullscreen</div></button>
         <button class="" onclick="/*this.parentElement.parentElement.parentElement.classList.remove('open')*/;Login.Logout()" title="Logout"><div class="logo w3-display-container"><span class="w3-display-middle fas fa-power-off"></span></div><div  class="title">Logout</div></button>
         </div>
    </div>
</div>

<!-- Box 2 -->
<div id="sidebox2" class="fadeInLeft animate-fast forwards">
   <!-- Program Filter -->
   <!-- <div class ="searchcont" id="">
   <div class="bbwa-textbox bbwa-transbox">
            <i class="bbwa-textbox-logo mbri-search"></i><input name="FormerName_Cand" id="FormerName_Cand" placeholder="Search Module or Programs" class="bbwa-textbox-input gen-text-shadow" value="" />
          </div>
    </div> -->
    <div class="header">
    <div class="content">
    {{R001:
      <div><img class="schlogo" src="{{Logo}}" alt="LOGO" /></div>
      <div class="abbr" title="{{Name}}">{{Abbreviation}}</div>
      <div class="appbgcolor smallcard card-1-1" style="font-size:0.8em">Student Desk</div>
      :R001}}
    </div>
    <div class="mainstruc">
  <button class="strucbtn struclist" type="button"><i class="fas fa-list-ul"></i></button>
  <button class="strucbtn strucgrid w3-hide-medium" type="button"><i class="fas fa-th-large"></i></button>
  <button class="strucbtn strucgrid2 w3-hide-small" type="button"><i class="fas fa-th"></i></button>
</div>
  </div>

    
    <!-- Program Filter End-->
    <!-- Program Box-->
<div class="programbx custom-scroll">
<?php
  /*  $cand = "";
   $others = "";
   while($indmenu = $pmenus[0]->fetch_assoc()){
      $lock = $indmenu['Enable'] == "TRUE"?"w3-hide":"";
if($indmenu['Scope'] == "CANDIDATE"){
   $cand .= '<a href="javascript:void(0)" onclick="" class="pitem">
   <span class="mbri-lock pitemind w3-display-right appcolor '.$lock.'"></span>
     <div class="logodesign">
        <div class="logoinner w3-indigo w3-display-container w3-example"><span class="w3-display-middle fas fa fa-'.$indmenu['Logo'].'"></span></div>
     </div>
     <div class="detdesign">
        <div class="maininfo">'.$indmenu['DisplayName'].'</div><div class="otherinfo appcolor"></div>
     </div>
   </a>';
}else{
   $others .= '<a href="javascript:void(0)"  id="menu_'.$indmenu['ID'].'" onclick="Admin.LoadTemp('.$indmenu['ID'].',\'1\',\''.$indmenu['Enable'].'\',this,\'\')" class="pitem">
   <span class="mbri-lock pitemind w3-display-right appcolor '.$lock.'" id="menulock_menu_'.$indmenu['ID'].'"></span>
     <div class="logodesign">
        <div class="logoinner w3-red w3-display-container w3-example"><span class="w3-display-middle fas fa fa-'.$indmenu['Logo'].'"></span></div>
     </div>
     <div class="detdesign">
        <div class="maininfo">'.$indmenu['DisplayName'].'</div><div class="otherinfo appcolor"></div>
     </div>
   </a>';
} 
  
  
   //get all sub menu

   }
   echo '<div class="pgroup">Entrance</div>';
   echo $cand;
   echo '<div class="pgroup">Student</div>';
   echo $others;*/
?>

{{R004:
   {{AppGroup:
  <a href="javascript:void(0)" onclick="Application.Load({ApplyGID:'{{ID}}',AutoLoad:true,Home:false,Logout:true,Login:false,OpenFrom:'open-from-menu',Logo:'{{Logo}}'})" class="pitem {{Color}} zoomInShort animated faster" style="grid-area: pitemm{{$}}; animation-delay:{{$}}00ms">
  <span class="mbri-lock {{Status}} pitemind w3-display-right appcolor"></span>
    <div class="logodesign">
       <div class="logoinner {{Color}} w3-display-container w3-example"><span class="w3-display-middle {{Logo}}"></span></div>
    </div>
    <div class="detdesign">
       <div class="maininfo">{{Name}}</div>
       <div class="otherinfo">
       {{Applications:
         <span>{{AppName}}</span>
      :Applications}}</div>
    </div>
  </a>
  :AppGroup}}
  :R004}}

  


</div>
<!-- Program Box End-->
</div>
<!-- Box 2 End -->

<!-- Box 21 -->
<!-- <div id="sidebox21"  class="w3-hide-large w3-hide-medium">
  <div class="sideindbx w3-display-container" onclick="Application.CloseAll()">
    <img class="w3-display-middle w3-circle w3-card" src="../epconfig/UserImages/Student/AK11_SMS_BMT_005.jpeg" />
  </div>
  <div class="demacator">&nbsp;</div>
  <div id="openpgs">
  
</div>
</div> -->
<!-- Box 21 End-->

<!-- Box 3 -->
<div id="sidebox3" class=" fadeInRight animate-fast forwards">
 <!-- Top Header -->
  <div class="header">
    <div class="content">
    {{R001:
      <div><img class="schlogo" src="{{Logo}}" alt="LOGO" /></div>
      <div class="abbr" title="{{Name}}">{{Abbreviation}}</div>
      <div class="appbgcolor smallcard card-1-1" style="font-size:0.8em">Student Desk</div>
      :R001}}
    </div>
  </div>
 <!-- Top Header End-->
 <!-- Body -->
<div class="body w3-row-padding custom-scroll">
{{R002:
  <!-- Student details Side -->
  <div class="w3-col l4 studdet detinnerbx" style="min-height:100%">
    <div class="studpassport w3-example" style="background-image: url({{Image}});">
    <button onclick="_Printer.Load({{PrintRecord}})" class="printBtn">
    <span class="mbri-print"></span> <span style="margin-left: 8px;"> Print Biodata</span>
    </button>
      <div class="w3-display-bottomleft w3-padding gen-text-shadow studname">
         
        <div class="studnamereal">{{SurName}} {{FirstName}} {{OtherNames}}</div>
        <div class="appbgcolorfade studregno">{{RegNo}}</div>
        <div class="">{{Email}} - {{Phone}}</div>
        
      </div>
    </div>

    <div class="w3-row deskbox-cont w3-example topmerge">
        <div class="deskbox appbggradient w3-col s12">
            <div class="">
               <div class="itemlogo"><span class="mbri-database"></span></div>
               <div class="itemcontent bigger"> {{FacName}}</div>
            </div>
            <div class="">
               <div class="itemlogo"><span class="mbri-edit"></span></div>
               <div class="itemcontent bigger">{{ProgName}} ({{DegreeName}})</div>
            </div>
            <div class="">
               <div class="itemlogo"><span class="mbri-setting2"></span></div>
               <div class="itemcontent bigger">{{R039:{{LevelName}}:R039}}</div>
            </div>
            <div class="">
               <div class="itemlogo"><span class="mbri-edit"></span></div>
               <div class="itemcontent bigger">{{R039:{{SemesterName}}:R039}}</div>
            </div>
        </div>
    </div>
:R002}}
    <!-- <div class="w3-row deskbox-cont w3-example">
    {{R039:
    <div class="deskbox appbggradient w3-col s5 twobx">
    <div class="">
        <div class="itemlogo"><span class="mbri-setting2"></span></div>
       <div class="txtonly itemcontent">
         <div class="w3-xlarge">{{LevelName}}</div>
        <div class="deskbox-seperator">Level</div>
      </div>
</div>
    </div>
    <div class="deskbox appbggradient w3-col s5 twobx w3-right">
    <div class="">
        <div class="itemlogo"><span class="mbri-edit"></span></div>
       <div class="txtonly itemcontent">
         <div class="w3-xlarge">{{SemesterName}}</div>
        <div class="deskbox-seperator">Semester</div>
      </div>
</div>
    </div>
    :R039}}
    </div> -->

<div class="studstat">
 <div class="header">
  <div class="logo w3-xlarge"><span class="mbri-bulleted-list"></span></div><div class="title">Statistics</div>
</div>

{{R057:
<div class="statbody">

<div class="indbx w3-example">
<div class="logo w3-xlarge"><span class="mbri-cash"></span></div><div class="title">Payment</div><div class="state {{Payment}}"><i class="fa fas fa-check-circle w3-text-green on"></i><i class="fa fas fa-times-circle w3-text-red off"></i></div>
</div>

<div class="indbx w3-example">
<div class="logo w3-xlarge"><span class="mbri-edit"></span></div><div class="title">Course Registration</div><div class="state {{Course}}"><i class="fa fas fa-check-circle w3-text-green on"></i><i class="fa fas fa-times-circle w3-text-red off"></i></div>
</div>

<div class="indbx w3-example">
<div class="logo w3-xlarge"><span class="mbri-sites"></span></div><div class="title">Result</div><div class="state {{Result}}">
<i class="fa fas fa-check-circle w3-text-green on"></i><i class="fa fas fa-times-circle w3-text-red off"></i></div>
</div>
:R057}}
</div>

</div>

</div>
  <!-- Student details Side End-->
  <!-- Student details Side -->
  <div class="w3-col l8 detinnerbx" style="min-height:100%">

  <div class="line-cont">
  <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;"><div class="tcolline-line-inner-h" style="width: 70%;
left: 10%;"></div></div>
<div class="w3-display-right line-logo" style="top:0%"><span class="mbri-timer"></span></div>
</div>

{{R065:
<div class="deskboard">
  {{R066:

    {{notify:
  <div class="circlebx" onclick="Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}')">
     <div class="procircle w3-display-container" style="">
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:;"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: 130,150; stroke:;"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">--</div>
        <i class="mbri-letter w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
        
     </div>
     <div class="protxt">Notification</div>
   </div>
   :notify}}
    {{pay:
   <div class="circlebx" onclick="Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}')">
     <div class="procircle w3-display-container" >
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:{{PayProgressColor}};"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: {{PayProgress}},150; stroke:{{PayProgressColor}};"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">{{PayDisTxt}}</div>
        <i class="mbri-cash w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
     </div>
     <div class="protxt">Payment</div>
   </div>
   :pay}}

   {{course:
   <div class="circlebx" onclick="Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}')">
     <div class="procircle w3-display-container"  style="">
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:{{CProgressColor}};"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: {{CProgress}},150; stroke:{{CProgressColor}};transition: stroke-dasharray 1s 0.4s ease-in-out;"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">{{CDisTxt}}</div>
        <i class="mbri-contact-form w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
     </div>
     <div class="protxt">Courses</div>
   </div>
   :course}}

   <div class="circlebx">
     <div class="procircle w3-display-container" >
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:#f44336aa;"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: 5,150; stroke:#f44336aa;"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">0/0</div>
        <i class="mbri-edit w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
     </div>
     <div class="protxt">Assignment</div>
   </div>

   <div class="circlebx">
     <div class="procircle w3-display-container"  style="">
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:#f44336aa;"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: 5,150; stroke:#f44336aa;"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">0/0</div>
        <i class="mbri-image-slider w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
     </div>
     <div class="protxt">Lectures</div>
   </div>

  
    {{result:
   <div class="circlebx"  onclick="Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}')" >
     <div class="procircle w3-display-container" >
     <div class="progress">
       <!-- stroke:#f44336aa; -->
                <svg class="spinner-container w3-display-middle tray" viewBox="0 0 44 44"><circle class="path" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke:{{RProgressColor}};"></circle></svg>
                <svg class="spinner-container w3-display-middle" viewBox="0 0 44 44"><circle class="path cen-stroke-color-fade" cx="22" cy="22" r="20" fill="none" stroke-width="4" style="stroke-dasharray: {{RProgress}},150; stroke:{{RProgressColor}};"></circle></svg>
                <div class="progress-text w3-display-middle">
                <div class="w3-display-middle w3-large">{{RDisTxt}}</div>
        <i class="mbri-sale w3-display-middle w3-xlarge"></i> 
                </div>
            </div>
     </div>
     <div class="protxt">Result</div>
     
   </div>
   :result}}
   :R066}}
   <div style="clear:both"></div>

</div>
:R065}}

<div class="line-cont">
  <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;"><div class="tcolline-line-inner-h" style="width: 70%;
left: 10%;"></div></div>
<div class="w3-display-right line-logo" style="top:0%"><span class="mbri-cash"></span></div>
</div>

<div class="deskboard wallet">
   <!-- <div>Wallet Balance: <span></span></div> -->
   {{R040:
<div class="logobx w3-text-grey scaleover">
<div class="logoicon">
     <span class=" w3-xxxlarge mbri-cash"></span>
     <!-- <span class=""> Wallet Balance</span> -->
     </div>
    
<div class="logotxt2 appcolor"><sup>₦</sup> <span class='w3-xlarge'>{{Balance}}</span></div>

     <div class="logoicon w3-center">
     <!-- <span class=""> Wallet Balance</span> Application.Load({ApplyGID:'{{GroupID}}',AutoLoad:true,Home:false,Logout:true,Login:false,OpenFrom:'open-from-menu',Logo:'mbri-briefcase'}) -->
     </div>
     
   </div>
{{WalletMenus:
   <a class="linkbx logobx w3-button card-1" href="javascript:void(0)" onclick="Application.LoadPage(null,{{ID}},{{GroupID}},null,{{GroupID}},'{{Placeholder}}','{{GroupLogo}}')" title="{{Descr}}">
     <div class="logoimg">
     <span class=" w3-xxlarge {{Logo}}"></span>
     </div>
     <div class="logotxt">{{Name}}</div>
</a>
:WalletMenus}}
:R040}}
<!-- <a class="linkbx logobx w3-button" href="#">
     <div class="logoimg">
     <span class=" w3-xxlarge mbri-shopping-bag"></span>
     </div>
     <div class="logotxt">Withdraw</div>
</a>

<a class="linkbx logobx w3-button" href="#">
     <div class="logoimg">
     <span class=" w3-xxlarge mbri-share"></span>
     </div>
     <div class="logotxt">Transfer</div>
</a>

<a class="linkbx logobx w3-button" href="#">
     <div class="logoimg">
     <span class=" w3-xxlarge mbri-clock"></span>
     </div>
     <div class="logotxt">History</div>
</a> -->
<div style="clear:both"></div>
  

</div>

<div class="line-cont">
  <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;"><div class="tcolline-line-inner-h" style="width: 70%;
left: 10%;"></div></div>
<div class="w3-display-right line-logo" style="top:0%"><span class="mbri-file"></span></div>
</div>

<div class="deskboard">
<div class="logobx scaleover">
     <!-- <div class="logoimg">
        <img src="../epconfig/UserImages/App/backup.png" />
     </div> -->
     <div class="logoicon">
     <span class=" w3-xxxlarge mbri-opened-folder"></span>
     </div>
     <div class="logotxt">30MB free of 30MB</div>
   </div>

   <div class="logobx">
   <div class="logoicon">
     <span class=" w3-xxxlarge mbri-photos"></span>
     </div>
     <div class="logotxt">0 Images</div>
   </div>

   <div class="logobx">
   <div class="logoicon">
     <span class=" w3-xxxlarge mbri-video-play"></span>
     </div>
     <div class="logotxt">0 Videos</div>
   </div>

   <div class="logobx">
   <div class="logoicon">
     <span class=" w3-xxxlarge mbri-file"></span>
     </div>
     <div class="logotxt">0 Docs</div>
   </div>
   <div style="clear:both"></div>

</div>

<div class="line-cont">
  <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;"><div class="tcolline-line-inner-h" style="width: 70%;
left: 10%;"></div></div>
<div class="w3-display-right line-logo" style="top:0%"><span class="mbri-link"></span></div>
</div>

<div class="deskboard">
 <a class="linkbx w3-button card-1" target="_blank" href="../">My School Site</a>
 <a class="linkbx w3-button card-1" target="_blank" href="https://earth.google.com/web/"> World Map (3D)</a>
 <!-- <a class="linkbx w3-button" href="#">How to cook White Soup</a> -->
 <!-- <a class="linkbx w3-button" href="#">Linear Algebra II</a> -->
 <a class="linkbx w3-button card-1" target="_blank" href="https://scholar.google.com/">Google Scholar</a>
 <a class="linkbx w3-button card-1" target="_blank" href="https://betterexplained.com/">Mathematics</a>
 <a class="linkbx w3-button card-1"  id="addnewmenu" href="javascript:void(0)"><i class="fa fas fa-plus"></i></a>

 <template id="addlink">
 <div class="zoomInShort animated faster delay-0-2s w3-hide">
 <h1 class="appcolor w3-xlarge w3-center">Add Link</h1>
 <form id="addlonkform" action="javascript:void(0)" onsubmit="MessageBox.Hint('Adding Link is Disabled','fas fa-ban');MessageBox.ClosePopup()">
<div class="bbwa-groupbox" id="">
        <!-- <h1 class="bbwa-groupbox-title">{{title}}</h1> -->
        <div class="bbwa-textbox noSelect" title="Link Title">
        <i class="bbwa-textbox-logo mbri-globe"></i><input  title="Link Title" name="new-link-title" id="new-link-title" placeholder="Link Title"
            class="bbwa-textbox-input gen-text-shadow  noSelect" value=""  style="" type="text" />
        <div class="required appcolor tooltip" tooltip="Link Title"><i class="fas fa-star"></i></div>
    </div>

    <div class="bbwa-textbox noSelect" title="Link URL">
        <i class="bbwa-textbox-logo mbri-link"></i><input  title="Link URL" name="new-link-title" id="new-link-title" placeholder="Link URL"
            class="bbwa-textbox-input gen-text-shadow  noSelect" value=""  style="" type="text" />
        <div class="required appcolor tooltip" tooltip="Link URL"><i class="fas fa-star"></i></div>
    </div>

    </div>
  <button class="bbwa-button tooltip" id="maininstalbtn"  tooltip="Install"><i class="mbri-plus"></i><span>Add</span></button>
</form>
 
  </div>
 </template>

</div>

<div class="line-cont">
  <div class="tcolline-line-outer-h" style="position:relative;min-width:100%;"><div class="tcolline-line-inner-h" style="width: 70%;
left: 10%;"></div></div>
<div class="w3-display-right line-logo" style="top:0%"><span class="mbri-save"></span></div>
</div>

<div class="deskboard">
 <a class="savebx w3-button card-1" href="#">
    <div class="iconcont"><i class="fa fas fa-file-pdf fa-file-pdf-o w3-xlarge"></i></div>
    <div class="savetxt">welcome.pdf</div>
 </a>

 <a class="savebx w3-button card-1" href="#">
    <div class="iconcont"><i class="fa fas fa-word-pdf fa-file-word-o w3-xlarge"></i></div>
    <div class="savetxt">welcome.docx</div>
 </a>

 <a class="savebx w3-button card-1" href="#">
    <div class="iconcont"><i class="fa fas fa-file-powerpoint fa-file-powerpoint-o w3-xlarge"></i></div>
    <div class="savetxt">welcome.ppt</div>
 </a>

 <a class="savebx w3-button card-1" href="#">
    <div class="iconcont"><i class="fa fas fa-word-pdf fa-file-word-o w3-xlarge"></i></div>
    <div class="savetxt">welcome.docx</div>
 </a>

 <a class="savebx w3-button card-1" href="#">
    <div class="iconcont"><i class="fa fas fa-excel-pdf fa-file-excel-o w3-xlarge"></i></div>
    <div class="savetxt">welcome.xlsx</div>
 </a>
 
 <a class="savebx w3-button card-1" href="#"><i class="fa fas fa-save"></i></a>
 <div style="clear:both"></div>
</div>



</div>
  <!-- Student details Side End-->
</div>
 <!-- Body End-->
</div>
<!-- Box 3 End-->

<!-- Box 4 -->
<div id="sidebox4"  class="fadeInRight animate-fast animate-delay-normal animate-fill-both">
  <div class="sideindbx w3-display-container">
  <img class="w3-display-middle w3-circle w3-card w3-hide-large w3-hide-medium" src="{{R002:{{Image}}:R002}}" onclick="document.body.classList.add('detailsview')" />
    <i class="mbri-browse w3-display-middle w3-hide-small" onclick="/*Application.CloseAll();*/localStorage.setItem('aaa','ddd');console.log(localStorage.getItem('aaa'))"></i>
    <i class="mbri-more-vertical w3-display-middle backtomodule w3-hide-large w3-hide-medium" onclick="document.body.classList.remove('detailsview')"></i>
  </div>
  <div class="demacator">&nbsp;</div>
  <div id="openpgs">
  <div class="innercont" >
         <div class="bottomitems">
         <button class="" onclick="" title="Opened Pages"><div class="logo w3-display-container"><span class="w3-display-middle mbri-layers"></span></div></button>
      </div>
    </div>
</div>
</div>
<!-- Box 4 End-->


</div>
<?php $epapi->WriteEnd();  ?>