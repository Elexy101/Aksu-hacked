<?php
session_start();
//sleep(50);
$err = '{"Code":{{Error_Code}},"Message":"{{Error_Message}}"}';
//confirm if parameter sent
if (!isset($_POST['ApplyGID']) && !isset($_POST['Scope'])) {
  exit(str_replace(array('{{Error_Code}}', '{{Error_Message}}'), array('10', 'Invalid Application'), $err));
}



include "../epapi/api.php";


//$_SESSION = $_POST;
//$_POST['LoginName'] = $_SESSION['ALRegNo'];
$enstr = json_encode($_POST);
//exit($enstr."d");
$subdir = $_POST['SubDir'];
unset($_POST['SubDir']);

//get the settings
$config = file_get_contents("../../../{$subdir}config.json");
if ($config == "") exit(str_replace(array('{{Error_Code}}', '{{Error_Message}}'), array('--1', 'Reading Setup Failed'), $err));
$config = substr($config, strpos($config, "{"));
$config = json_decode($config, true);
if ($config === null) exit(str_replace(array('{{Error_Code}}', '{{Error_Message}}'), array('--2', 'Invalid Config Structure'), $err));
//reset the control url
$cmk = $config["ControlMarkup"];
//exit(str_replace(array('{{Error_Code}}','{{Error_Message}}'),array('--2',$config["ControlMarkup"]),$err));
if (substr(trim($cmk), 0, strlen('epcore/')) == 'epcore/') {
  $config["ControlMarkup"] = "../" . substr(trim($cmk), strlen('epcore/') - 1);
} else {
  $cmkarr = explode('/epcore/', $cmk);
  if (count($cmkarr) == 2) {
    $config["ControlMarkup"] = "../" . $cmkarr[1];
  }
}


$epapi = new epapi($config);
$epapi->OnErrorWriteStart();
echo $err;
$epapi->OnErrorWriteExit();
//request Form
//exit(json_encode($_POST)."ggg");
$pageform = $epapi->Request(["RequestID" => "R004", "Param" => json_encode($_POST)]);
//exit(json_encode($pageform)."ll");
$epapi->OnErrorWriteStart();
echo $err;
$epapi->OnErrorWriteExit();
if (!isset($_POST['OpenFrom'])) $_POST['OpenFrom'] = "open-from-home";
//$markup = $pageform['PageMarkup'];
$epapi->WriteStart();
?>
<!-- Content Popop -->
<!-- <div class="menu-popup close-popup" id="menu-popup"> -->
<!-- {{R004: -->

{{AppGroup:
 <div class="body-cont bdcont{{ID}}" id="id{{ID}}">
<div class="body-cont-title">{{Descr}}</div>
<div class="w3-row struc-row">
  <!-- Back Button-->
  <div class="w3-col l4 struc-col back-btn">
    <div class="ind-menu-bx" onclick="Application.LoadPrevPage(this)">
      <div class="ind-menu-bx-logo appcolor"><i class="mbri-left fa-fw"></i></div>
      <div class="ind-menu-bx-cont">
        <div class="ind-menu-bx-cont-title appcolor">Back</div>
      </div>
    </div>
  </div>


  {{Applications:
    <div class="w3-hide" id="{{AID}}_subs">
  {{SubMenuJson}}
</div>
<!--<div class="ind-menu-drop">
      {{Menus:
          <button onclick="Application.LoadPage(this,{{ARID}},{{ID}},null,{{PAGEID}},'{{Placeholder}}')">{{AppRName}}</button>
  :Menus}} 
</div>-->
<div class="w3-col l4 struc-col zoomInShort fast animated delay-0-{{$}}s" style="position: relative;">

  <div class="ind-menu-bx appmenu{{AID}} bbwa-textbox2d" id="mainappmenu_{{AID}}" onclick="Application.LoadPagePre(this,{{AID}},{{ID}},null,{{PAGEID}},'{{Placeholder}}')">

    <div class="ind-menu-bx-logo card-1-1 {{AppColor}}"><i class="{{AppLogo}} fa-fw"></i></div>
    <div class="ind-menu-bx-cont">
      <div class="ind-menu-bx-cont-title">{{AppName}}</div>
      <div class="ind-menu-bx-cont-det">{{AppDescr}}</div>
    </div>
    <div style="clear:both"></div>
  </div>
</div>
:Applications}}

</div>
<div class="menu-bx-cont fadeIn custom-scroll">
  <div class="menu-bx-ind-cont">
    <div class="loading-cont">
      <!-- <img src="images/logo.png" class="" /> -->
    </div>
  </div>
</div>


<!-- <button name="" class="w3-button w3-card w3-hide-large heartBeat2 w3-hide-medium gen-back-menu-btn appbgcolor w3-circle" onclick="this.parentElement.classList.remove('preview-mode');this.parentElement.parentElement.classList.remove('preview-mode-parent')"><div class="w3-display-container"><i class="mbri-features w3-large fa-fw w3-display-middle"></i></div></button> -->
</div>

:AppGroup}}

<!-- :R004}} -->

<?php $epapi->WriteEnd();  ?>