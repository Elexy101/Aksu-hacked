<?php
//sleep(4);
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
/*$rtn = array('enablednum'=>30,'enabledbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td>
</tr>','failednum'=>10,'failedbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td><td>Testing</td>
</tr>');*/
function Success($rrr,$RegNo,$ItemName){
  global $rtn;
  $rtn['enablednum'] += 1;
  $rtn['enabledbody'] .= '<tr>
  <td>'.$rtn['enablednum'].'</td><td>'.$rrr.'</td><td>'.$RegNo.'</td><td>'.$ItemName.'</td>
  </tr>';
}

function Failed($failed,$rrr,$RegNo="",$ItemName=""){
    global $rtn;
    $rtn['failednum'] += 1;
    $rtn['failedbody'] .= '<tr>
    <td>'.$rtn['failednum'].'</td><td>'.$rrr.'</td><td>'.$RegNo.'</td><td>'.$ItemName.'</td><td>'.$failed.'</td>
    </tr>'; 
}
$rtn = array('enablednum'=>0,'enabledbody'=>'','failednum'=>0,'failedbody'=>'');

$rrrs = trim($_POST['rrr']);
if($rrrs == ""){
    exit(json_encode($rtn));
}
$rrrs = explode(",",$rrrs);
foreach($rrrs as $rrr){
    $rrr = trim(str_replace("-","",$rrr));
  $rst = $dbo->SelectFirstRow("order_tb o, item_tb i","o.*, i.ItemName","`TransNum` = '$rrr' AND i.ID = o.ItemID");
  if(is_array($rst)){
     /*if($rst['Paid'] == 1){
         $rtn['failednum'] += 1;
         $rtn['failedbody'] += '<tr>
         <td>'.$rtn['failednum'].'</td><td>'.$rrr.'</td><td>'.$rst['RegNo'].'</td><td>'.$rst['ItemID'].'</td><td>Aready Paid</td>
         </tr>';
     }else{

     }*/
     $RegNo = $rst['RegNo'];
     $lchar = substr($RegNo,strlen($RegNo) - 1, 1);
     if($lchar == "s"){
         //perform update
         $RegNo = substr($RegNo,0, strlen($RegNo) - 1);
         $up = $dbo->Update('order_tb',array("RegNo"=>$RegNo),"TransNum = '$rrr'");
         if(is_array($up)){
             Success($rrr,$RegNo,$rst['ItemName']);
         }else{
            Failed("Update Failed",$rrr,$RegNo,$rst['ItemName']);
         }
        
     }else{
        Success($rrr,$RegNo,$rst['ItemName']);
     } 
  }else{
    Failed("Payment Not Found",$rrr);
  }
}

exit(json_encode($rtn));

?>