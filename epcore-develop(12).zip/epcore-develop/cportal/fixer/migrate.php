<?php
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
$pids = trim($_POST['pids']);
$rtn = "";
if($pids != ""){
    $pids = explode(",",$pids);
    //loop through all From Migrating programmes
    foreach($pids as $pid){
        $pid = trim($pid);
        //get the programm details
        $pdet = $dbo->SelectFirstRow("programme_tb","","ProgID=$pid");
        if(is_array($pdet)){
          $rtn .= '<h2 class="w3-blue w3-padding w3-medium">From: '.$pdet['ProgName'].' <button onclick="EnableOrder.ToExcel(\'tb'.$pid.'\')" class="w3-button w3-red w3-margin-left w3-small" id="enexbtn" style="margin:auto;max-width:98%">Export To Excel</button></h2>';
          //get the Courses in the Programme
          $pcourses = $dbo->Select("course_tb","","DeptID=$pid and Lvl=3");
          if(is_array($pcourses) && $pcourses[1] > 0){
            $rtn .='<div class="w3-margin w3-left w3-pale-red w3-padding" style="width:800px;min-height:200px;margin:auto ">
            <table id="tb'.$pid.'" class="w3-table w3-striped w3-white w3-small">';
              while($pcourse = $pcourses[0]->fetch_assoc()){
                  $rtn .='<tr class="w3-red w3-padding w3-medium">
                  <th  colspan="4">'.$pcourse['CourseCode'].' - '.$pcourse['Title'].' - '.$pcourse['CH'].'Unit</th></tr>';
                  //exclude from programms
                  $exclf = " AND p.ProgID != " . implode(" AND p.ProgID != ",$pids);
                   //get other programme in current from programm department
                  // $oprogs = $dbo->Select("programme_tb","","DeptID={$pdet['DeptID']}".$exclf);
                  $facid = $dbo->SelectFirstRow("fac_tb f, dept_tb d","f.FacID","d.FacID = f.FacID and d.DeptID = {$pdet['DeptID']}");
                  $facid = is_array($facid)?$facid[0]:6;
                  $oprogs = $dbo->Select("programme_tb p, fac_tb f, dept_tb d","p.*","p.DeptID = d.DeptID and d.FacID = f.FacID and f.FacID = $facid".$exclf);
                  //echo $exclf;
                   if(is_array($oprogs) && $oprogs[1] > 0){
                       //form query
                       $query = "";
                       $pcourse['CourseID'] = 0;
                       $cnt = 1;
                       $rtn .= '<tr><th>S/N</th><th>To Programme</th><th>Course ID</th><th>Description</th></tr>';
                    while($oprog = $oprogs[0]->fetch_assoc()){
                        //$query .= "INSERT INTO `course_tb`(`CourseCode`, `Former`, `CourseStatus`, `Title`, `Lvl`, `DeptID`, `Sem`, `CH`, `Elective`, `StudyID`, `GroupID`) VALUES ({$pcourse['CourseCode']},{$pcourse['Former']},{$pcourse['CourseStatus']},{$pcourse['Title']},3,{$oprog['ProgID']},{$pcourse['Sem']},{$pcourse['CH']},{$pcourse['Elective']},{$pcourse['StudyID']},{$pcourse['GroupID']});";
                        //check if course already exist for the oprog
                        $Check = $dbo->SelectFirstRow("course_tb","","UPPER(TRIM(CourseCode)) = UPPER(TRIM('{$pcourse['CourseCode']}')) and Lvl=3 and DeptID = {$oprog['ProgID']}");
                       //exit($Check);
                        if(!is_array($Check)){
                            $pcourse['DeptID'] = $oprog['ProgID'];
                        $int = $dbo->InsertID("course_tb",$pcourse);
                        //$int = 1;
                        $des = $int > -1?"Successful":"Failed";
                        $cls = $int > -1?"":"w3-pale-red";
                        }else{
                            $int = $Check['CourseID'];
                            $des = "Already Exist";
                            $cls = "w3-pale-green";
                        }
                        
                        $rtn .= '<tr class="'.$cls.'"><td>'.$cnt.'</td><td>'.$oprog['ProgName'].'</td><td>'.$int.'</td><td>'.$des.'</td></tr>';
                        $cnt++;
                    }
                   }
                  
              }
              $rtn .='</table></div>';
          }
        }
        $rtn .='<div style="clear:both"></div>';
    }
}else{
    echo "Error";
}
echo $rtn;

?>