<?php
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
$Progs = $dbo->Select("programme_tb","","1=1 ORDER BY ProgName ASC");
$rtn = "";
if(is_array($Progs) && $Progs[1]>0){
  while($prog = $Progs[0]->fetch_array()){
    $rtn .= '<option value="'.$prog['ProgID'].'">'.$prog['ProgName'].'</option>';
  }
}
echo $rtn;


?>