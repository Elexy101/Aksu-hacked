<?php
//sleep(4);
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
/*$rtn = array('enablednum'=>30,'enabledbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td>
</tr>','failednum'=>10,'failedbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td><td>Testing</td>
</tr>');*/

function Success($RegNo,$FullName,$fac,$prog){
  global $rtn;
  $rtn['penablednum'] += 1;
  $rtn['popstudbody'] .= '<tr>
  <td>'.$rtn['penablednum'].'</td><td>'.$RegNo.'</td><td>'.$FullName.'</td><td>'.$fac.'</td><td>'.$prog.'</td>
  </tr>';
}

function Failed($failed,$RegNo=""){
    global $rtn;
    $rtn['pfailednum'] += 1;
    $rtn['popfailedbody'] .= '<tr>
    <td>'.$rtn['pfailednum'].'</td><td>'.$RegNo.'</td><td>'.$failed.'</td>
    </tr>'; 
}
$rtn = array('penablednum'=>0,'popstudbody'=>'','pfailednum'=>0,'popfailedbody'=>'');

$regs = trim($_POST['popreg']);
if($regs == ""){
    exit(json_encode($rtn));
}
$regs = explode(",",$regs);
$ucurrSes = CurrentSes();
$ucurrSesID = $ucurrSes['SesID'];
foreach($regs as $reg){
  $reg = trim($reg);
  //check if already added
  $rstala = $dbo->SelectFirstRow("studentinfo_tb p","p.*","p.JambNo = '$reg'");
  if(is_array($rstala)){
    Failed("Already Populated",$reg);
    continue;
  }

  $rst = $dbo->SelectFirstRow("pstudentinfo_tb p, fac_tb f, dept_tb d, programme_tb pr","p.*, f.FacName, pr.ProgName","p.JambNo = '$reg' AND f.FacID = d.FacID AND pr.DeptID = d.DeptID");
  if(is_array($rst)){
    $RegNo = $rst['JambNo'];
     //Check if student complate registration
     if((int)$rst['RegLevel'] == 6){
           //Insert details in student info
           $pdet = array();
           foreach(array("SurName","FirstName","RegNo","OtherNames","JambNo","StateId","LGA","Gender","MaritalStatus","Phone","Email","Addrs","ModeOfEntry","JambAgg","OlevelRstDetails","OlevelRst","ProgID","StudyID","OtherCert","RegID") as $fname){
             $pdet[$fname]=$rst[$fname];
           }
           $pdet['StartSes'] = $ucurrSesID;
           //insert the records
           $ins = $dbo->Insert("studentinfo_tb",$pdet);
           if($ins == "#"){ //if successfull
            Success($RegNo,$rst['SurName']." ".$rst['FirstName']." ".$rst['OtherNames'],$rst['FacName'],$rst['ProgName']);
           }else{
            Failed("Population Failed ".$ins,$RegNo);
           }

     }else{
      Failed("Incomplete Entrance Registration",$RegNo);
     }
     
    
     //} 
  }else{
    Failed("Invalid Registration Number",$reg);
  }
}

exit(json_encode($rtn));

?>