
    
    /*(function(win) {
        var TaquaLB = function(selector){
           return new TaquaLB.main.Init(selector);
        }
        
        TaquaLB.main = TaquaLB.prototype = {
           
            aaa:function(){
         
            },

            //Basic Operations
        }
        Init = TaquaLB.main.Init = function(selector){
            this[0]=document.getElementById(selector);
            this.length = 1;
            return this;
          //perform selection operation (real _)
        }

        Init.prototype = TaquaLB.main;

        win.ssssdd = win.TaquaLB = TaquaLB; //Publish method
    })(window);*/
//populating admision list
var Student = {
    Ajax:new Ajax(),
    Search:function(){
        if(_('adstudregno').textContent.Trim() == "")return;
        _('searchbtn').className += " w3-disabled";
        _('searchbtn').textContent ="SEARCHING ...";
        var tb = _('entrsearch').checked?"p":"";
        Student.Ajax.Post({
            Action:"stud.php",
            PostData:"search="+escape(_('adstudregno').textContent)+"&pre="+tb,
            OnComplete:function(res){
                //alert(res);
              var resjson = JSON.parse(res);
              _('totalstud').textContent = resjson.TotalStud;
              _('searchstudbody').innerHTML = resjson.StudReport;
             
              _('searchbtn').className = _('searchbtn').className.replace(" w3-disabled","");
              _('searchbtn').textContent ="SEARCH";
              //_('ordrrr').textContent = "";
            },
            OnError:function(res){
                alert("Server Error");
                _('searchbtn').className = _('searchbtn').className.replace(" w3-disabled","");
              _('searchbtn').textContent ="SEARCH";
            }
        })
    },
    Clean:function(){
        if(_('cleanstudRegs').textContent.Trim() == "")return;
        _('cleanstudbtn').className += " w3-disabled";
        _('cleanstudbtn').textContent ="CHANGING ...";
        Admission.Ajax.Post({
            Action:"cleanstud.php",
            PostData:"cleanRegs="+escape(_('cleanstudRegs').textContent)+"&Progs="+_('cprogs').Value(),
            OnComplete:function(res){
              var resjson = JSON.parse(res);
              _('scleanstudnum').textContent = resjson.scleanstudnum;
              _('scleanstudbody').innerHTML = resjson.scleanstudbody;
              _('fcleanstudnum').textContent = resjson.fcleanstudnum;
              _('fcleanstudbody').innerHTML = resjson.fcleanstudbody;
              _('cleanstudbtn').className = _('cleanstudbtn').className.replace(" w3-disabled","");
              _('cleanstudbtn').textContent ="CHANGE";
              //_('ordrrr').textContent = "";
            },
            OnError:function(res){
                alert("Server Error");
                _('cleanstudbtn').className = _('cleanstudbtn').className.replace(" w3-disabled","");
                _('cleanstudbtn').textContent ="CHANGE";
            }
        })
    },
    CountReg:function(){
        var txt = _('cleanstudRegs').textContent.Trim();
        var len = 0;
        if(txt != ""){

            len = txt.TrimRight(",").split(",").length;
        }
        _('cleanstudnum').textContent = len;
        if(len > 0){
            _('cleanstudbtn').className = _('cleanstudbtn').className.replace(' w3-hide','');
        }else{
          _('cleanstudbtn').className += ' w3-hide';
        }
      }
}
var Admission = {
    CountReg:function(){
        var txt = _('adregno').textContent.Trim();
        var len = 0;
        if(txt != ""){

            len = txt.TrimRight(",").split(",").length;
        }
        _('pallnum').textContent = len;
        if(len > 0){
            _('populatebtn').className = _('populatebtn').className.replace(' w3-hide','');
        }else{
          _('populatebtn').className += ' w3-hide';
        }
      },
      Ajax:new Ajax(),
      Populate:function(){
          if(_('adregno').textContent.Trim() == "")return;
        _('populatebtn').className += " w3-disabled";
        _('populatebtn').textContent ="POPULATING ...";
        Admission.Ajax.Post({
            Action:"populate.php",
            PostData:"popreg="+escape(_('adregno').textContent),
            OnComplete:function(res){
              var resjson = JSON.parse(res);
              _('penablednum').textContent = resjson.penablednum;
              _('popstudbody').innerHTML = resjson.popstudbody;
              _('pfailednum').textContent = resjson.pfailednum;
              _('popfailedbody').innerHTML = resjson.popfailedbody;
              _('populatebtn').className = _('populatebtn').className.replace(" w3-disabled","");
              _('populatebtn').textContent ="POPULATE";
              //_('ordrrr').textContent = "";
            },
            OnError:function(res){
                alert("Server Error");
                _('populatebtn').className = _('populatebtn').className.replace(" w3-disabled","");
                _('populatebtn').textContent ="ENABLE";
            }
        })
      }
}
var EnableOrder = {
    ToExcel:function(id){
   tableToExcel(_(id).innerHTML,"Excel");
    },
    CountRRR:function(){
      var txt = _('ordrrr').textContent.Trim();
      var len = 0;
      if(txt != ""){
          len = txt.split(",").length;
      }
      _('allnum').textContent = len;
      if(len > 0){
          _('enableorderbtn').className = _('enableorderbtn').className.replace(' w3-hide','');
      }else{
        _('enableorderbtn').className += ' w3-hide';
      }
    },
    Ajax:new Ajax(),
    Start:function(){
        if(_('ordrrr').textContent.Trim() == "")return;
      _('enableorderbtn').className += " w3-disabled";
      _('enableorderbtn').textContent ="ENABLING ...";
      EnableOrder.Ajax.Post({
          Action:"server.php",
          PostData:"rrr="+escape(_('ordrrr').textContent),
          OnComplete:function(res){
            var resjson = JSON.parse(res);
            _('enablednum').textContent = resjson.enablednum;
            _('enabledbody').innerHTML = resjson.enabledbody;
            _('failednum').textContent = resjson.failednum;
            _('failedbody').innerHTML = resjson.failedbody;
            _('enableorderbtn').className = _('enableorderbtn').className.replace(" w3-disabled","");
            _('enableorderbtn').textContent ="ENABLE";
            //_('ordrrr').textContent = "";
          },
          OnError:function(res){
              alert("Server Error");
              _('enableorderbtn').className = _('enableorderbtn').className.replace(" w3-disabled","");
              _('enableorderbtn').textContent ="ENABLE";
          }
      })
    }
}

var Opner = {
    Open:function(id){
        //close all
        _('allpg').Walk(function(k,v){
            v.Hide();
            _(v.id+"_c").className = _(v.id+"_c").className.replace(' w3-blue','');
        });
        _(id).Show();
        _(id+"_c").className += ' w3-blue';
    }
}

var Migrate = {
    Ajax: new Ajax(),
    Start:function(){
        _('migratebtn').textContent = 'MIGRATING...';
        var pids = _('pids').value.Trim();
        if(pids != ""){
            Migrate.Ajax.Post({
                Action:"migrate.php",
                PostData:"pids="+escape(pids),
                OnComplete:function(res){
                  _('rstcont').innerHTML = res;
                  _('migratebtn').textContent = 'MIGRATE';
                },
                OnError:function(res){
                    _('rstcont').innerHTML = "Error: "+res; 
                    _('migratebtn').textContent = 'MIGRATE'; 
                }
            });
        }
    }
}


var Course = {
    Ajax: new Ajax(),
    Migrate:function(){
        _('cmigratebtn').textContent = 'MIGRATING...';
        var frompID = _('frompID').value.Trim();
        var topID = _('topID').value.Trim();
        if(frompID == "" || topID == ""){alert("Enter From and To Programme ID"); return}
        
            Migrate.Ajax.Post({
                Action:"cmigrate.php",
                PostData:"frompID="+escape(frompID)+"&topID="+escape(topID),
                OnComplete:function(res){
                    var resjson = JSON.parse(res);
                    _('migratedfrom').textContent = "From:"+resjson.migratedfrom;
                    _('migratedto').textContent = "To:"+resjson.migratedto;
                    _('migratednum').textContent = resjson.migratednum;
                    _('migratedbody').innerHTML = resjson.migratedbody;
                    _('fmigratednum').textContent = resjson.fmigratednum;
                    _('fmigratedbody').innerHTML = resjson.fmigratedbody;
                   // _('enableorderbtn').className = _('enableorderbtn').className.replace(" w3-disabled","");
                  _('cmigratebtn').textContent = 'MIGRATE';
                },
                OnError:function(res){
                    alert(res); 
                    _('cmigratebtn').textContent = 'MIGRATE'; 
                }
            });
        
    }
}

DOM.Ready(function(){
  var aj = new Ajax();
  aj.Post({
      Action:"progs.php",
      PostData:"",
      OnComplete:function(res){
        _('cprogs').insertAdjacentHTML('beforeend',res);
      },
      OnError:function(res){

      }
  })
});



