<?php
//sleep(4);
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
/*$rtn = array('enablednum'=>30,'enabledbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td>
</tr>','failednum'=>10,'failedbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td><td>Testing</td>
</tr>');*/

function Success($RegNo,$FullName,$prog){
  global $rtn;
  $rtn['scleanstudnum'] += 1;
  $rtn['scleanstudbody'] .= '<tr>
  <td>'.$rtn['scleanstudnum'].'</td><td>'.$RegNo.'</td><td>'.$FullName.'</td><td>'.$prog.'</td>
  </tr>';
}

function Failed($failed,$RegNo=""){
    global $rtn;
    $rtn['fcleanstudnum'] += 1;
    $rtn['fcleanstudbody'] .= '<tr>
    <td>'.$rtn['fcleanstudnum'].'</td><td>'.$RegNo.'</td><td>'.$failed.'</td>
    </tr>'; 
}
$rtn = array('scleanstudnum'=>0,'scleanstudbody'=>'','fcleanstudnum'=>0,'fcleanstudbody'=>'');

$regs = trim($_POST['cleanRegs']);
$progs = $_POST['Progs'];
if($regs == "" || (int)$progs == 0){
    exit(json_encode($rtn));
}
$regs = explode(",",$regs);
//$ucurrSes = CurrentSes();
//$ucurrSesID = $ucurrSes['SesID'];
foreach($regs as $reg){
  $reg = trim($reg);
  if($reg == "")continue;
  //Get the student details
  $studDet = $dbo->SelectFirstRow("studentinfo_tb s, programme_tb p","s.id,s.RegNo, s.JambNo, s.SurName, s.FirstName, s.OtherNames, p.ProgName","(RegNo='$reg' OR JambNo='$reg') AND s.ProgID = p.ProgID");
  if(is_array($studDet)){// stud reg exis
      
         $regNo = $studDet['RegNo'];
         //Get the JambNo 
         $jambNo = $studDet['JambNo'];
         $query = "";
         if(trim($regNo) != "" ){
          //form accesscode query
         $query .= "UPDATE `accesscode_tb` SET `JambNo`='$jambNo' WHERE JambNo = '$reg';";
         //Update the RegNo in order_tb
         $query .= "UPDATE `order_tb` SET `RegNo`='$jambNo' WHERE RegNo = '$reg';";
          //Update the RegNo in payinfo_tb
          $query .= "UPDATE `payhistory_tb` SET `RegNo`='$jambNo' WHERE RegNo = '$reg';";
          //Update the RegNo in result_tb
          $query .= "UPDATE `result_tb` SET `RegNo`='$jambNo' WHERE RegNo = '$reg';";
         }
         
         //Delete the courseReg
         $query .= "DELETE FROM `coursereg_tb` WHERE (RegNo = '$reg' OR RegNo = '$jambNo') AND RegNo != '';";
         //Update the RegNo,Passport,AutoGenReg,AutoNum in studentinfo_tb
         $query .= "UPDATE `studentinfo_tb` SET `RegNo`='',ProgID=$progs, Passport = '../epconfig/UserImages/PUTME/$jambNo.jpg', AutoGenReg = 'FALSE', AutoNum =0 WHERE id = ".$studDet['id'].";";
         $dump = $dbo->Connection->multi_query($query);
         if(!$dump){
          //echo "#Server Error: ".$dbo->Connection->error;
          Failed("Server Error: ".$dbo->Connection->error,$reg);
        }else{
           Success($reg,$jambNo,$studDet['SurName']." ".$studDet['FirstName']." ".$studDet['OtherNames'],$studDet['ProgName']);
        }
      
  }else{
    Failed("Invalid RegNo",$reg);
  }
}

exit(json_encode($rtn));

?>