<?php
//sleep(4);
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
/*$rtn = array('enablednum'=>30,'enabledbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td>
</tr>','failednum'=>10,'failedbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td><td>Testing</td>
</tr>');*/

function Success($RegNo,$FullName,$fac,$prog){
  global $rtn;
  $rtn['TotalStud'] += 1;
  $rtn['StudReport'] .= '<tr>
  <td>'.$rtn['TotalStud'].'</td><td>'.$RegNo.'</td><td>'.$FullName.'</td><td>'.$fac.'</td><td>'.$prog.'</td>
  </tr>';
}

$rtn = array('TotalStud'=>0,'StudReport'=>'');

$regs = trim($_POST['search']);
$pre = $_POST['pre'];
if($regs == ""){
    exit(json_encode($rtn));
}
$regs = explode(",",$regs);
$ucurrSes = CurrentSes();
$ucurrSesID = $ucurrSes['SesID'];
$querycond = "";
foreach($regs as $reg){
  $reg = trim($reg);
  //form the search string
  $querycond = " (s.RegNo LIKE '".$reg."' OR s.JambNo LIKE '".$reg."' OR ";
}
$querycond = rtrim($querycond," OR"). ")";
$rst = $dbo->RunQuery("SELECT s.RegNo,s.JambNo, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as FullName, f.FacName, p.ProgName FROM {$pre}studentinfo_tb s, fac_tb f, dept_tb d, programme_tb p WHERE s.RegLevel = 6 AND s.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND".$querycond);
if(is_array($rst)){
  while($rrst = $rst[0]->fetch_array()){
    $regno = trim($rrst['RegNo']) == ""?$rrst['JambNo']:$rrst['RegNo'];
    Success($regno,$rrst['FullName'],$rrst['FacName'],$rrst['ProgName']);
  }
}
exit(json_encode($rtn));

?>