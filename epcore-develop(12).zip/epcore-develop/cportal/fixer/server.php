<?php
//sleep(4);
require_once("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../../epconfig/GenScript/PHP/getinfo.php");
/*$rtn = array('enablednum'=>30,'enabledbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td>
</tr>','failednum'=>10,'failedbody'=>'<tr>
<td>1</td><td>35363673773</td><td>47474747</td><td>SCHOOL FEE DB</td><td>Testing</td>
</tr>');*/

function Success($rrr,$RegNo,$ItemName){
  global $rtn;
  $rtn['enablednum'] += 1;
  $rtn['enabledbody'] .= '<tr>
  <td>'.$rtn['enablednum'].'</td><td>'.$rrr.'</td><td>'.$RegNo.'</td><td>'.$ItemName.'</td>
  </tr>';
}

function Failed($failed,$rrr,$RegNo="",$ItemName=""){
    global $rtn;
    $rtn['failednum'] += 1;
    $rtn['failedbody'] .= '<tr>
    <td>'.$rtn['failednum'].'</td><td>'.$rrr.'</td><td>'.$RegNo.'</td><td>'.$ItemName.'</td><td>'.$failed.'</td>
    </tr>'; 
}
$rtn = array('enablednum'=>0,'enabledbody'=>'','failednum'=>0,'failedbody'=>'');

$rrrs = trim($_POST['rrr']);
if($rrrs == ""){
    exit(json_encode($rtn));
}
$rrrs = explode(",",$rrrs);
foreach($rrrs as $rrr){
    $rrr = trim(str_replace("-","",$rrr));
  $rst = $dbo->SelectFirstRow("order_tb o, item_tb i","o.*, i.ItemName","`TransNum` = '$rrr' AND i.ID = o.ItemID AND o.ItemID = 5");
  if(is_array($rst)){
    $RegNo = $rst['RegNo'];
     //Check if not Payment Made
     if($rst['Paid'] == 0){
          //try to query from remita
          $data = VerifyPayRemote($rrr,true); //RRR
          if(!is_array($data) || $data[0] != 1){ //if not paid
            Failed("Payment Not Made",$rrr,$RegNo,$rst['ItemName']);
            continue;
          }

     }
     
     //$lchar = substr($RegNo,strlen($RegNo) - 1, 1);
     //if($lchar == "s"){
         //perform update
         //$RegNo = substr($RegNo,0, strlen($RegNo) - 1);
         $up = $dbo->Update('order_tb',array("RegNo"=>$RegNo),"RegNo = '{$RegNo}s'");
         if(is_array($up)){
             $numup = $up[1];
             Success($rrr,$RegNo,$rst['ItemName']." ($numup Fixed)");
         }else{
            Failed("Update Failed",$rrr,$RegNo,$rst['ItemName']);
         }
        
    // }else{
       // Success($rrr,$RegNo,$rst['ItemName']);
     //} 
  }else{
    Failed("Invalid Late Payment RRR",$rrr);
  }
}

exit(json_encode($rtn));

?>