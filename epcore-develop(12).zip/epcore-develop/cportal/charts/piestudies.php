<?php
$core = urldecode($_GET['core']);
$subdir = urldecode($_GET['subdir']);
$configdir = "../../../../".$subdir;
require_once("../../general/config.php"); 

?>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Encode+Sans+Condensed" rel="stylesheet">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="../../general/TaquaLB/Ajax/Ajaxlite.js"></script>
    <style>
    body,select{font-family:'Encode Sans Condensed','Encode Sans Condensed Medium',"Segoe UI Light", "Segoe UI Semibold", "Segoe UI Semilight","Segoe UI", "Segoe UI Black"}
     .header{
       text-align:center;
       padding:5px;
       font-size:1em;
       background-color:rgb(196, 209, 218); margin:10px;
     }
    </style>
    
  </head>
  <body>
    <?php
    //get all schools
    $schls = $dbo->Select("school_grp_tb");
    if(!is_array($schls) || $schls[1] < 1){
    ?>
     <h1>CHARTS NOT AVAILABLE</h1>
    <?php
    }else{
      if($schls[1] > 1){
    ?>
    <select onchange="drawChart(Number(this.value))" style="width:100%;border:none; border-bottom:solid grey thin;background-color:transparent;padding:5px">
    <?php
      $fid = 0;
       while ($schgrp = $schls[0]->fetch_array()) {
         if($fid == 0)$fid=$schgrp['SchGrpID'];
         echo '<option value="'.$schgrp['SchGrpID'].'">'.$schgrp['SchGrpName'].'</option>';
       }
    ?>
    </select>
      <?php }else{
        $schgrp = $schls[0]->fetch_array();
        $fid=$schgrp['SchGrpID'];
      } ?>
    <!-- <div class="header">STUDIES</div>
    <div id="donutchart" style="width: 100%; height: 500px;"></div> -->
    <?php
    }
    ?>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      var rawdata = [
          [
          ['Faculty', 'Number of Student'],
          ['Engineering',     11],
          ['Social Sciences',      2],
          ['Business Administartion',  2],
          ['Agriculture', 2],
          ['Art',    7]
        ],
        [
          ['Faculty', 'Number of Student'],
          ['Engineering 2',     6],
          ['Social Sciences 2',      12],
          ['Business Administartion 2',  5],
          ['Agriculture 2', 1],
          ['Art 2',    3]
        ]

      ]
      function drawChart(ind) {
        //alert(_);
          ind = ind || <?php echo $fid ?>;
          //alert(ind);
          var aj = new Ajax;
          aj.Post({
            Action:"scripts/getstudies.php",
            PostData:"SchID="+ind+"&core="+encodeURIComponent('<?php echo $core ?>')+"&subdir="+encodeURIComponent('<?php echo $subdir ?>'),
            OnComplete:function(res){
               resobj = JSON.parse(res);
               if(typeof resobj.Error != _UND){
                body.innerHTML = resobj.Error;
               }else{
                 var hind = (resobj.length < 2)?1:resobj.length;
                 console.log(window.frameElement.style.height) ;
                 window.frameElement.style.height = (hind * 300)+"px";
                 //return;
                 for(st=0;st<resobj.length;st++){
                   var det = resobj[st];
                   var header = document.createElement('div');
                   header.className = 'header';
                   header.innerHTML = det.StudyName + ' - <b>'+ det.Overall +'</b>';
                   document.body.insertAdjacentElement('beforeend',header);

                   var cnt = document.createElement('div');
                   cnt.id = 'chartcnt'+st;
                   cnt.style.width = "100%";
                   cnt.style.height = "250px";
                   cnt.style.position = "relative";
                   cnt.style.overflow = "hidden";
                  // cnt.textContent = det.StudyName;
                   document.body.insertAdjacentElement('beforeend',cnt);
                   var curdata = det.Data;

                   var data = google.visualization.arrayToDataTable(curdata);

                  var options = {
                  backgroundColor:'#FAFAFA',
                    pieHole: 0.4,
                    chartArea:{left:'0px',top:'0%',width:'100%',height:'200px'},
                    pieSliceText: 'label',
                    legend:{position: 'top', textStyle: {color: 'blue', fontSize: 16},alignment:'end'},
                    height:380,
                    pieSliceTextStyle:{color: 'white', fontName: 'Encode Sans Condensed', fontSize: 10},
                    is3D:true
                  };

                  var chart = new google.visualization.PieChart(_(cnt.id));
                  chart.draw(data, options);
                 }
                
               }
            },
            OnError:function(res){

            },
            OnAbort:function(res){
              
            }
          });
          //get the studies from database
       
      }
    </script>
  </body>


</html>