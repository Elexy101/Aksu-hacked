<?php
//require("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
//require_once("../../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require_once("../../epconfig/TaquaLB/Elements/Elements.php");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Eduporta::Setup</title>
<script src="../../epconfig/TaquaLB/Loader/Loader.js" loadtype="Premium;../Resources/Javascripts/main.js" onComplete=""></script>
<link href="../Resources/Css/main.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../epconfig/GenScript/CSS/logos/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body id="Default">
 <div id="contgen">
   <div id="loginCont" style="opacity:1">
          <?php 

//$UID = $_POST['UID'];
   ?>

     <div id="loginContInner" >
        <div id="header">
          <div><i class="fa fa-cogs fa-2x" style="color:#666" aria-hidden="true"></i></div> <div id="userLoginName"> Setup: Database</div>
        </div>
        
         <?php
         
		 Form("id=lngfrmsetup,name=lngfrmsetup,action=javascript:Setup.Verify(),method=post");
		  TextBox("title=Host,style=width:calc(100% - 40px);margin:auto;margin-top:20px,id=hostnm,logo=home,value=localhost");
      TextBox("title=User,style=width:calc(100% - 40px);margin:auto;margin-top:20px,id=usernm,logo=user");
      TextBox("title=Password,style=width:calc(100% - 40px);margin:auto;margin-top:20px,id=pwnm,logo=user-secret,type=password");
       TextBox("title=Database,style=width:calc(100% - 40px);margin:auto;margin-top:20px,id=dbnm,logo=database");
       //Check("id=newdb,text=New Database,check=Setup.NewDbChecked,uncheck=Setup.NewDbUnChecked,style=margin-top:10px;margin-left:22px");
      //TextBox("title=Password,style=width:calc(100% - 40px);margin:auto;margin-top:20px;display:none;opacity:0,id=userpssw,type=password,logo=user-secret");
      //TextBoxGroup();
      FlatButton("text=Publish,style=width:308px;margin:auto;margin-top:20px,id=tocportal,logo=cog");
      //TextBoxGroupItemMore();
      FlatButton("text=Setup,style=width:308px;margin:auto;margin-top:20px,id=veridybtn,logo=database,submit=true");
      //_TextBoxGroup();
      _Form();
      
      Box(" ");


      _Box();
		 /*Radio("group=aaa,id=r3");
		 Radio("group=aaa,id=r4");
		 Radio("group=aaa,id=r5");*/
		 /*if(isset($UID) && (int)$UID != 0){
			 $dbo->Updatedbtb("user_tb",array("Online"=>0),"UserID = $UID");
		 }*/
	  ?>
       <input type="hidden" id="setup_tabs" value="setup=Setup"  />  
     </div>
  </div>
</div>
 
   <!-- <div id="genloading"><i class="fa fa-circle-o-notch fa-spin"></i></div> -->
   
<?php
//}else{
//	echo "Page Error";
//}

?>
<!--<div id="lockscreen">
  
</div> -->
 <!--Loading Element-->
  <!--<div id="mainLoader" class="">
 
  <div id="movingbg"></div>
  <img src="Resources/Images/eduportaimg.png" alt="eduPORTAL" id="eduportLogo" onload=""  />
  </div>-->
  
  <!--main menus-->
  
  <!--<div class="messagebx">
     Error Message
  </div>-->
  
  <!--Main Login-->
  
  
  <!--Left and Right Fenders-->
  <!--Left Fenders-->
 <!-- <div class="Fender" id="FenderLeft">
    
  </div>-->
  <!--Right Fenders-->
<!--  <div class="Fender" id="FenderRight">
     
     <div class="textBx" id="tbnw">
       <input  type="text" id="tbnw_id" value="" placeholder="Enter Text" />
     </div> 
  
  </div>-->
 
  
<!--<div class="pgmain" id="newpg" >
  
</div>
<div id="addmarker"></div>--> 

<!-- <div id="Pagescont">
<img id="pagescontclose" src="TaquaLB/Elements/Images/close.png" width="40" height="40" alt="Close"  />
<div style="clear:both"></div>
<div class="indbox">
    <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/student.png" alt="Student" />
    <div class="title">Student</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/course.png" alt="Student" />
    <div class="title">Course</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/school.png" alt="Student" />
    <div class="title">School</div>
 </div>
 <div class="indbox"></div>
</div>-->

</body>
</html>
