<?php

//get the config file
$EPCONFIG = file_exists("config.json")?"config.json":"epapi/config.json";
if(!file_exists($EPCONFIG))exit("Configuration File Not Found");
$config = file_get_contents($EPCONFIG);
$config = substr($config,strpos($config,"{")) ;

//get the settings as an array
$config = json_decode($config,true);
$configdir = "";
require($config['Core']."general/config.php");
require($config['Core']."general/TaquaLB/Elements/Elements.php");

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Portal</title>
    <!--Load the AJAX API
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>-->

    <?php
  
?>
    <script src="<?php echo $config['Core'] ?>js/aimlite.js"></script>
    <?php //exit($config['Core']."js/aimlite.js");W3CSS4 ?>
    <link href="<?php echo $config['Core'] ?>cportal/Resources/Css/w3snippest.css" rel="stylesheet" type="text/css" media="all" />
    <!-- <link href="<?php echo $config['Require'] ?>W3CSS4/w3.css" rel="stylesheet" type="text/css" media="all" /> -->
    <script type="text/javascript" src="./config.json"></script>

    <script src="<?php echo $config['Core'] ?>general/TaquaLB/Loader/Loader.js" ansyc
        loadtype="Premium;<?php echo $config['Core'] ?>cportal/Resources/Javascripts/main.js;<?php echo $config['Core'] ?>cportal/Resources/Javascripts/pay.js"
        onComplete="Loading.Start()"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/progressbar.js/1.0.1/progressbar.min.js"></script>

    <!-- <script src="../epconfig/ProgressBar/lib/control/progressbar.min.js"></script> -->
    <link href="<?php echo $config['Require'] ?>Animate/animate.css" rel="stylesheet" type="text/css" media="all" />
    <!-- <link href="<?php echo $config['Core'] ?>css/animated.css" rel="stylesheet" type="text/css" media="all" /> -->
    <link href="https://fonts.googleapis.com/css?family=Encode+Sans+Condensed" rel="stylesheet">
    <link href="<?php echo $config['Core'] ?>cportal/Resources/Css/main.css" rel="stylesheet" type="text/css"
        media="all" />
       <!--  <link href="<?php echo $config['Require'] ?>FA4/css/font-awesome.min.css" rel="stylesheet" type="text/css"
           media="all" />  -->
    <link href="<?php echo $config['Require'] ?>FA515/css/all.min.css" rel="stylesheet" type="text/css"
        media="all" />
    <!-- <link href="<?php echo $config['Require'] ?>FA5/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all" /> -->
    <link href="<?php echo $config['Require'] ?>mobiriseicons/24 px/mobirise/style.css" rel="stylesheet" type="text/css"
        media="all" />
    <link href="<?php echo $config['Core'] ?>cportal/Resources/Css/gen.css" rel="stylesheet" type="text/css"
        media="all" />
        <link rel="manifest" href="./manifestcp.json">
    <?php
$baseFore = ['0,0,0','66,143,199'];
  $portaldet = $dbo->SelectFirstRow("portal_tb");
  //exit(json_encode($portaldet));
  if(is_array($portaldet)){
    $colors = trim($portaldet['colorScheme']);
    if($colors != ""){
      $baseFore = explode(";",$colors);
    }
  }

?>
    <style>
    .text-color-base {
        color: rgb(<?php echo $baseFore[0] ?>);
    }

    .bg-color-base {
        background-color: rgb(<?php echo $baseFore[0] ?>);
    }

    .text-color-fore {
        color: rgb(<?php echo $baseFore[1] ?>);
    }

    .bg-color-fore {
        background-color: rgb(<?php echo $baseFore[1] ?>);
    }

    .pr-box {
        display: inline-block;
    }

    .pr-progress {
        width: 100px;
        height: 100px;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .pr-progress>.pr-inner {
        position: absolute;
        color: red;
    }

    .pr-progress>svg {
        height: 100%;
        display: block;
    }
    </style>
    <script type="text/javascript">
    function resizeIframe(obj) {
        //alert('aaa');
        obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
        //alert(obj.contentWindow.document.body.scrollHeight + 'px');
    }
    var bar = null;
    var cur = 0.1;

    function pProgress() {
        /* var progressBar = 
          new ProgressBar.Circle('#pr-progress', {
            color: 'red',
            strokeWidth: 10,
            duration: 2000, // milliseconds
            easing: 'easeInOut'
          });

        progressBar.animate(0.91); */
        bar = new ProgressBar.Circle("#pr-container", {
            color: '#aaa',
            // This has to be the same size as the maximum width to
            // prevent clipping
            strokeWidth: 4,
            trailWidth: 1,
            easing: 'easeInOut',
            duration: 1400,
            text: {
                autoStyleContainer: false
            },
            from: {
                color: '#aaa',
                width: 1
            },
            to: {
                color: '#333',
                width: 4
            },
            // Set default step function for all animate calls
            step: function(state, circle) {
                circle.path.setAttribute('stroke', state.color);
                circle.path.setAttribute('stroke-width', state.width);

                var value = Math.round(circle.value() * 100);
                if (value === 0) {
                    circle.setText('');
                } else {
                    circle.setText(value);
                }

            }
        });
        bar.text.style.fontFamily = '"Raleway", Helvetica, sans-serif';
        bar.text.style.fontSize = '2rem';

        bar.animate(cur);
    }

    function mooo() {
        cur += 0.1;
        bar.animate(cur); // Number from 0.0 to 1.0
    }
    /* // Load the Visualization API and the controls package.
      google.charts.load('current', {'packages':['corechart', 'controls']});

// Set a callback to run when the Google Visualization API is loaded.
google.charts.setOnLoadCallback(drawDashboard);

// Callback that creates and populates a data table,
// instantiates a dashboard, a range slider and a pie chart,
// passes in the data and draws it.
function drawDashboard() {

  // Create our data table.
  var data = google.visualization.arrayToDataTable([
    ['Name', 'Donuts eaten'],
    ['Michael' , 5],
    ['Elisa', 7],
    ['Robert', 3],
    ['John', 2],
    ['Jessica', 6],
    ['Aaron', 1],
    ['Margareth', 8]
  ]);

  // Create a dashboard.
  var dashboard = new google.visualization.Dashboard(
      document.getElementById('dashboard_div'));

  // Create a range slider, passing some options
  var donutRangeSlider = new google.visualization.ControlWrapper({
    'controlType': 'NumberRangeFilter',
    'containerId': 'filter_div',
    'options': {
      'filterColumnIndex': 1
    }
  });

  // Create a pie chart, passing some options
  var pieChart = new google.visualization.ChartWrapper({
    'chartType': 'PieChart',
    'containerId': 'chart_div',
    'options': {
      'width': 300,
      'height': 300,
      'pieSliceText': 'value',
      'legend': 'right'
    }
  });

  // Establish dependencies, declaring that 'filter' drives 'pieChart',
  // so that the pie chart will only display entries that are let through
  // given the chosen slider range.
  dashboard.bind(donutRangeSlider, pieChart);

  // Draw the dashboard.
  dashboard.draw(data);
} */
    </script>
</head>

<body id="Default" class="Defaultbg">

    <?php 
//print_r($config);
//add the printer design template 
AddPrinterPreview(); 

//add the option box
AddOptionBox();
$schoolDet = $dbo->Select4rmdbtbFirstRw("school_tb","","");
if(is_array($schoolDet)){
  //echo json_encode($schoolDet)
?>

    <!--Main Page Header
http://localhost.com/epdevelop/cportal/Reports/Exams/resultsheet.php?rstudstudy=5&rstudfac=1&rstuddept=3&rstudprog=3&rstudlvl=1&semest=1&sestb=1&rcourse=10-->
    <div id="Header">
       <button type="button" onclick="document.querySelector('.toolboxR.toolbox').classList.add('toolboxOpen')" class="menubtn-main showExplorer">
           <i class="mbri-menu showExplorer"></i>
       </button>
        <div class="menubtn" id="MenuInfo" title="<?php echo $schoolDet["Name"] ?>" onclick=""><img
                src="Files/<?php echo $schoolDet["logo"] ?>" alt="<?php echo $schoolDet["Name"] ?>" /></div>
        <h1 id="SchoolName" onclick="Fender.Close();"><span id="NamesAbbr"><?php echo $schoolDet["Abbr"] ?></span><span id="Names"><?php echo $schoolDet["Name"] ?></span><span id="DateTime" class="OtherColor"> </span>
            <div class="clear"></div>
        </h1>
        <div class="menubtn" id="LoginInfo" title=""><img id="userloginimgsm" src="" alt="" /></div>
        <div class="clear"></div>
    </div>
    <div id="genloading"><i class="fa fa-spinner fa-spin" style="color:#FFF"></i></div>

    <?php
}else{
	echo "Page Error";
}

?>
    <!--<div id="lockscreen">
  
</div> -->
    <!--Loading Element-->
    <!--<div id="mainLoader" class="">
 
  <div id="movingbg"></div>
  <img src="Resources/Images/eduportaimg.png" alt="eduPORTAL" id="eduportLogo" onload=""  />
  </div>-->

    <!--main menus-->

    <!--<div class="messagebx">
     Error Message
  </div>-->

    <!--Main Login-->


    <!--Left and Right Fenders-->
    <!--Left Fenders-->
    <!-- <div class="Fender" id="FenderLeft">
    
  </div>-->
    <!--Right Fenders-->
    <!--  <div class="Fender" id="FenderRight">
     
     <div class="textBx" id="tbnw">
       <input  type="text" id="tbnw_id" value="" placeholder="Enter Text" />
     </div> 
  
  </div>-->


    <!--<div class="pgmain" id="newpg" >
  
</div>
<div id="addmarker"></div>-->

    <!-- <div id="Pagescont">
<img id="pagescontclose" src="TaquaLB/Elements/Images/close.png" width="40" height="40" alt="Close"  />
<div style="clear:both"></div>
<div class="indbox">
    <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/student.png" alt="Student" />
    <div class="title">Student</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/course.png" alt="Student" />
    <div class="title">Course</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/school.png" alt="Student" />
    <div class="title">School</div>
 </div>
 <div class="indbox"></div>
</div>-->

<script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('swcp.js')
            .then(regObj => console.log("Service worker registered"))
            .catch(err => console.log("An error occured", err))
    }


 //app installation Prompt
 let deferredPrompt;
  //const addBtn = document.querySelector('.add-button');
  //addBtn.style.display = 'none';

  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent Chrome 67 and earlier from automatically showing the prompt
    e.preventDefault();
    // Stash the event so it can be triggered later.
    deferredPrompt = e;
    // Update UI to notify the user they can add to home screen
    //addBtn.style.display = 'block';
   
    OptionBox.Show({
        Logo:"cogs",
					Title: "INSTALL CPORTAL",
                    TitleHTML:`<h1 class="appcolor">Congratulations !!!</h1><p>This Application is available for your device.</p>`,
					Options: [{
						Logo: "cogs",
						Title: "INSTALL",
						Info: "Install the Cportal on your device",
						Function: function () {
							// Show the prompt
                        deferredPrompt.prompt();
                        // Wait for the user to respond to the prompt
                        deferredPrompt.userChoice.then((choiceResult) => {
                            if (choiceResult.outcome === 'accepted') {
                            //console.log('User accepted the A2HS prompt');
                            } else {
                            //console.log('User dismissed the A2HS prompt');
                            }
                            deferredPrompt = null;
                        });
						},
						 Parameter:deferredPrompt
					},
					{
						Logo: "times",
						Title: "Cancel",
						Info: "Abort the Install Operation",
						Function: function () {
							//MessageBox.Show("Print Operation Canceled");
						},
						//Parameter:selectedRegNo
					}]

				});
  
  });

   
    </script>

</body>

</html>