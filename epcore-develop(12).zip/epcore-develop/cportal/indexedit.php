<?php
require("../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require("../epconfig/TaquaLB/Elements/Elements.php");

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Control Portal</title>
<!--Load the AJAX API
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>-->

<script src="../epconfig/TaquaLB/Loader/Loader.js" ansyc loadtype="Premium;Resources/Javascripts/main.js;../portal/UserScript/Payment/pay.js" onComplete="Loading.Start()"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/progressbar.js/1.0.1/progressbar.min.js"></script>
<!-- <script src="../epconfig/ProgressBar/lib/control/progressbar.min.js"></script> -->

<link href="https://fonts.googleapis.com/css?family=Encode+Sans+Condensed" rel="stylesheet">
<link href="Resources/Css/main.css" rel="stylesheet" type="text/css" media="all" />
<link href="../epconfig/GenScript/CSS/logos/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="../epconfig/GenScript/CSS/gen.min.css" rel="stylesheet" type="text/css" media="all" />
<?php
$baseFore = ['0,0,0','66,143,199'];
  $portaldet = $dbo->SelectFirstRow("portal_tb");
  if(is_array($portaldet)){
    $colors = trim($portaldet['colorScheme']);
    if($colors != ""){
      $baseFore = explode(";",$colors);
    }
  }

?>
<style>
.text-color-base{
  color:rgb(<?php  echo $baseFore[0] ?>);
}
.bg-color-base{
  background-color:rgb(<?php  echo $baseFore[0] ?>);
}
.text-color-fore{
  color:rgb(<?php  echo $baseFore[1] ?>);
}
.bg-color-fore{
  background-color:rgb(<?php  echo $baseFore[1] ?>);
}
.pr-box {
  display: inline-block;
}

.pr-progress {
  width: 100px;
  height: 100px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.pr-progress > .pr-inner {
  position: absolute;
  color: red; 
}

.pr-progress > svg {
  height: 100%;
  display: block;
}


</style>
<script type="text/javascript">
function resizeIframe(obj) {
   //alert('aaa');
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
    //alert(obj.contentWindow.document.body.scrollHeight + 'px');
  }
var bar = null;
var cur = 0.1;
function pProgress(){
  /* var progressBar = 
    new ProgressBar.Circle('#pr-progress', {
      color: 'red',
      strokeWidth: 10,
      duration: 2000, // milliseconds
      easing: 'easeInOut'
    });

  progressBar.animate(0.91); */
   bar = new ProgressBar.Circle("#pr-container", {
  color: '#aaa',
  // This has to be the same size as the maximum width to
  // prevent clipping
  strokeWidth: 4,
  trailWidth: 1,
  easing: 'easeInOut',
  duration: 1400,
  text: {
    autoStyleContainer: false
  },
  from: { color: '#aaa', width: 1 },
  to: { color: '#333', width: 4 },
  // Set default step function for all animate calls
  step: function(state, circle) {
    circle.path.setAttribute('stroke', state.color);
    circle.path.setAttribute('stroke-width', state.width);

    var value = Math.round(circle.value() * 100);
    if (value === 0) {
      circle.setText('');
    } else {
      circle.setText(value);
    }

  }
});
bar.text.style.fontFamily = '"Raleway", Helvetica, sans-serif';
bar.text.style.fontSize = '2rem';

bar.animate(cur); 
}

function mooo(){
  cur += 0.1;
  bar.animate(cur);  // Number from 0.0 to 1.0
}
      /* // Load the Visualization API and the controls package.
      google.charts.load('current', {'packages':['corechart', 'controls']});

// Set a callback to run when the Google Visualization API is loaded.
google.charts.setOnLoadCallback(drawDashboard);

// Callback that creates and populates a data table,
// instantiates a dashboard, a range slider and a pie chart,
// passes in the data and draws it.
function drawDashboard() {

  // Create our data table.
  var data = google.visualization.arrayToDataTable([
    ['Name', 'Donuts eaten'],
    ['Michael' , 5],
    ['Elisa', 7],
    ['Robert', 3],
    ['John', 2],
    ['Jessica', 6],
    ['Aaron', 1],
    ['Margareth', 8]
  ]);

  // Create a dashboard.
  var dashboard = new google.visualization.Dashboard(
      document.getElementById('dashboard_div'));

  // Create a range slider, passing some options
  var donutRangeSlider = new google.visualization.ControlWrapper({
    'controlType': 'NumberRangeFilter',
    'containerId': 'filter_div',
    'options': {
      'filterColumnIndex': 1
    }
  });

  // Create a pie chart, passing some options
  var pieChart = new google.visualization.ChartWrapper({
    'chartType': 'PieChart',
    'containerId': 'chart_div',
    'options': {
      'width': 300,
      'height': 300,
      'pieSliceText': 'value',
      'legend': 'right'
    }
  });

  // Establish dependencies, declaring that 'filter' drives 'pieChart',
  // so that the pie chart will only display entries that are let through
  // given the chosen slider range.
  dashboard.bind(donutRangeSlider, pieChart);

  // Draw the dashboard.
  dashboard.draw(data);
} */

</script>
</head>
<body id="Default" class="Defaultbg">

<?php 
//add the printer design template 
AddPrinterPreview(); 
//add the option box
AddOptionBox();
$schoolDet = $dbo->Select4rmdbtbFirstRw("school_tb","","");
if(is_array($schoolDet)){
?>
<!--Main Page Header
http://localhost.com/epdevelop/cportal/Reports/Exams/resultsheet.php?rstudstudy=5&rstudfac=1&rstuddept=3&rstudprog=3&rstudlvl=1&semest=1&sestb=1&rcourse=10-->
   <div id="Header" >
   
      <div class="menubtn" id="MenuInfo" title="<?php echo $schoolDet["Name"] ?>" onclick=""><img src="../epconfig/<?php echo $schoolDet["logo"] ?>" alt="<?php echo $schoolDet["Name"] ?>" /></div>
      <h1 id="SchoolName" onclick="Fender.Close();"><span id="Names"><?php echo $schoolDet["Name"] ?></span><span id="DateTime" class="OtherColor" style="display:none"> </span><div class="clear"></div></h1>
      <div class="menubtn" id="LoginInfo" title="" ><img id="userloginimgsm" src="Resources/Images/user.jpg" alt="" /></div>
      <div class="clear"></div>
   </div>
   <div id="genloading"><i class="fa fa-spinner fa-spin"></i></div>
   
<?php
}else{
	echo "Page Error";
}

?>
<!--<div id="lockscreen">
  
</div> -->
 <!--Loading Element-->
  <!--<div id="mainLoader" class="">
 
  <div id="movingbg"></div>
  <img src="Resources/Images/eduportaimg.png" alt="eduPORTAL" id="eduportLogo" onload=""  />
  </div>-->
  
  <!--main menus-->
  
  <!--<div class="messagebx">
     Error Message
  </div>-->
  
  <!--Main Login-->
  
  
  <!--Left and Right Fenders-->
  <!--Left Fenders-->
 <!-- <div class="Fender" id="FenderLeft">
    
  </div>-->
  <!--Right Fenders-->
<!--  <div class="Fender" id="FenderRight">
     
     <div class="textBx" id="tbnw">
       <input  type="text" id="tbnw_id" value="" placeholder="Enter Text" />
     </div> 
  
  </div>-->
 
  
<!--<div class="pgmain" id="newpg" >
  
</div>
<div id="addmarker"></div>--> 

<!-- <div id="Pagescont">
<img id="pagescontclose" src="TaquaLB/Elements/Images/close.png" width="40" height="40" alt="Close"  />
<div style="clear:both"></div>
<div class="indbox">
    <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/student.png" alt="Student" />
    <div class="title">Student</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/course.png" alt="Student" />
    <div class="title">Course</div>
 </div>
 <div class="indbox">
   <img class="cnclbtn" title="Close" src="TaquaLB/Elements/Images/cancel.png" alt="Close" />
    <img class="mlogo" title="Student" src="Files/MenuImages/school.png" alt="Student" />
    <div class="title">School</div>
 </div>
 <div class="indbox"></div>
</div>-->

</body>
</html>
