<?php
$SubDir = urldecode($_POST['SubDir']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
//sleep(5);
//echo "1~akakka~jsjsjsj";exit;
if(isset($_POST['email']) && trim($_POST['email']) != ""){
   $email = $dbo->SqlSafe($_POST['email']);
   $emailrec = $dbo->Select4rmdbtbFirstRw("user_tb","","UserLogName = '$email'");
   if(is_array($emailrec)){
	   echo $emailrec['UserID'] . "~" .$emailrec['UserLogName']  . "~" . $emailrec['UserName'];
   }else{
	  echo "##"; 
   }
}

?>