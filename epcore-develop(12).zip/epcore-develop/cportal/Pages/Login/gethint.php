<?php
$SubDir = urldecode($_POST['SubDir']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
$email = $dbo->SqlSafe(@$_POST['email']);
if(trim($email) == ""){
    exit("#Invalid Username Supplied");
}

$rst = $dbo->RunQuery("SELECT Hint FROM user_tb WHERE UserLogName = '$email' LIMIT 1");
if(is_array($rst)){
    if($rst[1] > 0){ //user found
       $rstarr = $rst[0]->fetch_array();
       $hint = $rstarr['Hint'];
       if(trim($hint) == ""){
           exit("Hint not Exist");
       }
       exit("*Hint: ".$hint);
    }else{ //user not exsit
      exit("#Invalid User");
    }
}else{ //error runing query
    exit("#Internal Error: Cannot get Hint");
}

?>