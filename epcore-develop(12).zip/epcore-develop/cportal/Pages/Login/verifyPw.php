<?php
//session_start();
$SubDir = urldecode($_POST['SubDir']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
if(isset($_POST['email']) && trim($_POST['email']) != "" && isset($_POST['pw']) && trim($_POST['pw']) != ""){
   $email = $dbo->SqlSafe($_POST['email']); //admin@eduporta.com
   $pw = $dbo->SqlSafe($_POST['pw']);
   //$hash = $dbo->Hash($pw);
   //$dbo->Insert2DbTb(array("UserLogName"=>$email,"UserPassw"=>$hash[0],"enc"=>$hash[1]),"user_tb");
   $enc = $dbo->Select4rmdbtbFirstRw("user_tb","enc","UserLogName = '$email'"); 
   //$enc = array();
   if(is_array($enc)){
	  $enc = $enc[0];
	 // $enc = "W.%#Š·ÒCÒ‚åÝs‰¼‡";
	 //$hash = $dbo->Hash("eduporta@admin"); 
	  $hash = $dbo->Hash($pw,$enc); //eduporta@admin
	  $hashpw = $hash[0];
	  //$salt = $hash[1];
	  //echo "UserLogName = $email and UserPassw = $hashpw and enc = $salt";
	  //echo $dbo -> getToken(20);
	  //exit;
	 $emailrec = $dbo->Select4rmdbtbFirstRw("user_tb","","UserLogName = '$email' and UserPassw = '$hashpw'");
	 if(is_array($emailrec)){
		 echo $emailrec['UserID'] . "~" .$emailrec['UserLogName'] . "~" . $emailrec['UserName'] . "~" . $emailrec['IdleTime'] . "~" . $emailrec['PinStatus'] . "~" . $emailrec['MaxEntry']."~" . $emailrec['Privs'];
		 $_SESSION['UID'] = $emailrec['UserID'];
		 //$user['UserID']."~".$user['UserLogName']."~".$user['UserName']."~".$user['IdleTime']."~".$user['PinStatus']."~".$user['MaxEntry'];
	 }else{
		echo "#"; 
	 }
   }else{
	 echo "#";   
   }
}else{
	 echo "##"; 
}

?>