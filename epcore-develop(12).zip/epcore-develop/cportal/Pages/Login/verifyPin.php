<?php
//sleep(4);
$SubDir = urldecode($_POST['SubDir']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
if(isset($_POST['email']) && trim($_POST['email']) != "" && isset($_POST['pin']) && trim($_POST['pin']) != ""){
   $email = $dbo->SqlSafe($_POST['email']);
   $pin = $dbo->SqlSafe($_POST['pin']);
   //encode pin before verification
   
   ////////////////////////////////
   $emailrec = $dbo->Select4rmdbtbFirstRw("user_tb","","UserLogName = '$email' and pin = '$pin'");
   if(is_array($emailrec)){
	   echo $emailrec['UserID'] . "~" .$emailrec['UserLogName'] . "~" . $emailrec['UserName'];
   }else{
	  echo "#".$emailrec; 
   }
}else{
	 echo "##"; 
}

?>