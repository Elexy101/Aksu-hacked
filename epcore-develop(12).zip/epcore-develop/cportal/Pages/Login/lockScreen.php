<?php //sleep(4); 
$SubDir = urldecode($_POST['SubDir']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
require_once("../../../general/TaquaLB/Elements/Elements.php");
?>
<!-- <div id="lockpinbox" style="-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none;" unselectable="on" onselectstart="return false;" onmousedown="return false;">
    <input type="password" id="screen" readonly value="" />
    <div class="button" title="1"  onClick="Lock.KeyPress(this)" >1</div>
    <div class="button" onClick="Lock.KeyPress(this)" title="2abc" >2<span>abc</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="3def">3<span>def</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="4ghi">4<span>ghi</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="5jkl">5<span>jkl</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="6mno">6<span>mno</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="7pqrs">7<span>pqrs</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="8tuv">8<span>tuv</span></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="9wxyz">9<span>wxyz</span></div>
    <div class="button" id="backspbtn" onClick="Lock.KeyBack()"  title="Clear"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i></div>
    <div class="button" onClick="Lock.KeyPress(this)"  title="0" >0</div>
    <div class="button" id="enterbtn" onClick="Lock.Enter(Login.Unlock)"  title="Enter">
    
      <i id="lockenterlogo" class="fa fa-unlock-alt"></i>
      <i id="lockenterloading" class="fa fa-circle-o-notch fa-spin"></i>
    
    </div>
  </div> -->

  <?php
  $uid = $_REQUEST['UID'];
  $userdet = $dbo->Select4rmdbtbFirstRw("user_tb","","UserID = $uid");
  $idletime = 30;
  $maxRetry = 8;
  if(is_array($userdet)){
    $idletime = (int)$userdet['IdleTime'];
    $maxRetry = $userdet['MaxEntry'];
  }
        GroupBox("title=Pin,id=pingrp,class=lockpinbox,style=width:290px;height:400px;");
           // TextBox("title=Password,style=width:270px,id=opassw,textchange=,logo=unlock,type=password");
               //SubHeader(Icon("lock"));
               Hidden("idletime_h",$idletime);
               TextBox("title=Type your Pin,style=width:270px;margin-top:30px;text-align:center,id=screen,textchange=,logo=lock,type=password,readonly=true");
               Box("style=margin:10px");
                  echo '<span style="font-weight:bold;color:#777;font-size:0.7em;text-transform:uppercase">RETRY: </span>';
                  echo '<span style="font-weight:bold;font-size:0.7em;color:rgba(86,176,55,1)" ><span id="retryfield">0</span>/<span id="maxretryfield">'.$maxRetry.'</span></span>';
               _Box();
               Box("style=margin:auto;margin-top:10px;margin-left:30px;-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none, unselectable=on,onselectstart=return false;,onmousedown=return false;");
                  SmallButton("id=p1,text=1,style=margin:10px,title=1,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p2,text=2,style=margin:10px,title=2,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p3,text=3,style=margin:10px,title=3,onclick=Lock.KeyPress(this)");
                  NL();
                  SmallButton("id=p4,text=4,style=margin:10px,title=4,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p5,text=5,style=margin:10px,title=5,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p6,text=6,style=margin:10px,title=6,onclick=Lock.KeyPress(this)");
                  NL();
                  SmallButton("id=p7,text=7,style=margin:10px,title=7,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p8,text=8,style=margin:10px,title=8,onclick=Lock.KeyPress(this)");
                  SmallButton("id=p9,text=9,style=margin:10px,title=9,onclick=Lock.KeyPress(this)");
                  NL();
                  SmallButton("id=pclear,logo=arrow-circle-left,style=margin:10px,title=Clear,onclick=Lock.KeyBack()");
                  SmallButton("id=cleargen,text=0,style=margin:10px,title=0,onclick=Lock.KeyPress(this)");
                  SmallButton("id=usegen,text=C,style=margin:10px,title=Cancel,onclick=Lock.KeyCancel()");
               _Box();
        _GroupBox();
  ?>