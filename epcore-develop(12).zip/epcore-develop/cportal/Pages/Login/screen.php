<?php
//session_start();
$SubDir = urldecode($_POST['SubDir']);
$Core = urldecode($_POST['Core']);
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php");
require_once("../../../general/TaquaLB/Elements/Elements.php");
//get school details
$schdet = $dbo->SelectFirstRow("school_tb");
$portal = $dbo->SelectFirstRow("portal_tb");
$UID = $_POST['UID'];
   ?>

     <div id="loginContInner" >
    <!--  <div class="pr-box">
  <div class="pr-progress" id="pr-progress">
    <div class="pr-inner">
      heart
    </div>
  </div>
</div> -->

        <div id="header">
          <!-- <div><i class="fa fa-user fa-2x" style="color:#666" aria-hidden="true"></i></div> <div id="userLoginName"> User Login</div> -->
          <img src="<?php echo $Core ?>images/App/Images/eplogosm.png" style="display:inline-block;height:40px;vertical-align:middle" onclick="mooo()" />
          <div  style="display:inline-block;height:40px;vertical-align:middle; width:auto;font-size:0.8em;margin-top: 0px">
          <div style="font-weight:bold;color:#555;display:block;height: auto;margin-top: 0px;padding: 0px;"><?php echo $portal['BrandName'] ?> &trade;</div>
          <div style="color:#3E4095;display:block;font-size:1.1em;height: auto;margin-top: 0px;padding: 0px;">cPortal</div>
        </div>
        </div>
        <div style="padding:0px 15px;color:#777;margin-bottom:15px" id="userLoginName"></div>
        <div style="font-weight:bold;color:#777;padding:0px 25px;font-size:1.3em" id="screentxt" onclick="pProgress()">Sign In</div>
        <div style="height:250px; padding-top:0px; display:none" id="UserimgrCont" >
        <div id="Userimg" onclick="">
          <div id="userimgInner">
            <img id="userimgInnerReal" src="Files/MenuImages/result.PNG" alt="User" />
          </div>
        </div>
        </div>
         <?php
		 Form("id=lngfrm,name=lngfrm,action=javascript:Login.Verify(),method=post");
		  TextBox("title=Provide your Email,style=width:calc(100% - 40px);margin:auto;margin-top:10px;background:transparent;font-size:1.2em,id=usernm,logo=user");
		  TextBox("title=Provide your Password,style=width:calc(100% - 40px);margin:auto;margin-top:10px;display:none;opacity:0;background:transparent;font-size:1.2em,id=userpssw,type=password,logo=user-secret");
      Box("style=width:calc(100% - 40px);margin:auto; color:#666;cursor:pointer");
         Box("style=float:right; margin-left:10px,title=Recorver Password");Icon("recycle");_Box();
         Box("style=float:right; margin-left:10px,title=Hint,onclick=Login.GetHint(),id=hintcont");Icon("question");_Box();
         ClearFloat();
      _Box();
      FlatButton("text=Continue,style=width:auto;display:inline-block;float:right;margin-top:25px;margin-right:20px,onclick=_('lngfrm').submit(),id=veridybtn,submit=true,logo=check-circle");
      echo '<div style="clear:both"></div>';
      _Form();
      
      
		 /*Radio("group=aaa,id=r3");
		 Radio("group=aaa,id=r4");
		 Radio("group=aaa,id=r5");*/
		 if(isset($UID) && (int)$UID != 0){
			 $dbo->Updatedbtb("user_tb",array("Online"=>0),"UserID = $UID");
     }
     //destroy the session
     $dbo->Destroy_Session();
	  ?>
        <div style="font-size:0.7em; color:#777;padding:20px 0px 0px 20px">&copy; 2018 <?php echo $portal['BrandName'] ?> - <?php echo $schdet['Name'] ?></div>
     </div>
  
  
<!--<div class="HeaderTop">-->
     
  <!--</div>-->
  
 