<?php
//dash board common functions
function LoadRegistration($putme,$pref = ""){
	$rtn = _LoadRegistration($putme,$pref);
	
	if(is_numeric($rtn)){
		$id = $pref == "p"?"dashBEntrCont":"dashBSchCont";
		echo '<div class="progressbarbx">
      <div class="progressbar">
        <div class="bar" style="width:'.$rtn.'%" id="'.$id.'Bar"></div>
      </div>
      <div class="perc"  id="'.$id.'Perc">'.$rtn.'%</div>
    </div>';
	}else{
		echo $rtn;
	}
}
function _LoadRegistration($putme,$pref = ""){
	global $dbo;
if($putme["Status"] == "CLOSED" || $putme["Status"] == "--"){ 
  // return $putme["Status"];
   return '<div class="status">  '.$putme["Status"].'  </div>';
    }else if($putme["DashBoard"] == "STATUS"){
		//return "on";
   return '<div class="status"> on </div>';
    }else{ 
	//echo "aaa";
       //get total putme for the current ses
	   $totstud = $dbo->Select4rmdbtbFirstRw($pref."studentinfo_tb","count(id)","StartSes = (select SesID from session_tb where Enable = 1 order by Current desc,SesID desc limit 1)");
	   
	   if(is_array($totstud)){
		   $totstud =$totstud[0];
		   if($totstud > 0){
			    $regstud = $dbo->Select4rmdbtbFirstRw($pref."studentinfo_tb","count(id)","StartSes = (select SesID from session_tb where Enable = 1 order by Current desc,SesID desc limit 1) and RegLevel = 6");
				if(is_array($regstud)){
					$regstud =$regstud[0];
					$totstud = ($regstud/$totstud)*100;
					$totstud = round($totstud);
					$totstud =  $totstud > 100 ?100:$totstud;
					
				}else{
					$totstud = 0;
				}
		   }
	   }else{
		   $totstud = 0;
	   }
	   return $totstud;
  
     /* echo '<div class="progressbarbx">
      <div class="progressbar">
        <div class="bar" style="width:'.$totstud.'%"></div>
      </div>
      <div class="perc">'.$totstud.'%</div>
    </div>';*/
    } 	
	
}


function _LoadDashCourseReg($coursecontr){
	global $dbo;
  if($coursecontr["Status"] == "CLOSED" || $coursecontr["Status"] == "--"){ 
    //return $coursecontr["Status"];
   return '<div class="status">  '.$coursecontr["Status"].'  </div>';
    }else if($coursecontr["DashBoard"] == "STATUS"){
	//return "on";	
   return '<div class="status"> on </div>';
    }else{ 
	  $totrst = 0;
	  //get total number of student expected to register in the cureent ses
	   $totstudc = $dbo->RunQuery("select count(s.id)  from studentinfo_tb s, programme_tb p, modeofentry_tb m where s.ProgID = p.ProgID and s.ModeOfEntry = m.Level and p.YearOfStudy >= (select SesID from session_tb where Enable = 1 order by Current desc,SesID desc limit 1) +  m.Level - s.StartSes and s.RegLevel = 6");
	   if(is_array($totstudc)){
		 $rst =   $totstudc[0]->fetch_array();
		 $totrst = $rst[0];
	   }
	   
	   if($totrst > 0){
		   $regstudcourses = $dbo->Select4rmdbtbFirstRw($pref."coursereg_tb","count(ID)","SesID = (select SesID from session_tb where Enable = 1 order by Current desc,SesID desc limit 1) and Sem = (select IF(Num=0,ID,Num) as ID from semester_tb where Enable = 1 ORDER BY Current DESC limit 1)");
		  $totregcourse = 0;
		   if(is_array($regstudcourses)){
			   $totregcourse = $regstudcourses[0];  
		   }
		   $per = round(($totregcourse/$totrst)*100);
		   $per = $per > 100?100:$per;
	   }
  return $per;
	
	}	
	
}

function LoadDashCourseReg($coursecontr){
	$rtn = _LoadDashCourseReg($coursecontr);
	if(is_numeric($rtn)){
		echo '<div class="progressbarbx">
      <div class="progressbar">
        <div class="bar" style="width:'.$rtn.'%" id="dashBCourseContBar"></div>
      </div>
      <div class="perc"  id="dashBCourseContPerc" >'.$rtn.'%</div>
    </div>';
	}else{
		echo $rtn;
	}
}

function _SchoolPay($payrst){
   if($payrst["Status"] == "CLOSED" || $payrst["Status"] == "--"){ 
   return '<div class="status">'.$payrst["Status"].'</div>';
    }else{
   return '<div class="status">on</div>';
	}	
}

function SchoolPay($payrst){
	echo _SchoolPay($payrst);
}

function _UnreadMails($UID){
	global $dbo;
	//get total number of user unread mails
     $totmail = "--";
	 if(isset($UID)){
	   $totunmail = $dbo->RunQuery("select count(ID)  from mail_tb where (Receiver LIKE '$UID' OR Receiver LIKE '$UID:::%' OR Receiver LIKE '%:::$UID:::%' OR Receiver LIKE '%:::$UID') AND (ReadMail NOT LIKE '$UID' AND ReadMail NOT LIKE '$UID:::%' AND ReadMail NOT LIKE '%:::$UID:::%' AND ReadMail NOT LIKE '%:::$UID') ");
	   if(is_array($totunmail)){
		 $rstmail =   $totunmail[0]->fetch_array();
		 $totmail = (int)$rstmail[0]==0?"--":$rstmail[0];
	   }
	 }
	// return '<div class="status">'._Logo("bell-o")." ".$totmail.' </div>';
	return $totmail;
}

function UnreadMails($UID){
	echo _UnreadMails($UID);
}

function _OnlineStaff(){
	global $dbo;
  $users = $dbo->Select4rmdbtbFirstRw("user_tb","count(UserID)","Online = 1");
	$onl = "--";
	  if(is_array($users)){
		  $onl = $users[0];
	  }	
	  //return '<div class="status">'._Logo("users")." ".$onl.'</div>';
		return $onl;
}

function OnlineStaff(){
	echo _OnlineStaff();
}
?>