<?php
//print_r($_POST);
//exit();
$subdir = urldecode($_POST['SubDir']);
$core = urldecode($_POST['Core']);
//unset($_POST['SubDir']);

//get the settings
if(!file_exists("../../../../../{$subdir}conf.txt")){
  exit('<div style="color:#fff">No Encrypted Configuration Found</div>');
}

$configdir = "../../../../../{$subdir}";

//error_reporting(1);
require_once("../../../general/config.php");

require_once("../../../general/TaquaLB/Elements/Elements.php");

require_once("dashboard.php");
 $putme = $dbo->Select4rmdbtbFirstRw("putme","","");
 $putme = is_array($putme)?$putme:array("Status"=>"--");
 $form = $dbo->Select4rmdbtbFirstRw("form_tb","","");
 $form = is_array($form)?$form:array("Status"=>"--");
  $coursecontr = $dbo->Select4rmdbtbFirstRw("coursecontrol_tb","","");
 $coursecontr = is_array($coursecontr)?$coursecontr:array("Status"=>"--");
  $payrst = $dbo->Select4rmdbtbFirstRw("schoolpayment_tb","","");
 $payrst = is_array($payrst)?$payrst:array("Status"=>"--");
 $UID = @$_POST['UID'];

 //update user online status
$dbo->Updatedbtb("user_tb",array("Online"=>1),"UserID = $UID");
$user = $dbo->Select4rmdbtbFirstRw("user_tb","","UserID = $UID");
function DisplayStatus($rec,$logo){
   if($rec['Status'] == "OPENED"){
     echo '<i class="fa fa-'.$logo.' fa-2x" aria-hidden="true"></i><br /> OPENED';
   }else{
     echo '<i class="fa fa-'.$logo.' fa-2x" aria-hidden="true"></i><br /> CLOSED';
   }
}

?>

<div class="menucontrolbox"  id="menucontrolboxl" >
  <!--<div title="Pages"><i class="fa fa-files-o" aria-hidden="true"></i></div>-->
  <div title="Lock" onclick="Lock.Show()"><i class="fa fa-key" aria-hidden="true"></i>
</div><div title="Logout" onclick="Login.Logout();" ><i class="fa fa-power-off" aria-hidden="true"></i></div><div class="lst"></div></div>

<div id="menuContDiv">
<a name="dashBanc" id="dashBanc" ></a>
<div class="dashboardContner">

<?php //$putmeSt = $putme['Status'] ==    ?>
<div class="dashboardBox">
   <div class="dashboardSwitch">
     
     <?php
        DisplayStatus($putme,' mbri-login');
        ?>
  </div>
   <div class="dashboardTxt">Entrance Registration</div>
  </div>
  <div class="dashboardBox">
   <div class="dashboardSwitch">
     <?php
        DisplayStatus($form,' mbri-user');
        
        ?>
     </div>
   <div class="dashboardTxt">Bio-Data Registration</div>
  </div>
  <div class="dashboardBox">
   <div class="dashboardSwitch">
     <?php
        DisplayStatus($coursecontr,' mbri-edit');
        ?>
     </div>
   <div class="dashboardTxt">Course Registration</div>
  </div>
  <div class="dashboardBox">
   <div class="dashboardSwitch">
     <?php
        DisplayStatus($payrst,' mbri-cash');
        ?>
     </div>
   <div class="dashboardTxt">School Payment</div>
  </div>
  <div class="dashboardBox">
   <div class="dashboardSwitch"><i class="fa mbri-letter fa-2x" aria-hidden="true"></i> <br />
    <?php
      UnreadMails($UID);
    ?>
   </div>
   <div class="dashboardTxt">Mail</div>
  </div>

  <div class="dashboardBox">
   <div class="dashboardSwitch"><i class="fa mbri-users  fa-2x" aria-hidden="true"></i> <br />
    <?php
      OnlineStaff();
      
    ?>
   </div>
   <div class="dashboardTxt">Online Users</div>
  </div>
  </div>
<!--OnlineStaff()<div class="dashboard" id="dashBEntr">
 <div class="tit">Entrance Registration</div>
 <div class="cont" id="dashBEntrCont">
     <?php //LoadRegistration($putme,"p") ?>
 </div>
</div>
<div class="dashboard" id="dashBSch">
  <div class="tit">Freshers Registration</div>
  <div class="cont" id="dashBSchCont">
   <?php //LoadRegistration($form,"") ?>
  </div>
 </div>
<div class="dashboard" id="dashBCourse">
  <div class="tit">Course Registration</div>
  <div class="cont" id="dashBCourseCont">
  <?php  
   //LoadDashCourseReg($coursecontr);
	?>
  </div>
</div>
<div class="dashboard" id="dashBPay">

 <div class="tit">School Fee Payment</div>
 <div class="cont" id="dashBPayCont">

<?php  
 //SchoolPay($payrst);
?>

   
 </div>
</div>
<div class="dashboard" id="dashBMail">
 <div class="tit">Mails</div>
  <div class="cont"  id="dashBMailCont">
  <?php
  
  //UnreadMails($UID);
  ?>
   
 </div>
</div>
<div class="dashboard" id="dashBOnline">
  <div class="tit">Online Staff</div>
  <div class="cont" id="dashBOnlineCont">
  
    <?php
	 // OnlineStaff();
	?>
    
    <div class="clear"></div>
  </div>
</div>
<div class="clear"></div>
-->
<?php

if(is_array($user)){
  $userdet = $user['UserID']."~".$user['UserLogName']."~".$user['UserName']."~".$user['IdleTime']."~".$user['PinStatus']."~".$user['MaxEntry']."~".$user['Privs'];
   Hidden("userdet",$userdet);
}

$grpctr = '<div title="Dash Board"><a href="#dashBanc">'._Logo("tachometer-alt").'</a></div>';
?>

<div class="left-menus-bx" >
<?php
//holds html of all group element to display in the group control box
$menus = $dbo->Select4rmdbtb("menu_tb","","1=1 ORDER BY GrpOrder");
if(is_array($menus)){
	if($menus[1] > 0){
    $menustr = '';
   // $rst = 
		while($gmenu = $menus[0]->fetch_array()){
			$src = $gmenu["Script"];
      $gname = $gmenu["GName"];
      
			if(trim($src) == ""){
				$fext = file_exists("../Page/".strtolower($gname).".php");
				if($fext){
					$src = $core."cportal/Pages/Page/".strtolower($gname).".php";
				}
			}
			$dname = $gmenu["DName"];
			$Tabs = $gmenu["Tabs"];
      $glogo = _Logo($gmenu["Logo"]);
      //$cl = $grpNamea == $gnamea?"":"closesub";
			$menustr .= '<li class="closesub showExplorer" id="explorermainmenu_'.$gname.'">
			<a class="hoverable showExplorer" onclick="this.parentElement.classList.toggle(\'closesub\')"><span class="imgcont  showExplorer"><i class="fa fa-caret-right showExplorer" aria-hidden="true"></i></span><span class="showExplorer">'.$dname.'</span></a><ul>';
			/*if(!file_exists("../../".$glogo)){
				$glogo = "Files/MenuImages/result.PNG";
			}*/
			?>
      <!-- <div style="margin-left:100px">
      <div id="dashboard_div">-->
      <!--Divs that will hold each control and chart-->
      <!--<div id="filter_div"></div>
      <div id="chart_div"></div>
    </div> 
    </div>-->
     <div class="menuGroupCont greyShadow" style="" id="<?php echo $gname."Menu" ?>">
     <a name="<?php echo $gname."anc" ?>" id="<?php echo $gname."anc" ?>" ></a>
      <div class="soround">
       <div class="gruopmenu" onclick="Login.ShowHideMenus('<?php echo $gname."Menu" ?>')"> 
         <input type="hidden" id="<?php echo $gname."logo" ?>" value="<?php echo $gmenu["Logo"] ?>" />
         <div class="txt" > <?php  echo $glogo ." ".$dname ?> </div>
         <div class="sign" > <?php  echo _Logo("");  ?> </div>
         <div class="clear"></div>
       </div>
       <?php
	      //form the group element for the group control box
		  $grpctr .= '<div title="'.$dname.'" onclick="_(\'lk'.$gname.'anc\').click()"><a id="lk'.$gname.'anc" href="#'.$gname.'anc">'.$glogo.'</a></div>';
	   ?>
       <input type="hidden" id="<?php echo $dname ?>_tabs" value="<?php echo $Tabs ?>"  />
       <div class="menuscont">
         <div class="menubody" >
         <?php
		     if(trim($Tabs) != ""){
				 $tabsarr = explode("&",$Tabs);
				 if(count($tabsarr) > 0){
					 for($r = 0; $r <count($tabsarr); $r++){
						 $tabind = $tabsarr[$r];
						 $tabindarr = explode("=",$tabind);
						 if(count($tabindarr) == 2){
							 $tabname = $tabindarr[0];
               $tabDisname = $tabindarr[1];//'Pages/Fender/left.php',0,'Result','Course'
               $tabNamearr = explode("~",$tabDisname);
               $tabDisname = $tabNamearr[0];
               if(isset($tabNamearr[1]) && trim($tabNamearr[1]) != ""){
                $action = "window.open('".$tabNamearr[1]."')";
               }else{
                  $action = "Page.Open('$src',$r,'$gname','$tabname','$tabDisname')";
               }
              
							 ?>

                              <div id="<?php echo $gname."_".$r ?>" class="menuind <?php echo $tabname ?>" onClick="<?=$action?>"> <img src="<?php echo $core;  ?>cportal/Files/MenuImages/<?php echo strtolower($tabname) ?>.png" alt="<?php echo "" ?>" /> <div><?php echo $tabDisname ?></div></div>
                              <div id="<?= $tabname ?>_data" style="display:none">
                                <?php echo json_encode(["Src"=>$src,"ID"=>$r,"GName"=>$gname,"TName"=>$tabname,"TDisName"=>$tabDisname]) ?>
                              </div>
                             <?php
                             $menustr .= '<li class="showExplorer-d"><a id="explorersubmenu_'.$tabname.'" class="hoverable showExplorer-d exsubitems" href="javascript:void(0)" onclick="Page.OpenByTabName(\''.$tabname.'\',true);Fender.SelectSub(this)"><span class="imgcont showExplorer-d"><img class="showExplorer-d" src="'.$core.'cportal/Files/MenuImages/'.strtolower($tabname).'.png" /></span><span class="showExplorer-d">'.$tabDisname.'</span></a></li><input type="hidden" id="explorersubmenu_'.$tabname.'_gn" value="'.$gname.'" />';
						 }
					 }
				 }
			 }
       $menustr .= '</ul></li>';
		 ?>
         
         <div class="clear"></div>
         </div>
       </div>
      </div>
     </div>
            
            <?php
		}
	}
}else{
 echo $menus;	
}

?>
</div>
<div class="right-menus-bx" >
<div class="menuGroupCont greyShadow" style="border:#CCC solid thin;margin-left:auto;margin-right:auto;width:95%" id="astat">
     
      <div class="soround">
       <div class="gruopmenu" onclick="Login.ShowHideMenus('astat')"> 
         <div class="txt" > <i class="fa fa-pie-chart"></i> Statistics</div>
         <div class="sign" > <?php  echo _Logo("");  ?> </div>
         <div class="clear"></div>
       </div>
       <div class="menuscont">
         <div class="menubody" >
         
         <iframe style="width:98%;margin:auto;height:300px" frameborder="0" scrolling="no" src="<?php echo $core ?>cportal/charts/piestudies.php?core=<?php echo urlencode($core) ?>&subdir=<?php echo urlencode($subdir) ?>" ></iframe>
             <!-- <h2 style="text-align:center" class="altColor"><i class="fa fa-exclamation-triangle"></i><br/>NOT AVAILABLE</h2> -->
         </div>
        </div>
      </div>
    </div>

   

</div>
<div style="height:40px;clear:left" ></div>
</div>
<div class="menucontrolboxtop" id="menucontrolboxl" ><?php  echo $grpctr  ?></div>
<?php $ids = "All";  ?>
<!-- Right Fender -->
<div class="toolboxR toolbox wstoolbox" id="genFender">

<!-- Explorer -->
  <div class="explorer">
	 <div class="inner">
	   <div class="expheader showExplorer" onclick="this.parentElement.parentElement.parentElement.classList.toggle('OpenExplorer');">Explorer</div>
	   <ul class="expbody">
		 <!-- <li>
		 <a class="hoverable" onclick="this.parentElement.classList.toggle('closesub')"><i class="fa fa-caret-right" aria-hidden="true"></i><span>Student</span></a>
		 <ul>
		   <li><a class="hoverable" href="javascript:Page.OpenByTabName('psetting',true)"><span class="imgcont"><img src="Files/MenuImages/mngcourse.png" /></span><span>Bio Data</span></a></li>
		 </ul>
		 </li> -->
     <?php echo $menustr; ?>
     <li style="margin-bottom:50px"></li>
	   </ul>
	 </div>
  </div>

  <!-- Settings -->
  <span class="setexplorer">
	 <div class="inner">
	   <div class="expheader showExplorer" onclick="this.parentElement.parentElement.parentElement.classList.toggle('OpenExplorer');">Settings</div>
	   <ul class="expbody">
		 <!-- <li>
		 <a class="hoverable" onclick="this.parentElement.classList.toggle('closesub')"><i class="fa fa-caret-right" aria-hidden="true"></i><span>Student</span></a>
		 <ul>
		   <li><a class="hoverable" href="javascript:Page.OpenByTabName('psetting',true)"><span class="imgcont"><img src="Files/MenuImages/mngcourse.png" /></span><span>Bio Data</span></a></li>
		 </ul>
		 </li> -->
     <?php //echo $menustr; ?>
     <li style="margin-bottom:50px"></li>
	   </ul>
	 </div>
  </span>

   <div id="<?php echo $ids; ?>_userloginbox" title="<?php echo $user['UserName']; ?>"  class ="sel no head" title=""  onclick="this.parentElement.classList.toggle('toolboxOpen')">
   <div class="headinner showExplorer">
<img  id="<?php echo $ids; ?>_userloginboximg"  src="Files/UserImages/<?php echo $user['UserID']; ?>.jpg" alt="" class="showExplorer" /><span class="showExplorer" id="<?php echo $ids; ?>_userloginboximgn"><?php echo str_replace(" ","&nbsp;",strlen($user['UserName']) > 9?substr($user['UserName'],0,9)." ...":$user['UserName']); ?></span>
</div>
   <div class="opener showExplorer" ><i class="fa fa-chevron-right showExplorer" aria-hidden="true"></i></div>
   
   </div>
   

<div title="Explorer" class="explorerbtn showExplorer OpenExplorerbtn" onclick="this.parentElement.classList.toggle('OpenExplorer');this.parentElement.classList.remove('OpenSettings');"><i class="mbri-features showExplorer" aria-hidden="true" ></i><span class="showExplorer">Explorer </span><i class="fa fa-chevron-right ind showExplorer" aria-hidden="true" ></i></div>

   <div title="Home" id="menuhome" onclick="this.parentElement.classList.remove('toolboxOpen');Page.MinimizeAll();Page.HideTaskBar();"><i class="mbri-home" aria-hidden="true"></i><span>Home</span></div>

    <div title="Workspace" id="menuworkspace" onclick="Page.OpenWorkSpace()"><i class="mbri-home" aria-hidden="true"></i><span>Workspace</span></div>

    <div class="sepr"></div>


<div title="Close" onclick="this.parentElement.classList.remove('toolboxOpen');Page.Remove()"><i class="mbri-error" aria-hidden="true"></i><span>Close</span></div>

<div title="Reload All" onclick="this.parentElement.classList.remove('toolboxOpen');Page.Reload()"><i class="mbri-update" aria-hidden="true"></i><span>Reload</span></div>

<div title="Info" onclick="this.parentElement.classList.remove('toolboxOpen');ToolBox.NoFunc()"><i class="mbri-idea" aria-hidden="true"></i><span>Info</span></div>

<div class="sepr"></div>

<div title="Explorer" class="explorerbtn showExplorer OpenSettingsbtn" onclick="this.parentElement.classList.toggle('OpenSettings');this.parentElement.classList.remove('OpenExplorer');"><i class="mbri-setting3 showExplorer" aria-hidden="true" ></i><span class="showExplorer">Settings </span><i class="fa fa-chevron-right ind showExplorer" aria-hidden="true" ></i></div>

<div class="sepr"></div>

<div title="Switch User"  onclick="this.parentElement.classList.remove('toolboxOpen');ToolBox.NoFunc()"><i class="mbri-users" aria-hidden="true"></i><span>Switch</span></div>
<div title="Logout"  onclick="Login.Logout()"><i class="mbri-logout" aria-hidden="true"></i><span>Logout</span></div>
<div title="Lock" onclick="this.parentElement.classList.remove('toolboxOpen');Lock.Show()"><i class="mbri-lock" aria-hidden="true"></i><span>Lock</span></div>

  </div>
  <script>
 
  </script>
  <!-- Right Fender Ends -->
<!--<div class="menuGroupCont">
      <div class="soround">
       <div class="gruopmenu"> 
         <img class="logo" src="Files/MenuImages/result.PNG" alt="Result Logo" />
         <div class="txt" > result </div>
         <div class="clear"></div>
       </div>
       
       <div class="menuscont">
         <div class="menubody" >
            <div id="Result_0" class="menuind" onClick="Page.Open('Pages/Fender/left.php',0,'Result','Course')"> <img src="Files/MenuImages/course.png" alt="Course" /> <div>Courses</div></div>
            <div id="Result_1" class="menuind" onClick="Page.Open('Pages/Fender/left.php',1,'Result','Student')"> <img src="Files/MenuImages/student.png" alt="Student" /> <div>Stundent</div></div>
            <div id="Result_2" class="menuind" onClick="Page.Open('Pages/Fender/left.php',2,'Result','School')"> <img src="Files/MenuImages/school.png" alt="School" /> <div>School</div></div>
            <div class="clear"></div>
         </div>
       </div>
      </div>
     </div>
     
 
 <div class="menuGroupCont">
      <div class="soround">
       <div class="gruopmenu"> 
         <img class="logo" src="Files/MenuImages/result.PNG" alt="Result Logo" />
         <div class="txt" > Testing </div>
         <div class="clear"></div>
       </div>
       
       <div class="menuscont">
         <div class="menubody" >
            <div  id="ResultTest_0" class="menuind" onClick="Page.Open('Pages/Fender/left.php',0,'ResultTest','Course')"> <img src="Files/MenuImages/course.png" alt="Course" /> <div>Course Test</div></div>
            <div  id="ResultTest_1" class="menuind" onClick="Page.Open('Pages/Fender/left.php',1,'ResultTest','Student')"> <img src="Files/MenuImages/student.png" alt="Student" /> <div>Stundent Test</div></div>
            <div  id="ResultTest_2" class="menuind" onClick="Page.Open('',2,'ResultTest','School')"> <img src="Files/MenuImages/school.png" alt="School" /> <div>School Test</div></div>
            <div class="clear"></div>
         </div>
       </div>
      </div>
     </div>-->