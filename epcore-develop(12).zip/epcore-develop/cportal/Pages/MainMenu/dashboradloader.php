<?php
require_once("../../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require_once("../../../epconfig/TaquaLB/Elements/Elements.php");
require_once("dashboard.php");
$putme = $dbo->Select4rmdbtbFirstRw("putme","","");
 $putme = is_array($putme)?$putme:array("Status"=>"--");
 $form = $dbo->Select4rmdbtbFirstRw("form_tb","","");
 $form = is_array($form)?$form:array("Status"=>"--");
  $coursecontr = $dbo->Select4rmdbtbFirstRw("coursecontrol_tb","","");
 $coursecontr = is_array($coursecontr)?$coursecontr:array("Status"=>"--");
  $payrst = $dbo->Select4rmdbtbFirstRw("schoolpayment_tb","","");
 $payrst = is_array($payrst)?$payrst:array("Status"=>"--");
 $UID = $_POST['UID'];
 $entrance = _LoadRegistration($putme,"p");
 $schreg = _LoadRegistration($form,"");
 $courseReg = _LoadDashCourseReg($coursecontr);
 $schpay = _SchoolPay($payrst);
 $mails = _UnreadMails($UID);
 $sonline = _OnlineStaff();
 
 echo $entrance.":::".$schreg.":::".$courseReg.":::".$schpay.":::".$mails.":::".$sonline;

?>