  <?php 
//LE 22-5-17 #1
//sleep(60);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); //hold basic functions to perform some common database operations or request
$sch = GetSchool();
$allset = $dbo->SelectFirstRow("coursecontrol_tb");
Page();
 Tab();
 //$studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)");
 $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
   //Upload Result
   TabBody("name=ManageCourse");
     Form("groupname=objgrpelemmgecourse,action=javascript:Course.ManageCourse.PerformSave(),id=grpmngcoursefrm,style=height:100%");
     SideBar();
     //Box("style=width:1204px;height:auto");
     GroupBox("title=Course Details,id=coursedetgrp,size=1*1,logo=list-alt");
     
        $userID = 0; $staffID = 0;$loadcond="";
        $user = $_POST['USER'];
        $deptasign = "";
        if($user != ""){
          $userdet = explode("~",$user);
          if(count($userdet) > 0){
            $userID = $userdet[0];
            //get the staffdet
            $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
            if(is_array($staffDet)){
               $staffID = $staffDet["StaffID"];
               //$courses = trim($staffDet['Courses']);
               /* if($courses != ""){
                 $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
               } */
              $deptasign = $staffDet['DeptIDs'];

            }
          }
        }
        $UID = $userID;
        $intStudyID = key($studyarr); //get the selected study
        if(trim($deptasign) != ""){ //if dept assign to user
           
            //check if one dept asign
            $deptasignarr = explode("~",$deptasign); //get all asign departids
            $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
          //get study based on the assigned dept
          $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
         /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
          if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
            if(count($deptasignarr) < 2){ //if one dept/prog assigned
             
              //load level based on the prog
              //$lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
              $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
              $spillStr = ExtraLevelString();
              $lstlvl = end($lvlarr);
              $lstkey = key($lvlarr);
              for($s=1;$s <= 4; $s++){
                $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
              }
          } 
          }
       TextBoxGroup();
       $schStruc = json_decode($sch['SchStrucContr'],true);
         //LoadFac
        if(trim($deptasign) == ""){ //if no dept/prog assing
          $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=c,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";
          TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=cstudy,required=true,selected=$selestu,logo=building-o,onchange=Course.ManageCourse.GenLoader.LoadFac",$studyarr);
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=coursefac,onchange=Course.ManageCourse.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Course.ManageCourse.GenLoader.LoadProg,id=coursedept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
		  TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=courseprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Course.ManageCourse.GenLoader.LoadLevel",array());
		  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=courselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoader.LoadSemester",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
        }else{ //if dept asign
            //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=cstudy,required=true,selected=-1,logo=building-o,onchange=Course.ManageCourse.GenLoader.LoadLevel",$studyarr);
            
            //initial study
             if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
              echo '<input type="hidden" id="courseprog" class="objgrpelemmgecourse" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
              if(!isset($progDet)){
                $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                             }
                             
                            if(is_array($progDet)){
                                 Note();
                        echo $progDet['FacName']. " - ".$progDet['ProgName'];
                _Note();
                            }
               //Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
              TextBox("title=Level,style=width:250px;text-transform:uppercase,id=courselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoader.LoadSemester,chain=courselvl:;coursesemest:",$lvlarr); //load the lvel drop down
            }else{ // if multiple dept/prog assigned
            $deptasignsql = "p.ProgID=".str_replace("~", " or p.ProgID=",$deptasign);
              //load prog the textbox
              TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=courseprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Course.ManageCourse.GenLoader.LoadLevel,chain=courseprog:;courselvl:;coursesemest:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
              //create lvl dropdown
              TextBox("title=Level,style=width:250px;text-transform:uppercase,id=courselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoader.LoadSemester",array() );
            }
          }
      TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=coursesemest,required=true,logo=star-half-o,onchange=",array());
      $op = "0";
      _TextBoxGroup();
      echo "<br/>";
        FlatButton("text=Load Courses,logo=list-alt,onclick=Course.ManageCourse.Load(),style=width:262px;margin:auto;border-radius:0px,title=Load Courses,id=loadcoursebtn");
        
      _GroupBox();
      _SideBar();
      HomeDisplay([
        "id"=>"managecoursehome",
        "logo"=>$dbo->Config['Core']."cportal/Files/asset/c2t.png",
        "text"=>"Select details and click LOAD COURSES"
        ]);
      GroupBox("title={$sch['SemLabel']} Courses,id=coursepgagrp,size=3*1,logo=leanpub,style=width:calc(100% - 10px);min-width:500px;display:none,class=fadeIn animated fastest");
          Box("style=width:100%;font-size:0.95em;margin-top:5px;overflow:auto,id=coursecontdiv");
          
	_Box();
      _GroupBox(); 
     //_Box(); 	 
     _Form();
   _TabBody();

    //Monitor Course Registration
    TabBody("name=MonitorCourse");
    Form("groupname=MCoursegrpelem,action=javascript:Course.MonitorCourse.Save(),id=grpMCoursefrm");
    GroupBox("title=Title,id=mcoursegrp,style=width:290px;height:400px");
         Box("class=defaultTabText");
         Box();Icon("info-circle fa-3x");_Box();
         Box();echo"MONITOR COURSE REGISTRATION PROCESS";_Box();  
         Box();echo"Internal Evaluation in Progress ....";_Box();  
       _Box();  
     _GroupBox();
          
    _Form();
  _TabBody();

  //Course Template Design
  TabBody("name=CourseTemplate");
  Form("groupname=ctempgrpelem,action=javascript:Course.CourseTemplate.Save(),id=grpctempfrm");
  GroupBox("title=Title,id=ctempgrp,style=width:290px;height:400px");
       Box("class=defaultTabText");
       Box();Icon("info-circle fa-3x");_Box();
       Box();echo"DESIGN COURSE FORM TEMPLATE PROCESS";_Box();  
       Box();echo"Internal Evaluation in Progress ....";_Box();  
     _Box();  
   _GroupBox();
        
  _Form();
_TabBody();

//Course Settings
TabBody("name=CourseSetting,title=Course Management Settings");

Form("groupname=csetpgrpelem,action=javascript:Course.CourseSetting.Save(),id=grpcsetpfrm");
GroupBox("title=Portal Status,id=csetportalgrp,style=width:290px,size=1,logo=laptop");
$cstate = $allset['Status'] == 'CLOSED'?0:1;
TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
Switcher("id=openportal,state=$cstate,text=Open Registration,style=width:100%;margin-top:10px,info=Open course Reg. Proccess,ontext=yes,offtext=no,align=right,onchange=Course.CourseSetting.StatusChange");
TextBoxGroupItem();
Note();
  echo 'Closure of Course Registration does not close payment. To Close School Payment, Kindly Use the <a href="javascript:Page.OpenByTabName(\'psetting\')">Payment Settings Module</a>';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
Line();
$autoregst = $allset['AutoRegStatus'] == 'FALSE'?0:1;
TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
Switcher("id=autoregst,state=$autoregst,text=Auto Registration,style=width:100%;margin-top:10px,info=Register Courses Automatically,ontext=yes,offtext=no,align=right");
TextBoxGroupItem();
Note();
  echo 'Student Courses are Registered Automatically, upon successfull '.$sch['SemLabel'].' Payment';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
 _GroupBox();

 GroupBox("title=Portal Settings,id=csetdispgrp,style=width:290px,size=1,logo=tv");

 $lowlvl = $allset['LowerLevel'] == 'TRUE'?1:0;
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 Switcher("id=lowlvl,state=$lowlvl,text=Lower Level,style=width:100%;margin-top:10px,info=Include Lower Level Courses in Student Course ,ontext=yes,offtext=no,align=right");
 //Line();
 $unreg = $allset['UnRegCourses'] == 'TRUE'?1:0;
 Switcher("id=unregcourses,state=$unreg,text=Unregistered Courses,style=width:100%;margin-top:10px,info=Load & Select Unregistered Courses,ontext=yes,offtext=no,align=right");
 //Line();
 $rept = $allset['ReptCourses'] == 'TRUE'?1:0;
 Switcher("id=reptcourses,state=$rept,text=Repeat Courses,style=width:100%;margin-top:10px,info=Load & Select Repeat Courses,ontext=yes,offtext=no,align=right");
 //Line();
 $cprob = $allset['CheckProb'] == 'TRUE'?1:0;
 Switcher("id=chkprob,state=$cprob,text=Check Probation,style=width:100%;margin-top:10px,info=Check if student is on probation,ontext=yes,offtext=no,align=right");
 //Line();
 $cprev = $allset['CheckPrevReg'] == 'TRUE'?1:0;
 Switcher("id=chkprev,state=$cprev,text=Check Prev. Reg.,style=width:100%;margin-top:10px,info=Check if student has Registered Previous Courses,ontext=yes,offtext=no,align=right");
 _TextBoxGroup();
 _GroupBox();

 GroupBox("title=Payment,id=csetpaygrp,style=width:290px,size=1,logo=money");
 Box("style=font-style:italic; padding:5px; width:auto; font-size:0.8em");
  echo 'Select Course Registration Preceeding Payment';
_Box();
Box("style=max-height:260px;overflow:auto; width:95%;margin:auto;border-top:#CCC solid thin;position:relative; border-bottom:#CCC solid thin, class=greyShadow");
 Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent,id=paytbll,multiselect=false,data-type=table,onselect=Student.RegReport.NullFunc,rowalt=true,rowfilter=true,filtertitle=Filter Payment Type,filterstyle=width:100%");
 THeader(array("PAYMENT TYPE"),"style=text-align:left");
$PayID = $allset['PayID'];
$allitem = $dbo->Select("item_tb");
if(is_array($allitem)){
   if($allitem[1] > 0){
    while($rw = $allitem[0]->fetch_assoc()){
$sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=$sel");
//TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
    }
   }
}
//  THeader(array("PAYMENT ITEM"),"style=text-align:left");
// TRecord(array("Accptance Fee"),"style=text-align:left");
// TRecord(array("School Fee"),"style=text-align:left");
// TRecord(array("Convocation Fee"),"style=text-align:left");
// TRecord(array("PUTME Fee"),"style=text-align:left");
 _Table();
 _Box();
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 TextBoxGroupItem();
 $adprepay = $allset['AdminPrePay'] == 'FALSE'?0:1;
 Switcher("id=adminprepaycntr,state=$adprepay,text=Admin Pre-Payment,style=width:100%;margin-top:10px,info=Allow Payment Verification in Cportal Course Registration,ontext=yes,offtext=no,align=right");
_TextBoxGroupItem();
_TextBoxGroup();
 //Ranges("id=hdhd,min=400,max=2000,text=Testing,value=0.8");
 _GroupBox();

 GroupBox("title=General,id=csetgengrp,style=width:290px,size=1,logo=list");
 $semstrict = $allset['SemStrict'] == 'FALSE'?0:1;
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 Switcher("id=semcntr,state=$semstrict,text={$sch['SemLabel']} Control,style=width:100%;margin-top:10px,info=Load Active {$sch['SemLabel']} Only,ontext=yes,offtext=no,align=right");
 TextBoxGroupItem();
 Note("style=font-size:12px");
 echo 'You can Change the Active School '.$sch['SemLabel'].' in <a href="javascript:Page.OpenByTabName(\'ssettings\')">School Settings Module</a>';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
 Line();
 $duplc = $allset['DuplicateCourse'] == 'TRUE'?1:0;
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 Switcher("id=duplcourse,state=$duplc,text=Allow Duplicate Courses,style=width:100%;margin-top:10px,info=Allow duplicate courses to be added (Same Course Code and Credit Hour),ontext=yes,offtext=no,align=right");
 TextBoxGroupItem();
 /* Note("style=font-size:12px");
  echo 'It is recommended to disable this features, to avoid redundancy and data integrity loss in <a href="javascript:Page.OpenByTabName(\'MngCourse\')">Course Management Module</a>';
_Note(); */
_TextBoxGroupItem();
_TextBoxGroup();

Line();
$dymlvl = $allset['DynamicBulkRegLvl'] == 'TRUE'?1:0;
TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
Switcher("id=dymlvl,state=$dymlvl,text=Allow Dynamic Level,style=width:100%;margin-top:10px,info=Allow dynamic Level selection in bulk Course Registration (CPortal),ontext=yes,offtext=no,align=right");
TextBoxGroupItem();
Note("style=font-size:12px");
 echo 'When enabled, Student Course Registration (Bulk) for any level can be done';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();

 _GroupBox();

 GroupBox("title=Course Group,id=cgrp,size=2,logo=braille");
         $headerd = array(
          /* , */
          "*CGrpName"=>"GROUP",
               "*Resit"=>array("RESIT ALLOWED","-1=INFINITE&0=NONE&1=ONCE&2=TWICE&3=THREE TIMES&4=FOUR TIMES&5=FIVE TIMES&6=SIX TIMES"),
               "-CGrpID"=>"#ID"
         );
         //get all course groups
        /*  $CGrps = $dbo->Select("coursegroup_tb");
$dump = [];
if(is_array($CGrps) && $CGrps[1] > 0){
  while($indgrp = $CGrps[0]->fetch_assoc()){
    $dump;
  }
} */
TextBoxGroup("width:calc(100% - 16px);font-size:0.9em;margin:auto");
TextBoxGroupItem();
Note();
  echo '<b style="font-weight:bold">RESIT ALLOWED</b> - Indicate the number of times a student can Resit any course in the Group.<br/>
  If Student exceeds the Allowed Resit Number, the Course will be removed from Student Repeat Record';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
          Box("id=coursegrpbx");
              // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
               SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px,id=cgrpsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=7,disable=CGrpID",$headerd,"SELECT Descr, AllowFail,ID FROM coursegroup_tb");
               _Box();
      _GroupBox();

 //Elective Group
 GroupBox("title=Electives,id=csetelec,logo=th,size=2*1");
 TextBoxGroup("width:calc(100% - 16px);font-size:1em;margin:auto");
 TextBoxGroupItem();
 //Box("style=display:block;color:#777;margin-top:10px;font-size:0.7em;text-transform:uppercase");
 //echo 'Maximum Elective Group';
 //_Box();
 $maxelec = ((int)$allset['MaxElectiveGrp'] - 1)/9;
 Ranges("id=maxelectivegrp,max=10,min=1,value=$maxelec,text=Maximum Elective Group");
 _TextBoxGroupItem();
 TextBoxGroupItem();
 Note();
 echo 'A Group Number Specifies the total number of Elective course(s) that can be registered in the group. 
 <ul>
 <li><b style="font-weight:bold">Default - ZERO OR ABOVE -</b> None or any number of Elective Courses can be Registerd</li>
 <li><b style="font-weight:bold">1 : ONE ONLY -</b> Only One Elective Course must be Registered</li>
 <li><b style="font-weight:bold">2 : TWO ONLY -</b> Only Two Elective Courses must be Registered</li>
 <li><b style="font-weight:bold">3 : THREE ONLY -</b> Only Three Elective Course must be Registered</li>
 <li>....</li>
 <li><b style="font-weight:bold">Maximum Elective Group -</b> Maximum Elective Group (Number of) Courses must be Registered</li>
 
 </ul>
 For ZERO OR ABOVE GROUP, If no Elective Course Registered, no course will be taken as Un-Registered. <br />
 For OTHER GROUP, If Number of Group Elective Courses not registered the remaining will be taken as Un-Registered (Based on Entering Poirity)
 ';
 _Note();
 _TextBoxGroupItem();
 _TextBoxGroup();
 _GroupBox();

 GroupBox("title=Total Credit Hour,id=tchgrp,logo=tasks,size=4");
 $dump = [];
 $headers = array(
   "-mxID"=>"MXID",
  "*mxStudyID"=>array("STUDY TYPE",$dbo->DataString(TextBoxSQL("select * from study_tb where SchoolType = (select Type from school_tb limit 1)"))),
  "*mxFac"=>array("FACULTY","#select 0 as FacID,'ALL FACULTY/SCHOOL' as FacName UNION select FacID,FacName from fac_tb where StudyID = ?mxStudyID?"),
  "*mxDept"=>array("DEPARTMENT","#select 0 as DeptID,'ALL DEPARTMENT' as DeptName UNION select DeptID,DeptName from dept_tb where FacID = ?mxFac?"),
  "*mxProgID"=>array("PROGRAMME","#select 0 as ProgID,'ALL PROGRAMME' as ProgName UNION select ProgID, ProgName from programme_tb where DeptID = ?mxDept?"),
  "*mxLvl"=>array("LEVEL","#select 0 as Level,'ALL LEVEL' as Name UNION select Level, Name from schoollevel_tb where StudyID = ?mxStudyID? and SchoolTypeID = (select Type from school_tb limit 1) order by Level"),
  "*mxSem"=>array($sch['SemLabel'],$dbo->DataString(TextBoxSQL("select 0 as ID,'ALL {$sch['SemLabel']}' as Sem UNION select IF(Num=0,ID,Num) as ID, Sem from semester_tb where Enable = 1"))),
  "*mxCH"=>"TOTAL CH");
  Box("id=mxcourselecbx,style=width:100%;overflow:auto");
  SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=mxxhspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=12",$headers,"select ID, StudyID, FacID, DeptID, ProgID, Lvl, Sem, MaxCH FROM maxch_tb");
_Box();
 _GroupBox();
      
_Form();
_TabBody();

//register
TabBody();
Form("groupname=creggrpelem,action=javascript:Course.Register.Save(),id=grpcregfrm,style=height:100%");
SideBar();
GroupBox("title=Student Scope,id=creggrp,style=width:290px;height:auto;padding-bottom:5px");
//Box("style=display:block;width:270px");
TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
         Switcher("id=cregtype,state=0,text=Specific Student,style=width:100%,info=Select Students by Reg.No,ontext=yes,offtext=no,align=right,onchange=Course.Register.ChangeType");
     //_Box();
   _TextBoxGroup();
     /* Box("style=margin-top:8px;display:none,id=cregregno,class=ep-animate-opacity");
     TextBoxGroup();
    //  TextBox("title=REG. NUMBER (Seperated with comma),style=width:250px;text-transform:uppercase,id=cregspec,logo=users,type=multiline");
     _TextBoxGroup();
     _Box(); */
Box("style=margin-top:8px,id=cregrange,class=ep-animate-opacity");
// TextBox("title=All Session,style=width:270px;text-transform:uppercase,id=fsestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb ORDER BY SesID DESC",array(0=>"ALL SESSION")));
   
// TextBox("title=Study,style=width:270px;text-transform:uppercase,id=tstudstudy,required=true,logo=building-o,selected=-1",$studyarr);
//array_unshift($studyarr,"ALL STUDY");


$userID = 0; $staffID = 0;$loadcond="";
     $user = $_POST['USER'];
     $deptasign = "";
     if($user != ""){
       $userdet = explode("~",$user);
       if(count($userdet) > 0){
         $userID = $userdet[0];
         //get the staffdet
         $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
         if(is_array($staffDet)){
            $staffID = $staffDet["StaffID"];
            $courses = trim($staffDet['Courses']);
            if($courses != ""){
              $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
            }
           $deptasign = $staffDet['DeptIDs'];

         }
       }
     }
     // $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)");
     $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
     $studyarr["0"] = "ALL STUDY";
     ksort($studyarr);
     $UID = $userID;
     $intStudyID = key($studyarr); //get the selected study
     
     if(trim($deptasign) != ""){ //if dept assign to user
        
       //check if one dept asign
       $deptasignarr = explode("~",$deptasign); //get all asign departids
       if(count($deptasignarr) < 2){ //if one dept/prog assigned
        
         //load level based on the prog
         $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
         $spillStr = ExtraLevelString();
         $lstlvl = end($lvlarr);
         $lstkey = key($lvlarr);
         for($s=1;$s <= 4; $s++){
           $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
         }
     } 
     }

     
     
     
//$schStruc = json_decode($sch['SchStrucContr'],true);
//echo json_encode($studyarr);
$scharr = TextBoxSQL("select * from school_grp_tb");
 if(trim($deptasign) == ""){ //if no department assign to user
  Box("class=cregregnoc,style=display:none");
     TextBoxGroup();
     TextBox("title=REG. NUMBER (Seperated with comma),style=width:250px;text-transform:uppercase,id=cregspec,logo=users,type=multiline");
     _TextBoxGroup();
     Line();
     _Box();
   TextBoxGroup();
       if(count($scharr) > 1){
         TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=cregstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
       }
   TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=cregstudstudy,required=true,selected=-1,logo=building-o,onchange=Course.Register.StudyLoad,default=0",$studyarr);
   _TextBoxGroup();
   Box("class=cregrangec");
   Line();
   TextBoxGroup();
   $facdef = $schStruc['FacID']['SilentMode'] == true?array():array(0=>"ALL {$schStruc['FacID']['Name']}");
TextBox("title=ALL {$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=cregstudfac,onchange=Course.Register.GenLoader.LoadDept,logo=server,default=0,selected=-1,silent={$schStruc['FacID']['SilentMode']}", $facdef);
//TextBoxSQL("select * from fac_tb order by FacName")
$depdef = $schStruc['DeptID']['SilentMode'] == true?array():array(0=>"ALL {$schStruc['DeptID']['Name']}");
TextBox("title=All {$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Course.Register.GenLoader.LoadProg,id=cregstuddept,logo=tasks,default=0,selected=-1,silent={$schStruc['DeptID']['SilentMode']}",$depdef);

$probdef = $schStruc['ProgID']['SilentMode'] == true?array():array(0=>"ALL {$schStruc['ProgID']['Name']}");
TextBox("title=All {$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=cregstudprog,required=true,logo=list-alt,onchange=Course.Register.GenLoader.LoadLevel,default=0,selected=-1,silent={$schStruc['ProgID']['SilentMode']}",$probdef);
$sessionsarr = TextBoxSQL("select 0 as SesID,'ALL BATCHES' as SesName,0 as Orderd UNION select SesID, SesName, 1 as Orderd from session_tb WHERE Enable = 1 ORDER BY Orderd ASC, SesID DESC");
TextBox("title=Batch,style=width:250px;text-transform:uppercase,id=cregsestb,required=true,logo=calendar,selected=-1,onchange=Course.Register.GenLoader.GetLevel",$sessionsarr);
Note("style=font-size:10px");
echo '<b style="font-weight:bold" id="blvl">--</b>';
echo '<span style="display:none" id="hlvl">0</span>';
_Note();
TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=cregmode,required=true,logo=university,selected=-1",TextBoxSQL("(select 0,'ALL MODE OF ENTRY') UNION (select Level, Name from modeofentry_tb)"));
_TextBoxGroup();
_Box();
 }else{
  TextBoxGroup();
   if(count($scharr) > 1){
     TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=cregstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
   }
   TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=cregstudstudy,required=true,selected=-1,logo=building-o,onchange=Course.Register.GenLoader.LoadLevel,chain=cregstudstudy:;cregstudlvl:;,default=0",$studyarr);
   
   //initial study
   if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
     
     //Hidden("tstudprog",trim($deptasign));
     echo '<input type="hidden" id="cregstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
     //load level based on the prog
     
     
   }else{
     
     $deptasignsql = "ProgID=".str_replace("~", " or ProgID=",$deptasign);
     //load the textbox
     TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=cregstudprog,required=true,logo=list-alt,onchange=Course.Register.GenLoader.LoadLevel,chain=cregstudprog:;cregstudlvl:",TextBoxSQL("select ProgID, ProgName from programme_tb where ".$deptasignsql));
     _TextBoxGroup();
     
   }
 }
 



 

 _Box();

 Line();
 TextBoxGroup();
 Switcher("id=cregautoreg,state=0,text=Auto Session/Level/{$sch['SemLabel']},style=width:100%,info=System automatically determine Student Next Session/Level/{$sch['SemLabel']} to Register,ontext=yes,offtext=no,align=right,onchange=Course.Register.AutoLSChange");
 _TextBoxGroup();
 echo '<input type="hidden" id="rcsemName" value="'.$sch['SemLabel'].'" data-value="'.$sch['SemLabel'].'" />';
 Box("id=autoLSbox,style=display:block,class=ep-animate-opacity");
//  echo '<div style="font-size:1em;font-weight:bold">Registration Details</div>';
 Line();
 TextBoxGroup();
 array_shift($sessionsarr);
 TextBox("title=Registration Session,style=width:250px;text-transform:uppercase,id=cregsestbr,required=true,logo=calendar,selected=-1",$sessionsarr);
 //check if dynamic level selection for bulk course registration is set
//  if(isset($dymlvl) && $dymlvl == 1){
   if(trim($deptasign) == ""){
  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=cregstudlvl,required=true,logo=list-ol,default=0,selected=-1",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
 }else{
  if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
    TextBox("title=Level,style=width:250px;text-transform:uppercase,id=cregstudlvl,required=true,logo=list-ol,selected=-1,default=0",$lvlarr);
  }else{
    TextBox("title=Level,style=width:250px;text-transform:uppercase,id=cregstudlvl,required=true,logo=list-ol,default=0",array() );
  }
 }
//  }
   
 TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=cregstudsem,required=true,logo=list-alt,onchange=,chain=",TextBoxSQL("select IF(Num < 1,ID,Num) as Num, Sem from semester_tb"));
 _TextBoxGroup();
 _Box();

 if($sch['BulkPayUpdate'] == "TRUE"){
    Line();
Note();
echo "Bulk Payment is Enabled, Student Course Registration payment will be Updated";
_Note();
 }


Box("style=width:260px; margin:auto; text-align:center;margin-top:10px");
FlatButton("text=Load Student,logo=cogs,onclick=Course.Register.GetAllStudent(),style=width:260px,title=Load All Student,id=cregbtn");

_Box();  
 _GroupBox();
 _SideBar();

 HomeDisplay([
  "id"=>"bulkcreghome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/creg.png",
  "text"=>"Select registration details and click LOAD STUDENT"
  ]);

 //troubleshooting terminal
 GroupBox("title=Terminal,id=cregtrem,size=3*1,logo=list-alt,style=width:auto;min-width:100%,display:none,height:auto");
 //top reporting box
 Box("style=width:98%;font-size:0.95em;padding:10px;overflow:auto,id=cregheader");
   Box('style=float:left;width:70%,id=cregtitle');_Box();
   Box('style=float:right;width:30%');
   Box('style=float:right;display:none,id=cregcntrbtn');
   LogoButton('onclick=Course.Register.Stop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
   LogoButton('onclick=Course.Register.Pause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=cregpausebtn');
   LogoButton('onclick=Course.Register.Play();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=cregplaybtn');
   /* echo '
   <button onclick="Exams.ResultFixer.Pause()" id="fixpausebtn" title="Pause" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede"><i class="fa fa-pause"></i> </botton>
   <button onclick="Exams.ResultFixer.Play()" id="fixplaybtn" title="Resume" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede;display:none"><i class="fa fa-play"></i> </botton>'; */
   _Box();
   
   Box('style=float:right;display:none,id=cntrbtncregall');
   LogoButton('onclick=Course.Register.RegAllStop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
   LogoButton('onclick=Course.Register.RegAllPause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=cregallpausebtn');
   LogoButton('onclick=Course.Register.RegAllPlay();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=cregallplaybtn');
   _Box();

   //Unregister control buttons
   Box('style=float:right;display:none,id=cntrbtncunregall');
   LogoButton('onclick=Course.Register.UnRegAllStop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
   LogoButton('onclick=Course.Register.UnRegAllPause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=cunregallpausebtn');
   LogoButton('onclick=Course.Register.UnRegAllPlay();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=cunregallplaybtn');
   _Box();

   LogoButton('onclick=Course.Register.UnRegAll(this);return false;,title=Unregister All,style=float:right;display:none;color:#fff;background-color:rgba(255\,104\,53\,1);margin-left:10px,logo=trash,id=cunregallbtn,text=Unregister ALL');
   LogoButton('onclick=Course.Register.RegAll(this);return false;,title=Register All,class=success,style=float:right;display:none;color:#fff,logo=wrench,id=cregallbtn,text=Register ALL');
  
   echo'<div style="clear:both"></div>';
   _Box();
 _Box();

 Box("style=width:100%;overflow:auto");
 //main container
     FlatTable("id=cregbx,style=margin-bottom:20px;min-width:700px");
     //header box
     FlatTHead();
      FlatTData("#","size=5");
      FlatTData("STUDENT","size=40");
      FlatTData("LEVEL","size=10");
      FlatTData(strtoupper($sch['SemLabel']),"size=10");
      FlatTData("REGISTER","size=10");
      FlatTData("NOTES","size=20");
      FlatTData("&nbsp;","size=5");
       /* echo '<div style="width:5%" class="rptitem">#</div>
       <div style="width:40%" class="rptitem">STUDENT</div>
       <div style="width:10%" class="rptitem">RESULT</div>
       <div style="width:10%" class="rptitem">ISSUES</div>
       <div style="width:20%" class="rptitem">FIXES</div>
       <div style="width:10%" class="rptitem">NOTES</div>
       <div style="width:5%" class="rptitem">&nbsp;</div>
       <div style="clear:both"></div>'; */
     _FlatTHead();

     Box("id=cregcontdiv");
     //individual report
     
     _Box();
     //$procgrde = ; //return all grade structure with the grade symbole
    // Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
    // echo '<iframe src="Pages/Scripts/Exams/fix.php" style="border:none; width:100%; height:500px; background-color:#FFF"></iframe>';
_FlatTable();
_Box();
 _GroupBox();

 _Form();
_TabBody(); 



   _Tab();
   _Page();

   ?>