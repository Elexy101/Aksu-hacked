<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 
include("../Scripts/Application/genfunc.php");
$sch=$dbo->SelectFirstRow("school_tb","AppInstall");
Page();
Tab();
   //password Tab 
   TabBody("name=AppUpdate");
   Form("groupname=appupdateelem,action=javascript:Application.AppUpdate.Save(),id=grpappupdfrm");
  GroupBox("title=Setups,id=appupdhistory,logo=history,style=width:calc(100% - 16px)");
  Box("id=supspshtbx,style=width:100%;overflow:auto;box-sizing:border-box");
 LoadSetups();
  _Box();
  TextBoxGroup("max-width:700px;margin:auto;font-size:1.0em;margin-top:10px",'blockinmobile');
  TextBoxGroupItem();
     FlatButton("text=Install Eduporta Setup (.epx),logo=cogs,onclick=Application.AppUpdate.AddSetup(this),style=width:350px;margin:auto;border-radius:0px;text-transform:none,title=Install Setup,id=appaddsetup"); 
     TextBoxGroupItemMore();
     FlatButton("text=Execute Patch Script,logo=code,onclick=Application.AppUpdate.RunPatch(this),style=width:350px;margin:auto;border-radius:0px;text-transform:none,title=Add Setup,id=apprunpatch"); 
     _TextBoxGroupItem(); 
  _TextBoxGroup();
   _GroupBox();
  _Form();
   _TabBody();

    //password Tab 
    TabBody("name=AppInfo");
    Form("groupname=appinfoelem,action=javascript:Application.AppInfo.Save(),id=grpappinfofrm");
    GroupBox("title=Title,id=ctempgrp,style=width:290px;height:400px");
         Box("class=defaultTabText");
         Box();Icon("info-circle fa-3x");_Box();
         Box();echo"APPLICATION INFO";_Box();  
         Box();echo"Internal Evaluation in Progress ....";_Box();  
       _Box();  
     _GroupBox();
    _Form();
    _TabBody();

     //password Tab 
   TabBody("name=AppBackup");
   Form("groupname=appbackupelem,action=javascript:Application.AppBackup.Save(),id=grpappbkfrm");
   GroupBox("title=Title,id=ctempgrp,style=width:290px;height:400px");
        Box("class=defaultTabText");
        Box();Icon("info-circle fa-3x");_Box();
        Box();echo"APPLICATION BACKUP";_Box();  
        Box();echo"Internal Evaluation in Progress ....";_Box();  
      _Box();  
    _GroupBox();
   _Form();
   _TabBody();

   $appdet = ["name"=>"","short_name"=>"","description"=>"","display"=>"standalone"];

    //password Tab 
    TabBody("name=AppSetting");
    Form("groupname=appsetelem,action=javascript:Application.AppSetting.PerformSave(),id=grpappsetfrm");
    GroupBox("title=Application Settings,id=appsettgrp,style=width:290px,size=1,logo=cogs");
    TextBoxGroup();
    $install = (isset($sch['AppInstall']))?(int)$sch['AppInstall']:1;
    //get the manifest
    $manifest = file_get_contents($configdir."manifest.json");
    if($manifest){
      $appdet = json_decode($manifest,true);
    }
    Switcher("id=allowapp,state=$install,text=Allow Installation,style=width:100%;font-size:1.1em,info=Allow installation of the app on supported devices,ontext=on,offtext=off,align=right,showstate=false");
    _TextBoxGroup();
    Line();
    TextBoxGroup();
    TextBox("title=Name,style=width:250px,id=appsetname,required=true,logo=mobile,text=".str_replace(",",'\,',$appdet['name']));
  TextBox("title=Abbrevation,style=width:250px,id=appsetabbr,required=true,logo=map-signs,text=".str_replace(",",'\,',$appdet['short_name']));

  TextBox("title=Description,style=width:250px,type=multiline,id=appsetdescr,logo=info-circle,text=".str_replace(",",'\,',$appdet['description']));
 
_TextBoxGroup();
Line();
TextBoxGroup();
TextBox("title=Display,style=width:250px;margin-top:0px,id=appsetdisplay,required=true,logo=laptop,selected={$appdet['display']}",["standalone"=>"Standalone","fullscreen"=>"Fullscreen","minimal-ui"=>"Minimal UI","browser"=>"Browser"]);
_TextBoxGroup();
     _GroupBox();

     GroupBox("title=Application Icon,id=appicongrp,size=2,logo=image");
     $dicon = "";
     if(isset($appdet['icons']) && is_array($appdet['icons']) && count($appdet['icons']) > 0){
      $dicon = ",rel=$configdir,src=".ltrim($appdet['icons'][0]['src'],"./");
     }
     ImagePad("id=appicon,maxsize=600000000".$dicon);
 _GroupBox();
 
//  Color theme
GroupBox("title=Color Settings,id=appcolorsetgrp,size=1,logo=image");

 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
ColorPicker("id=appbgcolor,text=Background Color,align=right,info=Select the Start Page Background Color,value=".$appdet['background_color']);
TextBoxGroupItem();
Note();
 echo 'Background Color - The background color of the Start Page';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();

Line();

TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
ColorPicker("id=appthemecolor,text=Theme Color,align=right,info=Select the App Theme Color,value=".$appdet['theme_color']);
TextBoxGroupItem();
Note();
 echo 'Theme Color - The Color to display at the app window top bar';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
//$gg = RGBToHex([82,43,133]);
//$dd = HexToRGB('522b85');
// echo json_encode($dd);
//echo $gg;
 _GroupBox();

 GroupBox("title=Shortcuts,id=appshortcuts,size=2,logo=link");
 Box("id=appshortcutloadbx,class=ep-animate-opacity,style=max-height:360px;overflow:auto");
 $sesheaders = array(
  "*AppSCName"=>"NAME",
  "*AppSCABBR"=>"ABBREVIATION",
  "*AppSCDescr"=>"DESCRIPTION",
  "*AppSCAppl"=>["MODULE","#Select ID, Name from new_apply_group_tb where Enable=1 order by MenuOrder"]);
  $dumb=[];
  if(isset($appdet['shortcuts']) && is_array($appdet['shortcuts']) && count($appdet['shortcuts']) > 0){
    foreach($appdet['shortcuts'] as $key => $sc){
      /* "name": "Enrol",
          "short_name": "Enrol",
          "description": "Enrol into the School",
          "url": "?apgid=1",
          "icons": [{ "src": "/icons/play-later.png", "sizes": "192x192" }] */
          $urlarr = explode("?",$sc['url']);
          $dataarr['apgid'] =  0;
          if(count($urlarr) > 1){
            $dataarr = $dbo->DataArray($urlarr[1]);
            if(!isset($dataarr['apgid']))$dataarr['apgid']=0;
          }

          $iconset = "#";
          //check icons 
          if(isset($sc['icons']) && count($sc['icons']) > 0){
            $iconset = "*";
          }
          
      $dumb[$key] = [$sc['name'],$sc['short_name'],$sc['description'],$dataarr['apgid'],"logo"=>$iconset."image","info"=>"Set Icon","Action"=>"Application.Setting.SetIcon($key)"];
    }
  }
  /* $dumb=[
    ["Enrol","Enrol","Enrol Now",1,"logo"=>"#image","info"=>"Set Icon","Action"=>"Application.Setting.SetIcon(0)"],
    ["Paymeny","Pay","Make Payment and Wallet",3,"logo"=>"#image","info"=>"Set Icon","Action"=>"Application.Setting.SetIcon(0)"],
    ["Result","Result","Check your Result",4,"logo"=>"#image","info"=>"Set Icon","Action"=>"Application.Setting.SetIcon(0)"]
  ]; */
 // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
 SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schactsessionspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1,disable=SchMDName,case=false",$sesheaders, $dumb);
 _Box();
 _GroupBox();


    _Form();
    _TabBody();


   _Tab();


_Page();

?>

?>