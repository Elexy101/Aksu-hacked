<?php 
//LE 22-5-17 #1
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); //hold basic functions to perform some common database operations or request

Page();
 Tab();

 //Preloader
 TabBody("name=EPreLoader");
 Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
 GroupBox("title=Title,id=mstmrkgrp,style=width:290px;height:400px");
      Box("class=defaultTabText");
      Box();Icon("info-circle fa-3x");_Box();
      Box();echo"NOT AVAILABLE";_Box();  
      Box();echo"Internal Evaluation in Progress ....";_Box(); 
    _Box();  
  _GroupBox();
       
 _Form();
_TabBody();

 //BoiData
 TabBody("name=EBoiData");
 Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
 GroupBox("title=Title,id=mstmrkgrp,style=width:290px;height:400px");
      Box("class=defaultTabText");
      Box();Icon("info-circle fa-3x");_Box();
      Box();echo"NOT AVAILABLE";_Box();  
      Box();echo"Internal Evaluation in Progress ....";_Box(); 
    _Box();  
  _GroupBox();
       
 _Form();
_TabBody();

 //MonitorReg
 TabBody("name=MonitorReg");
 Form("groupname=emonreggrpelem,action=javascript:Entrance.MonitorReg.Save(),id=grpemonregfrm");
 //load the results
// print_r($staffDet);
 
// print_r($dump);
 //echo $Depts;
 GroupBox("title=Applicant Progress,id=emonreggrp,size=4,logo=graduation-cap");
     // Box("style=width:444px;display:inline-block;vertical-align:top");
     TextBoxGroup("width:calc(100% - 16px);margin:auto;font-size:0,9em","blockinmobile");
     TextBoxGroupItem();
      TextBox("title=Search Applicants,style=width:440px,onchange=,id=emonregsearch,logo=search,info=Inteligent Search: Search by any information you have about the Applicant,textchange=Entrance.MonitorReg.Search"); 
      //_Box();
     TextBoxGroupItemMore();
     // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
      TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=nonregfilter,onchange=Entrance.MonitorReg.Search,logo=filter,info=Filter Search by Registration Level,selected=-1",array("All","VERIFICATION","BASIC DETAILS","PAYMENT","CONTACT","PASSPORT","ACADEMIC","GUADIANCE/REFEREE","RESULT/QUESTIONAIRE","FILE UPLOAD","ATTESTATION","COMPLETE"));
     // _Box();
     TextBoxGroupItemMore();
   // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
    //SubHeader(_Icon("list-alt")." MAXIMUM DISPLAY RECORDS"); 
    Ranges("id=emonregmaxrec,value=0.0204,max=500,min=10,text=MAXIMUM DISPLAY RECORDS"); 
    //_Box();
    TextBoxGroupItemMore();
  // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
   SmallButton("id=reloadbtnemonreg,logo=sync,style=margin-left:10px,title=Reload,onclick=Entrance.MonitorReg.Search()");
   /* TextBoxGroupItemMore();
  // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
   SmallButton("id=selallappr,logo=refresh,style=margin:0px,title=Reload,onclick=Exams.Approval.Search()"); _Box();Box("style=clear:both"); */
   _TextBoxGroupItem();
   _TextBoxGroup();
   //_Box();
   Line();
   //echo "<div style=\"width:100%; height:2px;\" class=\"altBgColor2\" > </div>";
      Box("id=emonregstsloadin,style=margin-top:100px;text-align:center;position:absolute;z-index:3;width:1090px;visibility:hidden");
         Icon("sync fa-spin");
      _Box();
      
      Box("id=rstemonregbx,style=margin-top:10px;padding-bottom:20px");
      $FromPage = true;
      include "../Scripts/Entrance/loadapplicantmonitor.php";
    _Box();  
  _GroupBox();

  

 _Form();
_TabBody();

 //PhotoAlbum
 TabBody("name=PhotoAlbum");
 Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
 GroupBox("title=Title,id=mstmrkgrp,style=width:290px;height:400px");
      Box("class=defaultTabText");
      Box();Icon("info-circle fa-3x");_Box();
      Box();echo"NOT AVAILABLE";_Box();  
      Box();echo"Internal Evaluation in Progress ....";_Box(); 
    _Box();  
  _GroupBox();
       
 _Form();
_TabBody();

 //Clearance
 TabBody("name=Clearance");
 Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
 GroupBox("title=Title,id=mstmrkgrp,style=width:290px;height:400px");
      Box("class=defaultTabText");
      Box();Icon("info-circle fa-3x");_Box();
      Box();echo"NOT AVAILABLE";_Box();  
      Box();echo"Internal Evaluation in Progress ....";_Box();   
    _Box();  
  _GroupBox();
       
 _Form();
_TabBody();




   //Upload Result
   TabBody("name=Screening");
     Form("groupname=objgrpelemscreen,action=javascript:Entrance.Screening.Save(),id=grpscreenfrm,style=height:100%");
     //Box("style=width:1204px;height:100%;position:relative");
     SideBar();
     GroupBox("title=Result Details,id=rstdetgrp,size=1*1,logo=list-alt,sticky=true");
    
     TextBoxGroup();
      /*TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=filtertb,required=true,logo=filter,onchange=Entrance.Screening.Deselect,selected=-1",array("1"=>"ALL","2"=>"MAIN STUDENT","3"=>"REPEAT STUDENT")); //added the filter drop down and a horizontal rule 22-5-17 #1
      
     Line();
     */
         /* Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"RESULT UPLOAD REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box(); */
        $userID = 0; $staffID = 0;$loadcond="";
        $user = $_POST['USER'];
        $deptasign = "";
        if($user != ""){
          $userdet = explode("~",$user);
          if(count($userdet) > 0){
            $userID = $userdet[0];
            //get the staffdet
            $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
            if(is_array($staffDet)){
               $staffID = $staffDet["StaffID"];
               $courses = trim($staffDet['Courses']);
               if($courses != ""){
                 $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
               }
              $deptasign = $staffDet['DeptIDs'];

            }
          }
        }
        $UID = $userID;
        // $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)");
        $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
        $intStudyID = key($studyarr); //get the selected study
        
        if(trim($deptasign) != ""){ //if dept assign to user
           
          //check if one dept asign
          $deptasignarr = explode("~",$deptasign); //get all asign departids
          $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
          //get study based on the assigned dept
          $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
         /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
          if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
          if(count($deptasignarr) < 2){ //if one dept/prog assigned
           
            //load level based on the prog
           // $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
            $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
            $spillStr = ExtraLevelString();
            $lstlvl = end($lvlarr);
            $lstkey = key($lvlarr);
            for($s=1;$s <= 4; $s++){
              $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
            }
        } 
        }
       // echo $loadcond
        // if($loadcond == ""){
        /* TextBox("title=Session,style=width:250px;text-transform:uppercase,onchange=,id=appsestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC")); */
        
        TextBox("title=Filter By,style=width:250px;text-transform:uppercase,id=loadfilter,required=true,logo=graduation-cap,selected=-1",array(1=>"ADMITTED & NOT ADMITTED","NOT ADMITTED","ADMITTED"));
        Switcher("id=disfilterbox,state=0,text=More Filter,style=width:100%,info=Filter Applicant by other Parameters,ontext=yes,offtext=no,align=right,onchange=Entrance.Screening.FilterBox,logo=search");
        _TextBoxGroup();
        Box("id=filterboxscr,style=display:none; margin-top:5px,class=fadeIn");
        TextBoxGroup();
         //LoadFac
        if(trim($deptasign) == ""){ //if no dept/prog assing 
          $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title=school,style=width:250px;text-transform:uppercase,id=apprstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          TextBox("title=Study,style=width:250px;text-transform:uppercase,id=apprstudstudy,required=true,selected=-1,logo=building-o,onchange=Entrance.Screening.GenLoader.LoadFac",$studyarr);
		 TextBox("title=Faculty,style=width:250px;text-transform:uppercase,required=true,id=apprstudfac,onchange=Entrance.Screening.GenLoader.LoadDept,logo=server",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title=Department,style=width:250px;text-transform:uppercase,required=true,onchange=Entrance.Screening.GenLoader.LoadProg,id=apprstuddept,logo=tasks",array());
		  TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=apprstudprog,required=true,logo=list-alt,onchange=Entrance.Screening.GenLoader.LoadLevel",array());
		//   TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Entrance.Screening.GenLoader.LoadSemester",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
        }else{ //if dept asign
          //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=rstudstudy,required=true,selected=-1,logo=building-o,onchange=Entrance.Screening.LoadLevel",$studyarr);
          //initial study
           if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
            echo '<input type="hidden" id="apprstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
             //get the programe name
             if(!isset($progDet)){
              $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                           }
                           
                          if(is_array($progDet)){
                               Note();
                      echo $progDet['FacName']. " - ".$progDet['ProgName'];
              _Note();
                          }
             //Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
            // TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Entrance.Screening.GenLoader.LoadSemester,chain=rstudlvl:;semest:;rcourse:",$lvlarr); //load the lvel drop down
          }else{ // if multiple dept/prog assigned
          $deptasignsql = "ProgID=".str_replace("~", " or ProgID=",$deptasign);
            //load prog the textbox
            TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=apprstudprog,required=true,logo=list-alt,onchange=Entrance.Screening.GenLoader.LoadLevel,chain=rstudprog:;rstudlvl:;semest:;rcourse:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
            //create lvl dropdown
            // TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Entrance.Screening.GenLoader.LoadSemester",array() );
          }
        }
       
      //$op = "0";
       /*  }else{ //if courses set
          TextBox("title=Session,style=width:250px;text-transform:uppercase,onchange=Entrance.Screening.Deselect,id=sestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"));
          $op = "1";
        } */
        _TextBoxGroup();
        _Box();
        Box("style=margin-top:5px");
        TextBoxGroup();
        TextBox("title=Display Limit,style=width:250px;text-transform:uppercase,id=displlimit,required=true,logo=list-alt,selected=-1",array(1=>"20","50","100","200","500","1000"));
        _TextBoxGroup();
        _Box();
        FlatButton("text=Load Applicant,logo=list-alt,onclick=Entrance.Screening.LoadApplicant(),style=margin:15px auto,title=Load Applicants");
        
      /* Box("id=loadcourses,style=background-color:;width:270px;min-height:100px;margin-top:3px;overflow:auto;position:absolute;z-index:1;display:flex;text-align:center;opacity:0;visibility:hidden");
        Icon("cog fa-spin altColor2","align-self:center;margin:auto");
      _Box();  */
     // echo "sss";
     /*  Box("id=lcourses,style=width:100%;margin-top:5px; padding-top:10px;padding-bottom:10px;text-align:center;text-transform:uppercase;opacity:$op ");
      
         if($loadcond != ""){
           //echo $loadcond;
           LoadStaffCourses($loadcond,NULL,true); //in getinfo.php (show the course department along side the course)
         }
      _Box(); */
     /* TextBox("title=Course,style=width:270px;text-transform:uppercase,id=rcourse,required=true,logo=edit",array());
      Box("style=min-width:50px;margin:auto;text-align:center;margin-top:20px");
      SmallButton("id=preload,logo=list-alt,style=margin:10px,title=Load,onclick=Entrance.Screening.Load()");
     // SmallButton("id=reloadbtn,logo=refresh,style=margin:10px,title=Reload,onclick=");
         SmallButton("id=clearsheet,logo=table,style=margin:10px,title=Empty Sheet,onclick=");
        _Box();*/
      _GroupBox();
     _SideBar();
     HomeDisplay([
      "id"=>"screeninghome",
      "logo"=>$dbo->Config['Core']."cportal/Files/asset/screening.png",
      "text"=>"Screen and Admit Applicants",
      "onclick"=>"Entrance.Screening.LoadApplicant()",
      "value"=>"Load Applicant",
      "icon"=>"users"
      ]);
      GroupBox("title=Applicants,id=applrgrp,size=3,logo=check-square-o,style=width:auto;min-width:800px;padding:5px;display:none,class=fadeIn animated faster");
          Box("style=width:auto;font-size:0.95em,id=applcontdiv");
          //$procgrde = ; //return all grade structure with the grade symbole
          /* Box("id=gradeStruc,style=display:none");
          echo GetGrade(-1);
          _Box(); */
          //Hidden("gradeStruc",GetGrade(-1));
          //$header=array("*RegNo"=>"REGISTRATION NO.","*CA"=>"ASSESSMENT","*Exm"=>"EXAM","#Tot"=>"TOTAL","#Grd"=>"GRADE","Rmk"=>"REMARK");
          //get all 
         /*   $scorestrcs = $dbo->Select("scorestruc_tb");
          $scorearr = ["*SC1"=>"ASSESSMENT","*SC2"=>"EXAM"];
          $cnter = 1;
          if(is_array($scorestrcs) && $scorestrcs[1] > 0){
             while($scr = $scorestrcs[0]->fetch_assoc()){
              $scorearr["*SC".$cnter] = $scr['Title'];
              $cnter++;
             }
          } */
          /* $scorestrcs = $dbo->Select("scorestruc_tb");
          $scorearr = ["*SC1"=>"ASSESSMENT","*SC2"=>"EXAM"];
          $maxScorarr = ["SC1"=>30.0,"SC2"=>70.0];
          $cnter = 1;
          if(is_array($scorestrcs) && $scorestrcs[1] > 0){
             while($scr = $scorestrcs[0]->fetch_assoc()){
              $scorearr["*SC".$cnter] = $scr['Title'];
              $maxScorarr["SC".$cnter] = $scr['MaxScore'];
              $cnter++;
             }
          } */
          //echo json_encode($scorearr);

          /* $headers = array("-applID"=>"APPLID","*appFullName"=>"FULL NAME",
	 "-appDOB"=>"DATE OF BIRTH","*appGender"=>array("GENDER","M=MALE&F=FEMALE"),"*appFacs"=>array("FACULTY","#select FacID,FacName from fac_tb"),"#appDept"=>array("DEPARTMENT","#select DeptID,DeptName from dept_tb where FacID = ?appFacs?"),"*appProgID"=>array("PROGRAMME","#select * from programme_tb where DeptID = ?appDept?"),"appStateIds"=>array("STATE",$dbo->DataString(TextBoxSQL("select * from state_tb order by StateName"))),
	 "-appLGA"=>array("LGA","#select * from lga_tb where StateID=?appStateIds?"),"*appPhone"=>"PHONE","-appEmail"=>"EMAIL");
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-bottom:6px,id=sprstscreen,multiselect=false,cellfocus=,cellblur=,cellkeypress=,disable=appEmail;appFullName;appDOB;appStateIds;appPhone;appLGA;appGender,dynamiccolumn=false,dynamicrow=false,minrow=-1,dependables=CA:Grd~Tot;Exm:Grd~Tot,rowdelete=false,rowfilter=true,filtertitle=FILTER APPLICANTS,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:6px;",$headers); */

      Box("class=defaultTabText");
      Box();Icon("download fa-3x altColor2");_Box();
      Box();echo"LOAD APPLICANT";_Box();  
      Box();echo"Select Required Details and Click <span class='altColor2'>Load Apllicant</span>";_Box();  
    _Box();  

      /* echo '<div style="display:none" id="rstScoreStruc">'.json_encode(array_values($scorearr)).'</div>';
   echo '<div style="display:none" id="rstScoreStrucMax">'.json_encode(array_values($maxScorarr)).'</div>';
   echo '<div style="display:none" id="rstScoreStrucID">'.json_encode(array_keys($maxScorarr)).'</div>'; */
	_Box();
      _GroupBox(); 
    // _Box(); 	 
     _Form();
   _TabBody();

    //Preloader
 TabBody("name=EtranceSettings");
 Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
 GroupBox("title=Settings,id=mstmrkgrp,style=width:290px;height:400px");
 TextBoxGroup();
 TextBox("title=Verification Type,style=width:250px;text-transform:uppercase,id=etrvertype,required=true,logo=list-alt,selected=-1",array(1=>"Preload","Email","Phone","Email or Phone"));
 Note();
echo '<b>Preload: </b> Verify preloaded candidates <br/><b>Email: </b> Use candidate Email only for registration process<br/><b>Phone: </b> Use candidate Phone only for registration process<br/><b>Email or Phone: </b> Use candidate Email or Phone for registration process';
 _Note();
 _TextBoxGroup();
  _GroupBox();
 _Form();
_TabBody();

   _Tab();
   _Page();


   ?>