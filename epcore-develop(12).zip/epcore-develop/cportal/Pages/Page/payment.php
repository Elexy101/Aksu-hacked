<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); //hold basic functions to perform some common database operations or request
function PreloadData($tableName,$holderID){
  global $dbo;
   $facobj = array();
        $facs = $dbo->Select($tableName);
        if(is_array($facs)){
          if($facs[1] > 0){
            while($fac = $facs[0]->fetch_array()){
             $facobj[] = $fac;
            }
          }
        }
        $jsonstr = json_encode($facobj);
        Box("style=display:none,id=$holderID");
          echo $jsonstr;
        _Box();
    
}

function PadNum($Num){
  $Num = $Num."";
  $pad = 3 - strlen($Num);
  $rst = ($pad > 0)?str_repeat("0",$pad).$Num:$Num;
  //$rst = ($pad > 0)?str_pad($Num,$pad,"0",STR_PAD_LEFT):$Num;
  return $rst;
}
$NewPayeeIDNum = 1;
$schDet = GetSchool();
if(isset($_POST['USER'])){ //if user detail sent
 //get individual user details
 $userDetArr = explode("~",$_POST['USER']);
 $UID = $userDetArr[0];
 $UEmail = $userDetArr[1];
 $UName = $userDetArr[2];

 $Abbr = $schDet['Abbr'];
 //get last payment num
 $LstUser = $dbo->SelectFirstRow("payee_tb","","PayeeID LIKE '$Abbr/$UID/%' ORDER BY ID DESC");
 
 if(is_array($LstUser)){
   $LastPayeeID = $LstUser['PayeeID'];
   $LastPayeeIDArr = explode("/",$LastPayeeID);
   if(count($LastPayeeIDArr) == 3){
     $LastPayeeIDNum = $LastPayeeIDArr[2];
     $NewPayeeIDNum = (int)$LastPayeeIDNum + 1;
   }
 }
}

Page();
 Tab();
   //paytype
   TabBody("name=PaymentType");
   Form("groupname=objgrpelempayType,action=javascript:Payment.PaymentType.PerformSave(),id=grppayTypefrm,style=height:100%");
   SideBar();
   GroupBox("title=Payment Types,id=payTypegrp,size=1*1,logo=money");
 TextBoxGroup();
 Note();
 echo '<b style="font-weight:bold">Select a Payment Type</b> to load the Payment Type Details and Rules. If No Payment Type selected, System will attempt to add a new Payment Type';
_Note();
_TextBoxGroup();
Line();
   Box("style=overflow:auto;max-height:calc(100% - 140px);width:100%;margin:auto;position:relative,id=paytypes");
   Table("rowselect=false,style=font-size:0.8em;margin:auto;text-align:left;margin-bottom:6px,id=paytbpaym,multiselect=false,data-type=table,onselect=Payment.PaymentType.LoadPayType,rowalt=true,rowfilter=true,filtertitle=FILTER PAYMENT TYPE");
   //THeader(array("PAYMENT TYPE"),"style=text-align:left");
  //$PayID = $allset['PayID'];
  $allgatew = $dbo->Select("item_tb");
  if(is_array($allgatew)){
     if($allgatew[1] > 1){
      while($rw = $allgatew[0]->fetch_assoc()){
 // $sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
  TRecord(array($rw['ItemName']." (#".$rw['ID'].")"),"style=text-align:left,id=".$rw['ID']."");
  //TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
      }
     }
  }
  //  THeader(array("PAYMENT ITEM"),"style=text-align:left");
  // TRecord(array("Accptance Fee"),"style=text-align:left");
  // TRecord(array("School Fee"),"style=text-align:left");
  // TRecord(array("Convocation Fee"),"style=text-align:left");
  // TRecord(array("PUTME Fee"),"style=text-align:left");
   _Table();

   _Box();
   FlatButton("text=New Payment Type, style=margin:auto; margin-top:10px; width:260px,onclick=Payment.PaymentType.New(),logo=plus,id=newpaytypebtn");
   _GroupBox();
_SideBar();

HomeDisplay([
  "id"=>"paytypehomescreen",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/paytype.png",
  "text"=>"Setup or Manage School Payment Type",
  "onclick"=>"Payment.PaymentType.New()",
  "value"=>"Start Now",
  "icon"=>"plus"
  ]);
  Box("id=paymenttypebx,class=fadeIn animated faster,style=display:none");
   //payment type details
   GroupBox("title=Details,id=paytypedet,size=1*1,logo=list-alt");
   TextBoxGroup();
   TextBox("title=Payment Type Name,style=width:250px,id=paytypenametb,required=true,logo=tag");
   TextBox("title=Payment Type Description,style=width:250px;margin-top:5px,id=paytypedecrtb,logo=info-circle,type=multiline");
   TextBox("title=Currency,style=width:250px,id=paycurrencytb,required=true,logo=money,selected=-1",TextBoxSQL("select ID, CONCAT(Name,' (',Abbr,')') as Name from currency_tb"));
   TextBox("title=Payment Scope,style=width:250px,id=payscopetb,required=true,logo=users",array("r"=>"Student","f"=>"Candidate","w"=>"Wallet"));
   TextBox("title=Payment Gateway,style=width:250px,id=paytypegatewaytb,required=true,logo=sign-in",TextBoxSQL("select ID, Name from thirdparty_tb"));
   TextBox("title=Item Reference,style=width:250px,id=payitemreftb,logo=hashtag");
Note();
//echo 'Determine the class of Student that will access the Payment Type.<br/>';
echo 'Reference Number (Payment Gateway Platform)';
_Note();
TextBox("title=Receiving Bank,style=width:250px,id=payitemrecbnktb,logo=university");
_TextBoxGroup();
   

   
   /* Note();
echo "Select Payment Gateway<br/>Payment Gateways can be manage and configured in the ".'<a href="javascript:Page.OpenByTabName(\'pgateway\')">Payment Gateway Module</a>';
   _Note(); */
   _GroupBox();

   GroupBox("title=Payment Control,id=mctrdet,size=2*1,logo=cogs");
   TextBoxGroup("width:calc(100% - 16px);margin:auto;display:none");
   Switcher("id=paytmultiorder,state=0,text=Allow Multiple Order,style=width:100%,info=Multiple unpaid orders will be allowed,ontext=yes,offtext=no,align=right,onchange=,logo=file");
   Note();
   echo 'Multiple Order will be automatically disabled for Wallet Payment Scope';
   _Note();
   _TextBoxGroup();
  //  Line();
   TextBoxGroup("width:calc(100% - 16px);margin:auto;font-size:0.8em");
   
   Note();
   echo 'Assign a <strong style="font-weight:bold">Payment Control</strong> to the Payment Type';
   _Note();
   TextBox("title=Control Group,style=width:550px,id=paymoduletb,required=true,logo=bank,info=Select a Payment Control Group,onchange=Payment.PaymentType.LoadModuleCntr",array(1=>"Entrance Controls","Registration Controls","School Payment Controls"));
  
   Note();
   echo "You can manage Payment Controls in the ".'<a href="javascript:Page.OpenByTabName(\'pcontrol\')">Payment Controls Module</a>';
   _Note();
   _TextBoxGroup();
   Box("id=modulescntrs,style=width:100%;height:230px;overflow:auto");
     // echo ;
   _Box();
   _GroupBox();

   //Analysis
   GroupBox("title=Rules,id=payanaldet,logo=tasks,size=4*1, style=min-width:calc(100% - 20px);width:auto");
  /*  $headerd = array(
    "*PItems"=>array("ITEM","#select ID,ItemName from payitem_tb UNION select '#' as ID, '".$dbo->SqlSafe('<a href="javascript:Page.OpenByTabName(\'psetting\')"><i class="fa fa-plus"></i> Add Payment Item</a>')."' as ItemName"),
    
   "*PLevel"=>array("LEVEL","@cportal/Pages/Scripts/Payment/paytypecond.php PayTypeLevel",true),
   "*PCond"=>array("CONDITION",$dbo->DataString(
    array("None","State of Origin","Gender","Marital Status","Set/Batch","Mode Of Entering","Department","Faculty/School","Study")
   )),
   "*CondOp"=>array("OPERATOR","1=IS&2=IS NOT"),
   "*PVal"=>array("VALUE","@cportal/Pages/Scripts/Payment/paytypecond.php PayTypeCondValue Cond=?PCond?"),
   "*Fpay"=>"FIRST",
   "*Spay"=>"SECOND",
   "*PTot"=>"TOTAL"
  ); */
   Box("id=paytypeanabx,style=width:100%;overflow:auto");
   Box("class=defaultTabText");
   Box();Icon("table fa-3x altColor2");_Box();
   //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
   Box();echo"Select a Payment Control, to Load Rule Structure";_Box();  
 _Box(); 
  // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
       
       // SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=paytypeanal,multiselect=false,cellfocus=,cellblur=Payment.PaymentType.FormatAmt,cellkeypress=Payment.PaymentType.TotalAmt,dynamiccolumn=false,dynamicrow=true,minrow=10,rowfilter=true,disable=PTot,filtertitle=FILTER ANALYSIS,disable=PID",$headerd);
        _Box();
   _GroupBox();
   _Box();
   _Form();
   _TabBody();
  
   //monitor
   TabBody();
   Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box(); // 
        _Box(); 
   _TabBody();


   //troubleshoot
   TabBody();
   Form("groupname=paytrogrpelem,action=javascript:Payment.Troubleshoot.Save(),id=grppaytrofrm,style=height:100%");
   SideBar();
   GroupBox("title=Student Scope,id=paytrogrp,style=width:290px;height:auto");
   //Box("style=display:block;width:270px");
   TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
            Switcher("id=paytrotype,state=0,text=Specific Student/Payment,style=width:100%,info=Search by Student Reg. Number or Ref. Number,ontext=yes,offtext=no,align=right,onchange=Payment.Troubleshoot.ChangeType");
        //_Box();
      _TextBoxGroup();
        Box("style=margin-top:8px;display:none,id=paytroregno,class=ep-animate-opacity");
        TextBoxGroup();
        TextBox("title=REG. NUMBER OR NAME,style=width:250px;,id=paytrospec,logo=users,type=multiline");
        _TextBoxGroup();
        _Box();
   Box("style=margin-top:8px,id=paytrorange,class=ep-animate-opacity");
  // TextBox("title=All Session,style=width:270px;text-transform:uppercase,id=fsestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb ORDER BY SesID DESC",array(0=>"ALL SESSION")));
      
   // TextBox("title=Study,style=width:270px;text-transform:uppercase,id=tstudstudy,required=true,logo=building-o,selected=-1",$studyarr);
   //array_unshift($studyarr,"ALL STUDY");
  
   TextBoxGroup();
   $userID = 0; $staffID = 0;$loadcond="";
        $user = $_POST['USER'];
        $deptasign = "";
        if($user != ""){
          $userdet = explode("~",$user);
          if(count($userdet) > 0){
            $userID = $userdet[0];
            //get the staffdet
            $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
            if(is_array($staffDet)){
               $staffID = $staffDet["StaffID"];
               $courses = trim($staffDet['Courses']);
               if($courses != ""){
                 $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
               }
              $deptasign = $staffDet['DeptIDs'];

            }
          }
        }
        // $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)");
        $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
        $studyarr["0"] = "ALL STUDY";
        ksort($studyarr);
        $UID = $userID;
        $intStudyID = key($studyarr); //get the selected study
        
        if(trim($deptasign) != ""){ //if dept assign to user
           
          //check if one dept asign
          $deptasignarr = explode("~",$deptasign); //get all asign departids
          if(count($deptasignarr) < 2){ //if one dept/prog assigned
           
            //load level based on the prog
            $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
            $spillStr = ExtraLevelString();
            $lstlvl = end($lvlarr);
            $lstkey = key($lvlarr);
            for($s=1;$s <= 4; $s++){
              $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
            }
        } 
        }
   //echo json_encode($studyarr);
   $scharr = TextBoxSQL("select * from school_grp_tb");
    if(trim($deptasign) == ""){ //if no department assign to user
      
          if(count($scharr) > 1){
            TextBox("title=school,style=width:250px;text-transform:uppercase,id=ptrobstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
      TextBox("title=Study,style=width:250px;text-transform:uppercase,id=ptrobstudstudy,required=true,selected=-1,logo=building-o,onchange=Payment.Troubleshoot.GenLoader.LoadFac,default=0",$studyarr);
 TextBox("title=ALL Faculties/Schools,style=width:250px;text-transform:uppercase,required=true,id=ptrobstudfac,onchange=Payment.Troubleshoot.GenLoader.LoadDept,logo=server,default=0,selected=-1",array(0=>"ALL Faculties/Schools"));
 //TextBoxSQL("select * from fac_tb order by FacName")
 TextBox("title=All Departments,style=width:250px;text-transform:uppercase,required=true,onchange=Payment.Troubleshoot.GenLoader.LoadProg,id=ptrobstuddept,logo=tasks,default=0,selected=-1",array(0=>"ALL Department"));
  TextBox("title=All Programmes,style=width:250px;text-transform:uppercase,id=ptrobstudprog,required=true,logo=list-alt,onchange=Payment.Troubleshoot.GenLoader.LoadLevel,default=0,selected=-1",array(0=>"ALL Programmes"));
  TextBox("title=All Level,style=width:250px;text-transform:uppercase,id=ptrobstudlvl,required=true,logo=list-ol,default=0,selected=-1",array(0=>"ALL Levels") );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
    }else{
      if(count($scharr) > 1){
        TextBox("title=school,style=width:250px;text-transform:uppercase,id=ptrobstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
      }
      TextBox("title=Study,style=width:250px;text-transform:uppercase,id=ptrobstudstudy,required=true,selected=-1,logo=building-o,onchange=Payment.Troubleshoot.GenLoader.LoadLevel,chain=ptrobstudstudy:;ptrobstudlvl:;,default=0",$studyarr);
      //initial study
      if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
        
        //Hidden("tstudprog",trim($deptasign));
        echo '<input type="hidden" id="ptrobstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
        //load level based on the prog
        
        TextBox("title=Level,style=width:250px;text-transform:uppercase,id=ptrobstudlvl,required=true,logo=list-ol,selected=-1,default=0",$lvlarr);
      }else{
        
        $deptasignsql = "ProgID=".str_replace("~", " or ProgID=",$deptasign);
        //load the textbox
        TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=ptrobstudprog,required=true,logo=list-alt,onchange=Payment.Troubleshoot.GenLoader.LoadLevel,chain=ptrobstudprog:;ptrobstudlvl:",TextBoxSQL("select ProgID, ProgName from programme_tb where ".$deptasignsql));
        TextBox("title=Level,style=width:250px;text-transform:uppercase,id=ptrobstudlvl,required=true,logo=list-ol,default=0",array() );
      }
    }
    _TextBoxGroup();
    _Box();
  //TextBox("title=Semester,style=width:270px;text-transform:uppercase, id=tsemest,required=true,logo=star-half-o,selected=-1",TextBoxSQL("select * from semester_tb"));
  /* Box("style=display:block;width:270px;margin-top:6px");
            Switcher("id=autofix,state=0,text=AUTO FIX,style=width:100%,info=Automatically fix issues,ontext=yes,offtext=no,align=right,onchange=Exams.ResultFixer.AutoFix");
        _Box(); */
  Box("style=width:260px; margin:auto; text-align:center;margin-top:10px");
  FlatButton("text=Verify Payments,logo=wrench,onclick=Payment.Troubleshoot.GetAllStudent(),style=width:260px,title=Verify Student Payments,id=ptrobtn");

  _Box();  
    _GroupBox();
    _SideBar();
    HomeDisplay([
      "id"=>"verpayhome",
      "logo"=>$dbo->Config['Core']."cportal/Files/asset/verpay.png",
      "text"=>"Verify, fix and updates pending payments"
      ]);
    //troubleshooting terminal
    GroupBox("title=Terminal,id=ptrobtrem,size=3*1,logo=list-alt,style=display:none");
    //top reporting box
    Box("style=width:95%;font-size:0.95em;padding:10px;overflow:auto,id=ptrbheader");
      Box('style=float:left;width:70%,id=ptrobtitle');_Box();
      Box('style=float:right;width:30%');
      Box('style=float:right;display:none,id=ptobcntrbtn');
      LogoButton('onclick=Payment.Troubleshoot.Stop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
      LogoButton('onclick=Payment.Troubleshoot.Pause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=ptrobpausebtn');
      LogoButton('onclick=Payment.Troubleshoot.Play();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=ptrobplaybtn');
      /* echo '
      <button onclick="Exams.ResultFixer.Pause()" id="fixpausebtn" title="Pause" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede"><i class="fa fa-pause"></i> </botton>
      <button onclick="Exams.ResultFixer.Play()" id="fixplaybtn" title="Resume" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede;display:none"><i class="fa fa-play"></i> </botton>'; */
      _Box();
      
     /*  LogoButton('onclick=Payment.Troubleshoot.FixAll(this);return false;,title=Fix All,class=success,style=float:right;display:none;color:#fff,logo=wrench,id=fixallbtn,text=FIX ALL'); */
      echo'<div style="clear:both"></div>';
      _Box();
    _Box();

    Box("style=width:100%;overflow:auto");
    //main container
        FlatTable("id=ptrobbx,style=margin-bottom:20px;min-width:700px");
        //header box
        FlatTHead();
         FlatTData("#","size=5");
         FlatTData("STUDENT","size=40");
         FlatTData("PAID","size=10");
         FlatTData("UNPAID","size=10");
         FlatTData("UPDATED","size=10");
         FlatTData("NOTES","size=20");
         FlatTData("&nbsp;","size=5");
          /* echo '<div style="width:5%" class="rptitem">#</div>
          <div style="width:40%" class="rptitem">STUDENT</div>
          <div style="width:10%" class="rptitem">RESULT</div>
          <div style="width:10%" class="rptitem">ISSUES</div>
          <div style="width:20%" class="rptitem">FIXES</div>
          <div style="width:10%" class="rptitem">NOTES</div>
          <div style="width:5%" class="rptitem">&nbsp;</div>
          <div style="clear:both"></div>'; */
        _FlatTHead();

        Box("id=ptrobcontdiv");
        //individual report
        
        _Box();
        //$procgrde = ; //return all grade structure with the grade symbole
       // Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
       // echo '<iframe src="Pages/Scripts/Exams/fix.php" style="border:none; width:100%; height:500px; background-color:#FFF"></iframe>';
_FlatTable();
_Box();
    _GroupBox();

    _Form();
   _TabBody(); 
   
   //payment report
   TabBody("name=PaymentReport");
     Form("groupname=objgrpelempayrpt,action=javascript:Payment.PaymentReport.Save(),id=grppayrptfrm,style=height:100%");
     SideBar();
     //Box("style=width:1204px;height:auto");
     GroupBox("title=REPORT DETAILS,id=paytypegrp,size=1*1,logo=check-square-o");
       TextBoxGroup();
        TextBox("title=Session,style=width:250px;text-transform:uppercase, onchange=,id=payrptses,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC",array(0=>"ALL")));
        TextBoxGroupItem();
       Check("id=datefilterch,check=Payment.PaymentReport.EnableDateFilter,uncheck=Payment.PaymentReport.DisableDateFilter,text=Filter by Date,style=margin-top:10px");
       _TextBoxGroupItem();
       _TextBoxGroup();
      /*  Table("rowselect=true,style=width:95%;font-size:0.8em;margin:auto;text-align:left;margin-top:10px;display:none,id=payrptdatefilter,multiselect=false,data-type=table");
       $tday = date("d/m/Y");
        THeader(array("FROM:","TO:"),"style=text-align:center");
        TRecord(array("<span id=\"frmdate\" >$tday</span>"._Icon('calendar calen Calendar" data-style="margin-top:0px;margin-left:0px" data-today=">" data-input="frmdate'),"<span id=\"todate\">$tday</span>"._Icon('calendar calen DatePicker" data-style="margin-top:0px;margin-left:0px" data-today=">" data-input="todate')),"data-id=filterdate");
        //DatePicker" data-style="margin-top:-300px;margin-left:-40px" data-input="dndndn"
        _Table(); */
        $tday = date("d/m/Y");
Box("id=payrptdatefilter,style=display:none;margin-left:9px");
Line();
        TextBoxGroup("margin:auto");
        TextBoxGroupItem();
        TextBox("title=FROM:,type=calendar,style=width:120px;text-transform:uppercase,id=frmdate,logo=calendar,text=".$tday);
        TextBoxGroupItemMore();
        TextBox("title=TO:,type=calendar,style=width:125px;text-transform:uppercase,id=todate,logo=calendar,text=".$tday);
        _TextBoxGroupItem();
        _TextBoxGroup();
        Line();
        _Box();

        TextBoxGroup("font-size:0.9em;margin:auto;width:95%;margin-top:10px");
        Switcher("id=payrptonline,state=1,text=ONLINE PAYMENT,style=width:100%,info=Include Online Payment in Report,ontext=yes,offtext=no,align=right,onchange=Payment.PaymentReport.PTyper");
          Switcher("id=payrptoffline,state=0,text=OFFLINE PAYMENT,style=width:100%,info=Include Offline Payment in Report,ontext=yes,offtext=no,align=right,onchange=Payment.PaymentReport.PTyper");
        _TextBoxGroup();
        
      
     // echo "sss";
      //Box("id=payrptbx,style=width:270px;max-height:400px;margin:20px 0px;overflow:auto;background-color:#FFF;border-top:thin solid #CCC; border-bottom:thin solid #CCC; padding-top:10px;padding-bottom:10px;text-align:center;text-transform:uppercase;opacity:1 ");
       Table("rowselect=true,style=width:95%;font-size:0.8em;margin:auto;margin-top:10px;text-align:left,id=payrpttypstb,onselect=Payment.PaymentReport.PreLoad");
        THeader(array("REPORT TYPE"),"style=text-align:center");
        TRecord(array(_Icon("list-ul altColor2")." PAYMENT TYPE"),"data-id=paytypesumrpt");
        
        //TRecord(array(_Icon("th-list")." Item Based Report"._Icon('chevron-right calen')),"data-id=paytypeitem");
        TRecord(array(_Icon("th-large altColor2")." SCHOOL STRUCTURE"),"data-id=paytypefac");
        TRecord(array(_Icon("users altColor2")." CLASS FEES LIST"),"data-id=paytypeclassdet");
        TRecord(array(_Icon("users altColor2")." CLASS FEES LIST - BALANCE"),"data-id=paytypeclassdetdual");
        TRecord(array(_Icon("shopping-basket altColor2")." PAYMENT ITEM"),"data-id=payitems");
        /* TRecord(array(_Icon("users altColor2")." CLASS   LIST (PAID/DEBTOR)"),"data-id=paytypeclass");
        TRecord(array(_Icon("thumbs-up altColor2")." CLASS LIST (PAID)"),"data-id=paytypeclassp");
        TRecord(array(_Icon("thumbs-down altColor2")." CLASS LIST (DEBTOR)"),"data-id=paytypeclassup"); */
        //TRecord(array(_Icon("th-large")." Faculty/School Based Report"._Icon('chevron-right calen')),"data-id=paytypefacind");
        _Table();
        //PreloadData("fac_tb","facsdata");
        //PreloadData("item_tb","payitemdata"); 
        //get all facs
       
     /* TextBox("title=Course,style=width:270px;text-transform:uppercase,id=rcourse,required=true,logo=edit",array());
      Box("style=min-width:50px;margin:auto;text-align:center;margin-top:20px");
      SmallButton("id=preload,logo=list-alt,style=margin:10px,title=Load,onclick=Exams.ResultUpload.Load()");
     // SmallButton("id=reloadbtn,logo=refresh,style=margin:10px,title=Reload,onclick=");
         SmallButton("id=clearsheet,logo=table,style=margin:10px,title=Empty Sheet,onclick=");*/
       // _Box();
        //FlatButton("text=Load Report,logo=list-alt,onclick=Payment.PaymentReport.Load(),style=width:265px;margin:auto;margin-top:10px,title=Load Report,id=loadpayrptbtn");
      _GroupBox();
_SideBar();
HomeDisplay([
  "id"=>"payrporthome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/payreport.png",
  "text"=>"Generate Payment Reports <br/><small style='color:#666'>Select a REPORT TYPE to get Started</small>"
  ]);
      GroupBox("title=Report,id=payrptgrpbx,size=3*1,logo=list-alt,style=display:none;width:auto;min-width:100%;overflow-x: hidden;padding: 0px 8px;");

      
       Box("id=reportbx");
        /*  Box("class=pointer altColor,style=position:absolute;z-index:10;margin-left:-20px;margin-top:90px;font-size:2.0em");
           Icon("arrow-left");
           echo " Select Report Type";
         _Box(); */
        
	    _Box();
      _GroupBox();
      Box("id=exportdiv,style=display:none;visibility:hidden");

      _Box();
    // _Box(); 	 
     _Form();
   _TabBody();
   //manual pay 
   TabBody("name=ManualPay");
     
     Form("groupname=paytypeMPelem,action=javascript:Payment.ManualPay.SavePerform(),id=manualPayfrm,style=height:100%");
SideBar();
     //student Search
     StudentSearchBox("id=mpss,title=Search,onselect=Payment.ManualPay.SelectStud,param=a,onunselect=Payment.ManualPay.ClearAll,logo=search,script={$_POST['CORE']}cportal/Pages/Scripts/Student/studsearch.php,info=Search Student or Candidate by Reg. Number or Name,action=Payment.ManualPay.RequestByRef(),actionlogo=search,actiontitle=REQUEST BY REF");
     _SideBar();
     HomeDisplay([
      "id"=>"offlinepay",
      "logo"=>$dbo->Config['Core']."cportal/Files/asset/offlinepay.png",
      "text"=>"Process offline payments<br/><small style='color:#666'>Search and Select a student to get Started</small>"
      ]);
      Box("id=payofflinebx,style=display:none,class=fadeIn animated faster");
     GroupBox("title=Payment Details,id=paydetgrp,size=1,logo=list-alt");
     TextBoxGroup();
        TextBox("title=Payment Type,style=width:250px,id=paytypetb,required=true,logo=money,onchange=Payment.ManualPay.PayTypeChange",TextBoxSQL("select ID, ItemName from item_tb "));
        TextBox("title=Payment Session,style=width:250px,id=paysestb,required=true,logo=calendar",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
        TextBox("title=Level,style=width:250px,id=mpleveltb,required=true,logo=signal,onchange=Payment.ManualPay.LoadPayPol,info=Select a Student in the Search Box to Load Level",array(""));
        TextBox("title=Payment Policy,style=width:250px,id=mppaypolicytb,required=true,logo=star-half-o,info=Select Student Level to Load Payment Policies,onchange=Payment.ManualPay.LoadPayDetails",array(""));
         _TextBoxGroup();
         Text("text=".EscapeString(_Icon("cog fa-spin"))." Loading ...,style=display:;width:270px;opacity:0;visibility:hidden;position:absolute;text-align:center;margin-top:60px,id=panalyLoading");
         ;
        
         Box("id=disanalysbx,style=opacity:1");
        
      _Box();
     _GroupBox();
     GroupBox("title=Receipt Details,id=payrecieptdetgrp,size=1,logo=money");
     TextBoxGroup();
     TextBox("title=Receipt Number,style=width:250px,id=receiptnumtb,required=true,logo=money");
     TextBox("title=Bank,style=width:250px,id=receiptbanktb,logo=university");
     TextBox("title=Bank Branch,style=width:250px,id=receiptbankbrtb,logo=map");
     TextBox("title=Payment Date,style=width:250px,id=receiptdatetb,logo=calendar,type=calendar");
      _TextBoxGroup();
     _GroupBox(); 

      GroupBox("title=Scanned Receipt,id=payrecieptgrp,size=1,logo=image");
           ImagePad("id=imgpd,maxsize=600000");
       _GroupBox(); 
       _Box();
     _Form();
           
       
   _TabBody();
    //pay now
   TabBody("name=PayNow");
     Form("groupname=payNowelem,action=javascript:Payment.PayNow.SavePerform(),id=payNowfrm,style=height:100%");
     SideBar();
        GroupBox("title=Payee Details,id=payeedetgrp,size=1,logo=user");
        //$NewPayeeIDNum = PadNum($NewPayeeIDNum);
        $NewPayeeID = $Abbr."/".$UID."/".PadNum($NewPayeeIDNum);
        Hidden("NewPayeeID",$NewPayeeID);
        //Box("style=background-color:;width:270px;height:auto;margin-bottom:3px"); 
         // Box("style=display:block;width:inherit");
         TextBoxGroup();
              Switcher("id=newpayee,state=0,text=New Payee,style=width:100%;font-size:1.2em,info=Create new Payee Details,ontext=yes,offtext=no,align=right,onchange=Payment.PayNow.NewPayee");
            _TextBoxGroup();
          //_Box();
        //_Box();
        Line();
        TextBoxGroup();
            TextBox("title=Identification Number,style=width:250px,id=payeeID,logo=user,info=Enter Payee ID/Registration Number,textchange=Payment.PayNow.SearchPayee");
            TextBox("title=Payee Name,style=width:250px,id=payeeName,logo=user,onchange=Payment.ManualPay.LoadPayPol,info=Enter Payee Name,disabled=true");
            _TextBoxGroup();
        Box("id=pnotherdet,style=display:none");
        Line();
       // Box("style=background-color:;width:270px;height:auto;margin-top:5px"); 
          //  Box("style=display:block;width:inherit");
          TextBoxGroup("margin:auto;margin-top:10px;width:95%");
                Switcher("id=studpayee,state=0,text=Student Payee,style=width:100%;font-size:1.2em,info=Enable other Student Details,ontext=yes,offtext=no,align=right,onchange=Payment.PayNow.StudPayee");
          _TextBoxGroup();
           // _Box();
      //  _Box();
        Box("style=width:100%; margin:auto; text-align:left;margin-top:3px;display:none,id=studpayeedet");
        TextBoxGroup();
        if(count($scharr) > 1){
          TextBox("title=school,style=width:250px;text-transform:uppercase,id=pnstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
        }
            TextBox("title=Study,style=width:250px;text-transform:uppercase,id=pnstudstudy,required=true,onchange=Payment.PayNow.GenLoader.LoadFac,logo=building-o",$studyarr);
            TextBox("title=Faculty,style=width:250px;text-transform:uppercase,id=pnstudfac,onchange=Payment.PayNow.GenLoader.LoadDept,logo=server",array(""));
            //TextBoxSQL("select * from fac_tb order by FacName")
            TextBox("title=Department,style=width:250px;text-transform:uppercase,onchange=Payment.PayNow.GenLoader.LoadProg,id=pnstuddept,logo=tasks",array(""));
              TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=pnstudprog,required=true,logo=list-alt",array(""));
              _TextBoxGroup();
        _Box();
        _Box();
        FlatButton("text=Done,logo=wrench,onclick=Payment.PayNow.Done(),style=width:260px;margin-top:50px,title=Pay Now,id=paynowdonebtn");
        _GroupBox();
     _SideBar();
         
     HomeDisplay([
      "id"=>"paynowhome",
      "logo"=>$dbo->Config['Core']."cportal/Files/asset/paynow.png",
      "text"=>"Make Payment<br/><small style='color:#666'>Search a Student to make Payment</small>"
      ]);
Box("id=paynowbx,style=display:none,class=fadeIn animated faster");
     GroupBox("title=Payment Details,id=paynwdetgrp,size=1,logo=list-alt");
     TextBoxGroup();
        TextBox("title=Payee ID,style=width:250px,id=paynidtb,required=true,readonly=true,logo=user");
        TextBox("title=Payee Name,style=width:250px,id=paynnametb,required=true,readonly=true,logo=user");
      _TextBoxGroup();
      Line();
     TextBoxGroup();
        TextBox("title=Payment Type,style=width:250px,id=payntypetb,required=true,logo=money,onchange=Payment.PayNow.PayTypeChange",TextBoxSQL("select ID, ItemName from item_tb "));
        TextBox("title=Level,style=width:250px,id=mpnleveltb,required=true,logo=signal,onchange=Payment.PayNow.LoadPayPol,info=Select Payment Type to Load Payee Level",array(""));
        TextBox("title=Payment Policy,style=width:250px,id=mpnpaypolicytb, required=true,logo=star-half-o,info=Select Payee Level to Load Payment Policies,onchange=Payment.PayNow.LoadPayDetails",array(""));
      _TextBoxGroup();
         Text("text=".EscapeString(_Icon("cog fa-spin"))." Loading ...,style=display:;width:270px;opacity:0;visibility:hidden;position:absolute;text-align:center;margin-top:60px,id=pnanalyLoading");
         Hidden("Payee_det","");
         Box("id=disanalysbxn,style=opacity:1");
        
      _Box();
     _GroupBox();
      _Box();
       
     _Form();
   _TabBody(); 

    //payment Gateways
    TabBody("name=PayGateway");
    Form("groupname=objgrpelempaygate,action=javascript:Payment.PayGateway.PerformSave(),id=grppaygatefrm,style=height:100%");
    SideBar();
    GroupBox("title=Payment Gateways,id=payGategrp,size=1*1,logo=sign-out");
  TextBoxGroup();
  Note();
  echo '<b style="font-weight:bold">Select a Payment Gateway</b> to load the Payment Gateway Details. If No Payment Gateway selected, System will attempt to add a new Payment Gateway';
 _Note();
 _TextBoxGroup();
 Line();
    Box("style=overflow:auto;max-height:200px;width:100%;margin:auto;position:relative,id=paygates");
    Table("rowselect=false,style=font-size:0.8em;margin:auto;text-align:left;margin-bottom:6px,id=paytbpaygate,multiselect=false,data-type=table,onselect=Payment.PayGateway.LoadPayGateway,rowalt=true,rowfilter=true,filtertitle=FILTER PAYMENT GATEWAY");
    //THeader(array("PAYMENT TYPE"),"style=text-align:left");
   //$PayID = $allset['PayID'];
   $allgatew = $dbo->Select("thirdparty_tb");
   if(is_array($allgatew)){
      if($allgatew[1] > 1){
       while($rw = $allgatew[0]->fetch_assoc()){
  // $sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
   TRecord(array($rw['Name'].""),"style=text-align:left,id=".$rw['ID']."");
   //TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
       }
      }
   }
   //  THeader(array("PAYMENT ITEM"),"style=text-align:left");
   // TRecord(array("Accptance Fee"),"style=text-align:left");
   // TRecord(array("School Fee"),"style=text-align:left");
   // TRecord(array("Convocation Fee"),"style=text-align:left");
   // TRecord(array("PUTME Fee"),"style=text-align:left");
    _Table();
 
    _Box();
    FlatButton("text=New Payment Gateway, style=margin:auto; margin-top:10px; width:260px,onclick=Payment.PayGateway.New(),logo=plus,id=newpaygatebtn");
    _GroupBox();
    _SideBar();

    HomeDisplay([
      "id"=>"paygatewayhome",
      "logo"=>$dbo->Config['Core']."cportal/Files/asset/paygate.png",
      "text"=>"Select or Create New Payment Gateway to get started",
      "onclick"=>"Payment.PayGateway.New()",
      "value"=>"New Payment Gateway",
      "icon"=>"plus"
      ]);
      Box("id=paygatewaydetbx,style=display:none,class=fadeIn animated faster");
    //basic details
    GroupBox("title=Gateway Details,id=payGatedetgrp,size=1*1,logo=info-circle");
    
    TextBoxGroup();
    TextBox("title=Gateway Name,style=width:250px,id=paygatenametb,required=true,logo=tag");
    TextBox("title=Gateway Description,style=width:250px;margin-top:5px,id=paydateedecrtb,logo=info-circle");
    EmailBox("title=Email,style=width:250px,id=paygateemailtb,logo=at");
 
    PhoneBox("title=Contact,style=width:250px,id=paygatephonetb,logo=phone");
 
    TextBox("title=Address,style=width:250px,id=paygateaddrtb,logo=map,type=multiline");
    TextBox("title=Transaction Reference Indicator,style=width:250px,id=paygatetransindtb,logo=globe");
    
   /*  TextBox("title=Printout Footer,style=width:250px,id=paygatefootertb,readonly=true,logo=image");
    FlatButton("text=Set Printout Footer (Image), style=margin:auto; margin-top:0px;font-size:1em; width:260px,onclick=Payment.PayGateway.LoadFooter(_('paygatefootertb')),logo=image,id=paygatefooterbtn"); */

    _TextBoxGroup();
    _GroupBox();

    

    //Gateway Script
    GroupBox("title=Gateway Script,id=payGatescriptgrp,size=1*1,logo=code");
    TextBoxGroup();
    TextBox("title=Gateway Script,style=width:250px,id=paygatescripttb,required=true,readonly=true,logo=file");
    FlatButton("text=Set Gateway Script, style=margin:auto; margin-top:0px;font-size:1em; width:260px,onclick=Payment.PayGateway.LoadScript(_('paygatescripttb')),logo=upload,id=paygateprescriptbtn");
    TextBox("title=Pre Payment Method,style=width:250px,id=paygatepremtdtb,required=true,logo=code");
    Note();
    echo 'Initialize Payment (returns Payment Ref).';
    _Note();
    TextBox("title=Post Payment Method,style=width:250px,id=paygatepostmtdtb,logo=code");
    Note();
     echo "Post Payment Details to Gateway Platform";
    _Note();
    TextBox("title=Payment Query Method,style=width:250px,id=paygatequerytb,logo=code");
    Note();
     echo "Query Payment Status From Gateway Platform";
    _Note();
     TextBox("title=Payment Finish Method,style=width:250px,id=paygatefinishtb,logo=code");
    Note();
     echo "Finish Payment Process";
    _Note(); 
    /* _TextBoxGroup();
    Line();
    TextBoxGroup(); */
        
        _TextBoxGroup();

    /* Line();

    TextBoxGroup();
    TextBox("title=Post Payment Script,style=width:250px,id=paygatepoststb,required=true,logo=file");
    FlatButton("text=Set Post Payment Script, style=margin:auto; margin-top:0px;font-size:1em; width:260px,onclick=Payment.PayGateway.LoadScript('post'),logo=upload,id=paygatepostscriptbtn");
    Note();
     echo "Script to proccess/redirect payment to Gateway Platform, for online/card transaction";
    _Note();
    _TextBoxGroup(); */

    _GroupBox();

    //Gateway URLs
    GroupBox("title=Gateway URL,id=payGateurlgrp,size=1*1,logo=globe");
    TextBoxGroup();
    
    TextBox("title=Payment Request URL,style=width:250px,id=paygaterequesturltb,logo=file,readonly=true");
    TextBoxGroupItem();
    FlatButton("text=Set URL, style=margin:auto; margin-top:0px;font-size:1em; width:120px; float:left,onclick=Payment.PayGateway.LoadScript(_('paygaterequesturltb')),logo=upload,id=paygaterequestbtn");
    //TextBoxGroupItemMore();
    FlatButton("text=Copy URL, style=margin:auto; margin-top:0px;font-size:1em; width:120px; float:right,onclick=Payment.PayGateway.CopyURL('paygaterequesturltb'),logo=copy,id=paygatecopyrequestbtn");
    echo '<div style="clear:both"></div>';
    _TextBoxGroupItem();
    Note();
     echo "When accessed with the require parameter sent, will return the payment/transaction details";
    _Note();
    _TextBoxGroup();

    Line();

    TextBoxGroup();
    TextBox("title=Payment Notification URL,style=width:250px,id=paygateresponsetb,logo=file,readonly=true");
    //FlatButton("text=Set Payment Response Script, style=margin:auto; margin-top:0px;font-size:1em; width:260px,onclick=Payment.PayGateway.LoadScript(_('paygateresponsetb')),logo=upload,id=paygateresponsebtn");
    TextBoxGroupItem();
    FlatButton("text=Set URL, style=margin:auto; margin-top:0px;font-size:1em; width:120px; float:left,onclick=Payment.PayGateway.LoadScript(_('paygateresponsetb')),logo=upload,id=paygateresponsebtn");
    //TextBoxGroupItemMore();
    FlatButton("text=Copy URL, style=margin:auto; margin-top:0px;font-size:1em; width:120px; float:right,onclick=Payment.PayGateway.CopyURL('paygateresponsetb'),logo=copy,id=paygatecopyresponsebtn");
    echo '<div style="clear:both"></div>';
    _TextBoxGroupItem();
    Note();
     echo "Script to proccess/receive payment status/notification from Gateway Platform";
    _Note();
_TextBoxGroup();
TextBoxGroup();
TextBox("title=Post Responce Ref. ID,style=width:250px,id=paygateresponseidtb,logo=globe");
        Note();
     echo "Lookup Reference ID in Post Finish Script";
    _Note();
    _TextBoxGroup();


    _GroupBox();

    GroupBox("title=Printout Footer,id=payGatepfootgrp,size=1*1,logo=image");

  ImagePad("id=payGatefoot,maxsize=600000");
    _GroupBox();
    //Parameters
    GroupBox("title=Gateway Parameters,id=payGateparamgrp,size=3*1,logo=cogs,style=width:auto;min-width:100%;padding:0px 10px");
    TextBoxGroup("margin:auto;width:280px");
    Switcher("id=paygatestatus,state=0,text=STATUS,style=width:270px;font-size:1.2em,info=DEMO | LIVE,ontext=yes,offtext=no,align=right");
    _TextBoxGroup();
    Line();
    Box("style=overflow:auto;width:100%;margin:auto;position:relative,id=paygateparambx");
    $headerd = array(
      "*GateParam"=>"PARAMETER",
     "*GateDemo"=>"DEMO",
     "*GateLive"=>"LIVE"
    );
    SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-bottom:6px,case=none,id=paygateparamspreadsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,rowfilter=true,filtertitle=FILTER GATEWAY PARAMETERS,filterstyle=width:calc(100% - 16px);margin:auto,minrow=12",$headerd);

    _Box();
    _GroupBox();
_Box();
    _Form();
  _TabBody();

   //settings
   TabBody("name=PaySetting");
   
      	 
   GroupBox("title=Payment Settings,id=paystgrp,size=1*1,logo=cogs");
   /* TextBoxGroup();
   Note();
   echo "Payment Controls are managed in Module Settings - ".'<a href="javascript:Page.OpenByTabName(\'SSetting\')">Student Registration Settings</a>, <a href="javascript:Page.OpenByTabName(\'Esetting\')">Entrance Registration Settings</a> and <a href="javascript:Page.OpenByTabName(\'ssettings\')">School Payments Settings</a>';
   _Note();
   //get school details
   $paygatewayID = $schDet['PayThirdPartyID'];
  
   TextBox("title=Payment Gateway,style=width:250px,id=paygatewtb,required=true,logo=credit-card,selected=$paygatewayID",TextBoxSQL("select ID, Name from thirdparty_tb "));
   Note();
echo "Select Payment Gateway<br/>Payment Gateways can be manage and configured in the ".'<a href="javascript:Page.OpenByTabName(\'pgateway\')">Payment Gateway Module</a>';
   _Note();
   _TextBoxGroup(); */

   TextBoxGroup();
   TextBox("title=Payment Order Validity Period (Day),style=width:250px,id=payorderexpiretb,required=true,logo=calendar,type=number,text=".$schDet['OrderValidity']);
   Note();
     echo 'The period (in days) an unpaid order will be valid';
   _Note();
   $uniqueTransID = $schDet['UniqueTransID'] == "TRUE"?1:0;
   Switcher("id=uniquetranid,state=$uniqueTransID,text=Unique Transaction ID,style=width:100%;margin-top:3px,info=Unique ID for each Transaction Request,ontext=Auto,offtext=All,align=right,showstate=false");
   Note("style=font-size:12px");
   echo 'Always generate a new/unique Transaction ID for every transaction post to gateway';
  _Note(); 
   _TextBoxGroup();
   
   Line();
   $sch = SchoolPayDet();
   //$schd = GetSchool();
   //-1 = default - Active Semester - FALSE
//0 = off - All Semester - ALL
//1 = on - Auto Semester - TRUE
   $autosem = $sch['AutoSem'] == "TRUE"?1:($sch['AutoSem'] == "FALSE"?-1:0);
   $autolvl = $sch['AutoLevel'] == "TRUE"?1:0;
   TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
   Switcher("id=schautosem,state=$autosem,text=Auto {$schDet['SemLabel']},style=width:100%;margin-top:3px,info=Auto-Load {$schDet['SemLabel']},ontext=Auto,offtext=All,defaulttext=Active,align=right,showstate=true");
   Note("style=font-size:12px");
   echo '<strong style="font-weight:bold">All: </strong>Always Load/Display All '.$schDet['SemLabel'].'(Policy)</br><strong style="font-weight:bold">Active: </strong>Load/Display the Active '.$schDet['SemLabel'].'(Policy) <br/> You can Change the Active School '.$schDet['SemLabel'].' in <a href="javascript:Page.OpenByTabName(\'ssettings\')">School Settings Module</a> <br /><strong style="font-weight:bold">Auto: </strong>Load '.$schDet['SemLabel'].'(Policy) based on the last Payment '.$schDet['SemLabel'].'(Policy)';
  _Note(); 
  _TextBoxGroupItem();
  Switcher("id=schautolvl,state=$autolvl,text=Auto Level,style=width:100%;margin-top:3px,info=Auto-Load Level,ontext=Auto,offtext=Active,align=right,showstate=true");
   Note("style=font-size:12px");
   echo '<strong style="font-weight:bold">Active: </strong>Allow payment for expected level only <br/> You can Change the Active School Session in <a href="javascript:Page.OpenByTabName(\'ssettings\')">School Settings Module</a> <br /><strong style="font-weight:bold">Auto: </strong>Load Payment Level based on the last Payment';
  _Note(); 
  _TextBoxGroup();
Line();

  $bulkupdate= $schDet['BulkPayUpdate'] == "TRUE"?1:0;
   TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
   Switcher("id=schbulkupdate,state=$bulkupdate,text=Bulk Payment Update,style=width:100%;margin-top:3px,info=Update Multiple Payment(Bulk),ontext=ENABLE,offtext=DISABLE,align=right,showstate=false");
   Note("style=font-size:12px");
   echo 'Allow bulk Update of Payment(Offline) during bulk Course Reigistration';
  _Note(); 
  _TextBoxGroupItem();
  _TextBoxGroup();

  Line();

   _GroupBox();

   GroupBox("title=Part Payment Restrict,id=paypartrestgrp,size=1*1,logo=ban");
   $headerl = array(
     "*PartPLvlName"=>"LEVEL NAME",
    "*PartPLvl"=>"LEVEL",
   "*PartPRest"=>array("RESTRICT","YES|NO")
  );
   //get all restrict level
   $rstriclevel = $sch['PartPayRestrict'];
   $resarr = [];
if(trim($rstriclevel) != "-1" && trim($rstriclevel) != ""){
  $resarr = explode("~",$rstriclevel);
}
$lvldump = [];
$seenarr = [];
//get all school level
$schlvls = $dbo->RunQuery("select Level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1) ORDER BY Level");
if(is_array($schlvls) && $schlvls[1] > 0){
  $lastlvl = 0;
  $maaxextr = (int)$schDet['MaxExtraYear'];
  while($slvl = $schlvls[0]->fetch_assoc()){
    if(isset($seenarr[$slvl['Level']])){ //if level already seen
       //add level name to dump
       $levelsarr = explode(" , ",$lvldump[$seenarr[$slvl['Level']]][0]);
       if(!in_array($slvl['Name'],$levelsarr)){
$lvldump[$seenarr[$slvl['Level']]][0] .= " , ".$slvl['Name'];
       }
       
    }else{
       $rstatus = in_array($slvl['Level']."",$resarr)?1:0;
      $lvldump[] = [$slvl['Name'],$slvl['Level'],$rstatus];
      $seenarr[$slvl['Level']] = count($lvldump) - 1;
      $lastlvl = $slvl['Level'];
    }
  }
  for($dd=1; $dd<=$maaxextr; $dd++){
    $nlvl = (int)$lastlvl + $dd;
    $rstatus = in_array($nlvl."",$resarr)?1:0;
    $lvldump[] = ["Level ".$nlvl,$nlvl,$rstatus];
  }
  
}
SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-bottom:6px,id=partpaylvlrst,multiselect=false,cellfocus=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,rowfilter=true,filtertitle=FILTER PART PAYMENT RESTRICT LEVEL,filterstyle=width:calc(100% - 16px);margin:auto,minrow=6,readonly=PartPLvlName;PartPLvl",$headerl,$lvldump);
   _GroupBox();

   GroupBox("title=Payment Items,id=payitgrp,size=2,logo=tasks");
   $headerd = array(
     "*PItem"=>"ITEM",
    "*PItemAmt"=>"AMOUNT",
    "-PID"=>"PIID"
   );
    Box("id=payitemsbx");
  //  Box("id=payitemsbx,style=height:calc(".$GroupBoxStyle["height"]." - 30px);overflow:auto");
    //get all added payment item
  /*   $payitems = $dbo->Select("payitem_tb","ID,ItemName,FORMAT(Amt,2) as Amt");
    $dump=[];
    if(is_array($payitems) && $payitems[1] > 0){
       while($rw = $payitems[0]->fetch_assoc()){
        $pdump = [$rw['ItemName'],$rw['Amt']];
        $pdump['ID'] = $rw['ID'];
        $dump[] = $pdump;
       }
    } */
        // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
        
         SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-bottom:6px,id=payitems,multiselect=false,cellfocus=,cellblur=Payment.PaySetting.FormatAmt,cellkeypress=,dynamiccolumn=false,dynamicrow=true,rowfilter=true,filtertitle=FILTER PAYMENT ITEMS,filterstyle=width:calc(100% - 16px);margin:auto,disable=PID,minrow=12",$headerd,"SELECT ItemName,FORMAT(Amt,2) as Amt,ID FROM payitem_tb");
         _Box();

   _GroupBox();
   _TabBody();

   //Result Approval
   TabBody("name=PayApproval");
     Form("groupname=payapprgrpelem,action=javascript:Payment.PayApproval.Save(),id=grppayapprfrm");
     //load the results
   // print_r($staffDet);
     
    // print_r($dump);
     //echo $Depts;
     GroupBox("title=Offline Payment Approval,id=payapprgrp,size=4,logo=check");
         // Box("style=width:444px;display:inline-block;vertical-align:top");
         TextBoxGroup("width:calc(100% - 16px);margin:auto;font-size:0,9em","blockinmobile");
         TextBoxGroupItem();
          TextBox("title=Search Offline Payments,style=width:440px,onchange=,id=payappsearch,logo=search,info=Inteligent Search: Search by any information you have about the Offline Payment,textchange=Payment.PayApproval.Search"); 
          //_Box();
         TextBoxGroupItemMore();
         // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
          TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=payapprfilter,onchange=Payment.PayApproval.Search,logo=filter,info=Filter Search by Approval Status,selected=-1",array("All","APPROVED","UNAPPROVED"));
         // _Box();
         TextBoxGroupItemMore();
       // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
        //SubHeader(_Icon("list-alt")." MAXIMUM DISPLAY RECORDS"); 
        Ranges("id=payapprmaxrec,value=0.0204,max=500,min=10,text=MAXIMUM DISPLAY RECORDS,style=margin-left:0px"); 
        //_Box();
        TextBoxGroupItemMore();
      // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
       SmallButton("id=reloadbtnpayappr,logo=sync,style=margin:0px,title=Reload,onclick=Payment.PayApproval.Search()"); _Box();Box("style=clear:both");
       /* TextBoxGroupItemMore();
      // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
       SmallButton("id=selallappr,logo=refresh,style=margin:0px,title=Reload,onclick=Exams.Approval.Search()"); _Box();Box("style=clear:both"); */
       _TextBoxGroupItem();
       _TextBoxGroup();
       //_Box();
       Line();
       //echo "<div style=\"width:100%; height:2px;\" class=\"altBgColor2\" > </div>";
          Box("id=payapprrstsloadin,style=margin-top:100px;text-align:center;position:absolute;z-index:3;width:100%;visibility:hidden");
             Icon("sync fa-spin");
          _Box();
          
          Box("id=rstpayapprbx,style=margin-top:10px;width:100%;overflow:auto");
          //Get the UserID
        /*  $deptCond = "(1=1)";
          if(isset($staffDet)){
            $Depts = trim($staffDet['DeptIDs']);
            if($Depts != ""){
              // $deptCond = "(st.ProgID = ".str_replace("~"," OR st.ProgID = ",$Depts). ")";
              $deptCond = "(od.Info LIKE '%\"ProgID\":\"".str_replace("~","\" OR od.Info LIKE '%\"ProgID\":\"",$Depts)."\")";
            }
          }
          $limit = round((0.0204 * (500 - 10)) + 10);
          LoadPaymentAppr($deptCond,$limit); //in getinfo.php */
        _Box();  
      _GroupBox();

      

     _Form();
   _TabBody();
  
    //Wallet Settings
    TabBody("name=Wallet");
    Form("groupname=walletgrpelem,action=javascript:Payment.Wallet.Save(),id=grpwalletfrm");
    //displayant
    GroupBox("title=Wallet Amount,id=walletamtgrp,size=1,logo=money");
    //get amount
    $walet = $dbo->SelectFirstRow("walletcontrol_tb");
    $wamtdump=[];
    $minbal = 0;
    if(is_array($walet)){
      $minbal = $walet['MinBalance'];
      //echo $walet['Amts'];
      $walamt = json_decode($walet['Amts'],true);
      if(!is_null($walamt)){
        $cache = [];
        foreach($walamt as $wamt){
            if(in_array($wamt,$cache))continue;
            $cache[] = $wamt;
            $wamtdump[] = [number_format($wamt,2)];
        }
      }
    }
    SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=pwalletamtsheet,multiselect=false,cellfocus=,cellblur=Payment.Wallet.FormatAmt,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=10,rowfilter=false,disable=,filtertitle=FILTER AMOUNT",["*WAmt"=>"AMOUNT"],$wamtdump);
    _GroupBox();

    //Payment type selection
    GroupBox("title=Payment Type,id=walletpaytypegrp,style=width:290px,size=1,logo=money");
 Box("style=font-style:italic; padding:5px; width:auto; font-size:0.8em");
  echo 'Assign Payment Type to Wallet System';
_Box();
Box("style=max-height:260px;overflow:auto; width:95%;margin:auto;border-top:#CCC solid thin;position:relative; border-bottom:#CCC solid thin, class=greyShadow");

  //paytbll
 Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent,id=wpaytbll,multiselect=false,data-type=table,onselect=Student.RegReport.NullFunc,rowalt=true,rowfilter=true,filtertitle=Filter Payment Type,filterstyle=width:100%");
 THeader(array("PAYMENT TYPE"),"style=text-align:left");
 $PayID = 0;
 if(is_array($walet))$PayID = $walet['PayID'];
$allitem = $dbo->Select("item_tb","","studType = 'w'");
if(is_array($allitem)){
   if($allitem[1] > 0){
    while($rw = $allitem[0]->fetch_assoc()){
$sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=$sel");
//TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
    }
   }
}
//  THeader(array("PAYMENT ITEM"),"style=text-align:left");
// TRecord(array("Accptance Fee"),"style=text-align:left");
// TRecord(array("School Fee"),"style=text-align:left");
// TRecord(array("Convocation Fee"),"style=text-align:left");
// TRecord(array("PUTME Fee"),"style=text-align:left");
 _Table();

 _Box();
 TextBoxGroup("border-top-color:transparent; width:95%;margin:auto");
 /*TextBoxGroupItem();
  Note("style=font-size:12px");
 echo 'All Wallet Payment Types will be automatically disabled in Student School Payment.';
_Note(); 
_TextBoxGroupItem();*/
_TextBoxGroup();
 //Ranges("id=hdhd,min=400,max=2000,text=Testing,value=0.8");
 _GroupBox();

 GroupBox("title=Settings,id=walletsetgrp,style=width:290px,size=1,logo=cogs");
 TextBoxGroup("width:95%;margin:auto");
 TextBox("title=Minimum Wallet Balance,style=width:250px,id=wallmimbaltb,required=true,logo=money,type=number,text=".$minbal);
 Note("style=font-size:12px");
 echo 'Minimum Wallet Balance';
_Note();
 _TextBoxGroup();
 Line();
 TextBoxGroup("width:95%;margin:auto");
 $minID = $walet['MenuID'];
 TextBox("title=Wallet Portal Menu,style=width:250px,id=wallportmenu,required=true,logo=th,type=text,selected=$minID",TextBoxSQL("select ID, Name from new_apply_group_tb WHERE Enable =1 ORDER BY MenuOrder"));
 Note("style=font-size:12px");
 echo 'Select the Wallet Portal Menu from list of Portal Menus';
_Note();
 _TextBoxGroup();
Line();
 TextBoxGroup();
 Switcher("id=dynamicwalamt,state={$walet['DynamicAmt']},text=Dynamic Amount,style=width:100%;margin-top:3px,info=Allow dynamic amount entering,ontext=ALLOW,offtext=Disallow,align=right,showstate=false");
 _TextBoxGroup();

 
 _GroupBox();

    _Form();
  _TabBody();

  //Payment Controls
  TabBody("name=Controls");
  Form("groupname=pcontrolsgrpelem,action=javascript:Payment.Controls.Save(),id=grppcontrolsfrm");
  

  _Form();
_TabBody();
 
 _Tab();
_Page();

 ?>