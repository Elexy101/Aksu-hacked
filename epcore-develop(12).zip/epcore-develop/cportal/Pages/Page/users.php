<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php");  
 ?>

<?php
   Page();
     Tab();
      TabBody("name=Manage");
      SideBar();
      SearchBox("id=usermag,title=Search User,onselect=Users.Manage.Load,scope=all,onunselect=,info=Search User by Name\, email or ID,logo=search,domain=user_tb,criteria=UserID:PUID;UserName:Name;UserLogName,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=UserLogName,action=Users.Manage.Clear(),actionlogo=plus,actiontitle=ADD NEW USER");
      _SideBar();
      HomeDisplay([
        "id"=>"manageuserhome",
        "logo"=>$dbo->Config['Core']."cportal/Files/asset/users.png",
        "text"=>"Search or Create Cportal Users",
        "onclick"=>"Users.Manage.Clear()",
        "value"=>"Create New User",
        "icon"=>"plus"
        ]);
      Form("groupname=usermanageGrp,id=userManageFrm,action=javascript:Users.Manage.SaveReal(),style=display:none");
        
        GroupBox("title=Basic Details,size=1,id=userbsDetgrp,logo=user");
        TextBoxGroup();
          EmailBox("id=userLognametb,info=User login name (email address),title=User Login Name,style=width:250px,logo=lock,required=true");
          TextBox("id=usernametb,info=User Full Name,title=User Name,style=width:250px,logo=user,required=true");
           Switcher("id=ustaffst,state=off,text=SCHOOL STAFF,style=width:250px;font-size:1.2em,info=User is a Staff of the School,onchange=Users.Manage.StaffChange,ontext=YES,offtext=NO");
           /*Box("id=ustaffdet,style=opacity:0.6;margin-bottom:20px");
             TextBox("id=ustaffid,info=School Identification,title=Staff ID,style=width:270px,logo=address-card-o,readonly=true");
             //TextBox("id=ustaffname,title=Full Name,info=Full Name in School Approved Format,style=width:270px,logo=users,required=true,readonly=true");
             //TextBox("id=ufname,title=First Name,style=width:270px,logo=user,required=true,readonly=true");
             //TextBox("id=uoname,title=Other Names,style=width:270px,logo=user-plus,readonly=true");
            TextBox("id=ustaffunit,title=Unit / Department,info=Unit or Department of Service,style=width:270px,logo=university,readonly=true");
           _Box();*/
           Note();
              echo 'Access the <a href="javascript:Page.OpenByTabName(\'staff\')">Staff Module</a>, to Manage Staff Data';
           _Note();
           _TextBoxGroup();
           
        _GroupBox();


        GroupBox("title=User Passport,id=userpasspgrp,size=2,logo=image");
           ImagePad("id=userpasspd,maxsize=600000");
       _GroupBox(); 
       Hidden("CurrStaffSt","0");
      /* GroupBox("title=Staff,id=userstaffgrp,size=1,logo=address-card");
           Switcher("id=ustaffst,state=off,text=SCHOOL STAFF,style=width:270px,info=Add User as a Staff,onchange=Users.Manage.StaffChange");
           Box("id=ustaffdet,style=opacity:0.6;margin-bottom:20px");
             TextBox("id=ustaffid,info=School Identification,title=Staff ID,style=width:270px,logo=address-card-o,readonly=true");
             TextBox("id=ustaffname,title=Full Name,info=Full Name in School Approved Format,style=width:270px,logo=users,required=true,readonly=true");
             //TextBox("id=ufname,title=First Name,style=width:270px,logo=user,required=true,readonly=true");
             //TextBox("id=uoname,title=Other Names,style=width:270px,logo=user-plus,readonly=true");
            TextBox("id=ustaffunit,title=Unit / Department,info=Unit or Department of Service,style=width:270px,logo=university,readonly=true");
           _Box();
           Box("style=font-size:0.9em; padding:4px; font-style:italic");
              echo "Access the <strong class=\"altColor2\">SCHOOL "._Icon("angle-double-right")." STAFF Module </strong>, to comprehensively manage Staff Data";
           _Box("");
       _GroupBox();*/
       _Form();
      _TabBody();
      TabBody("name=Priv");
       
       // StudentSearchBox("id=userpriv,title=Search User,onselect=Users.Priv.Load,scope=all,onunselect=Users.Priv.Clear,info=Search User by Name\, email or ID,script=Pages/Scripts/Users/usersearch.php,logo=search");
       SideBar();
       SearchBox("id=userpriv,title=Search User,onselect=Users.Priv.Load,scope=all,onunselect=Users.Priv.Clear,info=Search User by Name\, email or ID,logo=search,domain=user_tb,criteria=UserID:PUID;UserName:Name;UserLogName,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=UserLogName");
       _SideBar();
       HomeDisplay([
        "id"=>"userprivhome",
        "logo"=>$dbo->Config['Core']."cportal/Files/asset/userpriv.png",
        "text"=>"Search and select a user to get started"
        ]);

       Form("group=userprivGrp,id=userPrivFrm,action=javascript:Users.Priv.SaveReal(),style=display:none,class=fadeIn animated faster");
        $menus = $dbo -> Select("menu_tb","","1=1 ORDER BY GrpOrder"); //get all menus
        if(is_array($menus)){
           if($menus[1] > 0){
            
             while($menu = $menus[0]->fetch_array()){ //move trough all menus
              $id = $menu['ID']; $GName = $menu['GName']; $DName = $menu['DName']; $Tabs = $menu['Tabs']; $logo = $menu['Logo'];
              if(trim($Tabs) != ""){
              $TabArr = $dbo->DataArray($Tabs); //covert tabs data string to array
              if(count($TabArr) > 0){ //if tab exist
                if($GName != "Users"){ //if menu not users (cos only the default user is permitted to manage user)
                GroupBox("group={$GName}grp,id={$GName}{$id}grps,title={$DName},size=1,logo={$logo}");
                Box("style=max-height:360px;overflow:auto;padding-bottom: 20px;box-sizing: border-box;");
                  TextBoxGroup();
                   foreach($TabArr as $tabid => $tabname){
                     //$st = in_array($tabid,$privs)?"on":"off"; 
                     Switcher("id=sw_{$tabid},state=off,text={$tabname},style=width:250px;font-size:1.2em,info=Allow/Disallow {$tabname} Module,onchange=Users.Priv.SwitchChange");
                   }
                   _TextBoxGroup();
                _Box();
                _GroupBox();
              }
              }
              }
             }
           }
        }
      Hidden("selprivs","");

       _Form();
      _TabBody();
     _Tab();
   _Page();


 ?>