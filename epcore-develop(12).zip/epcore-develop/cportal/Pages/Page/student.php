<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 
 ?>
<?php
$sch = GetSchool();
$studcntr = StudentSettings();
$studrecgrpdis = $studcntr['DisplayStudData'];
if(!is_null($studrecgrpdis) && trim($studrecgrpdis) != ""){
	$studrecgrpdis = json_decode($studrecgrpdis,true);
	if(is_null($studrecgrpdis)){
		$studrecgrpdis = [];
	}
}else{
	$studrecgrpdis = [];
}
//echo json_encode($studrecgrpdis);
$studrecgrpdisarr = [
	"Basic"=>["Display"=>true,"Title"=>"Details","Descr"=>"Student Personal Details","Required"=>true],
"School"=>["Display"=>true,"Title"=>"School","Descr"=>"Academic Details","Required"=>true],
"Passport"=>["Display"=>true,"Title"=>"Passport","Descr"=>"Student Passport Photograph","Required"=>true],
"Contact"=>["Display"=>true,"Title"=>"Contact","Descr"=>"Student Contact Details","Required"=>true],
"NOK"=>["Display"=>true,"Title"=>"Next of Kin","Descr"=>"Student Next of Kin Details","Required"=>false],
"Guidiance"=>["Display"=>true,"Title"=>"Guidance","Descr"=>"Student Sponsors/Guidance","Required"=>false],
"Result"=>["Display"=>true,"Title"=>"Result Details","Descr"=>"Student Entrance Result Details","Required"=>false],
"Registration"=>["Display"=>true,"Title"=>"Registration","Descr"=>"Student Registration/Portal Details","Required"=>true],
"Payment"=>["Display"=>true,"Title"=>"Payment Record","Descr"=>"Student Payment Records","Required"=>false],
"Course"=>["Display"=>true,"Title"=>"Course Registration","Descr"=>"Student Course Registration Details","Required"=>false]
];


$studrecgrpdisarr = array_merge($studrecgrpdisarr,$studrecgrpdis);

$BasicDis = (isset($studrecgrpdisarr['Basic']) && $studrecgrpdisarr['Basic']['Display'] == true)?"":",style=display:none";
	$SchoolDis = (isset($studrecgrpdisarr['School']) && $studrecgrpdisarr['School']['Display'] == true)?"":",style=display:none";
	$PassportDis = (isset($studrecgrpdisarr['Passport']) && $studrecgrpdisarr['Passport']['Display'] == true)?"":",style=display:none";
	$ContactDis = (isset($studrecgrpdisarr['Contact']) && $studrecgrpdisarr['Contact']['Display'] == true)?"":",style=display:none";
	$NOKDis = (isset($studrecgrpdisarr['NOK']) && $studrecgrpdisarr['NOK']['Display'] == true)?"":",style=display:none";
	$ResultDis = (isset($studrecgrpdisarr['Result']) && $studrecgrpdisarr['Result']['Display'] == true)?"":",style=display:none";
	$RegistrationDis = (isset($studrecgrpdisarr['Registration']) && $studrecgrpdisarr['Registration']['Display'] == true)?"":",style=display:none";
	$PaymentDis = (isset($studrecgrpdisarr['Payment']) && $studrecgrpdisarr['Payment']['Display'] == true)?"":",style=display:none";
	$CourseDis = (isset($studrecgrpdisarr['Course']) && $studrecgrpdisarr['Course']['Display'] == true)?"":",style=display:none";
// Page("save=Student.Save,print=Student.Print,clear=Student.Clear,delete=Student.Delete,copy=Student.Copy,paste=Student.Paste");
Page("");
  Tab(); 
   //bio data tab
   TabBody("name=BioData");
   SideBar();
   SearchBox("id=searchStud,title=Search Student,onselect=Student.BioData.LoadStudent,logo=search,info=Search Student by Registration Number or Name,script={$_POST['CORE']}cportal/Pages/Scripts/Student/studsearch.php,action=Student.BioData.Clear(),actionlogo=plus,actiontitle=ADD NEW STUDENT");
   _SideBar();
   HomeDisplay([
	"id"=>"studentrecdefault",
	"logo"=>$dbo->Config['Core']."cportal/Files/asset/studenthome.png",
	"text"=>"Search or Add a New Student",
	"onclick"=>"Student.BioData.LoadStudent()",
	"value"=>"Add Student",
	"icon"=>"plus"
	]);
     Form("groupname=BioDataelem,action=javascript:Student.BioData.PSave(),id=biodatafrm,style=display:none,class=fadeIn animated fastest");
	 GroupBox("title=Details,id=bDatagrpDet,size=1,logo=id-badge".$BasicDis);
	 Box("id=bDatagrpDetbx");
	 TextBoxGroup();
	    TextBox("title=Surname,style=width:250px;text-transform:uppercase,id=surnametxt,required=true,logo=users");
		TextBox("title=Firstname,style=width:250px;text-transform:uppercase,id=firstnametxt,required=true,logo=user");
		TextBox("title=Othername,style=width:250px;text-transform:uppercase,id=othernametxt,logo=user-plus");
		TextBox("title=Date of Birth,type=calendar,style=width:250px;text-transform:uppercase,id=studDOB,logo=calendar");
		
		//DateBox("title=DATE OF BIRTH,id=studDOB,required=true,range=".((int)date("Y") - 10)."-".((int)date("Y") - 61));
		TextBox("title=Gender,style=width:250px;text-transform:uppercase,id=studgender,required=true,logo=female",array("Male","Female"));
		TextBox("title=Marrital Status,style=width:250px;text-transform:uppercase,id=studstatus,required=true,logo=heart",array("Single","Married"));
		TextBox("title=Religion,style=width:250px;text-transform:uppercase,id=studreligion,logo=street-view",array("Christainity"=>"Christainity","Islamic"=>"Islamic","Others"=>"Others"));
		_TextBoxGroup();
		_Box();
	 _GroupBox();

	
	 //school details
		GroupBox("title=School,id=bDatagrpSch,size=1,logo=university".$SchoolDis);
		Box("id=bDatagrpSchbx");
	    TextBoxGroup();
		 TextBox("title=Registration Number,style=width:250px;text-transform:uppercase,id=studregNo,logo=eye,required=false");
		 		 
		 TextBox("title=Entrance Number,style=width:250px;text-transform:uppercase,id=jambNo,logo=graduation-cap,required=false");
		 
		 _TextBoxGroup();
		 Line();
		 TextBoxGroup();
		 if(is_null($sch['SchStrucContr'])){ //no structure
			Note();
			echo "No Academic Structure Configured, Kindly contact the Admin";
			_Note();
		   }
		   $schStruc = json_decode($sch['SchStrucContr'],true);
		 $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=stud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
		  } 
		  
		  $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");

		  //$Studystr = isset($schStruc['StudyID'])?$schStruc['StudyID']:["Name"=>"Study","SilentMode"=>"false"];
		 TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=studstudy,required=true,onchange=Student.GenLoader.LoadFac,logo=building-o",$studyarr);
		 //,chain=studstudy:;studfac:;studdept:;studprog:;studlvl:
//$Facstr = isset($schStruc['FacID'])?$schStruc['FacID']:["Name"=>"Faculty","SilentMode"=>"false"];
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,id=studfac,onchange=Student.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",array(""));
		 //TextBoxSQL("select  * from fac_tb order by FacName")
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,onchange=Student.GenLoader.LoadProg,id=studdept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array(""));

		  TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=studprog,required=true,onchange=Student.GenLoader.LoadClass,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']}",array(""));

		  TextBox("title=Start Session,style=width:250px;text-transform:uppercase,id=studstartses,required=true,dropup=true,onchange=Student.GetLevel,logo=calendar",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
		  Note("style=font-size:10px");
			  echo 'Operational: <b style="font-weight:bold" id="oplvl">--</b><br/>Calculated: <b style="font-weight:bold" id="exlvl">--</b>';
		_Note();
		TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=studclass,required=false,dropup=true,logo=users,silent={$schStruc['ClassID']['SilentMode']}",array() );

//echo $schStruc['ProgID']['SilentMode'];
		  //TextBox("title=Level,style=width:250px;text-transform:uppercase,id=studlvl,required=true,logo=list-ol",array(""));//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)")
		 
			_TextBoxGroup();
			_Box();
	 _GroupBox();
	 
	 
	 //passport photograph
	 GroupBox("title=Passport,id=bDatagrpPassp,size=1,logo=image".$PassportDis);
	 Box("id=bDatagrpPasspbx");
	  // ImageBox("style=margin-top:15px,id=studpassp");
	  // echo '<input type="hidden" name="temppass" id="temppass" value="" />';
	  // FlatButton("text=Change, style=margin:auto; margin-top:15px; width:250px,onclick=Student.BioData.ChangePassport(),logo=image,id=uploadpw");
			ImagePad("id=studpassp,maxsize=300000");	 
		_Box();
	 _GroupBox();
	 
	 
	 GroupBox("title=Contact,id=bDatagrpCont,size=1,logo=address-book".$ContactDis);
	     /*$states = array();
		 $statesrst =  $dbo->Select4rmdbtb("state_tb","","1 = 1 order by StateName");
		 if(is_array($statesrst)){
			if($statesrst[1] > 0){
				while($st = mysql_fetch_array($statesrst[0])){
					$states[$st[0]] = $st[1];
				}
			}
		 }*/
   Box("id=bDatagrpContbx");
		 TextBoxGroup();
	     TextBox("title=State of Origin,style=width:250px;text-transform:uppercase,id=stateorig,required=true,logo=map,onchange=Student.BioData.LoadLGA,chain=stateorig:;lga:;",TextBoxSQL("select * from state_tb order by StateName"));
		 TextBox("title=Local Goverment Area,style=width:250px;text-transform:uppercase,id=lga,logo=map-marker",array(""));
		 TextBox("title=Nationality,style=width:250px;text-transform:uppercase,id=nat,logo=globe",array("NIGERIAN","OTHERS"));
		 EmailBox("title=Email,style=width:250px;text-transform:uppercase,id=bdemail,logo=envelope");
		 PhoneBox("title=Phone Number,style=width:250px;text-transform:uppercase,id=studphone,required=true,logo=phone");
		 TextBox("title=Address,type=multiline,style=width:100%;text-transform:uppercase,id=studaddr,logo=map-signs");
		 //TextPad("title=ADDRESS,style=width:250px; height:100px,id=studaddr,logo=map-signs");
		 _TextBoxGroup();
_Box();
	 _GroupBox();

	 
	 /*Next of kin*/
	 GroupBox("title=Next of Kin,id=bDatagrpNOK,size=1,logo=users".$NOKDis);
	 Box("id=bDatagrpNOKbx");
	 TextBoxGroup();
	 TextBox("title=Name,style=width:250px;text-transform:uppercase,id=nkname,logo=connectdevelop");
	 
		 PhoneBox("title=Phone Number,style=width:250px;text-transform:uppercase,id=nkphone,logo=phone");
		 TextBox("title=Address,type=multiline,style=width:250px;text-transform:uppercase,id=nkaddr,logo=map-signs");
		 //TextPad("title=ADDRESS,style=width:250px; height:100px,id=nkaddr,logo=map-signs");
		/* Box("id=txtbxxx");
		
		 _Box();*/
		 _TextBoxGroup();
_Box();
	 _GroupBox();
	

	 GroupBox("title=Result Details,id=bDatagrpRstDet,size=1,logo=list-alt".$ResultDis);
	 Box("id=bDatagrpRstDetbx");
	 TextBoxGroup();
	     TextBox("title=Jamb Aggregate,style=width:250px;text-transform:uppercase,id=jambscor,logo=star-half-o");
		 _TextBoxGroup();

		 Line();
		// Text("text=OLEVEL,style=display:block;font-weight:bold;color:#BBB;margin-top:10px;width:110px;margin-right:4px");
		//SubHeader("OLEVEL");
		 /*TextBox("title=Sitting,style=width:270px,id=olvrstSitting",array("1"=>"First","2"=>"Second"));*/
		 Box("id=gradebx,style=opacity:0;visibility:hidden;height:310px; margin-top:0px;width:280px;position:absolute;z-index:1;background-color:rgba(0\,0\,0\,.1);overflow:auto;display:flex");
		 Table("rowselect=false,style=width:100px;height:auto;margin-left:90px;align-self:center;text-align:center,id=gradetb,multiselect=false,onselect=Student.BioData.SetGrade,onunselect=Student.BioData.SetGrade");
		  THeader(array("Grade",_Icon('times','" onclick="Student.BioData.SetGrade(this)')),"cspan=d1:2");
		  $grds = $dbo->Select("olvlgrade_tb");
		  if(is_array($grds)){
			  if($grds[1] > 0){
				  $cnt = 0;
				  $tot = 0;
				  $grdarr = array();
				  $passDataStr = "";
				  $passDataStrID = "";
				  while($grd = $grds[0]->fetch_array()){
                      $grdarr[] = $grd['Grade'];
					  $passDataStr .= $grd['Grade']."=".$grd['PASS']."&";
					  $passDataStrID .= $grd['ID']."=".$grd['PASS']."&";
					  $cnt++;
					  $tot++;
					  if($cnt == 3){
						  TRecord($grdarr);
						  $cnt = 0;
						  $grdarr = array();
					  }
					  if($tot == $grds[1]){ //if last
                         $rem = 3 - $cnt;
						 if($rem > 0){ //if vacant cell exist
                           TRecord($grdarr);
						 }
					  }
					
				  }
				  $passDataStr = rtrim($passDataStr,"&");
				  $passDataStrID = rtrim($passDataStrID,"&");
                  Hidden("PassDataStr",$passDataStr);
                  Hidden("PassDataStrID",$passDataStrID);
			  }
		  }
		   /*TRecord(array("A1","B2","B3"));
		   TRecord(array("C4","C5","C6"));
		   TRecord(array("D7","E8","F9"));
		   TRecord(array("NA"),"cspan=d1:3");*/
		 _Table(); 
		 
		 _Box();
/* border-top:1px #D5D5D5 solid;border-bottom:1px #D5D5D5 solid; */
		 Box("id=olvlrst,style=opacity:1;position:absolute;height:300px; padding-top:5px; width:277px;overflow:auto");
		 TextBoxGroup();
		   TextBoxGroupItem("type=head");
		 //Text("text=FIRST SITTING,style=text-align:center;width:100%;font-size:0.8em");
		 echo '<span style="font-size:0.8em">FIRST SITTING</span>';
		 TextBoxGroupItemMore();
		 //echo '</td><td>';
		 //Text("text=SECOND SITTING,style=text-align:center;width:100%;font-size:0.8em");
		 echo '<span style="font-size:0.8em">SECOND SITTING</span>';
		 _TextBoxGroupItem();
		 $olvelexmtype = TextBoxSQL("select ID, Name from olevelexamtype_tb");
		 TextBoxGroupItem();
		 TextBox("title=Exam Type,style=width:110px;margin-right:4px;display:inline-block,id=olvrstxamtype1,logo=pencil-square-o",$olvelexmtype);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Type,style=width:110px;margin-right:0px;display:inline-block,id=olvrstxamtype2,logo=pencil-square-o,required=false",$olvelexmtype);
		 _TextBoxGroupItem();

		 $daysarry = array();
		for($a=(int)date("Y"); $a >= (int)date("Y") - 50; $a--){
		  $daysarry[$a] = $a;
		}
		TextBoxGroupItem();
		 TextBox("title=Exam Year,style=width:110px;margin-right:4px;display:inline-block,logo=calendar,id=olvrstxamyear1",$daysarry);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Year,style=width:110px;margin-right:0px;display:inline-block,logo=calendar,id=olvrstxamyear2",$daysarry);
		 _TextBoxGroupItem();
		 $batcharr = array(1=>"Internal",2=>"External");
		 TextBoxGroupItem();
		 TextBox("title=Exam Batch,style=width:110px;margin-right:4px;display:inline-block,logo=users,id=olvexmbatch1",$batcharr);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Batch,style=width:110px;margin-right:0px;display:inline-block,logo=users,id=olvexmbatch2",$batcharr);
		 _TextBoxGroupItem();

		 TextBoxGroupItem();
		 TextBox("title=Exam Number,style=width:110px;margin-right:4px;display:inline-block,id=olvexamno1,logo=user");
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Number,style=width:110px;margin-right:0px;display:inline-block,id=olvexamno2,logo=user");
		 _TextBoxGroupItem();

		 TextBoxGroupItem();
		 TextBox("title=School Name,style=width:110px;margin-right:4px;display:inline-block,id=olvrstschn1,logo=university");
		 TextBoxGroupItemMore();
		 TextBox("title=School Name,style=width:110px;margin-right:0px;display:inline-block,id=olvrstschn2,logo=university");
		 _TextBoxGroupItem();
		 _TextBoxGroup();
echo '<div style="margin-top:10px"></div>';
		   Table("rowselect=false,style=width:95%;font-size:0.7em;margin-top:10px;margin:auto;border-top-color:transparent,id=olevelrst,onselect=Student.BioData.ShowGrade,onunselect=Student.BioData.ClearGrade,multiselect=false,rowfilter=true,filtertitle=Filter Subject,filterstyle=width:95%;margin:auto");
		        THeader(array("FIRST SITTING","SUBJECT","SECOND SETTING"));
		       $olvelrsts = $dbo->Select4rmdbtb("olvlsubj_tb");
			  // $grades = array(array("A1"=>"A1","B2"=>"B2","B3"=>"B3","C4"=>"C4","C5"=>"C5","C6"=>"C6","D7"=>"D7","E8"=>"E8","F9"=>"F9"));
			   if(is_array($olvelrsts)){
				   if($olvelrsts[1] > 0){
					   while($olvlrst = $olvelrsts[0]->fetch_array()){
						    TRecord(array("",'<div style="text-align:center">'.$olvlrst[1].'</div>',""),"style=text-align:center,id=".trim(strtolower(str_replace(array(" ",",","="),array(".","\,","\="),$olvlrst[1]))));
					   }
					  // THeader(array("TOTAL","P0|F0|T0","P0|F0|T0"),"style=text-align:center;font-weight:bolder,id=totalrst");
				   }
			   }
		   _Table();
			_Box();
			_Box();
	 _GroupBox();
	 
	
		GroupBox("title=Registration,id=bDatagrpReg,size=1,logo=list".$RegistrationDis);
		Box("id=bDatagrpRegbx");
	  TextBoxGroup();
		TextBox("title=Registration Level,style=width:250px;text-transform:uppercase,id=studReglvl,logo=list",array("1"=>"Fresh","2"=>"Verfication","3"=>"Basic Details","4"=>"Contact","5"=>"Academic","6"=>"Complete"));
		TextBox("title=Registration Date,type=calendar,style=width:250px;text-transform:uppercase,id=regDate,logo=calendar");
		_TextBoxGroup();
		Line();
		TextBoxGroup();
		TextBox("title=Admission Session,style=width:250px;text-transform:uppercase,id=admisionses,required=false,dropup=false,logo=calendar",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
		TextBox("title=Admission Date,type=calendar,style=width:250px;text-transform:uppercase,id=adDate,logo=calendar");
		TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=modeentry,logo=sign-in",TextBoxSQL("select Level, Name from modeofentry_tb"));
	
		_TextBoxGroup();
		Line();
		TextBoxGroup();
	   //DateBox("title=REGISTRATION DATE,id=regDate,range=".date("Y")."-".((int)date("Y") - 90));
		//DateBox("title=ADMISSION DATE,id=adDate,logo=calender,range=".date("Y")."-".((int)date("Y") - 90));
		TextBox("title=Access Code,style=width:250px,id=studaccescode,required=true,logo=braille");
		_TextBoxGroup();
		Line();
		TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
 Switcher("id=studEnable,state=1,text=Active Account,style=width:100%;margin-top:10px,info=Activate/Deactivate Student Account,ontext=yes,offtext=no,align=right");
 _TextBoxGroup();
		_Box();
	 _GroupBox();

	 
	 GroupBox("title=Payment Records,id=bDatagrppayrec,size=2,logo=money".$PaymentDis);
		
		Box("id=bDatagrppayrecbx,style=max-height:400px;overflow:auto");
		DefaultBox("logo=money,text=Payment History");
		_Box();

	 _GroupBox();

	 
	 GroupBox("title=Course Registration,id=bDatagrpcreg,size=2,logo=th".$CourseDis);

	 Box("id=bDatagrpcregbx,style=max-height:400px;overflow:auto");
	 DefaultBox("logo=history,text=Course Registration History");
	 _Box();

	 _GroupBox();
	
	 echo '<div style="clear:both" ></div>';
	_Form();
   _TabBody();
   
   /*Student Bio-Data Pre Loader*/
   TabBody("name=PreLoad");
   /* Box("class=defaultTabText");
	  Box();Icon("info-circle fa-3x");_Box();
	   Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
	  Box();echo"Internal Evaluation in Progress ....";_Box();  
	 _Box(); */
	 Form("groupname=objgrpelempreload,action=javascript:Student.PreLoad.PerformSave(),id=grpmngpreloadfrm,style=height:100%");
	 SideBar();
	 GroupBox("title=Academic Details,id=preloadaccdetdetgrp,size=1*1,logo=list-alt,sticky=true");
     
	 $userID = 0; $staffID = 0;$loadcond="";
	 $user = $_POST['USER'];
	 $deptasign = "";
	 if($user != ""){
	   $userdet = explode("~",$user);
	   if(count($userdet) > 0){
		 $userID = $userdet[0];
		 //get the staffdet
		 $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
		 if(is_array($staffDet)){
			$staffID = $staffDet["StaffID"];
			//$courses = trim($staffDet['Courses']);
			/* if($courses != ""){
			  $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
			} */
		   $deptasign = $staffDet['DeptIDs'];

		 }
	   }
	 }
	 $UID = $userID;
	 $intStudyID = key($studyarr); //get the selected study
	 if(trim($deptasign) != ""){ //if dept assign to user
		
		 //check if one dept asign
		 $deptasignarr = explode("~",$deptasign); //get all asign departids
		 $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
	   //get study based on the assigned dept
	   $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
	  /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
	   if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
		 if(count($deptasignarr) < 2){ //if one dept/prog assigned
		  
		   //load level based on the prog
		   //$lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
		   $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
		   $spillStr = ExtraLevelString();
		   $lstlvl = end($lvlarr);
		   $lstkey = key($lvlarr);
		   for($s=1;$s <= 4; $s++){
			 $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
		   }
		   
		   //load all classes
		   $classarr = TextBoxSQL("(select 0, 'NONE') UNION (select ID, Name from studentclass_tb where ProgID=".$dbo->SqlSafe(trim($deptasign)).")");
	   } 
	   }
	TextBoxGroup();
	$schStruc = json_decode($sch['SchStrucContr'],true);
	$classTextbox = "";
	  //LoadFac
	 if(trim($deptasign) == ""){ //if no dept/prog assing
	   $scharr = TextBoxSQL("select * from school_grp_tb");
	   if(count($scharr) > 1){
		 TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=preloadschtb,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
	   }
	   $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";
	   TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=preloadstudy,required=true,selected=$selestu,logo=building-o,onchange=Student.PreLoad.GenLoader.LoadFac",$studyarr);
	  TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=preloadfac,onchange=Student.PreLoad.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
	  //TextBoxSQL("select * from fac_tb order by FacName")
	  TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Student.PreLoad.GenLoader.LoadProg,id=preloaddept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
	   TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=preloadprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Student.PreLoad.GenLoader.LoadClass",array());
	   $classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=preloadclass,required=true,logo=,silent={$schStruc['ClassID']['SilentMode']}",array() );
	  /*  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoader.LoadSemester",array() ); *///TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
	 }else{ //if dept asign
		 //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=cstudy,required=true,selected=-1,logo=building-o,onchange=Course.ManageCourse.GenLoader.LoadLevel",$studyarr);
		 
		 //initial study
		  if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
		   echo '<input type="hidden" id="preloadprog" class="objgrpelemmgecourse" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
		   if(!isset($progDet)){
			 $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
						  }
						  
						 if(is_array($progDet)){
							  Note();
					 echo $progDet['FacName']. " - ".$progDet['ProgName'];
			 _Note();
						 }
			//Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
			$classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=preloadclass,required=true,logo=users,silent={$schStruc['ClassID']['SilentMode']}",$classarr);
		  /*  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoader.LoadSemester,chain=preloadlvl:;preloadsemest:",$lvlarr); //load the lvel drop down */
		 }else{ // if multiple dept/prog assigned
		 $deptasignsql = "p.ProgID=".str_replace("~", " or p.ProgID=",$deptasign);
		   //load prog the textbox
		   TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=preloadprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Student.PreLoad.GenLoader.LoadClass,chain=preloadprog:;preloadlvl:;preloadsemest:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
		   $classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=preloadclass,required=true,logo=users,silent={$schStruc['ClassID']['SilentMode']}",array() );
		   //create lvl dropdown
		   /* TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoader.LoadSemester",array() ); */
		 }
	   }
  /*  TextBox("title=Semester,style=width:250px;text-transform:uppercase,id=preloadsemest,required=true,logo=star-half-o,onchange=",array()); */
  TextBox("title=Batch/Start Session,style=width:250px;text-transform:uppercase,id=preloadstartses,required=true,onchange=Student.PreLoad.GenLoader.GetLevel,logo=calendar",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
	   Note("style=font-size:12px");
		   echo 'Calculated Level: <b style="font-weight:bold" id="DisplayLvl">--</b>';
	 _Note();
   $op = "0";
   echo $classTextbox;
   TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=preloadmoe,required=true,logo=university",TextBoxSQL("select Level,Name from modeofentry_tb"));
   _TextBoxGroup();
   echo "<br/>";
	 FlatButton("text=Load Students,logo=list-alt,onclick=Student.PreLoad.Load(),style=margin:auto;display:block,title=Load Student,id=loadstudbtn");
	 
   _GroupBox();
	 _SideBar();
	 
	// Box("style=width:1204px;height:auto");noexambox
 /*    Box('id=,style=display:flex;height: 250px;justify-content: center;align-items: center;,class=fadeIn animated faster');
echo '<div style="text-align:center">';
echo '<img src="'.$dbo->Config['Core']."cportal/Files/asset/classlist.png".'" width="300px" />';
echo '<div style="font-size:1.3em;font-weight:bold">Select a <span>Class</span> and click LOAD STUDENTS</div>';*/
/* LogoButton('onclick=Cbt.Manage.AddExam(),title=Create Exam,class=success card-1,style=border-radius:5px;padding:13px 15px;color:#fff;margin:3px,logo=plus,text=Create Exam'); */
/*echo '</div>';
_Box(); */

HomeDisplay([
	"id"=>"classlisthome",
	"logo"=>$dbo->Config['Core']."cportal/Files/asset/classlist.png",
	"text"=>"Select a <span>Class</span> and click LOAD STUDENTS"
	]);
     GroupBox("title=Class List,id=preloadsheet,size=3*1,style=min-height:400px;min-width: 890px;width:auto; height:auto;display:none,logo=table,class=fadeIn animated fastest");
	
	/*  $dump = array(array('NC/AAA/BBB/0009&=','ADES53535ss','KEJEMILOBI','YOMMI',3,'AAAA~`!@#$%^&*()_5 -+=_{}[]|:;<,>.?\'/','F',1,3,3,48,'FRESH'),
	               array('NC/AAA/BBB/0009','ADES53535','KEJEMILOBI','YOMMI',3,'AAAA','M',0,2,2,45,'FRESH'),
				   array('NC/AAA/BBB/0009','ADES5353hh5','KEJEMILOBI','YOMMI',5,'AAAA','F',1,3,3,45,'FRESH'));  */
	 Box("style=width:100%;font-size:0.9em;margin-top:5px;overflow:auto,id=preloadsheetbox");
	 /* Box("class=defaultTabText");
	 Box();Icon("list-alt fa-3x altColor2");_Box();
	 Box();echo"LOAD CLASS LIST";_Box();  
	 Box();echo"Select Required Details and Click <span class='altColor2'>LOAD STUDENT</span>";_Box();  
   _Box();  */
   
	_Box();
	Box("style=width:100%;font-size:0.9em;margin-top:5px;overflow:auto");
	LogoButton('onclick=Student.PreLoad.ToggleErrorBox(this);return false;,style=display:block;margin:10px auto;color:#fff;min-width:80px;background-color:rgba(255\,104\,53\,1),logo=chevron-down,text=Display Error Log,id=errlogpreload');
	

	Box("id=studclisterr,style=display:none");
	//individual report
	FlatTable("style=height:auto;margin-top:10px");
	//header box
	FlatTHead();
	 FlatTData("#","size=5");
	 FlatTData("STUDENT","size=40");
	 FlatTData("MESSAGE","size=55");
	
	  /* echo '<div style="width:5%" class="rptitem">#</div>
	  <div style="width:40%" class="rptitem">STUDENT</div>
	  <div style="width:10%" class="rptitem">RESULT</div>
	  <div style="width:10%" class="rptitem">ISSUES</div>
	  <div style="width:20%" class="rptitem">FIXES</div>
	  <div style="width:10%" class="rptitem">NOTES</div>
	  <div style="width:5%" class="rptitem">&nbsp;</div>
	  <div style="clear:both"></div>'; */
	_FlatTHead();
	//preloaderrbx
	Box("id=preloaderrbx");
		  
	_Box();
	//$procgrde = ; //return all grade structure with the grade symbole
   // Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
   // echo '<iframe src="Pages/Scripts/Exams/fix.php" style="border:none; width:100%; height:500px; background-color:#FFF"></iframe>';
_FlatTable();
	_Box();
	_Box();
		
	 _GroupBox();
	 //_Box();
	 _Form();
   _TabBody();
   
   TabBody();
     Box("class=defaultTabText");
	  Box();Icon("info-circle fa-3x");_Box();
	   Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
	  Box();echo"Internal Evaluation in Progress ....";_Box();  
	 _Box();
   _TabBody();
   
   /* Registerd Student Reporting */
   TabBody("name=RegReport");
  
   Form("groupname=objgrpelemstudreg,action=javascript:Student.RegReport.Save(),id=grpstudregrptfrm,style=height:100%"); 
   SideBar();
   //Box("style=width:1204px;height:auto");
   GroupBox("title=Report Type,id=rpttypegrp,size=1*1,logo=check-square-o");
	 
	
	/* Check("id=datefilterch,check=Payment.PaymentReport.EnableDateFilter,uncheck=Payment.PaymentReport.DisableDateFilter,text=Filter by Date,style=margin-top:10px"); 
	 Table("rowselect=true,style=width:250px;font-size:0.8em;margin:auto;text-align:left;margin-top:10px;display:none,id=payrptdatefilter,multiselect=false,data-type=table");
	 $tday = date("j-M-Y");
	  THeader(array("Date From:","Date To:"),"style=text-align:center");
	  TRecord(array("<span id=\"frmdate\" >$tday</span>"._Icon('calendar calen DatePicker" data-style="margin-top:0px;margin-left:0px" data-today=">" data-input="frmdate'),"<span id=\"todate\">$tday</span>"._Icon('calendar calen DatePicker" data-style="margin-top:0px;margin-left:0px" data-today=">" data-input="todate')),"data-id=filterdate");
	  //DatePicker" data-style="margin-top:-300px;margin-left:-40px" data-input="dndndn"
	  _Table();*/
	  
	
   // echo "sss";
	

	  Box("style=margin-top:10px;margin-bottom:20px");
	  /* Box("style=padding-left:10px;text-align:left;font-weight:bold;font-size:0.9em;border-bottom:thin solid #CCC;margin-bottom:5px");
	   echo "Filters";
	   _Box(); */
	   TextBoxGroup();
	   TextBoxGroupItem("type=head");
echo "FILTERS";
	   _TextBoxGroupItem();

	  TextBox("title=Batch,style=width:250px;text-transform:uppercase, onchange=,id=studrptset,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC",array(0=>"ALL SET")));
	  TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase, onchange=,id=studrptmode,required=true,logo=sign-in,selected=-1",TextBoxSQL("select ID,Name from modeofentry_tb",array(0=>"ALL ENTRY")));
	  TextBox("title=Gender,style=width:250px;text-transform:uppercase, onchange=,id=studrptgender,required=true,logo=female,selected=-1",array("Male & Female","Male","Female"));
	  TextBox("title=Marital Status,style=width:250px;text-transform:uppercase, onchange=,id=studrptmstatus,required=true,logo=heart,selected=-1",array("Single & Married","Single","Married"));
	  _TextBoxGroup();
	 _Box();

	 Line();
	 
	 Box("id=regrptbx,style=width:100%;max-height:400px;margin:5px 0px;overflow:auto; padding-top:4px;padding-bottom:5px;text-align:center;text-transform:uppercase;opacity:1 ");
	 Table("rowselect=true,style=width:265px;font-size:0.75em;margin:auto;text-align:left,id=studregrpttyp,onselect=Student.RegReport.Load");
	  THeader(array("CLICK REPORT TYPE"),"style=text-align:center");
	  //TRecord(array(_Icon("th-list")." Item Based Report"._Icon('chevron-right calen')),"data-id=paytypeitem");
	  TRecord(array(_Icon("th-large altColor2")." Faculty/School"),"data-id=rpttypefac");
	  TRecord(array(_Icon("map altColor2")." State of Origin"),"data-id=rpttypestate");//studregall
	  TRecord(array(_Icon("graduation-cap altColor2")." Admmitted Student"),"data-id=studregall");
	  TRecord(array(_Icon("university altColor2")." Registered Student"),"data-id=studregreg");
	  
	  //TRecord(array(_Icon("th-large")." Faculty/School Based Report"._Icon('chevron-right calen')),"data-id=paytypefacind");
	  _Table();
	  
	  _Box();
	 
	 // FlatButton("text=Load Report,logo=list-alt,onclick=Student.RegReport.Load(),style=width:270px,title=Load Report,id=loadregrptbtn");
	_GroupBox();
_SideBar();
HomeDisplay([
	"id"=>"studreporthome",
	"logo"=>$dbo->Config['Core']."cportal/Files/asset/cl.png",
	"text"=>"Select a Report Type to Load report"
	]);
	GroupBox("title=Report,id=regrptgrpbx,size=3*1,logo=list-alt,style=display:none");

	
	 Box("id=regreportbx");
	   
	  
	  _Box();
	_GroupBox();
	Box("id=regexportdiv,style=display:none;visibility:hidden");

	_Box();
//    _Box(); 	 
   _Form();
   _TabBody();
   /* Registerd Student Reporting Ends*/


   TabBody();
     Box("class=defaultTabText");
	  Box();Icon("info-circle fa-3x");_Box();
	   Box();echo"STUDENT REGISTRATION NUMBER MANAGEMENT";_Box();  
	  Box();echo"Internal Evaluation in Progress ....";_Box();  
	 _Box();
   _TabBody();
   
  //Course Settings
TabBody("name=Settings,title=Student Management Settings");

Form("groupname=studsetpgrpelem,action=javascript:void(0),id=grpstudsetpfrm");


//Record group control
GroupBox("title=Record Group Control,id=studsetrecgrp,size=2,logo=table");

 
 //TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 $dump=[];
 $headers = ["*GroupID"=>"GROUP ID","*GROUPTITLE"=>"TITLE","*GROUPDESCR"=>"DESCRIPTION","*GROUPDISPLAY"=>["DISPLAY","Yes|No"],"-Requires"=>"REQ"];
 foreach($studrecgrpdisarr as $Type=>$Details){
	 $nrec = [$Type,$Details['Title'],$Details['Descr'],$Details['Display']?1:0,$Details['Required']?1:0];
	 $nrec['disable'] =  $Details['Required']?"true":"false";
	$dump[] = $nrec;
 }
 SpreadSheet("rowselect=false,class=fadeIn animated delay-0-2s,style=width:calc(100% - 12px);margin:auto;margin-bottom:6px,id=studrecdispsprsht,disable=GroupID,multiselect=false,dynamiccolumn=false,dynamicrow=false,case=inherit,minrow=10,rowfilter=true,filtertitle=FILTER,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:6px,rowmove=true",$headers,$dump);
// _TextBoxGroup();
 _GroupBox();
 GroupBox("title=Controls,id=studsetcpgrp,size=1,logo=table");
 $prequired = $studcntr['AdminPassportReq'] == 'TRUE'?1:0;
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 Switcher("id=passportcpreq,state=$prequired,text=Passport Required,style=width:100%;margin-top:10px,info=Make Student Passport Required in Cportal,ontext=yes,offtext=no,align=right");
 _TextBoxGroup();
  Line();
  TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
  $AdminVerifyPay = $studcntr['AdminVerifyPay'] == 'TRUE'?1:0;
  Switcher("id=AdminVerifyPay,state=$AdminVerifyPay,text=Verify Payment,style=width:100%;margin-top:10px,info=Verify Payment before Student Record Upadet in Cportal,ontext=yes,offtext=no,align=right");
 _TextBoxGroup(); 
 Line();
 TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
 $AutoAdmission = $studcntr['AutoAdmission'] == 'DISABLE'?0:($studcntr['AutoAdmission'] == 'ADMIT'?-1:1);
 Switcher("id=AutoAdmission,state=$AutoAdmission,text=AUTO ADMISSION,style=width:100%;margin-top:10px,info=Automatically Admit/Create Student Account After Registration,ontext=Auto-Create,offtext=Disable,defaulttext=Auto-Admit,align=right,showstate=true");
_TextBoxGroup();
 _GroupBox();
_Form();
   _TabBody();
   
  _Tab();
_Page();
?>