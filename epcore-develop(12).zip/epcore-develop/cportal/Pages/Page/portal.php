<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php");  

//get the portal setting
$portalset = $dbo->SelectFirstRow("portal_tb");
$sch = $dbo->SelectFirstRow("school_tb");
$maxelec = (int)$portalset['walldelay'] == 0?3/300:(int)$portalset['walldelay']/300;
Page("");
 Tab();
   //Wall Papers 
   TabBody("name=WallPaper");
     Form("groupname=objwallpapergrpelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjwallpaperfrm,style=height:100%");
     SideBar();
     GroupBox("title=Wallpapers,id=idwallpapersgrp,size=1,logo=image");
     TextBoxGroup();
     Ranges("id=wallpaperdelay,max=300,min=0,value=$maxelec,text=Transition Delay (seconds),style=font-size:1.1em");
     TextBoxGroupItem();
     Note("style=font-size:12px");
     echo 'Transition Delay will be updated when a Save Operation is done';
     _Note();
     _TextBoxGroupItem();
     _TextBoxGroup();
     /* FlatButton("text=Refresh List,logo=refresh,onclick=Portal.WallPaper.Refresh(),style=width:270px;margin-top:20px,title=Refresh List,id=walllistrefresh"); */
     Line();
     
     //get set walpapers
     Box("style=background-color:#FFF;height: calc(100% - 160px);width:95%;margin:auto;padding:4px 5px;border-radius:5px;box-sizing:border-box,id=wallpaperbx,class=card-1");
ThumbNailBox("onselect=Portal.WallPaper.SelectFunc,id=wallpapertn");
//break the string
//$walpaperarr = explode("~",$wallpaper);
//$wallidcond = "ID=".implode(" OR ID=",$walpaperarr);
//foreach($walpaperarr as $wallID){
  //get wallpaper details
$walldet = $dbo->Select("wallpapers_tb");
if(is_array($walldet) && $walldet[1] > 0){
  while($waldetind = $walldet[0]->fetch_assoc()){
    //ThumbNail("src=../epconfig/UserImages/wallpapers/bgs/".$waldetind['wallpaper'].",title=".str_replace(array(',','='),array('\,','\='),$waldetind['wallheader']).",text=".str_replace(array(',','=','<#','#>','<[',']>'),array('\,','\=','<img src\="','" />','<span class\="text-color-fore">','</span>'),$waldetind['wallheader']).",base=../../../,id=wall_".$waldetind['ID']);
    ThumbNail("src=Files/UserImages/wallpapers/bgs/".$waldetind['wallpaper'].",title=".str_replace(array(',','='),array('\,','\='),$waldetind['wallheader']).",text=".str_replace(array(',','='),array('\,','\='),$dbo->EpMarkup($waldetind['wallheader'])).",base=../../../../../$SubDir,id=wall_".$waldetind['ID']);
    
  }
}

  
//}
            
            _ThumbNailBox();
_Box();
Box("id=portaldesinrefresh,style=border-radius:3px;margin:5px 5px 0px 0px,class=SSBbuttons greenGradient card-1, title=Reload, onclick=Portal.WallPaper.Refresh()");
		    //echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
			echo '<i class="fa fa-sync " aria-hidden="true" style="margin-top:5px; font-size:1.3em"></i>';
		_Box();
	
		ClearFloat();  
            
      _GroupBox();
      _SideBar();

      //School Logo
  GroupBox("title=Wall Image,id=poratlimagegrp,size=2,logo=image");
  // ImageBox("style=margin-top:15px,id=studpassp");
  // echo '<input type="hidden" name="temppass" id="temppass" value="" />';
  // FlatButton("text=Change, style=margin:auto; margin-top:15px; width:250px,onclick=Student.BioData.ChangePassport(),logo=image,id=uploadpw");
    ImagePad("id=walimage,maxsize=6000000");	 
 _GroupBox();

 GroupBox("title=Wall Details,id=poratldetgrp,size=1,logo=list-alt");
 TextBoxGroup();
 TextBox("title=WALL HEADER TEXT,style=width:250px,id=wallheadertxt,required=true,logo=id-badge");
 TextBox("title=WALL TEXT,type=multiline,style=width:250px,id=walltxt,logo=edit");
 TextBoxGroupItem();
 Note("style=font-size:12px");
   echo '<b style="font-weight:bold">Image:</b> <#URL#> <br/> <b style="font-weight:bold">Forecolor:</b> <[Text]> <br/> <b style="font-weight:bold">Link:</b> <%URL:=>Text%>';
 _Note();
 _TextBoxGroupItem();
 _TextBoxGroup();
 Line();
 TextBoxGroup();
 Switcher("id=wallstatus,state=0,text=GO LIVE,style=width:100%;margin-top:10px;font-size:1.13em,info=Make the wall paper visible on the portal,ontext=yes,offtext=no,align=right");
 _TextBoxGroup();
 _GroupBox();


      	 
     _Form();
   _TabBody();

   //Appearance
   TabBody("name=Appearance");
     Form("groupname=objappearancegrpelem,action=javascript:Portal.Appearance.PerformSave(),id=grpappearanceobjfrm");
     GroupBox("title=Color Scheme,id=idcolorschemegrp,size=1,logo=image");
     $colorsch = $portalset['colorScheme'];
     $colorscharr = explode(";",$colorsch);
      $base= RGBToHex(explode(",",$colorscharr[0]));
      $fore= RGBToHex(explode(",",$colorscharr[1]));
      TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
     ColorPicker("id=basecolor,text=Base Color,align=right,info=Select the base color,onchange=alert(this.value),value=".$base);
     TextBoxGroupItem();
     Note();
      echo 'Base Color - The Portal Sidebar and Popups Background Color';
     _Note();
     _TextBoxGroupItem();
     _TextBoxGroup();

     Line();

     TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
     ColorPicker("id=forecolor,text=Fore Color,align=right,info=Select the fore color,value=".$fore);
     TextBoxGroupItem();
     Note();
      echo 'For Color - Main Button Background Color, Page Button Hover text and border Color, Popup Cancel button color, Check List Selection Background Color';
     _Note();
     _TextBoxGroupItem();
     _TextBoxGroup();
     //$gg = RGBToHex([82,43,133]);
     //$dd = HexToRGB('522b85');
     // echo json_encode($dd);
     //echo $gg;
      _GroupBox();

      GroupBox("title=Portal Footer Note,id=idfooternotegrp,size=1,logo=edit");
      TextBoxGroup("width:95%;font-size:0.9em;margin:auto");
    TextBox("title=Footer Note,id=footnote,logo=pencil,type=multiline,text=".str_replace(array(',','='),array('\,','\='),$sch['FooterNote']));
    TextBoxGroupItem();
    Note();
     echo 'Footer Note will be displayed on the Main Page Footer, e.g School Phone Number. <br />Markup (HTML) is allowed <br/> <b style="font-weight:bold">Image:</b> <#URL#> <br/> <b style="font-weight:bold">Forecolor:</b> <[Text]> <br/> <b style="font-weight:bold">Link:</b> <%URL:=>Text%>';
    _Note();
    _TextBoxGroupItem();
    _TextBoxGroup();

      _GroupBox();
      	 
     _Form();
   _TabBody();

   //Menu
   TabBody("name=Menus,title=Module Setup");
     Form("groupname=objgrpprtalmenuelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjpsetfrm");
     GroupBox("title=Menu/Module Setup,id=menusetgrp,size=4,logo=sitemap");
          Box("id=menusetinner,style=margin-top:20px,class=ep-animate-opacity");
          //echo 'ccc';
          include "../Scripts/Portal/loadmenus.php";
          
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

      //Menu
      TabBody("name=PMSetting,title=Other Settings");
      Form("groupname=objgrpprtalsetelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjpmsetfrm");
      GroupBox("title=Link Menus,id=menuinkgrp,size=2,logo=sitemap");
    $header = [
      "-MType"=>"MenuType",
      "*MName"=>"MODULE",
      "*MainMenu"=>["MAIN MENU","#Select ID, Name from new_apply_group_tb ORDER BY MenuOrder"],
      "*SubMenu"=>["SUB MENU","#Select ID, Name from new_apply_tb where GroupID=?MainMenu? ORDER BY MenuOrder"]
    ];
    //(Select 0, 'ALL') UNION (
      /* {"enrol":["Enrol","1","4"],"pay":["Payment","3","13"],"wallet":["Wallet","13","14"],"course":["Course\/Subject","4","19"],"restult":["Result","5","21"],"assignmet":["Assignment","6","24"],"elearn":["e-Learning","6","25"]} */
      $portaldet = $dbo->SelectFirstRow("portal_tb");
      $setmlinks = [];
      if(is_array($portaldet) && isset($portaldet['MenuLink']) && !is_null($portaldet['MenuLink'])){
        $setmlinks = json_decode($portaldet['MenuLink'],true);
      }
      
    $dump = [
      ["enrol","Enrol",0,0],
      ["pay","Payment",0,0],
      ["wallet","Wallet",0,0],
      ["course","Course/Subject",0,0],
      ["result","Result",0,0],
      ["assignmet","Assignment",0,0],
      ["elearn","e-Learning",0,0],
      ["notify","Notification",0,0]
    ];
    if(is_array($setmlinks) && count($setmlinks) > 0){
     // echo json_encode($setmlinks);
      foreach($dump as $ind=>$dumrec){
        
        if(isset($setmlinks[$dumrec[0]])){
         
          $dump[$ind][2] = $setmlinks[$dumrec[0]][1];
          $dump[$ind][3] = $setmlinks[$dumrec[0]][2];
        }
      }
    }
    SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=sprshmenuset,multiselect=false,cellfocus=,cellblur=,cellkeypress=,disable=MName,dynamiccolumn=false,dynamicrow=false,minrow=-1,dependables=MainMenu:SubMenu,rowdelete=false",$header,$dump);

      _GroupBox();
      _Form();
      _TabBody();

 _Tab();
_Page();

 ?>