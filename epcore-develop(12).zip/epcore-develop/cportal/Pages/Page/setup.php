<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 


Page("save=Object.Save,print=Object.Print,clear=Object.Clear,delete=Object.Delete,copy=Object.Copy,paste=Object.Paste");
 Tab();
   //password Tab 
   TabBody();
     Form("groupname=objgrpelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjfrm");
     GroupBox("title=Title,id=idgrp,style=width:290px;height:400px");
          Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();
 _Tab();
_Page();

 ?>