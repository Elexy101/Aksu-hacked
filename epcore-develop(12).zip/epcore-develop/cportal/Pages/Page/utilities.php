<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php");  
 ?>

<?php
   Page();
     Tab();
      TabBody("name=PinMgt");
      SideBar();
    //   SearchBox("id=usermag,title=Search User,onselect=Users.Manage.Load,scope=all,onunselect=,info=Search User by Name\, email or ID,logo=search,domain=user_tb,criteria=UserID:PUID;UserName:Name;UserLogName,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=UserLogName,action=Users.Manage.Clear(),actionlogo=plus,actiontitle=ADD NEW USER");
      _SideBar();
      /* HomeDisplay([
        "id"=>"pinmgthome",
        "logo"=>$dbo->Config['Core']."cportal/Files/asset/users.png",
        "text"=>"Search or Create Cportal Users",
        "onclick"=>"Users.Manage.Clear()",
        "value"=>"Create New User",
        "icon"=>"plus"
        ]); */
        Form("groupname=pinmgtgrpelem,id=grppinmgtfrm");
        //load the results
      // print_r($staffDet);
        
       // print_r($dump);
        //echo $Depts;
        GroupBox("title=Pin Management,id=pinmgtgrp,size=auto,logo=thumbs-o-up");
            // Box("style=width:444px;display:inline-block;vertical-align:top");
            TextBoxGroup("width:calc(100% - 16px);margin:auto;font-size:0.9em","blockinmobile");
            TextBoxGroupItem();
             TextBox("title=Search Pin,style=width:440px,onchange=,id=rstappsearch,logo=search,info=Inteligent Search: Search by any information you have about the Pin,textchange=Utility.Pin.Search"); 
             //_Box();
            TextBoxGroupItemMore();
            // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
             TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=pinmgtfilter,onchange=Utility.Pin.Search,logo=filter,info=Filter Search by Pin Status,selected=-1",array("All","NOT PRINTED","PRINTED", "EXPIRED", "UNUSED", "USED"));
            // _Box();
            TextBoxGroupItemMore();
          // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
           //SubHeader(_Icon("list-alt")." MAXIMUM DISPLAY RECORDS"); 
           TextBox("title=Date Filter,style=width:270px;text-transform:uppercase,id=pinmgtdatefilter,onchange=Utility.Pin.Search,logo=filter,info=Filter Search by Date Generated");
           //_Box();
           TextBoxGroupItemMore();
         // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
          SmallButton("id=reloadbtnpinmgt,logo=sync,style=margin:0px,title=Reload,onclick=Utility.Pin.Search()"); _Box();Box("style=clear:both");
          /* TextBoxGroupItemMore();
         // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
          SmallButton("id=selallappr,logo=refresh,style=margin:0px,title=Reload,onclick=Exams.Approval.Search()"); _Box();Box("style=clear:both"); */
          _TextBoxGroupItem();
          _TextBoxGroup();
          //_Box();
          Line();
          //echo "<div style=\"width:100%; height:2px;\" class=\"altBgColor2\" > </div>";
             Box("id=rstsloadinpinmgt,style=margin-top:100px;text-align:center;position:absolute;z-index:3;width:100%;visibility:hidden");
                Icon("sync fa-spin");
             _Box();
             
             Box("id=rstpinmgtbx,style=margin-top:10px;width:100%;overflow:auto");
             //Get the UserID
            /* $deptCond = "(ra.ProgID > 0)";
             if(isset($staffDet)){
               $Depts = trim($staffDet['DeptIDs']);
               if($Depts != ""){
                 $deptCond = "(ra.ProgID = ".str_replace("~"," OR ra.ProgID = ",$Depts). ")";
               }
             }
             $limit = round((0.0204 * (500 - 10)) + 10);
             LoadResultAppr($deptCond,$limit); //in getinfo.php */
           _Box();  
         _GroupBox();
   
         
   
        _Form();
      _TabBody();
      
     _Tab();
   _Page();


 ?>