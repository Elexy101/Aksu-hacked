<?php 
//LE 22-5-17 #1
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); //hold basic functions to perform some common database operations or request
$sch = GetSchool();
Page();
 Tab();
   //Upload Result
   TabBody("name=ResultUpload");
     Form("groupname=objgrpelemrstup,action=javascript:Exams.ResultUpload.Save(),id=grprstuplfrm,style=height:100%");
      //get all the exam settings
      $allexamset = $dbo->Select("resultinfo_tb");
      $settinarr = [];
      $grdstrc = [];
      if(is_array($allexamset) && $allexamset[1] > 0){
       $settinarr = [];
       $selectedsteID = 1;
       $setselect = isset($_POST['RstInfoID'])?(int)$_POST['RstInfoID']:1;
       while($indexamset = $allexamset[0]->fetch_assoc()){
 
 if(count($grdstrc) < 1 || (int)$indexamset['ID'] == $setselect){
   $grdstrc = $indexamset;
   $selectedsteID = $indexamset['ID'];
 }
 $settinarr[$indexamset['ID']] = $indexamset['SettingName'];
       }
      }
      $uplaodsetarr = $settinarr;
      $rstinfotheme = "";
      if(count($uplaodsetarr) > 0 ){
        $uplaodsetarr["0"]=DropDownLineLogoItem("Preview","tasks");
      }else{
        $uplaodsetarr["-1"] = DropDownLineLogoItem("No Result Settings Found","exclamation-triangle");
        $rstinfotheme = "error";
      }
     
     //Box("style=width:1204px;height:auto");
     SideBar();
     GroupBox("title=Result Details,id=rstdetgrp,size=1*1,logo=list-alt,sticky=true");
     TextBoxGroup();
      /*TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=filtertb,required=true,logo=filter,onchange=Exams.ResultUpload.Deselect,selected=-1",array("1"=>"ALL","2"=>"MAIN STUDENT","3"=>"REPEAT STUDENT")); //added the filter drop down and a horizontal rule 22-5-17 #1
      
     Line();
     */
         /* Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"RESULT UPLOAD REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box(); */
        $userID = 0; $staffID = 0;$loadcond="";
        $user = $_POST['USER'];
        $deptasign = "";
        if($user != ""){
          $userdet = explode("~",$user);
          if(count($userdet) > 0){
            $userID = $userdet[0];
            //get the staffdet
            $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
            if(is_array($staffDet)){
               $staffID = $staffDet["StaffID"];
               $courses = trim($staffDet['Courses']);
               $coursesclassarr=explode("~",$courses);
               $coursesreal = [];
               $classreal = [];
               $loadcondarr = [];
               foreach($coursesclassarr as $indcocl){
                 $indcoclarr=explode(":",$indcocl);
                 $coursesreal[]=$indcoclarr[0];
                 $classreal[]=isset($indcoclarr[1])?$indcoclarr[1]:1;
                 $classq=isset($indcoclarr[1])?" AND sc.ID=".$indcoclarr[1]:"";
                 $loadcondarr[] = "(c.CourseID=".$indcoclarr[0].$classq.")";
               }
               if($courses != ""){
                // $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
               // foreach
                 $loadcond = implode(" OR ",$loadcondarr);
               }
              $deptasign = $staffDet['DeptIDs'];

            }
          }
        }
        $UID = $userID;
        // $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)");
        $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
        $intStudyID = key($studyarr); //get the selected study
        
        if(trim($deptasign) != ""){ //if dept assign to user
           
          //check if one dept asign
          $deptasignarr = explode("~",$deptasign); //get all asign departids
          $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
          //get study based on the assigned dept
          $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
         /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
          if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
          if(count($deptasignarr) < 2){ //if one dept/prog assigned
           
            //load level based on the prog
           // $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
            $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
            $spillStr = ExtraLevelString();
            $lstlvl = end($lvlarr);
            $lstkey = key($lvlarr);
            for($s=1;$s <= 4; $s++){
              $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
            }
        } 
        }   
        $schStruc = json_decode($sch['SchStrucContr'],true);
       // echo $loadcond
        if($loadcond == ""){
        TextBox("title=Session,style=width:250px;text-transform:uppercase,onchange=,id=sestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"));
     
         //LoadFac
        if(trim($deptasign) == ""){ //if no dept/prog assing 
          $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=rstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }

         
          $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";

          TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=rstudstudy,required=true,selected=$selestu,logo=building-o,onchange=Exams.ResultUpload.GenLoader.LoadFac",$studyarr);
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=rstudfac,onchange=Exams.ResultUpload.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Exams.ResultUpload.GenLoader.LoadProg,id=rstuddept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
		  TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=rstudprog,required=true,logo=list-alt,onchange=Exams.ResultUpload.GenLoader.LoadClass,silent={$schStruc['ProgID']['SilentMode']}",array());
		  TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=rstclassid,required=true,logo=users,onchange=Exams.ResultUpload.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",array());
		  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Exams.ResultUpload.GenLoader.LoadSemester",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
        }else{ //if dept asign
          //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=rstudstudy,required=true,selected=-1,logo=building-o,onchange=Exams.ResultUpload.LoadLevel",$studyarr);
          //initial study
           if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
            echo '<input type="hidden" id="rstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
             //get the programe name
             if(!isset($progDet)){
              $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                           }
                           
                          if(is_array($progDet)){
                               Note();
                      echo $progDet['FacName']. " - ".$progDet['ProgName'];
              _Note();
                          }
                          TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=rstclassid,required=true,logo=users,onchange=Exams.ResultUpload.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",TextBoxSQL("select ID, Name from studentclass_tb WHERE ProgID = {$deptasign}"));
             //Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
            TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Exams.ResultUpload.GenLoader.LoadSemester,chain=rstudlvl:;semest:;rcourse:",$lvlarr); //load the lvel drop down
          }else{ // if multiple dept/prog assigned
          $deptasignsql = "ProgID=".str_replace("~", " or ProgID=",$deptasign);
            //load prog the textbox
            TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=rstudprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Exams.ResultUpload.GenLoader.LoadClass,chain=rstudprog:;rstudlvl:;semest:;rcourse:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
            TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=rstclassid,required=true,logo=users,onchange=Exams.ResultUpload.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",array());
            //create lvl dropdown
            TextBox("title=Level,style=width:250px;text-transform:uppercase,id=rstudlvl,required=true,logo=list-ol,onchange=Exams.ResultUpload.GenLoader.LoadSemester",array() );
          }
        }
      TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=semest,required=true,logo=star-half-o,onchange=Exams.ResultUpload.LoadCourse",array());
      $op = "0";
      $h = "";
        }else{ //if courses set
          TextBox("title=Session,style=width:250px;text-transform:uppercase,onchange=Exams.ResultUpload.Deselect,id=sestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"));
          $op = "1";$h="; height:calc(100% - 55px)";
        }
        _TextBoxGroup();
        
      Box("id=loadcourses,style=background-color:;width:270px;min-height:100px;margin-top:3px;overflow:auto;position:absolute;z-index:1;display:flex;text-align:center;opacity:0;visibility:hidden");
        Icon("cog fa-spin altColor2","align-self:center;margin:auto");
      _Box(); 
     // echo "sss";
      Box("id=lcourses,style=width:100%;margin-top:5px;padding-top:10px;{$h}padding-bottom:10px;text-align:center;text-transform:uppercase;opacity:$op ");
      
         if($loadcond != ""){
           //echo $loadcond;
           LoadStaffCourses($loadcond,NULL,true); //in getinfo.php (show the course department along side the course)
         }
      _Box();
     /* TextBox("title=Course,style=width:270px;text-transform:uppercase,id=rcourse,required=true,logo=edit",array());
      Box("style=min-width:50px;margin:auto;text-align:center;margin-top:20px");
      SmallButton("id=preload,logo=list-alt,style=margin:10px,title=Load,onclick=Exams.ResultUpload.Load()");
     // SmallButton("id=reloadbtn,logo=refresh,style=margin:10px,title=Reload,onclick=");
         SmallButton("id=clearsheet,logo=table,style=margin:10px,title=Empty Sheet,onclick=");
        _Box();*/
      _GroupBox();

      _SideBar();
      HomeDisplay([
        "id"=>"rstuplhome",
        "logo"=>$dbo->Config['Core']."cportal/Files/asset/rstupload.png",
        "text"=>"Upload Course/Subject Result"
        ]);
      Box("id=rstbxdiv,style=display:none,class=fadeIn animated faster");
       DropDownLine("id=ruppreset,selected=$selectedsteID,theme=$rstinfotheme,onselect=Exams.ResultUpload.ChangeRstInfo",$uplaodsetarr);
      GroupBox("title=Result Sheet,id=rstrpagrp,size=3*1,logo=check-square-o");
    
          Box("style=width:100%;font-size:0.95em;margin-top:5px;overflow:auto,id=rstcontdiv");
          //$procgrde = ; //return all grade structure with the grade symbole
          Box("id=gradeStruc,style=display:none");
          echo GetGrade(-1);
          _Box();
          //Hidden("gradeStruc",GetGrade(-1));
          //$header=array("*RegNo"=>"REGISTRATION NO.","*CA"=>"ASSESSMENT","*Exm"=>"EXAM","#Tot"=>"TOTAL","#Grd"=>"GRADE","Rmk"=>"REMARK");
          //get all 
         /*   $scorestrcs = $dbo->Select("scorestruc_tb");
          $scorearr = ["*SC1"=>"ASSESSMENT","*SC2"=>"EXAM"];
          $cnter = 1;
          if(is_array($scorestrcs) && $scorestrcs[1] > 0){
             while($scr = $scorestrcs[0]->fetch_assoc()){
              $scorearr["*SC".$cnter] = $scr['Title'];
              $cnter++;
             }
          } */
          $RstInfoID = 1;
          $scorestrcs = $dbo->Select("scorestruc_tb","","RstInfoID=".$RstInfoID);
          $scorearr = ["*SC1"=>"ASSESSMENT","*SC2"=>"EXAM"];
          $maxScorarr = ["SC1"=>30.0,"SC2"=>70.0];
          $cnter = 1;
          if(is_array($scorestrcs) && $scorestrcs[1] > 0){
             while($scr = $scorestrcs[0]->fetch_assoc()){
              $scorearr["*SC".$cnter] = $scr['Title'];
              $maxScorarr["SC".$cnter] = $scr['MaxScore'];
              $cnter++;
             }
          }
          //echo json_encode($scorearr);
          $header=array_merge(array("*RegNo"=>"REGISTRATION NO."),$scorearr,array("#Tot"=>"TOTAL","#Grd"=>"GRADE","Rmk"=>"REMARK"));
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=sprstupload,multiselect=false,cellfocus=,cellblur=Exams.ResultUpload.OnBlur,cellkeypress=Exams.ResultUpload.CellKeyPress,disable=Tot;Grd,dynamiccolumn=true,dynamicrow=true,minrow=-1,dependables=CA:Grd~Tot;Exm:Grd~Tot,rowdelete=false",$header);
      echo '<div style="display:none" id="rstScoreStruc">'.json_encode(array_values($scorearr)).'</div>';
   echo '<div style="display:none" id="rstScoreStrucMax">'.json_encode(array_values($maxScorarr)).'</div>';
   echo '<div style="display:none" id="rstScoreStrucID">'.json_encode(array_keys($maxScorarr)).'</div>';
	_Box();
      _GroupBox(); 
     _Box(); 	 
     _Form();
   _TabBody();

   //Result Approval
   TabBody("name=Approval");
     Form("groupname=apprgrpelem,action=javascript:Exams.Approval.Save(),id=grpapprfrm");
     //load the results
   // print_r($staffDet);
     
    // print_r($dump);
     //echo $Depts;
     GroupBox("title=Result Approval,id=apprgrp,size=4,logo=thumbs-o-up");
         // Box("style=width:444px;display:inline-block;vertical-align:top");
         TextBoxGroup("width:calc(100% - 16px);margin:auto;font-size:0,9em","blockinmobile");
         TextBoxGroupItem();
          TextBox("title=Search Result,style=width:440px,onchange=,id=rstappsearch,logo=search,info=Inteligent Search: Search by any information you have about the Result,textchange=Exams.Approval.Search"); 
          //_Box();
         TextBoxGroupItemMore();
         // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
          TextBox("title=Filter,style=width:270px;text-transform:uppercase,id=apprfilter,onchange=Exams.Approval.Search,logo=filter,info=Filter Search by Approve Status,selected=-1",array("All","APPROVED","UNAPPROVED"));
         // _Box();
         TextBoxGroupItemMore();
       // Box("style=width:280px;display:inline-block;margin-left:30px;vertical-align:top");
        //SubHeader(_Icon("list-alt")." MAXIMUM DISPLAY RECORDS"); 
        Ranges("id=maxrec,value=0.5,max=150,min=10,text=MAXIMUM DISPLAY RECORDS,style=margin-left:0px"); 
        //_Box();
        TextBoxGroupItemMore();
      // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
       SmallButton("id=reloadbtnappr,logo=sync,style=margin:0px,title=Reload,onclick=Exams.Approval.Search()"); _Box();Box("style=clear:both");
       /* TextBoxGroupItemMore();
      // Box("style=width:50px;display:inline-block;margin:10px;vertical-align:top");
       SmallButton("id=selallappr,logo=refresh,style=margin:0px,title=Reload,onclick=Exams.Approval.Search()"); _Box();Box("style=clear:both"); */
       _TextBoxGroupItem();
       _TextBoxGroup();
       //_Box();
       Line();
       //echo "<div style=\"width:100%; height:2px;\" class=\"altBgColor2\" > </div>";
          Box("id=rstsloadin,style=margin-top:100px;text-align:center;position:absolute;z-index:3;width:100%;visibility:hidden");
             Icon("sync fa-spin");
          _Box();
          
          Box("id=rstapprbx,style=margin-top:10px;width:100%;overflow:auto");
          //Get the UserID
         /* $deptCond = "(ra.ProgID > 0)";
          if(isset($staffDet)){
            $Depts = trim($staffDet['DeptIDs']);
            if($Depts != ""){
              $deptCond = "(ra.ProgID = ".str_replace("~"," OR ra.ProgID = ",$Depts). ")";
            }
          }
          $limit = round((0.0204 * (500 - 10)) + 10);
          LoadResultAppr($deptCond,$limit); //in getinfo.php */
        _Box();  
      _GroupBox();

      

     _Form();
   _TabBody();

   //Result Report
   TabBody("name=ResultReport");
     Form("groupname=objgrpelemrstrpt,action=javascript:Exams.ResultReport.Save(),id=grprstrptfrm,style=height:100%");
    // Box("style=width:1204px;height:auto");
    SideBar();
     GroupBox("title=Details,id=rstrptdetgrp,style=width:290px;height:auto,logo=list-alt");
     TextBoxGroup();
      TextBox("title=Session,style=width:250px;text-transform:uppercase,id=tsestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"));
        
       // TextBox("title=Study,style=width:250px;text-transform:uppercase,id=tstudstudy,required=true,logo=building-o,selected=-1",$studyarr);
        if(trim($deptasign) == ""){
          //$scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=tstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";
          TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=tstudstudy,required=true,selected=$selestu,logo=building-o,onchange=Exams.ResultReport.GenLoader.LoadFac",$studyarr);
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=tstudfac,onchange=Exams.ResultReport.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Exams.ResultReport.GenLoader.LoadProg,id=tstuddept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
      TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=tstudprog,required=true,logo=list-alt,onchange=Exams.ResultReport.GenLoader.LoadClass,silent={$schStruc['ProgID']['SilentMode']}",array());
      TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=tstudclass,required=true,logo=users,onchange=Exams.ResultReport.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",array());
		  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=tstudlvl,required=true,logo=list-ol,onchange=Exams.ResultReport.GenLoader.LoadSemester",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
        }else{
          //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=tstudstudy,required=true,selected=-1,logo=building-o,onchange=Exams.ResultReport.GenLoader.LoadLevel",$studyarr);
          //initial study
          if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
            //Hidden("tstudprog",trim($deptasign));
            echo '<input type="hidden" id="tstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
             //get the programe name
             if(!isset($progDet)){
$progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
             }
             
            if(is_array($progDet)){
                 Note();
        echo $progDet['FacName']. " - ".$progDet['ProgName'];
_Note();
            }
            TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=tstudclass,required=true,logo=users,onchange=Exams.ResultReport.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",TextBoxSQL("select ID, Name from studentclass_tb WHERE ProgID = {$deptasign}"));
            
            TextBox("title=Level,style=width:250px;text-transform:uppercase,id=tstudlvl,required=true,logo=list-ol,onchange=Exams.ResultReport.GenLoader.LoadSemester",$lvlarr);
          }else{
            $deptasignsql = "ProgID=".str_replace("~", " or ProgID=",$deptasign);
            //load the textbox
            TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=tstudprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Exams.ResultReport.GenLoader.LoadClass,chain=tstudprog:;tstudlvl:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));

            TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=tstudclass,required=true,logo=users,onchange=Exams.ResultReport.GenLoader.LoadLevel,silent={$schStruc['ClassID']['SilentMode']}",array());

            TextBox("title=Level,style=width:250px;text-transform:uppercase,id=tstudlvl,required=true,logo=list-ol,onchange=Exams.ResultReport.GenLoader.LoadSemester",array() );
          }
        }
      TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=tsemest,required=true,logo=star-half-o,selected=-1",TextBoxSQL("select IF(Num=0,ID,Num) as ID, Sem from semester_tb where Enable = 1"));
      _TextBoxGroup();
      Box("style=width:260px; margin:auto; text-align:center;margin-top:10px");
      FlatButton("text=Load Result,logo=list-alt,onclick=Exams.ResultReport.LoadResult(),style=width:260px,title=Load Result (Basic)");
     /* SmallButton("id=ldrst,logo=th-large,style=margin:10px;margin-left:20px,title=Load Result,onclick=Exams.ResultReport.LoadResult()");
         SmallButton("id=genrstsheet,logo=th,style=margin:10px,title=Generate Result Sheet,onclick=Exams.ResultReport.ResultSheet");*/
      _Box();
      _GroupBox();
_SideBar();//rstbxdiv
HomeDisplay([
  "id"=>"rsheethome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/rsheet.png",
  "text"=>"Generate class result broadsheet"
  ]);
      //results display group 
      GroupBox("title=Result Sheet,id=rstrptsht,size=3*1,logo=check-square-o,style=display:none");
          Box("style=width:100%;font-size:0.95em;margin-top:5px;overflow:auto,id=rstrptcontdiv");
          //$procgrde = ; //return all grade structure with the grade symbole
         // Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
         /*  $header=array("*RegNo"=>"REG. NO.","*RST"=>"RESULT","*TCH"=>"TCH","*TGP"=>"TGP","*GPA"=>"GPA","*CCH"=>"CCH","*CGP"=>"CGP","*CGPA"=>"CGPA");
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=sprstrpt,multiselect=false,readonly=RegNo;TCH;TGP;GPA;CCH;CGP;CGPA;RST,dynamiccolumn=false,dynamicrow=false,minrow=-1,rowdelete=false",$header);//Name; */
      Box("class=defaultTabText");
      Box();Icon("check-square-o fa-3x altColor2");_Box();
      Box();echo"CLASS RESULT REPORT";_Box();  
      Box();echo"Select Class and click <b class='altColor2'>Load Result</b> Botton";_Box();  
    _Box(); 
	_Box();
      _GroupBox();

      //_Box();

     _Form();
   _TabBody();

    //Master Mark Report
   TabBody("name=MasterMark");
     Form("groupname=mstmrkgrpelem,action=javascript:Exams.MasterMark.Save(),id=grpmstmrkfrm");
     GroupBox("title=Title,id=mstmrkgrp,style=width:290px;height:400px");
          Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"GENERATE MASTER MARK SHEET";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("name=ResultSetting");
   Box("id=rstsetbox");
     

     $FromScript = 1;
      include "../Scripts/Exams/setting_loadui.php"; 
      	 
     
    _Box();
   _TabBody();

   TabBody("name=ResultFixer");
     Form("groupname=rstfixgrpelem,action=javascript:Exams.ResultFixer.Save(),id=grprstfixfrm,style=height:100%");
     SideBar();
     GroupBox("title=Student Scope,id=rstfixgrp,style=width:290px;height:auto");
     echo '<input type="hidden" id="userdepts" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
     //Box("style=display:block;width:270px");
     TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
              Switcher("id=fixertype,state=0,text=Specific Student,style=width:100%,info=Fix by Reg. Number,ontext=yes,offtext=no,align=right,onchange=Exams.ResultFixer.FixerType");
          //_Box();
        _TextBoxGroup();
          Box("style=margin-top:8px;display:none,id=fixbyregno,class=ep-animate-opacity");
          TextBoxGroup();
          TextBox("title=REG. NUMBER (Seperated with comma),style=width:250px;text-transform:uppercase,id=fspecreg,logo=users,type=multiline");
          _TextBoxGroup();
          _Box();
     Box("style=margin-top:8px,id=fixbyrange,class=ep-animate-opacity");
    // TextBox("title=All Session,style=width:270px;text-transform:uppercase,id=fsestb,required=true,logo=calendar,selected=-1",TextBoxSQL("select * from session_tb ORDER BY SesID DESC",array(0=>"ALL SESSION")));
        
     // TextBox("title=Study,style=width:270px;text-transform:uppercase,id=tstudstudy,required=true,logo=building-o,selected=-1",$studyarr);
     //array_unshift($studyarr,"ALL STUDY");
     $studyarr["0"] = "ALL STUDY";
     ksort($studyarr);
     TextBoxGroup();
     //echo json_encode($studyarr);
      if(trim($deptasign) == ""){ //if no department assign to user
        if(count($scharr) > 1){
          TextBox("title=school,style=width:250px;text-transform:uppercase,id=fstud,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
        }
        TextBox("title=Study,style=width:250px;text-transform:uppercase,id=fstudstudy,required=true,selected=-1,logo=building-o,onchange=Exams.ResultFixer.GenLoader.LoadFac,default=0",$studyarr);
   TextBox("title=ALL Faculties/Schools,style=width:250px;text-transform:uppercase,required=true,id=fstudfac,onchange=Exams.ResultFixer.GenLoader.LoadDept,logo=server,default=0,selected=-1",array(0=>"ALL Faculties/Schools"));
   //TextBoxSQL("select * from fac_tb order by FacName")
   TextBox("title=All Departments,style=width:250px;text-transform:uppercase,required=true,onchange=Exams.ResultFixer.GenLoader.LoadProg,id=fstuddept,logo=tasks,default=0,selected=-1",array(0=>"ALL Department"));
    TextBox("title=All Programmes,style=width:250px;text-transform:uppercase,id=fstudprog,required=true,logo=list-alt,onchange=Exams.ResultFixer.GenLoader.LoadLevel,default=0,selected=-1",array(0=>"ALL Programmes"));
    TextBox("title=All Level,style=width:250px;text-transform:uppercase,id=fstudlvl,required=true,logo=list-ol,default=0,selected=-1",array(0=>"ALL Levels") );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
      }else{
        //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=fstudstudy,required=true,selected=-1,logo=building-o,onchange=Exams.ResultFixer.GenLoader.LoadLevel,chain=fstudstudy:;fstudlvl:;",$studyarr);
        //initial study
       
        if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
          
          //Hidden("tstudprog",trim($deptasign));
          echo '<input type="hidden" id="fstudprog" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
          //load level based on the prog
          if(!isset($progDet)){
            $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                         }
                         
                        if(is_array($progDet)){
                             Note();
                    echo $progDet['FacName']. " - ".$progDet['ProgName'];
            _Note();
                        }
          
          TextBox("title=Level,style=width:250px;text-transform:uppercase,id=fstudlvl,required=true,logo=list-ol,selected=-1",$lvlarr);
        }else{
          
          $deptasignsql = "p.ProgID=".str_replace("~", " or p.ProgID=",$deptasign);
          //load the textbox
          TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=fstudprog,required=true,logo=list-alt,onchange=Exams.ResultFixer.GenLoader.LoadLevel,chain=fstudprog:;fstudlvl:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
          TextBox("title=Level,style=width:250px;text-transform:uppercase,id=fstudlvl,required=true,logo=list-ol",array() );
        }
      }
      _TextBoxGroup();
      _Box();
    //TextBox("title=Semester,style=width:270px;text-transform:uppercase, id=tsemest,required=true,logo=star-half-o,selected=-1",TextBoxSQL("select * from semester_tb"));
    /* Box("style=display:block;width:270px;margin-top:6px");
              Switcher("id=autofix,state=0,text=AUTO FIX,style=width:100%,info=Automatically fix issues,ontext=yes,offtext=no,align=right,onchange=Exams.ResultFixer.AutoFix");
          _Box(); */
    Box("style=width:260px; margin:auto; text-align:center;margin-top:10px");
    FlatButton("text=Troubleshoot Result,logo=wrench,onclick=Exams.ResultFixer.GetAllStudent(),style=width:260px,title=Troubleshoot and Fix Result,id=fixbtn");
   /* SmallButton("id=ldrst,logo=th-large,style=margin:10px;margin-left:20px,title=Load Result,onclick=Exams.ResultReport.LoadResult()");
       SmallButton("id=genrstsheet,logo=th,style=margin:10px,title=Generate Result Sheet,onclick=Exams.ResultReport.ResultSheet");*/
    _Box();  
      _GroupBox();
_SideBar();
HomeDisplay([
  "id"=>"rstfixerhome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/rstfix.png",
  "text"=>"Automatically Detect and Fix Result Calculation Issues"
  ]);
      //fix terminal 
      GroupBox("title=Terminal,id=rstfixterm,size=3*1,logo=list-alt,style=display:none");
      //top reporting box
      Box("style=width:95%;font-size:0.95em;padding:10px;overflow:auto,id=rstfixheader");
        Box('style=float:left;width:70%,id=resultfixtitle');_Box();
        Box('style=float:right;width:30%');
        Box('style=float:right;display:none,id=cntrbtn');
        LogoButton('onclick=Exams.ResultFixer.Stop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
        LogoButton('onclick=Exams.ResultFixer.Pause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=fixpausebtn');
        LogoButton('onclick=Exams.ResultFixer.Play();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=fixplaybtn');
        /* echo '
        <button onclick="Exams.ResultFixer.Pause()" id="fixpausebtn" title="Pause" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede"><i class="fa fa-pause"></i> </botton>
        <button onclick="Exams.ResultFixer.Play()" id="fixplaybtn" title="Resume" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede;display:none"><i class="fa fa-play"></i> </botton>'; */
        _Box();
        Box('style=float:right;display:none,id=cntrbtnfixall');
        LogoButton('onclick=Exams.ResultFixer.FixAllStop();return false;,title=Stop,class=altColor,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=stop');
        LogoButton('onclick=Exams.ResultFixer.FixAllPause();return false;,title=Pause,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede,logo=pause,id=fixallpausebtn');
        LogoButton('onclick=Exams.ResultFixer.FixAllPlay();return false;,title=Resume,class=altColor2,style=border-radius:2px 0px 0px 2px;background-color:#eee;border:solid 1px #dedede;display:none,logo=play,id=fixallplaybtn');
        /* echo '
        <button onclick="Exams.ResultFixer.FixAllPause()" id="fixallpausebtn" title="Pause" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede"><i class="fa fa-pause"></i> </botton>
        <button onclick="Exams.ResultFixer.FixAllPlay()" id="fixallplaybtn" title="Resume" class="bbtn altColor2" style="border-radius:0px 2px 2px 0px;background-color:#eee;border:solid 1px #dedede;display:none"><i class="fa fa-play"></i> </botton>'; */
        _Box();
        LogoButton('onclick=Exams.ResultFixer.FixAll(this);return false;,title=Fix All,class=success,style=float:right;display:none;color:#fff,logo=wrench,id=fixallbtn,text=FIX ALL');
        echo'<div style="clear:both"></div>';
        _Box();
      _Box();

      //main container
          FlatTable("id=fixerbx,style=min-width:500px");
          //header box
          FlatTHead();
           FlatTData("#","size=5");
           FlatTData("STUDENT","size=40");
           FlatTData("RESULT","size=10");
           FlatTData("ISSUES","size=10");
           FlatTData("FIXES","size=20");
           FlatTData("NOTES","size=10");
           FlatTData("&nbsp;","size=5");
            /* echo '<div style="width:5%" class="rptitem">#</div>
            <div style="width:40%" class="rptitem">STUDENT</div>
            <div style="width:10%" class="rptitem">RESULT</div>
            <div style="width:10%" class="rptitem">ISSUES</div>
            <div style="width:20%" class="rptitem">FIXES</div>
            <div style="width:10%" class="rptitem">NOTES</div>
            <div style="width:5%" class="rptitem">&nbsp;</div>
            <div style="clear:both"></div>'; */
          _FlatTHead();

          Box("id=rstfixcontdiv");
          //individual report
          
          _Box();
          //$procgrde = ; //return all grade structure with the grade symbole
         // Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
         // echo '<iframe src="Pages/Scripts/Exams/fix.php" style="border:none; width:100%; height:500px; background-color:#FFF"></iframe>';
	_FlatTable();
      _GroupBox();
      	 
     _Form();
   _TabBody();

   


   
 _Tab();
_Page();

 ?>