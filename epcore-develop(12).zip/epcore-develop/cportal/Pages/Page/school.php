<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 
$sch = GetSchool();

Page("");
 Tab();
   //Structure
   TabBody("name=Structure,title=School Structure");
   
     Form("groupname=objgrpschstrelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjfrm");
     GroupBox("title=School Structure,id=schstrucgrp,size=4,logo=sitemap");
          Box("id=schstrcinner,style=margin-top:20px,class=ep-animate-opacity");
          //echo 'ccc';
          include "../Scripts/School/loadstructure.php";
          
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("name=Levels,title=School Level Management");
     Form("groupname=schlvlgrpelem,id=grpschlvlfrm,style=height:100%");
     SideBar();
     GroupBox("title=Parameter,id=idschlvlgrp,size=1");
          TextBoxGroup();
          $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title=school,style=width:250px;text-transform:uppercase,id=sclvlstudsch,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
          TextBox("title=Study,style=width:250px;text-transform:uppercase,id=sclvlstudschstudy,required=true,selected=-1,logo=building-o",$studyarr);
          
          _TextBoxGroup();
          FlatButton("text=Load Levels,logo=list-alt,onclick=School.Levels.Load(),style=width:262px;margin:auto;margin-top:30px;border-radius:0px,title=Load Study Levels,id=loadschstulvlbtn");
      _GroupBox();
_SideBar();
HomeDisplay([
  "id"=>"schlevelhome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/schlevel.png",
  "text"=>"Manage school academic levels",
  "onclick"=>"School.Levels.Load()",
  "value"=>"Load Levels Now",
  "icon"=>"list-alt"
  ]);
      GroupBox("title=DETAILS,id=schlevdetgrp,size=3,logo=th,style=display:none,class=fadeIn animated faster");
      Box("id=schlvldetbx,style=width:100%;overflow:auto");
      
      _Box();
       _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("");
     Form("groupname=objgrpelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjfrm");
     GroupBox("title=Title,id=idgrp,style=width:290px;height:400px");
          Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("");
     Form("groupname=objgrpelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjfrm");
     GroupBox("title=Title,id=idgrp,style=width:290px;height:400px");
          Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("");
     Form("groupname=objgrpelem,action=javascript:Object.GroupOBJ.Save(),id=grpobjfrm");
     GroupBox("title=Title,id=idgrp,style=width:290px;height:400px");
          Box("class=defaultTabText");
          Box();Icon("info-circle fa-3x");_Box();
          Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
          Box();echo"Internal Evaluation in Progress ....";_Box();  
        _Box();  
      _GroupBox();
      	 
     _Form();
   _TabBody();

   TabBody("name=SchoolSettings,title=School Wide Settings");
     Form("groupname=objgrpssettingselem,action=javascript:School.SchoolSettings.PerformSave(),id=grpobjssettingsfrm");
    // echo $sch;
     //School Details
     GroupBox("title=School,id=schdetgrpDet,size=1,logo=university");
     TextBoxGroup();
     TextBox("title=Name,style=width:250px;text-transform:uppercase,id=schsetname,required=true,logo=building,text=".str_replace(",",'\,',$sch['Name']));
   TextBox("title=Addrevation,style=width:250px;text-transform:uppercase,id=schsetabbr,required=true,logo=map-signs,text=".str_replace(",",'\,',$sch['Abbr']));
   TextBox("title=School Type,style=width:250px;margin-top:0px,id=schsettype,required=true,logo=university,selected={$sch['Type']}",TextBoxSQL("select ID,SchoolType from schooltype_tb order by SchoolType"));
   Switcher("id=schsetmigrate,state=0,text=Auto Migration,style=width:100%,info=Automatically migrate School Structures,ontext=yes,offtext=no,align=right");
   TextBoxGroupItem();
   Note("style=font-size:12px");
     echo 'Managed Level in the <a href="javascript:Page.OpenByTabName(\'AccLvl\')">School Level Module</a>';
   _Note();
   _TextBoxGroupItem();
   TextBox("title=Description,style=width:250px,type=multiline,id=schsetdescr,logo=map-signs,text=".str_replace(",",'\,',$sch['description']));
   TextBoxGroupItem();
   Note("style=font-size:12px");
   echo 'Description will be displayed as site description in search engines';
 _Note();
 _TextBoxGroupItem();
 _TextBoxGroup();
  _GroupBox();

  //School Contact
  GroupBox("title=Contact,id=schcontgrpDet,size=1,logo=map");
  TextBoxGroup();
  TextBox("title=Short Address,style=width:250px;text-transform:uppercase,id=schsetshortaddr,required=true,logo=map-signs,text=".str_replace(",",'\,',$sch['ShortAddr']));
  TextBoxGroupItem();
  Note("style=font-size:12px");
   echo 'Short Address will be used on print-outs';
 _Note();
 _TextBoxGroupItem();
  TextBox("title=Long Address,style=width:250px,type=multiline,id=schsetlongaddr,logo=map-signs,text=".str_replace(",",'\,',$sch['LongAddr']));
  EmailBox("title=Official Email,style=width:250px;text-transform:uppercase,id=schsetemail,logo=envelope,text=".$sch['email']);
  PhoneBox("title=Official Phone Number,style=width:250px;text-transform:uppercase,id=schsetphone,required=true,logo=phone,text=".$sch['Phone']);
  _TextBoxGroup();
  _GroupBox();

  //School Logo
  GroupBox("title=Logo,id=schlogogrp,size=1,logo=image");
	  // ImageBox("style=margin-top:15px,id=studpassp");
	  // echo '<input type="hidden" name="temppass" id="temppass" value="" />';
	  // FlatButton("text=Change, style=margin:auto; margin-top:15px; width:250px,onclick=Student.BioData.ChangePassport(),logo=image,id=uploadpw");
      ImagePad("id=schsetlogo,maxsize=300000,src=Files/".$sch['logo'].",rel=../../../../../".$SubDir);	 
   _GroupBox();
   
   //School Level Settings
  GroupBox("title=Level Settings,id=schcontgrpDet,size=1,logo=map");
  $cprob = $sch['LevelLoad'] == 'AUTO'?1:0;
  TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
 Switcher("id=schsetloadlvl,state=$cprob,text=Auto Load Level,style=width:100%;margin-top:10px,info=Automatically determine and load Student Level,ontext=yes,offtext=no,align=right");
 TextBoxGroupItem();
 Note("style=font-size:12px");
 echo 'Automatically determine the student current level and use it as the maximum display level for the student';
_Note();
_TextBoxGroupItem();
_TextBoxGroup();
Line();
TextBoxGroup();
TextBox("title=Extra Year Prefix,style=width:250px;text-transform:uppercase,id=schsetextrapre,required=true,logo=calendar,text=".str_replace(",",'\,',$sch['ExtraYearPrefix']));

Note("style=font-size:12px");
 echo 'Additional Year Level Prefix (e.g Spillover 1 .., CarryOver 1..., Extra-Time 1... e.tc)';
_Note();
   TextBox("title=Maximum Extra Year,style=width:250px,id=maxextratb,logo=database,type=number,text=".$sch['MaxExtraYear']);
   Note();
     echo 'The maximum number of Extra Year Allowed';
   _Note();

_TextBoxGroup();
  _GroupBox();

  GroupBox("title=Academic Session,id=schAcSesGrp,size=2,logo=calendar");
  
       Box("id=schsesloadbx,class=ep-animate-opacity,style=max-height:360px;overflow:auto");
       $sesheaders = array(
        "-SchSesID"=>"SesID",
        "*ScgSessionN"=>"SESSION",
        "*ScgSessionAbb"=>"ABBREVIATION",
        "*SchSesEnable"=>array("ENABLE","YES|NO"));
      // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
       SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schsessionspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1",$sesheaders, "SELECT SesID, SesName, Abbr, Enable, IF(Current = 1,'*check',IF(SesID={$sch['SchStartSes']},'*university','#wrench')) as logo, IF(Current = 1,'Active Session',IF(SesID={$sch['SchStartSes']},'Start Session','Set to Current')) as info , CONCAT('School.SchoolSettings.SetSession(',SesID,',\'',SesName,'\')') as Action FROM session_tb ORDER BY SesID");
       _Box();
       
       
_GroupBox();

GroupBox("title={$sch['SemLabel']},id=schSemGrp,size=2,logo=star-half");
  
Box("id=schsemloadbx,class=ep-animate-opacity");
$semheaders = array(
 "-SchSemID"=>"SemID",
 "*ScgSemName"=>strtoupper($sch['SemLabel']),
 "*ScgSemDescr"=>"DESCRIPTION",
 "*SchSemEnable"=>array("ENABLE","YES|NO"));
// Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
Box("class=ep-animate-opacity,style=width:100%;overflow:auto");
SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schsemspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1",$semheaders, "SELECT ID, Sem, Descr, Enable, IF(Current = 1,'*check',IF(ID={$sch['SchStartSem']},'*university','#wrench')) as logo, IF(Current = 1,'Active ".$sch['SemLabel']."',IF(ID={$sch['SchStartSem']},'School Start ".$sch['SemLabel']."','Set to Current')) as info , CONCAT('School.SchoolSettings.SetSem(',ID,',\'',Sem,'\')') as Action FROM semester_tb ORDER BY Num, ID");
_Box();
echo '<input type="hidden" id="SemLabelInp" value="'.$sch['SemLabel'].'" />';
_Box();

Line();
TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
TextBox("title=Label,style=width:250px,id=schsemlabel,logo=tag,text=".$sch['SemLabel']);
/* Note("style=font-size:12px");
 echo 'To ';
_Note(); */
_TextBoxGroup();

_GroupBox();

//Module Active Session Settings
GroupBox("title=Module Session,id=schActSesGrp,size=2,logo=calendar");
  
Box("id=schactsesloadbx,class=ep-animate-opacity,style=max-height:360px;overflow:auto");
$sesheaders = array(
 "-SchMdID"=>"ModuleID",
 "*SchMDName"=>"MODULE",
 "*SchMDSes"=>["ACTIVE SESSION","#select 0 as SesID,'Current' as SesName union Select SesID, SesName from session_tb where Enable=1 order by SesID DESC"]);
 $dumb=[
   [1,"Admission",0],
   [2,"School Payment",0],
   [3,"Course Registration",0],
   [4,"Result Upload",0]
 ];
// Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schactsessionspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,disable=SchMDName",$sesheaders, $dumb);
_Box();


_GroupBox();

//School Registration Number Settings
GroupBox("title=Registration Number,id=schregnogrpDet,size=1,logo=graduation-cap");
$cprob = $sch['AutoRegNo'] == 'TRUE'?1:0;
  TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
 Switcher("id=schsetautoreg,state=$cprob,text=Auto RegNo Generation,style=width:100%;margin-top:10px,info=Allow Auto Reg.No Generation,ontext=yes,offtext=no,align=right");
/*  TextBoxGroupItem();
 Note("style=font-size:12px");
 echo 'Allow Automatic Reg.No. Generation';
_Note(); 
_TextBoxGroupItem();*/
TextBox("title=Auto Reg.No. Format,style=width:250px,id=schautoregnoformat,logo=database,text=".$sch['RegNoFormat']);
Note();
  echo 'To specify keywords, enclose it with ? symbol';
_Note();
TextBox("title=Auto Reg.No. Start,style=width:250px,id=schautoregnostart,logo=list-ol,type=number,text=".$sch['RegNumStart']);
TextBox("title=Number Generation Scope,style=width:250px;margin-top:0px,id=schautoregnoscope,required=true,logo=university,selected={$sch['AutoRegNoScope']}",['BATCH'=>'BATCH BASES', 'PROG'=>'DEPARTMENTAL BASES', 'BATCHPROG'=>'BATCH-DEPARTMENTAL BASES', 'NONE'=>'NONE']);
Note();
  echo '<b>BATCH</b>:Start Auto-Increament in a new session<br/>
  <b>DEPARTMENTAL</b>:Start Auto-Increament in a new Department<br/>
  <b>BATCH-DEPARTMENTAL</b>:Start Auto-Increament in a new Department in a new Session';
_Note();
TextBox("title=Student Scope,style=width:250px;margin-top:0px,id=schautoregnostud,required=true,logo=graduation-cap,selected={$sch['AutoRegNoSet']}",["FRESH"=>"FRESH STUDENT ONLY","ANY"=>"ANY STUDENT"]);
if(!isset($sch['AutoRegNoTrigger']))$sch['AutoRegNoTrigger'] = '';
TextBox("title=GENERATE AFTER,style=width:250px;margin-top:0px,id=schautoregnotrigger,required=true,logo=tasks,selected={$sch['AutoRegNoTrigger']}",["COURSE"=>"COURSE/SUBJECT REGISTRATION","STUDACCOUNT"=>"STUDENT ACCOUNT CREATION"]);
_TextBoxGroup();
// Line();

_GroupBox();

      	 
     _Form();
   _TabBody();

   TabBody("name=Staff");
   
    // StudentSearchBox("id=usermag,title=Search Staff,onselect=School.Staff.Load,scope=all,onunselect=,info=Search Staff by Name\, PUID\, StaffID,script=Pages/Scripts/Users/usersearch.php,logo=search");
    SideBar();
    SearchBox("id=staffsearch,title=Search Staff,onselect=School.Staff.Load,onunselect=,info=Search Staff by Name\, PUID\, PSID and School Staff ID,logo=search,domain=staff_tb,criteria=StaffID:PSID;StaffName:Name;UserID;StaffSchID,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=StaffSchID,action=School.Staff.Load(),actionlogo=plus,actiontitle=ADD NEW STAFF");  
    _SideBar();
 HomeDisplay([
  "id"=>"staffhome",
  "logo"=>$dbo->Config['Core']."cportal/Files/asset/staff.png",
  "text"=>"Manage school staff",
  "onclick"=>"School.Staff.Load()",
  "value"=>"ADD NEW STAFF",
  "icon"=>"plus"
  ]); 
    Form("groupname=objgrpstaffelem,action=javascript:School.Staff.PerformSave(),id=grpobjstafffrm,style=display:none");
     GroupBox("title=Basic Info,id=staffbinfo,size=1,logo=address-card");
    // TextBox("title=PSID,style=width:270px,id=stuserId,logo=user,info=Portal Staff Identification Number (PSID)");
   Hidden("stuserId",""); 
       //  TextBox("title=PUID,style=width:270px;display:none,id=stuserId,logo=user,info=Portal User Identification Number (PUID),readonly=true");
      TextBoxGroup();
		TextBox("title=Full Name,style=width:250px,id=staffFullnme,required=true,logo=id-badge");
		TextBox("title=Date of Birth,style=width:250px,id=staffDOB,logo=calendar,type=calendar");
		//DateBox("title=DATE OF BIRTH,id=staffDOB,required=true,range=".((int)date("Y") - 10)."-".((int)date("Y") - 100));
        TextBox("title=State of Origin,style=width:250px;margin-top:0px,id=staffstateorig,required=true,logo=map,onchange=TextBox.Template.LoadLGA,chain=staffstateorig:;staffstateoriglga:;",TextBoxSQL("select * from state_tb order by StateName"));
		 TextBox("title=Local Goverment Area,style=width:250px,id=staffstateoriglga,logo=map-marker,required=true",array(""));
		 TextBox("title=Nationality,style=width:250px,id=staffnat,logo=globe");
		 EmailBox("title=Email,style=width:250px,id=staffemail,logo=envelope,required=true");
		 PhoneBox("title=Phone Number,style=width:250px,id=staffphone,required=true,logo=phone");
         PhoneBox("title=Emmergency Number,style=width:250px,id=staffemmg,logo=phone-square");
		 TextBox("title=ADDRESS,style=width:250px,type=multiline,id=staffaddr,logo=map-signs");  
     _TextBoxGroup(); 
      _GroupBox();


//contact
       /* GroupBox("title=Contact,id=staffcontact,size=1,logo=address-book");
          TextBox("title=State of Origin,style=width:270px,id=staffstateorig,required=true,logo=map,onchange=TextBox.Template.LoadLGA,chain=staffstateorig:;staffstateoriglga:;",TextBoxSQL("select * from state_tb order by StateName"));
		 TextBox("title=Local Goverment Area,style=width:270px,id=staffstateoriglga,logo=map-marker,required=true",array(""));
		 TextBox("title=Nationality,style=width:270px,id=staffnat,logo=globe");
		 EmailBox("title=Email,style=width:270px,id=staffemail,logo=envelope,required=true");
		 PhoneBox("title=Phone Number,style=width:270px,id=staffphone,required=true,logo=phone");
         PhoneBox("title=Emmergency Number,style=width:270px,id=staffemmg,logo=phone-square");
		 TextPad("title=ADDRESS,style=width:270px; height:100px,id=staffaddr,logo=map-signs"); 
      _GroupBox(); */

       GroupBox("title=Staff Passport,id=staffpasspgrp,size=1,logo=image");
           ImagePad("id=staffpasspd,maxsize=600000");
       _GroupBox(); 
      
    

      GroupBox("title=School,id=staffschdet,size=1,logo=university");
      TextBoxGroup();
       TextBox("title=Position,style=width:250px,id=staffposition,logo=cubes");
        TextBox("title=Staff ID,style=width:250px,id=staffIDSch,logo=id-card-o,info=Staff School Identification Number");
        TextBox("title=Unit/Department,style=width:250px,id=staffunit,logo=cogs");
        TextBox("title=Academic Qualification,style=width:250px,id=staffqual,logo=id-card,type=multiline"); 
       
       // Switcher("id=staffacst,state=off,text=ACADEMIC STAFF,style=width:270px;margin-top:20px,info=User is an Accademic Staff; Enable Courses Group,onchange=School.Staff.IsAccada,ontext=YES,offtext=NO");
        Switcher("id=staffrstup,state=off,text=RESULT UPLOAD,style=width:250px;font-size:1.2em,info=Allow/Disallow Staff to Upload Result,onchange=");
        _TextBoxGroup();
      _GroupBox();

      GroupBox("title=Staff Signature,id=staffsiggrp,size=2*1,logo=edit");
      Note();
        echo 'An edited signature with a transparent background is recommended';
      _Note();
           ImagePad("id=staffsigpd,maxsize=600000");
       _GroupBox(); 
      $StrucObj = json_decode($sch['SchStrucContr'],true);
       GroupBox("title=Staff Department,id=staffDeptsGrp,size=2*1,logo=braille");
         $headerd = array(
          "*Studyd"=>array(strtoupper($StrucObj['StudyID']['Name']),$dbo->DataString(TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)"))),
               "*Facd"=>array(strtoupper($StrucObj['FacID']['Name']),"#select FacID,FacName from fac_tb where StudyID = ?Studyd?"),
             
               "*ProgIDd"=>array(strtoupper($StrucObj['ProgID']['Name']),"#select p.ProgId, p.ProgName from programme_tb p, dept_tb d where p.DeptID = d.DeptID and d.FacID = ?Facd?")
         );
          Box("id=deptsbx,style=width:100%;overflow:auto;height:383px");
              // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
               SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=staffdepts,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=10",$headerd);
               _Box();
      _GroupBox();

      
     // echo $sch['SchStrucContr'];
      /* {"StudyID":{"SilentMode":false,"Name":"School"},"FacID":{"SilentMode":false,"Name":"Faculty"},"DeptID":{"SilentMode":false,"Name":"Department"},"ProgID":{"SilentMode":false,"Name":"Programme"},"SchID":{"Name":"Application"},"FacGrpID":{"Name":"Faculty Group"},"ClassID":{"Name":"Class Group","SilentMode":false}}
 COURSE
 */
     GroupBox("title=Course,id=staffCoursesGrp,size=4,logo=pencil-square-o");
          $headers = array(
               "*StudyID"=>array(strtoupper($StrucObj['StudyID']['Name']),$dbo->DataString(TextBoxSQL("select * from study_tb where SchoolType = (select Type from school_tb limit 1)"))),
               "*Fac"=>array(strtoupper($StrucObj['FacID']['Name']),"#select FacID,FacName from fac_tb where StudyID = ?StudyID?"),
               "*Dept"=>array(strtoupper($StrucObj['DeptID']['Name']),"#select DeptID,DeptName from dept_tb where FacID = ?Fac?"),
               "*ProgID"=>array(strtoupper($StrucObj['ProgID']['Name']),"#select * from programme_tb where DeptID = ?Dept?"),
               "*ClassID"=>array(strtoupper($StrucObj['ClassID']['Name']),"#select * from studentclass_tb where ProgID = ?ProgID?"),
               "*Lvl"=>array("LEVEL","#select Level, Name from schoollevel_tb where StudyID = ?StudyID? and SchoolTypeID = (select Type from school_tb limit 1) order by Level"),
               "*Sem"=>array(strtoupper($sch['SemLabel']),$dbo->DataString(TextBoxSQL("select IF(Num=0,ID,Num) as Num, Sem from semester_tb where Enable = 1 ORDER BY Num,ID"))),
               "*Courses"=>array("COURSE","#select CourseID,Concat(Title,' (',CourseCode,')') as Name from course_tb where Lvl = ?Lvl? and DeptID = ?ProgID? and Sem = ?Sem? and StudyID = ?StudyID?"));
               Box("id=courselecbx,style=width:calc(100% -12px);margin:auto;position:relative;overflow:auto");
              // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
               SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=staffcourses,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=12",$headers);
               _Box();
               
               
      _GroupBox();

    
     
     _Form();
   _TabBody();
 _Tab();
_Page();

 ?>