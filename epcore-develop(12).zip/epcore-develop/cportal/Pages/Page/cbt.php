<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 
Page();
Tab();
   //password Tab 
   TabBody("name=Manage");
   SideBar();
   // Box("style=width:1204px;height:auto");
   SearchBox("id=examsearch,title=Search Exam,onselect=Cbt.Manage.LoadQuestion,onunselect=,info=Search Exam by Abbr or Name,logo=search,domain=cbt_exam_tb,criteria=ExamID;ExamAbbr:Code;ExamName:Name;UserID,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=ExamAbbr,action=Cbt.Manage.AddExam(),actionlogo=plus,actiontitle=ADD NEW EXAM,sticky=false");
   _SideBar();
  
   
/* //No Exam Selected
Box('id=noexambox,style=display:flex;height: 100%;justify-content: center;align-items: center;,class=fadeIn animated faster');
echo '<div style="text-align:center">';
echo '<img src="'.$dbo->Config['Core']."cportal/Files/asset/newexam.png".'" width="300px" />';
echo '<div style="font-size:1.3em;font-weight:bold">Search or Create a New Exam</div>';
LogoButton('onclick=Cbt.Manage.AddExam(),title=Create Exam,class=success card-1,style=border-radius:5px;padding:13px 15px;color:#fff;margin:3px,logo=plus,text=Create Exam');
echo '</div>';
_Box(); */
HomeDisplay([
   "id"=>"noexambox",
   "logo"=>$dbo->Config['Core']."cportal/Files/asset/newexam.png",
   "text"=>"Search or Create a New Exam",
   "onclick"=>"Cbt.Manage.AddExam()",
   "value"=>"Create Exam",
   "icon"=>"plus"
   ]);

   GroupBox("title=Questions,id=questrpagrp,size=3*1,logo=check-square-o,style=display:none");
          /* Box("style=width:100%;margin-top:5px;overflow:auto,id=exmqcontdiv");
        
          $header=array("*CBTQuest"=>"EXAM QUESTION","*CBTAns"=>"OPTION/ANSWER","*CBTMrk"=>"MARK","*Medias"=>"MEDIA");
	    SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=spexamqst,multiselect=false,cellfocus=Cbt.Manage.CellFocus,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1,rowdelete=true,case=none",$header);
   _Box(); */
   // Head
   echo '<input type="hidden" value="0" name="cExamID" id="cExamID">';
   Box('id=questionbx,class=fadeIn animated faster,style=display:none');
   echo '<div style="width:100%;overflow:auto">';
   Box('style=width:100%;margin-bottom:10px;min-width:450px');
   Box('style=float:left;width:auto;min-width:30px;padding-left:10px;vertical-align:middle');
   LogoButton('onclick=Cbt.Manage.NewQuestion(),title=Add New Question,class=success card-1,style=border-radius:3px;padding:5px 8px;color:#fff;margin:3px,logo=plus,text=New');
   _Box();

   Box('style=float:left;width:calc(100% - 120px);text-align:left;vertical-align:middle;font-size:1.2em');
   LogoButton('onclick=Cbt.Manage.First();return false;,title=First,class=altColor2 card-1,style=border-radius:3px 0px 0px 3px;padding:5px 8px;margin:0px 0px 0px 5px;background-color:#fff;border:none,logo=angle-double-left');
   LogoButton('onclick=Cbt.Manage.Prev();return false;,title=Previous,class=altColor2 card-1,style=border-radius:0px 3px 3px 0px;padding:5px 8px;margin:0px 5px 0px 0px;background-color:#fff;border:none,logo=angle-left');
      echo '<strong class="altColor2" style="margin: 10px 5px 0px 5px"><span id="qnum" class="altColor">-</span> <small>/ <span id="qtot">-</span></small></strong>';
      
      LogoButton('onclick=Cbt.Manage.Next();return false;,title=Next,class=altColor2 card-1,style=border-radius:3px 0px 0px 3px;padding:5px 8px;margin:0px 0px 0px 5px;background-color:#fff;border:none,logo=angle-right');
      LogoButton('onclick=Cbt.Manage.Last();return false;,title=Last,class=altColor2 card-1,style=border-radius:0px 3px 3px 0px;padding:5px 8px;margin:0px 5px 0px 0px;background-color:#fff;border:none,logo=angle-double-right');
      LogoButton('onclick=Cbt.Manage.SearchQuestions();return false;,title=Search Question,class=altColor2 card-1,style=border-radius:3px 0px 0px 3px;padding:5px 8px;background-color:#fff;border:none;margin:3px 0px 3px 3px,logo=search');
      LogoButton('onclick=Cbt.Manage.QuestionMap();return false;,title=Question Map,class=altColor2 card-1,style=border-radius:0px 3px 3px 0px;padding:5px 8px;background-color:#fff;border:none;margin:3px 3px 3px 0px,logo=th');
      TextBoxGroup('float:right;width: 110px;','markqtb');
       TextBox("title=Mark,style=width:150px;font-size:1em,onchange=Editor.FontSize,id=qmark,logo=check-square,required=false,type=number");
       _TextBoxGroup();
       echo '<div style="clear:both"></div>';
   _Box();
   echo '<input type="hidden" id="curQID" value="0" data-value="0" />';

    Box('style=float:right;width:27px;vertical-align:middle;padding-right:10px;');
    LogoButton('onclick=Cbt.Manage.DeleteQuestion();return false;,title=Delete Question,class=altBgColor card-1,style=border-radius:3px;padding:4px 6px;margin:3px;color:#FFF,logo=trash');
   _Box(); 
   echo'<div style="clear:both"></div>';
   _Box();
   _Box();
   // Head

   // Editor
   Editor('id=cbtquetion,placeholder=Question Body,verifyfunction=Cbt.Manage.VerifyLoaded');


   //Option Box
   FlatTable("style=height:auto;margin-top:10px;margin-bottom:20px");
   Box("style=width:100%;overflow:auto");
		FlatTHead('style=min-width:710px');
      
		FlatTData(_LogoButton('onclick=Editor.BringToFront(_(\'optionansbx\')\,this\,Cbt.Manage.EnableAnswerBtn);return false;,title=Objective,class=altBgColor2 editor-item option-is-active,style=border-radius:3px;color:#fff;border:transparent solid thin;margin:4px 5px 0px 5px;padding:8px 16px,logo=th-list,text=Objective,id=optionansbx_btn'));
	   FlatTData(_LogoButton('onclick=Editor.AddText(this\,Cbt.Manage.VerifyLoaded);return false;,title=Insert Text,class=greenGradient card-1,style=border-radius:3px 0px 0px 3px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:5px 0px 0px 5px,logo=font,id=ansaddtext'));
		FlatTData(_LogoButton('onclick=Editor.AddImage(this\,Cbt.Manage.VerifyLoaded);return false;,title=Insert Image,class=greenGradient card-1,style=border-radius:0px 0px 0px 0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:5px 0px 0px 0px,logo=image,id=ansaddimage'));
		FlatTData(_LogoButton('onclick=Editor.AddAudio(this\,Cbt.Manage.VerifyLoaded);return false;,title=Insert Audio,class=greenGradient card-1,style=border-radius:0px 0px 0px 0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:5px 0px 0px 0px,logo=music,id=ansaddaudio'));
      FlatTData(_LogoButton('onclick=Editor.AddVideo(this\,Cbt.Manage.VerifyLoaded);return false;,title=Insert Video,class=greenGradient card-1,style=border-radius:0px 3px 3px 0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:5px 5px 0px 0px,logo=video-camera,id=ansaddvideo'));
      FlatTDataSep('style=padding:3px 1px;background-color:#dedede;margin:8px 5px 4px 5px;');
      FlatTData(_LogoButton('onclick=Editor.BringToFront(_(\'subjectiveansbx\')\,this\,Cbt.Manage.EnableAnswerBtn);return false;,title=Subjective,class=altBgColor2 editor-item,style=border-radius:3px;color:#fff;margin:4px 5px 0px 5px;padding:8px 16px,logo=square-o,text=Subjective,id=subjectiveansbx_btn'));
      FlatTData(_LogoButton('onclick=Editor.BringToFront(_(\'theoryansbx\')\,this\,Cbt.Manage.EnableAnswerBtn);return false;,title=Theory,class=altBgColor2 editor-item,style=border-radius:3px;color:#fff;margin:4px 5px 0px 5px;padding:8px 16px,logo=i-cursor,text=Theory,id=theoryansbx_btn'));
		FlatTData(_LogoButton('onclick=Editor.BringToFront(_(\'audioansbx\')\,this\,Cbt.Manage.EnableAnswerBtn);return false;,title= Answer,class=altBgColor2 editor-item,style=border-radius:3px;color:#fff;margin:4px 5px 0px 5px;padding:8px 16px,logo=music,text=Audio Answer,id=audioansbx_btn'));
		FlatTData(_LogoButton('onclick=Editor.BringToFront(_(\'videoansbx\')\,this\,Cbt.Manage.EnableAnswerBtn);return false;,title=Video Answer,class=altBgColor2 editor-item,style=border-radius:3px;color:#fff;margin:4px 5px 0px 5px;padding:8px 16px,logo=video-camera,text=Video Answer,id=videoansbx_btn'));
		
		
      
      
      _FlatTHead();
      _Box();
   Box("id=ansmainbx");
   FlatTBody("style=width:100%;min-height:100px;overflow:auto;position:relative,placeholder=Options/Answer,id=optionansbx,class=ansindbx ep-animate-opacity optionmain");
      //echo '<div class="option-tabbody">';
      OptionGrid();
      Option("label=Option 1,descr=Option One Description,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
      Option("label=Option 2,descr=Option Two Description,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
      Option("label=Option 3,descr=Option Three Description,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
      Option("label=Option 4,descr=Option Four Description,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
      Option("label=Option 5,descr=,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
      Option("label=Option 6,descr=,onfocus=Editor.SelectAs('optiondesc'\,this.parentElement)");
    _OptionGrid();
    
      _FlatTBody();
      FlatTBody("style=width:100%;min-height:100px;overflow:auto;position:relative,placeholder=Subjective,id=subjectiveansbx,class=ansindbx ep-animate-opacity");
      echo '<div class="editor-selectable ep-animate-opacity editor editor-bx"  id="qansubj"></div>';
      /* echo '<div style="clear:both"></div>'; */
      // echo '<div class="editor-label"><i class="fa fa-square"></i> Subjective Answer</div>';
  _FlatTBody();
FlatTBody("style=width:100%;min-height:100px;overflow:auto;position:relative,placeholder=Theory,id=theoryansbx,class=ansindbx ep-animate-opacity");
      echo '<div class="editor-text ep-animate-opacity editor editor-bx" style="min-height:100px" data-placeholder="Type Theory Answer Here" contenteditable ="true" id="qanstheory"></div>';
  _FlatTBody();
  FlatTBody("style=width:100%;min-height:100px;overflow:auto;position:relative,placeholder=Video Answer,id=videoansbx,class=ansindbx ep-animate-opacity");
      echo '<div class="editor-label"><i class="fa fa-video-camera"></i> Video Answer</div>';
  _FlatTBody();

  FlatTBody("style=width:100%;min-height:100px;overflow:auto;position:relative,placeholder=Audio Answer,id=audioansbx,class=ansindbx ep-animate-opacity");
  echo '<div class="editor-label"><i class="fa fa-music"></i> Audio Answer</div>';
  _FlatTBody();
      

      
_Box();
      

     
      _FlatTable();
_Box();

//NoQuestion Box
Box('id=noquestionbox,style=display:none;height: 350px;justify-content: center;align-items: center;,class=zoomInShort2 animated faster');
echo '<div style="text-align:center">';
echo '<img src="'.$dbo->Config['Core']."cportal/Files/asset/noquestion.png".'" width="300px" />';
echo '<div style="font-size:1.3em;font-weight:bold" id="exmnamdis">&nbsp;</div>';
LogoButton('onclick=Cbt.Manage.NewQuestion(),title=Add Question,class=success card-1,style=border-radius:5px;padding:13px 15px;color:#fff;margin:3px,logo=plus,text=Add Question');
echo '</div>';
_Box();

      _GroupBox();
      // _Box();
   _TabBody();

    //password Tab 
    TabBody("name=CbtSchedule");//BioDataelem
    SideBar();
    SearchBox("id=cbtschedulesearch,title=Search Schedule,onselect=Cbt.CbtSchedule.LoadSchedule,onunselect=Student.RegReport.NullFunc,info=Search Schedule by Name \, Code or Start Date,logo=search,domain=cbt_schedule_tb,criteria=ID;SchCode:CODE;SchName:NAME;DATE_FORMAT(StartDate \, '%M %d %Y'):START,img=ID,dir=../epconfig/UserImages/School,ext=jpg,thumbnailtext=NAME,thumbnailtitle=SchCode,action=Cbt.CbtSchedule.LoadSchedule(),actionlogo=plus,actiontitle=NEW EXAM SCHEDULE");
    _SideBar();
    
    Box('id=cbtschedulebx,style=height:100%');
     //Schedule content will be loaded here
     Box('id=noschedulebox,style=display:flex;height: 100%;justify-content: center;align-items: center;,class=fadeIn animated faster');
echo '<div style="text-align:center">';
echo '<img src="'.$dbo->Config['Core']."cportal/Files/asset/noschedule.png".'" width="300px" />';
echo '<div style="font-size:1.3em;font-weight:bold">Search or Create New Exam Schedule</div>';
LogoButton('onclick=Cbt.CbtSchedule.LoadSchedule(),title=New Schedule,class=success card-1,style=border-radius:5px;padding:13px 15px;color:#fff;margin:3px,logo=plus,text=New Schedule');
echo '</div>';
_Box();
 _Box();
//  _Form();
    _TabBody();

     //password Tab 
   TabBody("name=CbtMark");
   SideBar();
   //schedule search
   SearchBox("id=cbtmarkscsearch,title=Search Schedule,onselect=Cbt.Mark.LoadStudent,onunselect=Student.RegReport.NullFunc,info=Search Schedule by Name \, Code or Start Date,logo=search,domain=cbt_schedule_tb,criteria=ID;SchCode:CODE;SchName:NAME;DATE_FORMAT(StartDate \, '%M %d %Y'):START,img=ID,dir=../epconfig/UserImages/School,ext=jpg,thumbnailtext=NAME,thumbnailtitle=SchCode");
_SideBar();

HomeDisplay([
   "id"=>"marrkcbthome",
   "logo"=>$dbo->Config['Core']."cportal/Files/asset/mark.png",
   "text"=>"Search and Select a Schedule to get Started"
   ]);

   Box("id=markdet,style=display:none,class=fadeIn animated faster");
   GroupBox("title=Mark Basis,id=cbtmarkschgrp,size=1,logo=tasks");
   TextBoxGroup();
   Switcher("id=cbtschmarkbasis,state=0,text=Question / Candidate,style=width:100%;margin-top:10px,info=Mark Exam base on Question or Candidate,ontext=CANDIDATE,offtext=QUESTION,align=right,showstate=true,onchange=Cbt.Mark.LoadMarkBases");
   _TextBoxGroup();
   Box("id=cbtmarkbasisbx,style=max-height:300px;margin-top:10px;overflow:auto;position:relative");
      //loads the list based on the bases selected

   _Box();
   _GroupBox();

   GroupBox("title=Exam Details,id=cbtmarkexamdetgrp,size=2,logo=list-alt");
  /*  $headers=array("*CBTMQuest"=>"EXAM QUESTION","*CBTMOpt"=>"OPTION","*CBTMAns"=>"ANSWER","*CBTMMrk"=>"MARK","*MMedias"=>"MEDIA");
   SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=spexamqst,multiselect=false,cellfocus=Cbt.Manage.CellFocus,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1,rowdelete=true,case=none",$headers); */

   $headers=array("*CBTMRegNo"=>"REG. NO","*CBTMSName"=>"NAME","*CBTMAns"=>"ANSWER","*CBTMMrk"=>"MARK");
   SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=spexamstst,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1,rowdelete=true,case=none",$headers);

   _GroupBox();
   _Box();
   _TabBody();

    //password Tab 
    TabBody("name=CbtSetting");
    GroupBox("title=Select Question,id=cbtmnghh,size=1,logo=task");
    
    _GroupBox();
    _TabBody();


   _Tab();


_Page();

?>