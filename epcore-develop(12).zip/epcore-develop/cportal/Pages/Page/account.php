<?php 
//sleep(4);
$Core = $_POST['CORE'];
$SubDir = $_POST['SUBDIR'];
$configdir = "../../../../../".$SubDir;
require_once("../../../general/config.php"); 
//require_once("../../../general/getinfo.php"); 
require_once("../../../general/TaquaLB/Elements/Elements.php"); 
//user id

Page("");
$userdet = $_POST['USER']; //send from Page.Open in UI call (Element.js)
 Tab();
   //password Tab 
   TabBody("name=Password");
     Form("groupname=passwordelem,action=javascript:Account.Password.SaveReal(),id=passwordfrm");
     //Password Generator
     GroupBox("title=Generator,id=generatorgrp,size=1,logo=random");
     //$sss = '<i class\="fa fa-text-width" aria-hidden\="true" ></i>';
      Box("style=margin-left:0px");
       TextBoxGroup();
        //SubHeader(_Icon("text-width")." CHARACTER LENGHT");
         Ranges("id=genlenth,value=0.6,max=30,min=6,text=Total Number of Character");
         // SubHeader(_Icon("low-vision")." DOMAIN "._Icon("percent"));
         Ranges("id=gendomain,max=50,min=0,value=0.4,text=Concentration of unknow words");
         //SubHeader(_Icon("language")." CONCENTRATION "._Icon("percent"));
         Ranges("id=genconc,text=Set the character set Concentration of numeric and special character,max=50");
         _TextBoxGroup();
         Line();
         TextBoxGroup();
         TextBoxGroupItem();
         Box("style=width:auto;margin-left:0px;border:thin solid #ccc;padding:1px;margin-top:0px;min-height:16px");
            Text("id=genrst,text=,style=text-align:center;width:100%;color:#444;font-size:1.1em");
         _Box();
         _TextBoxGroupItem();
         _TextBoxGroup();
         Line();
         TextBoxGroup();
         TextBoxGroupItem("style=text-align:center");
         SmallButton("id=generate,logo=refresh,style=margin:auto;margin-top:4px,title=Generate Password,onclick=Account.Password.Generate()");
         TextBoxGroupItemMore("style=text-align:center");
         SmallButton("id=cleargen,logo=eraser,style=margin:auto;margin-top:4px,title=Clear Password,onclick=Account.Password.ClearGenerate()");
         TextBoxGroupItemMore("style=text-align:center");
         SmallButton("id=usegen,logo=check,style=margin:auto;margin-top:4px,title=Use Password,onclick=Account.Password.UseGenerate()");
         _TextBoxGroupItem();
         _TextBoxGroup();
    _Box();
        _GroupBox();
   $userarr = explode("~",$userdet);
           $email = "";$hint="";$phone="";$pinStatus = 1;$pinMaxTry = 8;$pinIdleTime=30;$loginName = "";$userID=0;
           if(count($userarr) > 2 ){
             $userID = $userarr[0];
              //Get the user records
              $Userrec = $dbo->Select4rmdbtbFirstRw("user_tb","","UserID = '$userID'");
              if(is_array($Userrec)){
                $email = $Userrec['remail'];
                $hint = $Userrec['Hint'];
                $phone = $Userrec['rphone'];
                $pinStatus = (int)$Userrec['PinStatus'];
                $pinMaxTry = (int)$Userrec['MaxEntry'];
                $pinIdleTime = (int)$Userrec['IdleTime'];
                $loginName = EscapeString($Userrec['UserName']);
              }
           }
     //Password
      	 GroupBox("title=Password,id=passwordgrp,size=1,logo=unlock-alt");
           
           // TextBox("title=Password,style=width:270px,id=opassw,textchange=,logo=unlock,type=password");
              //SubHeader("CURRENT PASSWORD");
              TextBoxGroup();
               TextBox("title=Password,style=width:250px,id=cpassw,textchange=,logo=lock,type=password,required=true");
              // TextBox("title=Verify Password,style=width:250px,id=ccpassw,textchange=,logo=shield,type=password,required=true");
               _TextBoxGroup();
               Line();
               TextBoxGroup();
               TextBox("title=New Password,style=width:250px,id=npassw,textchange=,logo=lock,type=password");
               TextBox("title=Verify New Password,style=width:250px,id=cnpassw,textchange=,logo=shield,type=password");
               _TextBoxGroup();
               Line();
                //SubHeader("HINT");
                TextBoxGroup();
            TextBox("title=Hint,text=$hint,style=width:250px,id=hint,textchange=,logo=low-vision");
            _TextBoxGroup();
        _GroupBox();

        //Recovery
        GroupBox("title=Recovery,id=precorverygrp,size=1,logo=share-square-o");
       /* SubHeader("SECURITY QUESTIONS");
           TextBox("title=Question 1,style=width:270px,id=sq1,logo=question-circle",
           array(
                "What is your mother pet name",
                "What is your favourite food",
                "How many country have you being to")
                );
        TextBox("title=Answer 1,style=width:270px,id=ans1,logo=thumbs-o-up");
        TextBox("title=Question 2,style=width:270px,id=sq2,required=true,logo=question-circle",
           array(
                "What is best color",
                "What is the name of your home town",
                "How old is your best friend")
                );
        TextBox("title=Answer 2,style=width:270px,id=ans2,logo=thumbs-o-up");*/
        //SubHeader("RECOVERY LOCATION");
        TextBoxGroup();
        EmailBox("title=Recovery Email Address,style=width:250px,text=$email,id=secureemail,textchange=,logo=envelope,required=true");
       // TextBox("title=Mobile,style=width:270px,id=secmobile,textchange=,logo=mobile");
        PhoneBox("title=Recovery Phone Number,style=width:250px,text=$phone,id=seccontact,textchange=,logo=phone,required=true");
        _TextBoxGroup();
        _GroupBox();

     _Form();
   _TabBody();

   //Pin Tab 
   TabBody("name=Pin");
       Form("groupname=pinelem,action=javascript:Account.Pin.Save(),id=pinfrm");
         //pin 
      	 GroupBox("title=Pin,id=pingrp,size=1,logo=key");
           // TextBox("title=Password,style=width:270px,id=opassw,textchange=,logo=unlock,type=password");
          // SubHeader("PIN");
          TextBoxGroup();
               TextBox("title=Old Pin,style=width:250px,id=cpin,textchange=,logo=lock,type=password,readonly=true,onfocus=Account.Pin.OnFocus(this),onblur=Account.Pin.OnBlur(this)");
               _TextBoxGroup();
               Line();
                //SubHeader("NEW PIN");
                TextBoxGroup();
               TextBox("title=New Pin,style=width:250px,id=npin,textchange=,logo=lock,type=password,readonly=true,onfocus=Account.Pin.OnFocus(this),onblur=Account.Pin.OnBlur(this)");
               TextBox("title=Confirm New Pin,style=width:250px,id=cnpin,textchange=,logo=shield,type=password,readonly=true,onfocus=Account.Pin.OnFocus(this),onblur=Account.Pin.OnBlur(this)");
               _TextBoxGroup();
               Line();
               Box("style=margin:10px;display:none");
                  echo '<span style="font-weight:bold;color:#777;font-size:0.7em;text-transform:uppercase">Field Selected: </span>';
                  echo '<span style="font-weight:bold;font-size:0.7em;color:rgba(86,176,55,1)" id="selfield"></span>';
               _Box();
               Box("style=margin:auto;margin-top:10px;-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none, unselectable=on,onselectstart=return false;,onmousedown=return false;");
               TextBoxGroup();
               TextBoxGroupItem();
               $cnt = 0;
                for($i=1;$i < 10; $i++){
                  $cnt++;
                  if($cnt > 3){
                    $cnt = 1;
                    _TextBoxGroupItem();
                    TextBoxGroupItem();
                  }else{
                    if($cnt > 1){
                     TextBoxGroupItemMore(); 
                    }
                  }
                  SmallButton("id=p{$i},text={$i},style=display:block;margin:auto;margin-top:4px;margin-bottom:3px,title={$i},onclick=Account.Pin.KeyPress(this)");
                  /* if($i ==3 || $i==6 || $i==9){
                    NL();
                  } */
                }
                _TextBoxGroupItem();
                    TextBoxGroupItem();
                  /*SmallButton("id=p1,text=1,style=margin:10px,title=1,onclick=Account.Pin.KeyPress(this)");
                  SmallButton("id=p2,text=2,style=margin:10px,title=2,onclick=Account.Pin.KeyPress(this)");
                  SmallButton("id=p3,text=3,style=margin:10px,title=3,onclick=Account.Pin.KeyPress(this)");
                  NL();
                  SmallButton("id=p4,text=4,style=margin:10px,title=4");
                  SmallButton("id=p5,text=5,style=margin:10px,title=5");
                  SmallButton("id=p6,text=6,style=margin:10px,title=6");
                  NL();
                  SmallButton("id=p7,text=7,style=margin:10px,title=7");
                  SmallButton("id=p8,text=8,style=margin:10px,title=8");
                  SmallButton("id=p9,text=9,style=margin:10px,title=9");
                  NL();*/
                  
                  SmallButton("id=pclear,logo=arrow-circle-left,style=display:block;margin:auto;margin-top:4px;margin-bottom:3px,title=Clear,onclick=Account.Pin.KeyPress(this\,true)");
                  TextBoxGroupItemMore(); 
                  SmallButton("id=cleargen,text=0,style=display:block;margin:auto;margin-top:4px;margin-bottom:3px,title=0,onclick=Account.Pin.KeyPress(this)");
                  TextBoxGroupItemMore(); 
                  SmallButton("id=usegen,text=C,style=display:block;margin:auto;margin-top:4px;margin-bottom:3px,title=Cancel,onclick=Account.Pin.KeyPress(this)");
                  _TextBoxGroupItem();
                  _TextBoxGroup();
               _Box();
        _GroupBox();

        //lock setting
        GroupBox("title=Lock Settings,id=locksettingsgrp,size=1,logo=wrench");
        Box("style=margin:auto;margin-top:15px;");
        $st = $pinStatus == 1?"on":"off";
        TextBoxGroup();
          Switcher("id=locksw,state=$st,text=Auto Screen Lock,style=width:250px;font-size:1.2em,info=Enable/Disable Auto Screen Lock");
          _TextBoxGroup();
          Line();
          //SubHeader(_Icon("ban")." MAXIMUM RETRY");
         $val = $pinMaxTry - 2;
         $percval = $val / (10-2);
         $val2 = $pinIdleTime - 5;
          $percval2 = $val2 / (120-5);
          TextBoxGroup();
         Ranges("id=pmaxtry,value=$percval,max=10,min=2,text=Set the Maximum number of wrong entering allowed");
         _TextBoxGroup();
         Line();
         //SubHeader(_Icon("clock-o")." IDLE TIME (sec)");
         TextBoxGroup();
         Ranges("id=pidletime,value=$percval2,max=120,min=5,text=Set the maximum idle time for screen lock in seconds");
         _TextBoxGroup();
        _Box();
        _GroupBox();
       _Form();
   _TabBody();
   //settings
   TabBody("name=Settings");
    Form("groupname=psettigelem,action=javascript:Account.Settings.SaveReal(),id=psettingfrm");
     GroupBox("title=Details,id=setdetailgrp,style=size=1,logo=user");
          // TextBox("title=First Name,style=width:270px,id=accsettinfirstName,textchange=,logo=address-book");
          // TextBox("title=Other Name,style=width:270px,id=accsettinOtherName,textchange=,logo=address-card");
         // $loginName = str_replace('"','\"',$loginName);
         // echo "$loginName";
         TextBoxGroup();
        TextBox("title=Login Name,text=$loginName,style=width:270px,id=asettingLName,textchange=,logo=user,info=User Login Display Name");
        _TextBoxGroup();
       // TextBox("title=email,style=width:270px,id=accsettinemail,textchange=,logo=envelope,info=User email address\, which will be use together with password to access(login) the Control Portal");
     _GroupBox();
     //passport photograph
	 GroupBox("title=Passport,id=bDatagrpPassp,size=2,logo=image");
	   ImagePad("id=userpst,maxsize=300000,src=Files/UserImages/{$userID}.jpg,rel=".$configdir);
	   //FlatButton("text=Change, style=margin:auto; margin-top:15px; width:250px,onclick=Account.Passport.ChangePassport(),logo=image,id=uploadpw");
	 _GroupBox();
    _Form();
   _TabBody();
 _Tab();
_Page();

 ?>