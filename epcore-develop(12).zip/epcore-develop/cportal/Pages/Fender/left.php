<?php require("../../../general/TaquaLB/Elements/Elements.php");   ?>
<!--<div class="HeaderTop">-->
      <?php
	   $Files["Course"] = "Resources/Images/course.png";
	   $Files["Student"] = "Resources/Images/student.png";
	    $Files["School"] = "Resources/Images/school.png";
		Page("save=Swa");
		/*$tabind = $_POST['TABIND'];
		$grpnme = $_POST['GRPNAME'];*/
		
	//$_POST['TABS'] = str_replace("`","&",$_POST['TABS']);
		 Tab();
	     TabBody();
		 GroupBox("style=width:400px;height:300px,title=student info");
	     SmallButton("class=back block,onClick=Page.Open('Pages/Fender/left.php'\,'pgggg'),id=FenderLeft,title=Close");
		 BigButton("logo=logo_print_big.png,onClick=Page.Maximize('pggg'),id=FenderLeftbg,title=Close");
		 Text("text=,class=block");
		 _GroupBox();
		 _TabBody();
		 TabBody();
		 Form("name=aaaa");
		 GroupBox("style=width:840px;height:300px,title=student info");
		  Radio("checked=false,group=aaa,id=r1,text=Orange,display=block");
		  Radio("group=aaa,id=r2,text=Mango,display=block");
		  Radio("group=aaa,id=r3,text=Bread,display=block");
		  Radio("group=,id=r6,text=Others,display=block");
		  Check("id=c1,text=Others,display=block,checked=true");
		  Check("id=c2,text=Others 2,display=block");
		 
		  Table("style=margin-top:10px;margin-left:10px;width:800px,onselect=dsd,rowselect=false,multiselect=true,id=tbs");
		  THeader(array("Name","Age","Class"));
		  TRecord(array("Yommy","23","computer"));
		  TRecord(array("aaaa","13","comcdputer"));
		  THeader(array("Total:","3"),"cspan=d1:2");
		  _Table();
		  _GroupBox();
		  _Form();
		  _TabBody();
		  TabBody();
		  
		 Form("name=aaaab");
		 
		  GroupBox("style=width:400px;min-height:300px,title=student info");
		   Table("style=margin-left:10px;margin-top:10px;width:200px,rowselect=false,multiselect=true");
		  THeader(array("Best Fruits","Price"));
		  TRecord(array("Mango","200"),"");
		  TRecord(array("Orange","150"));
		  TRecord(array("Bread","300"));
		  TRecord(array("Rice",500));
		  _Table();
		  TextBox("title=Textbox,style=width:300px,id=tb1,onchange=",array("fr1"=>"Mango","fr2"=>"Orange","fr3"=>"Pineaple"));
		  TextBox("title=Textbox2,style=width:300px,id=tb2");
          SmallButton("class=back block,onClick=alert(_('tb1').ValueContent()),id=btntb,title=Close");
		  Switcher("state=on,style=margin-top:10px; display:block,text=Course Registration,onchange=Swa");
		  Ranges("onmove=Sw");
		  Ranges("id=outrng,onmove=Sh");
		  FlatButton("text=login,style=margin:auto;width:380px,onclick=Page.Minimize('pggg')");
		  _GroupBox();
		  
		   GroupBox("style=width:400px;min-height:300px;,title=student info");
		   Table("style=margin-left:10px;margin-top:10px;width:200px,rowselect=false,multiselect=true");
		  THeader(array("Best Fruits","Price"));
		  TRecord(array("Mango","200"),"");
		  TRecord(array("Orange","150"));
		  TRecord(array("Bread","300"));
		  TRecord(array("Rice",500));
		  _Table();
		  TextBox("title=Textbox,style=width:300px,id=tb1,onchange=",array("fr1"=>"Mango","fr2"=>"Orange","fr3"=>"Pineaple"));
		  TextBox("title=Textbox2,style=width:300px,id=tb2");
          SmallButton("class=back block,onClick=alert(_('tb1').ValueContent()),id=btntb,title=Close");
		  Switcher("state=on,style=margin-top:10px; display:block,text=Course Registration,onchange=Swa");
		  Ranges("onmove=Sw");
		  Ranges("id=outrng,onmove=Sh");
		  FlatButton("text=login,style=margin:auto;width:380px,onclick=Page.Maximize('pggg')");
		  _GroupBox();
		  
		  GroupBox("style=width:400px;min-height:300px;,title=student info");
		   Table("style=margin-left:10px;margin-top:10px;width:200px,rowselect=false,multiselect=true");
		  THeader(array("Best Fruits","Price"));
		  TRecord(array("Mango","200"),"");
		  TRecord(array("Orange","150"));
		  TRecord(array("Bread","300"));
		  TRecord(array("Rice",500));
		  _Table();
		  TextBox("title=Textbox,style=width:300px,id=tb1,onchange=",array("fr1"=>"Mango","fr2"=>"Orange","fr3"=>"Pineaple"));
		  TextBox("title=Textbox2,style=width:300px,id=tb2");
          SmallButton("class=back block,onClick=alert(_('tb1').ValueContent()),id=btntb,title=Close");
		  Switcher("state=on,style=margin-top:10px; display:block,text=Course Registration,onchange=Swa");
		  Ranges("onmove=Sw");
		  Ranges("id=outrng,onmove=Sh");
		  FlatButton("text=login,style=margin:auto;width:380px,onclick=Page.Close('pggg')");
		  _GroupBox();
		  _Form();
		  _TabBody();
		   TabBody();
			 GroupBox("style=width:400px;height:300px,title=student info");
			 SmallButton("class=back block,onClick=Page.Open('Pages/Fender/left.php'\,'pgggg'),id=FenderLeft,title=Close");
			 BigButton("logo=logo_print_big.png,onClick=Page.Maximize('pggg'),id=FenderLeftbg,title=Close");
			 Text("text=List of Food,class=block biggest,style=font-weight:bold");
			 _GroupBox();
		 _TabBody();
		_Tab();
		_Page();
		 /*Radio("group=aaa,id=r3");
		 Radio("group=aaa,id=r4");
		 Radio("group=aaa,id=r5");*/
	  ?>
  <!--</div>-->