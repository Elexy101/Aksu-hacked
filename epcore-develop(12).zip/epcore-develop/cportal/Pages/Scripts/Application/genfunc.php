<?php
function LoadSetups(){
	$header=array("-SetupID"=>"SETUPID",
   "*SupVersion"=>"VERSION",
      "*SupAuthor"=>"AUTHOR",
      "*SupBuild"=>"BUILD",
      "*SupPubDate"=>"PUBLISH DATE",
      "*SupAddDate"=>"ADD DATE",  
      "*SupInstallDate"=>"INSTALL DATE"
  );
  Box("class=ep-animate-opacity");
  SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-top:0px;margin-bottom:6px,id=supsprsht,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=SupAddDate;SupVersion;SupAuthor;SupBuild;SupPubDate;SupStatus;SupInstallDate,rowdelete=false,rowfilter=true,case=none,filtertitle=FILTER ADDED SETUP,filterstyle=width:calc(100% - 16px);margin:auto",$header,"SELECT ID, Version, Author, IF(PublishType = 1,'Minified Only','Full'), DATE_FORMAT(PublishDate, '%d %M %Y %l:%i %p'), DATE_FORMAT(AddDate, '%d %M %Y %l:%i %p'), DATE_FORMAT(InstallDate, '%d %M %Y %l:%i %p'), IF(Inuse = 1,'*cogs','#wrench') as logo, CONCAT('Application.AppUpdate.Options(',ID,')') as Action, IF(Inuse = 1,'Running','Options') as info FROM setup_tb ORDER BY AddDate");
  _Box();
}





?>