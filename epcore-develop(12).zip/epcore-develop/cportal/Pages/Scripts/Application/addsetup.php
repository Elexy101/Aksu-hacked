<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 //require("../../../../general/getinfo.php");
 include("genfunc.php");
 AllowUser("Updates");
//exit(json_encode($_FILES['appaddsetup_file']));
$tempfilename = mt_rand(10000000000,100000000000);
while(is_dir("../../../../setup/".$tempfilename)){
    $tempfilename = mt_rand(10000000000,100000000000);
}

if(mkdir("../../../../setup/".$tempfilename,0777,TRUE)){
//upload file
 $resscript = UploadFile('appaddsetup',"../../../../setup/".$tempfilename."/tempsetup");
  if(is_string($resscript)){ //if uploaded
     //rename back to zip
rename("../../../../setup/".$tempfilename."/tempsetup.epx","../../../../setup/".$tempfilename."/tempsetup.zip");
$zip = new ZipArchive;
$res = $zip->open("../../../../setup/".$tempfilename."/tempsetup.zip");
if ($res === TRUE) {
    $zip->extractTo("../../../../setup/".$tempfilename."/", "meta.json");
    $zip->close();
//read the meta data
$meta = file_get_contents("../../../../setup/".$tempfilename."/meta.json");
if($meta !== FALSE){
    //{"Version":"3","Author":"TAQUATECH","Date":"2019-04-02","Time":"08:04:43","Update":"undefined","Minified":"1"}
    $meta = json_decode($meta,true);
    //check if already exist
    $chk = $dbo->SelectFirstRow("setup_tb","","Version='".$meta['Version']."'");
    $data = ["Version"=>$meta['Version']."","Author"=>$meta['Author'],"PublishType"=>$meta['Minified'],"PublishDate"=>$meta['Date']." ".$meta['Time'],"AddDate"=>date("Y-m-d H:i:s")];
    // if(is_array($chk))exit('{"Message":"#Setup Version Already Added"}');
    if(is_array($chk)){
      //update
      $instid = $dbo->Update("setup_tb",$data,"ID=".$chk['ID']);
      //if(is_array)
    }else{
      $instid = $dbo->InsertID("setup_tb",$data);
    }
    
if(is_numeric($instid) || is_array($instid)){
    $vstr = str_replace(".","_",$meta['Version']."");
if(is_dir("../../../../setup/".$vstr)){
    unlink("../../../../setup/".$vstr."/setup_$vstr.epx"); //remove the curent one
    rmdir("../../../../setup/".$vstr);
}
    //delete meta-data and rename setup
unlink("../../../../setup/".$tempfilename."/meta.json"); //remove the meta file
rename("../../../../setup/".$tempfilename,"../../../../setup/".$vstr);//rename the dir
rename("../../../../setup/".$vstr."/tempsetup.zip","../../../../setup/".$vstr."/setup_$vstr.epx"); //rename back to .epx
ob_start();
LoadSetups();
$markups = ob_get_contents();
ob_end_clean();

//form details
ob_start();
TextBoxGroup();
TextBoxGroupItem();echo "Version:";TextBoxGroupItemMore();echo $meta['Version'];_TextBoxGroupItem();
TextBoxGroupItem();echo "Author:";TextBoxGroupItemMore();echo $meta['Author'];_TextBoxGroupItem();
$dt = new DateTime($meta['Date']." ".$meta['Time']);
TextBoxGroupItem();echo "Publish Date:";TextBoxGroupItemMore();echo $dt->format("M d Y h:i A");_TextBoxGroupItem();
TextBoxGroupItem();echo "Build:";TextBoxGroupItemMore();echo (int)$meta['Minified'] == 1?"Minified Only":"Full";_TextBoxGroupItem();
_TextBoxGroup();
_TextBoxGroup();
TextBoxGroup();Note();echo "Eduporta Installation is recommended to be done when there is low or no traffic on the system";_Note();_TextBoxGroup();
$setupdet = ob_get_contents();
ob_end_clean();

$optype = is_array($instid)?"*Setup Updated Successfully":"*Setup Added Successfully";
$id = is_array($instid)?$chk['ID']:$instid;
$inuse = is_array($instid)?$chk['Inuse']:0;
exit(json_encode(["Setups"=>$markups,"Message"=>$optype,"Version"=>$meta['Version'],"Author"=>$meta['Author'],"PublishDate"=>$meta['Date']." ".$meta['Time'],"PublishType"=>$meta['Minified'],"ID"=>$id,"OptionMarkup"=>$setupdet,"Inuse"=>$inuse]));
}else{
    exit('{"Message":"#Adding Setup Failed"}');
}
}else{
    exit('{"Message":"#Reading Setup Meta-Data Failed"}');
}
} else {
    exit('{"Message":"#Reading Setup Failed"}');
}

  }else{
    exit('{"Message":"#Setup Upload Failed"}');
  }
}else{
    exit('{"Message":"#Tempoary Directory Creation Failed"}');
}
 

 ?>