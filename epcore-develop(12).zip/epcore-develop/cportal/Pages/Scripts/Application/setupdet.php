<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 //require("../../../../general/getinfo.php");
 extract($_POST);
 if(!isset($id) || (int)$id < 1)exit(json_encode(["Message"=>"#Invalid Setup Selected"]));
 $chk = $dbo->SelectFirstRow("setup_tb","","ID=".$id);
 if(!is_array($chk))exit(json_encode(["Message"=>"#Setup Not Found"]));
 ob_start();
TextBoxGroup();
TextBoxGroupItem();echo "Version:";TextBoxGroupItemMore();echo $chk['Version'];_TextBoxGroupItem();
TextBoxGroupItem();echo "Author:";TextBoxGroupItemMore();echo $chk['Author'];_TextBoxGroupItem();
$dt = new DateTime($chk['PublishDate']);
TextBoxGroupItem();echo "Publish Date:";TextBoxGroupItemMore();echo $dt->format("M d Y h:i A");_TextBoxGroupItem();
TextBoxGroupItem();echo "Build:";TextBoxGroupItemMore();echo (int)$chk['Minified'] == 1?"Minified Only":"Full";_TextBoxGroupItem();
_TextBoxGroup();
TextBoxGroup();Note();echo "Eduporta Installation is recommended to be done when there is low or no traffic on the system";_Note();_TextBoxGroup();

$setupdet = ob_get_contents();
ob_end_clean();
exit(json_encode(["ID"=>$id,"OptionMarkup"=>$setupdet,"Inuse"=>$chk['Inuse'],"Version"=>$chk['Version']]));

?>