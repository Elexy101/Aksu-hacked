<?php
// require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
// require("../../../../general/getinfo.php");
 //include("genfunc.php");
 AllowUser("Updates");
if(!isset($_POST['patch']) || trim($_POST['patch']) == "")exit("Invalid Patch File");
if(!file_exists("../../../../patch/temp/".$_POST['patch'].".php"))exit("Patch File not Found");
unlink("../../../../patch/temp/".$_POST['patch'].".php");
echo "*Patch Execution Aborted";
 ?>