<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
 include("genfunc.php");
 AllowUser("Updates");
 //********************NOTE************************** */
//In Patch Required Field Data - {,} symbol should not be used inside
 //********************NOTE************************** */
 $tempfilename = mt_rand(10000000000,100000000000);
while(file_exists("../../../../patch/temp/".$tempfilename.".php")){
    $tempfilename = mt_rand(10000000000,100000000000);
}
 $resscript = UploadFile('apprunpatch',"../../../../patch/temp/".$tempfilename,"php");
  if(is_string($resscript)){
    $mkup = "";
      //get the patch script requires if exist
      $patchcode = file_get_contents("../../../../patch/temp/".$tempfilename.".php");
      if($patchcode){
          //get the pathreqh
          $ppos = strpos($patchcode,"@PatchRequire={");
          if($ppos !== FALSE){ //if patch requires set
            $datastart = $ppos+14;
            $dataend = strpos($patchcode,"}",$datastart);
            $datalength = ($dataend - $datastart) + 1;
            //get the patch require data
            $patredata = substr($patchcode,$datastart,$datalength);
            //check if it is a valid data
            $reqobj = json_decode($patredata,true);
            if(!is_null($reqobj)){
                ob_start();
                TextBoxGroup();
              foreach($reqobj as $field=>$Info){
                TextBox("title=".str_replace(array(",","="),array('\,','\='),$Info).",style=width:250px,id=".str_replace(array(",","="),array('\,','\='),$field).",logo=edit,required=false,class=ep_patch_field");
              }
              _TextBoxGroup();
           $mkup = ob_get_clean();
            }
          }
      }
//get the current setup
$sid = $dbo->SelectFirstRow("setup_tb","ID","Inuse=1");
if(!is_array($sid))exit('{"Error":"*Running Version Identification Failed"}');
      $rtn = ["Patch"=>$tempfilename,"MarkUp"=>$mkup,"SID"=>$sid[0]];
    exit(json_encode($rtn));
  }
  exit('{"Error":"*Patch Verification Failed"}');

 ?>