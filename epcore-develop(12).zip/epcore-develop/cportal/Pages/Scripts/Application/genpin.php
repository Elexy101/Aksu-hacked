<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../" . $_REQUEST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

function GeneratePin($session = "")
{
  $rand4 = rand(1000, 9999);
  $rand2 = rand(10, 99);

  $time = (string)time();
  $tlength = strlen($time);
  $timestamp = substr($time, ($tlength - 4), $tlength);

  $pin = $rand4 . $timestamp . $session . $rand2;
  return $pin;
}
//hold queries
$PinOnlyArray = [];
//$q = [];
function GenerateMultiplePin($amount = 0,$maxUsage=5){
  global $PinOnlyArray;
  $a = 0;
  $PinArray = [];
  $session = [];
  while ($a < $amount) {

    if (!isset($session["LastTwo"])) {
      $session["LastTwo"] = (string)CurrentSesID();
      $length = strlen($session["LastTwo"]);
      if ($length == 1) $session["LastTwo"] = "0" . $session["LastTwo"];
      if ($length > 2) $session["LastTwo"] = substr($session["LastTwo"], ($length - 2), $length);
    }
    $cpin = GeneratePin($session["LastTwo"]);
    //check for accurrances
    // if(array_search($cpin,$PinOnlyArray)){
    //   print_r($cpin);
    // }

    $ft =substr($cpin,0,4);
    $sd = substr($cpin,4,4);
    $th = substr($cpin,8,4);
$withDash = $ft . "-" . $sd . "-". $th;

    $PinArray[] = "INSERT INTO pin_tb SET Pin='$cpin', MaxUsage=$maxUsage";
    $PinOnlyArray[] = ($a+1) . " => ".$withDash;
    $a++;
  }
  return [$PinArray,$PinOnlyArray];
}
$res = GenerateMultiplePin(50,5);

$query = implode(";",$res[0]).";";
$dump = $dbo->Connection->multi_query($query);
  if(!$dump){
    echo "#Server Error: ".$dbo->Connection->error;
  }else{
  
  echo implode("<br/>",$res[1]);
  } 
  



?>
