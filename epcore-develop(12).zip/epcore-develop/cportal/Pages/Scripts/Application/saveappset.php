<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
include $configdir.$dbo->Config['Require']."Image/image.php";
include "../../../../api/engine/parameter.php";
//get the manifest

//Resize Image Using the Image LB
function ResizeImage($imagepth,$width,$height,$newimage){
    global $dbo;
     $magicianObj = new imageLib($imagepth);
     $magicianObj -> resizeImage($width, $height, 'exact', true);
     $magicianObj -> saveImage($newimage, 100);
}

//Main Portal
//******************************************** */
$manifest = file_get_contents($configdir."manifest.json");

if($manifest){
  $appdet = json_decode($manifest,true);
}else{
    $appdet = json_decode('{
        "name": "Academa",
        "short_name": "Academa",
        "theme_color": "#2d2d2d",
        "background_color": "#E53456",
        "display": "standalone",
        "start_url": "./index.php",
        "orientation": "portrait-primary",
        "description": "Acadama: Smart School Solution",
        "icons": [
            {
                "src": "./icons/android-chrome-192x192.png",
                "sizes": "192x192",
                "type": "image/png"
            },
            {
                "src": "./icons/android-chrome-512x512.png",
                "sizes": "512x512",
                "type": "image/png"
            },
            {
                "src": "./icons/apple-touch-icon.png",
                "sizes": "180x180",
                "type": "image/png"
            },
            {
                "src": "./icons/favicon-16x16.png",
                "sizes": "16x16",
                "type": "image/png"
            },
            {
                "src": "./icons/favicon-32x32.png",
                "sizes": "32x32",
                "type": "image/png"
            }
        ],
        "shortcuts": [
            {
              "name": "Enrol",
              "short_name": "Enrol",
              "description": "Enrol into the School",
              "url": "?apgid=1",
              "icons": [{ "src": "/icons/sc.png", "sizes": "192x192" }]
            }
          ]
    }
    ',true);
}
//************************************************************** */

//CPortal
//*********************************************************** */
$manifestcp = file_get_contents($configdir."manifestcp.json");

if($manifestcp){
  $appdetcp = json_decode($manifestcp,true);
}else{
    $appdetcp = json_decode('{
        "name": "Academa",
        "short_name": "Academa",
        "theme_color": "#2d2d2d",
        "background_color": "#E53456",
        "display": "standalone",
        "start_url": "./cportal.php",
        "orientation": "portrait-primary",
        "description": "Acadama: Smart School Solution",
        "icons": [
            {
                "src": "./icons/android-chrome-192x192.png",
                "sizes": "192x192",
                "type": "image/png"
            },
            {
                "src": "./icons/android-chrome-512x512.png",
                "sizes": "512x512",
                "type": "image/png"
            },
            {
                "src": "./icons/apple-touch-icon.png",
                "sizes": "180x180",
                "type": "image/png"
            },
            {
                "src": "./icons/favicon-16x16.png",
                "sizes": "16x16",
                "type": "image/png"
            },
            {
                "src": "./icons/favicon-32x32.png",
                "sizes": "32x32",
                "type": "image/png"
            }
        ]
    }
    ',true);
}

//************************************************************* */

/* allowapp=1&appsetname=Akwa%20Ibom%20State%20University&appsetabbr=AKSU&appsetdescr=Akwa%20Ibom%20State%20University%20Official%20Portal%20Application&appsetdisplay=standalone&loadimg=&camimg=&clearimg=&appbgcolor=0&appthemecolor=0&appbgcolorr=%232d2d2d&appthemecolorr=%232d2d2d&SheetID=schactsessionspsh&MaxDataRow=1&1_ID=0&1_readonly=false&1_disable=false&1_deleted=false&1_position=1&1_1=Enrol&1_2=Enrol&1_3=Enrol%20into%20the%20School&1_4=1 */

$appdet['name'] = $_POST['appsetname'];
$appdetcp['name'] = $_POST['appsetname']." (Cportal)";
$appdet['short_name'] = $_POST['appsetabbr'];
$appdetcp['short_name'] = $_POST['appsetabbr']." (CP)";
$appdet['theme_color'] = $_POST['appthemecolorr'];
$appdetcp['theme_color'] = $_POST['appthemecolorr'];
$appdet['background_color'] = $_POST['appbgcolorr'];
$appdetcp['background_color'] = $_POST['appbgcolorr'];
$appdet['display'] = $_POST['appsetdisplay'];
$appdetcp['display'] = $_POST['appsetdisplay'];
$appdet['description'] = $_POST['appsetdescr'];
$appdetcp['description'] = $_POST['appsetdescr']." (Cportal)";
//exit(json_encode($_POST));
if(isset($_FILES['appicon_image_file'])){
    //upload and form icons
    
    $rst = Uploader($configdir."icons/",'appicon_image_file','appicon','image/png');
    if(count($rst['Failed']) > 0){
        die("#Icon Upload Failed (Only png format is allowed)");
    }
    $aarr = explode(".",$rst["Success"]['appicon_image_file']);
    $ext = $aarr[count($aarr) - 1];
    $iconset = [
        ["newname"=>$configdir."icons/android-chrome-192x192.".$ext,"width"=>192,"height"=>192],
        ["newname"=>$configdir."icons/android-chrome-512x512.".$ext,"width"=>512,"height"=>512],
        ["newname"=>$configdir."icons/apple-touch-icon.".$ext,"width"=>180,"height"=>180],
        ["newname"=>$configdir."icons/favicon-16x16.".$ext,"width"=>16,"height"=>16],
        ["newname"=>$configdir."icons/favicon-32x32.".$ext,"width"=>32,"height"=>32]
    ];
    foreach($iconset as $icon){
      if(file_exists($icon['newname'])){
        unlink($icon['newname']);
    }
    ResizeImage($rst["Success"]['appicon_image_file'],$icon['width'],$icon['height'],$icon['newname']);  
    }
    
    
   /*  ResizeImage($rst["Success"]['appicon_image_file'],512,512,$configdir."icons/android-chrome-512x512.".$ext);
    ResizeImage($rst["Success"]['appicon_image_file'],180,180,$configdir."icons/apple-touch-icon.".$ext);
    ResizeImage($rst["Success"]['appicon_image_file'],16,16,$configdir."icons/favicon-16x16.".$ext);
    ResizeImage($rst["Success"]['appicon_image_file'],32,32,$configdir."icons/favicon-32x32.".$ext); */ 
   


}else{
   // die("#Not Enter");
}

$scut = [];

if(isset($_POST['MaxDataRow']) && (int)$_POST['MaxDataRow'] > 0){
    for($s=1;$s<=(int)$_POST['MaxDataRow'];$s++){
        if($_POST[$s."_delete"] == "true")continue;
        $scname = $_POST[$s."_1"];
        $scabbr = $_POST[$s."_2"];
        $scdescr = $_POST[$s."_3"];
        $scappgid = $_POST[$s."_4"];
        $scut[] = ["name"=>$scname,"short_name"=>$scabbr,"description"=>$scdescr,"url"=>"./index.php?apgid=".$scappgid,"icons"=> [["src"=> "./icons/sc.png", "sizes"=> "192x192" ]]];
        /*  "name": "Enrol",
              "short_name": "Enrol",
              "description": "Enrol into the School",
              "url": "?apgid=1",
              "icons": [{ "src": "/icons/enrol.png", "sizes": "192x192" }] */
    }
}
$appdet['shortcuts'] = $scut;
$put = file_put_contents($configdir."manifest.json",json_encode($appdet,JSON_UNESCAPED_SLASHES));
$putcp = file_put_contents($configdir."manifestcp.json",json_encode($appdetcp,JSON_UNESCAPED_SLASHES));
if($put !== FALSE && $putcp !== FALSE){
    //update if installable
    $upd =  $dbo->Update("school_tb",["AppInstall"=>(int)$_POST['allowapp'],"AppThemeColor"=>$appdet['theme_color']]);
    exit("*Application Settings Saved");
}else{
    exit("#Application Settings Failed");  
}


?>