<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
extract($_POST);
if(!isset($Sheet)){
    exit("#INVALID PARAMETERS");
}
$Sheet = $dbo->DataArray($Sheet);
$TotRec = (int)$Sheet['MaxDataRow'];
$allrec= [];
/* SheetID=sprshmenuset&MaxDataRow=7&1_ID=0&1_readonly=false&1_disable=false&1_deleted=false&1_position=1&1_1=enrol&1_2=Enrol&1_3=1&1_4=4&2_ID=1&2_readonly=false&2_disable=false&2_deleted=false&2_position=2&2_1=pay&2_2=Payment&2_3=3&2_4=12&3_ID=2&3_readonly=false&3_disable=false&3_deleted=false&3_position=3&3_1=wallet&3_2=Wallet&3_3=5&3_4=0&4_ID=3&4_readonly=false&4_disable=false&4_deleted=false&4_position=4&4_1=course&4_2=Course%2FSubject&4_3=0&4_4=0&5_ID=4&5_readonly=false&5_disable=false&5_deleted=false&5_position=5&5_1=restult&5_2=Result&5_3=0&5_4=0&6_ID=5&6_readonly=false&6_disable=false&6_deleted=false&6_position=6&6_1=assignmet&6_2=Assignment&6_3=0&6_4=0&7_ID=6&7_readonly=false&7_disable=false&7_deleted=false&7_position=7&7_1=elearn&7_2=e-Learning&7_3=0&7_4=0 */
for($as=1;$as<=$TotRec;$as++){
    $allrec[$Sheet[$as.'_1']] = [$Sheet[$as.'_2'],$Sheet[$as.'_3'],$Sheet[$as.'_4']];
}

//update database
$upd = $dbo->Update("portal_tb",["MenuLink"=>json_encode($allrec)]);
if(is_array($upd)){
    exit("* Menu Linked Successfully");
}
echo "Internal Error occured while Linking Menus";

?>