<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser("wallPaper");
//walimage_image_file - {"loadimg":"","camimg":"","clearimg":"","wallheadertxt":"AKSU","walltxt":"An academic institution that keeps aflame the pursuit of knowledge, excellence and the spirit of enquiring; and offers opportunities for learning and leadership, service and self-actualization to all mankind, towards a peaceful, humane, prosperous and just society.","wallstatus":"1","selid":"0"}
if(!isset($_POST['walltxt']) || !isset($_POST['wallheadertxt'])  || !isset($_POST['selid'])){
    exit("#INVALID ENTERING");
}
$selid = $_POST['selid'];
if($selid == '0' && !isset($_FILES['walimage_image_file'])){
    exit("#No New Wall Image Set");
  }
$data = ['wallheader'=>$_POST['wallheadertxt'],'walltext'=>$_POST['walltxt']];
$delay = $_POST['wallpaperdelay'];
$set = "walldelay = ".$delay;
$dbo->Begin();
if($selid == '0'){ //add new wallpaper
    $name = $_FILES['walimage_image_file']['name'];
    //if filename already exist
while(file_exists("../../../../../../".$_POST['SubDir']."Files/UserImages/wallpapers/bgs/".$name)){
    $name = mt_rand(10000,999999).time().$name;
}
  $data['wallpaper'] = $name;

//perform insert
$insrt = $dbo->InsertID("wallpapers_tb",$data);
if(is_numeric($insrt)){
    if(Upload('walimage_image_file',"../../../../../../".$_POST['SubDir']."Files/UserImages/wallpapers/bgs/".$data['wallpaper'])){
        
       
        //update status
$wallstatus = (int)$_POST['wallstatus'];

if($wallstatus > 0){
  $set .= ",  wallpapers = CONCAT(wallpapers,'~','$insrt')";
}
$updportal = $dbo->RunQuery("UPDATE portal_tb SET ".$set);
$dbo->Commit();
exit("*Wallpaper Added Successfully");
}else{//if upload failed
    $dbo->Rollback();
    exit("#Wall Image Upload Failed");
}
}else{
    exit("#Error Adding New Wallpaper");
}

}else{ //update existing wallpaper
   if(isset($_FILES['walimage_image_file'])){
  $name = $_FILES['walimage_image_file']['name'];
  $data['wallpaper'] = $name;
   }

   //perfrom update
   $idarr = explode("_",$selid);
$id = isset($idarr[1])?$idarr[1]:$idarr[0];
//get the wallpaper details
$ex = $dbo->SelectFirstRow("wallpapers_tb","","ID=".$id);
if(!is_array($ex))exit("#Reading Wallpaper Details Failed");
$updt = $dbo->Update("wallpapers_tb",$data,"ID=".$id);
if(is_array($updt)){ //if no error
    $wallstatus = (int)$_POST['wallstatus'];

    
    $portalset = $dbo->SelectFirstRow("portal_tb");
    $wallpapers = $portalset['wallpapers'];
    $wallpaperarrs = explode("~",$portalset['wallpapers']);
    if($wallstatus > 0){
        if(!in_array($id,$wallpaperarrs)){
            $wallpapers .= "~".$id;
        }
    }else{
        $wallpapers = ltrim($wallpapers,$id."~");
        $wallpapers = rtrim($wallpapers,"~".$id);
        $wallpapers = str_replace("~".$id."~","",$wallpapers);


    }
    $wallpapers = trim($wallpapers,"~");
     $updportal = $dbo->RunQuery("UPDATE portal_tb SET $set, wallpapers = '$wallpapers'");
    
    

   if(isset($_FILES['walimage_image_file'])){
    if(Upload('walimage_image_file',"../../../../../../".$_POST['SubDir']."Files/UserImages/wallpapers/bgs/".$data['wallpaper'])){
        //$dbarr['logo'] = $db;
        //remove the prevous if changed
        if(trim($data['wallpaper']) != trim($ex['wallpaper'])){
            unlink("../../../../../../".$_POST['SubDir']."Files/UserImages/wallpapers/bgs/".$ex['wallpaper']);
        }
                //update status

        
}else{//if upload failed
    $dbo->Rollback();
    exit("#Wall Image Upload Failed");
}
   } //if image not change

   $dbo->Commit();
        exit("*Wallpaper Updated Successfully");
   
}else{//error in update
    exit("#Wallpaper Update Failed");
}

    
}
//echo json_encode($_POST);

?>