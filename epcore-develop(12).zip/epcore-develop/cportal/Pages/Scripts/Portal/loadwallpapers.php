<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

ThumbNailBox("onselect=Portal.WallPaper.SelectFunc,id=wallpapertn");
//break the string
//$walpaperarr = explode("~",$wallpaper);
//$wallidcond = "ID=".implode(" OR ID=",$walpaperarr);
//foreach($walpaperarr as $wallID){
  //get wallpaper details
$walldet = $dbo->Select("wallpapers_tb");
if(is_array($walldet) && $walldet[1] > 0){
  while($waldetind = $walldet[0]->fetch_assoc()){
    //ThumbNail("src=../epconfig/UserImages/wallpapers/bgs/".$waldetind['wallpaper'].",title=".str_replace(array(',','='),array('\,','\='),$waldetind['wallheader']).",text=".str_replace(array(',','='),array('\,','\='),$waldetind['wallheader']).",base=../../../../,id=wall_".$waldetind['ID']);
    ThumbNail("src=Files/UserImages/wallpapers/bgs/".$waldetind['wallpaper'].",title=".str_replace(array(',','='),array('\,','\='),$waldetind['wallheader']).",text=".str_replace(array(',','='),array('\,','\='),$dbo->EpMarkup($waldetind['wallheader'])).",base=../../../../../../".$_POST['SubDir'].",id=wall_".$waldetind['ID']);
  }
}

  
//}
            
            _ThumbNailBox();
?>