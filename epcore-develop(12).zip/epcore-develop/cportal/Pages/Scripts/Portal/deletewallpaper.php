<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser("wallPaper");
if(!isset($_POST['wallid'])){
    exit("#Invalid Parameter");
}

$wallid = $_POST['wallid'];
$wallidarr = explode("_",$wallid);
$id = count($wallidarr) > 1?$wallidarr[1]:$wallidarr[0];
$dbo->Begin();
//delete wallpaper
$del = $dbo->Delete("wallpapers_tb","ID=".$id);
if(is_array($del)){
    //remove from live wall paper if exist
    //get live wallpapers
    $portalset = $dbo->SelectFirstRow("portal_tb");
    $wallpapers = $portalset['wallpapers'];
    $wallpaperarrs = explode("~",$portalset['wallpapers']);
    
        $wallpapers = ltrim($wallpapers,$id."~");
        $wallpapers = rtrim($wallpapers,"~".$id);
        $wallpapers = str_replace("~".$id."~","",$wallpapers);

    $wallpapers = trim($wallpapers,"~");
     $updportal = $dbo->RunQuery("UPDATE portal_tb SET wallpapers = '$wallpapers'");
     $dbo->Commit();
     exit("*Wallpaper Deleted Successfully");
}
$dbo->Rollback();
exit("#Wallpaper Deletion Failed");

//echo json_encode($_POST);


?>