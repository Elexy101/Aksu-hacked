<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

//check if id set
if(!isset($_POST['wallid']) || trim($_POST['wallid']) == "")exit("#No Wallpaper Selected");

$idarr = explode("_",$_POST['wallid']);
//exit("#".$_POST['wallid']);
$id = isset($idarr[1])?$idarr[1]:$idarr[0];
//get the wallpape details
$walldet = $dbo->SelectFirstRow("wallpapers_tb","ID,wallpaper,wallheader,walltext","ID=".$id);
if(!is_array($walldet))exit("#Reading Wallpaper Details Failed - ".$walldet);

//check if image it exist
if(trim($walldet['wallpaper']) == "" || !file_exists("../../../../../../{$_POST['SubDir']}Files/UserImages/wallpapers/bgs/".$walldet['wallpaper'])){
    $walldet['wallpaper'] = '';
}

//check if set (live);
$portalset = $dbo->SelectFirstRow("portal_tb");
$wallpapers = explode("~",$portalset['wallpapers']);
$walldet['state'] = false;
if(in_array($walldet['ID'],$wallpapers)){
    $walldet['state'] = true;
}
exit(json_encode($walldet));

?>