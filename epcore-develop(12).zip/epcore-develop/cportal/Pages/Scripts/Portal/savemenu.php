<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
extract($_POST);
if(!isset($Data) || !isset($Sheet)){
    exit("#INVALID PARAMETERS");
}

//the database default, will be save as default if no structure set in db
$dbdefault = [
    "ApplyGID"=>["Name"=>"Application","SilentMode"=>false],
    "ApplyGIDSub"=>["Name"=>"Module Sub","SilentMode"=>false],
    "ApplyID"=>["Name"=>"Modules","SilentMode"=>false],
    "PageID"=>["Name"=>"Pages","SilentMode"=>false]
];

//get current school type
/* $schtpe = $dbo->SelectFirstRow('school_tb','Type,SchStrucContr');
$SchStrucContr = $schtpe['SchStrucContr'];
if(is_null($SchStrucContr)){
    $SchStrucContr = [];
}else{
    $SchStrucContr = json_decode($SchStrucContr,true);
} */
$Data = json_decode(urldecode($Data),true);
//get the current
$cur = $Data['Details']['Current'];
/* if(!isset($SchStrucContr[$cur])){
    $SchStrucContr[$cur] = [];
} */
//$SchStrucContr[$cur]["Name"] = trim($StrucName) == ""?$dbdefault[$cur]["Name"]:$StrucName;
//exit("SilentMode:"+$SilentMode);.$schtpe['Type']
$agid = $Data['ApplyGID']['ID'];
$agidsub = $Data['ApplyGIDSub']['ID'];
$aid = $Data['ApplyID']['ID'];
$pid = $Data['PageID']['ID'];
/* Name
Descr
GroupID 
Logo
Enable
Status
Color
Placeholder
Dir
GlobalData
Pages */
/* "-ApplyIDGSub"=>"GROUPSUB ID",
        "*ApplyNameGSub"=>"NAME",
        "*ApplyDescrGSub"=>"DESCRIPTION",
        "-ApplyGrpIDSub"=>"GROUPID",
        "*ApplyLogoGSub"=>"LOGO",
        "*ApplyColorGSub"=>"COLOR",
        "*ApplyEnableGSub"=>array("ENABLE","YES|NO"),
        "*ApplyStatusGSub"=>array("STATUS","OPENED=OPENED&CLOSED=CLOSED") */
$Sheet = $dbo->DataArray($Sheet);
$TotRec = (int)$Sheet['MaxDataRow'];
$StrData = [
    "ApplyGID"=>["Table"=>"new_apply_group_tb","Fields"=>[1=>"ID","Name","Descr","Logo","Color","Scope","int Enable || 1","position"=>"int MenuOrder || ".($TotRec + 1)],"Require"=>[2],"KeyIndex"=>1,"Relationship"=>"new_apply_group_sub_tb.GroupID"],
    "ApplyGIDSub"=>["Table"=>"new_apply_group_sub_tb","Fields"=>[1=>"ID","Name","Descr","GroupID || $agid","Logo","Color","int Enable || 1","Status","position"=>"int MenuOrder || ".($TotRec + 1)],"Require"=>[2],"KeyIndex"=>1,"Relationship"=>"new_apply_tb.GroupSubID"],
    "ApplyID"=>["Table"=>"new_apply_tb","Fields"=>[1=>"ID","Name","Descr","GroupID || $agid","Logo","Color","Dir","GlobalData","Pages","Enable","Status","PayID","PayBases","GroupSubID || $agidsub","position"=>"int MenuOrder || ".($TotRec + 1)],"Require"=>[2],"KeyIndex"=>1,"Relationship"=>""]
];
//Name,Capacity,HeadID, HeadTitle, Descr, ProgID
/* if($cur == "ApplyID"){
    exit("#"."GroupID || $agid");
} */
   // 
if(isset($StrData[$cur])){
    
$grdsh = SheetDatabind($Sheet,$StrData[$cur]['Table'],$StrData[$cur]['Fields'],$StrData[$cur]['Require'],$StrData[$cur]['KeyIndex'],$StrData[$cur]['Relationship']);
    if ($grdsh !== true)exit($grdsh."");
    //update the school structure control
    // $upd = $dbo->Update("school_tb",["SchStrucContr"=>json_encode($SchStrucContr)]);
     exit("#");
}
    
//}

//if($cur == "StudyID"){

//}

echo "STRUCTURE IDENTIFICATION FAILED";

?>