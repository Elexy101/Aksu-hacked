<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser("colorscheme");
if(!isset($_POST['basecolor']) || !isset($_POST['forecolor']) || !isset($_POST['footnote'])){
    exit("#Invalid Parameter");
}

$basecolor = implode(",",HexToRGB($_POST['basecolor']));
$forecolor = implode(",",HexToRGB($_POST['forecolor']));
$colorscheme = $dbo->SqlSafe($basecolor.";".$forecolor);
$footnote = $_POST['footnote'];
$dbo->Begin();
//update portal color
$upd = $dbo->Update("portal_tb",["colorScheme"=>$colorscheme]);
//update footernote
$updf = $dbo->Update("school_tb",["FooterNote"=>$footnote]);
if(is_array($upd) && is_array($updf)){
    $dbo->Commit();
  exit("*Student Portal Appearance Settings Saved Successfully");
}else{
    $dbo->Rollback();
    exit("#Operation Failed");  
}
//echo json_encode($_POST);


?>