<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
LoadFile("basic","../../../../");


//get all payment
$updated = '<div style="float:left;width:300px"><h1>Updated</h1>';
$recnotfound = '<div style="float:left;width:300px"><h1>Failed</h1>';
$updcnt = 0;
$faildcnt = 0;
$tb = 'payhistory_tb';
$allpay = $dbo->Select($tb);
if(is_array($allpay)){
    $cnt = 1;
    while($pay = $allpay[0]->fetch_array()){
        $RegNo = $pay['RegNo'];
        $ID = $pay['ID'];
        $PayID = $pay['PayID'];
   // if($pay['Info'] == ''){
        $PatchStr = StudPatchDet($RegNo,$PayID);
      if($PatchStr != ""){
        $upd = $dbo->Update($tb,array("Info"=>$PatchStr),"ID=".$ID);
        if(is_array($upd)){
            $updcnt++;
            $updated .= '<div>'.$updcnt.': '.$RegNo.'</div>';

        }else{
            $faildcnt++;
            $recnotfound .= '<div>'.$faildcnt.': '.$RegNo.' - Update Failed</div>'; 
        }
       }else{
        $faildcnt++;
        $recnotfound .= '<div>'.$faildcnt.': '.$RegNo.' - Record Not Found</div>';
       }
    }
    //}

}else{
    echo $allpay;
}
$updated .= '</div>';
$recnotfound .= '</div>';
echo $updated.$recnotfound;
?>