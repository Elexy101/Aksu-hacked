<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Paid Report</title>
    <script>
       function Excel(){
           table = document.getElementById('mtb');
            //get the innerHTML
    table = table.innerHTML;
    //if(!_.IsFound(table))return;
//the data url template
var uri = 'data:application/vnd.ms-excel;base64,'
, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',

//converts the formated uri(after replacing the table innerHTML and the wooksheet name) to base64
base64 = function(formateduri){
    return window.btoa(unescape(encodeURIComponent(formateduri)))
},

//replace the table innerHTML and wooksheet name in the uri template
format = function(templ, tbiHTMLWorksNme){
    return templ.replace(/{(\w+)}/g, function(m, p) { return tbiHTMLWorksNme[p]; });
},

//form the replace(format) object
ctx = {worksheet: "Sheet 1" || 'Worksheet', table: table}

//set the browser uri
window.location.href = uri + base64(format(template,ctx))
       }
    </script>
</head>
<body>
<?php
require_once("../../../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
LoadFile("basic","../../../../");

$allpay = $dbo->RunQuery("SELECT p.*  FROM payhistory_tb p WHERE p.Info LIKE '%\"StartSes\":\"6\"%' and p.PayDate >= '2017-1-1' and p.PayDate <= '2017-12-12' and p.PayID = 2");
if(is_array($allpay)){
    if($allpay[1] > 0){
        echo '<button onclick="Excel()">To Excel</button>';
        echo '<table style="" border="1" cellpadding="5" id="mtb">
        <tr><th>S/N</th><th>Reg.No</th><th>Name</th><th>Pay Level</th><th>Pay Semester</th><th>Amount</th><th>Tran. ID</th><th>PayDate</th><th>School</th><th>Department</th></tr>';
        $cnt = 1;
        while($pay = $allpay[0]->fetch_array()){
            $Info = $pay['Info'];
            $RegNo = $pay['RegNo'];
            $Amt = $pay['Amt'];
            $Sem = $pay['Sem'];
            $Lvl = $pay['Lvl'];
            $semn = $Sem == 1?"First":"Second";
            $TransID = $pay['TransID'];
            $det = json_decode($Info,true);
            $dt = new DateTime($pay['PayDate']);
            $ddat = $dt->modify("d/m/Y");
           echo "<tr><td>$cnt</td><td>$RegNo</td><th>".$det['Name']."</td><td>NCE $Lvl</td><td>$semn</td><td>$Amt</td><td>$TransID</td><td>".$pay['PayDate']."</td><td>".$det['FacName']."</td><td>".$det['ProgName']."</td></tr>";
           $cnt++;
        }
        echo "</table>";
    }
}




?>
</body>
</html>