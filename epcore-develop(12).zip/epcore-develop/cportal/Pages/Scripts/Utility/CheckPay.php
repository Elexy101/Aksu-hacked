<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
LoadFile("basic","../../../../");
if(isset($_POST['sub'])){
    //HasPaid($regNo,$payID,$lvl = 0,$sem = 0,$sempart=3,$RegID=1,$SesID=0)
    $paydet = HasPaid($_POST['RegNo'],$_POST['PayID'],$_POST['Lvl'],$_POST['Sem']);
    print_r($paydet);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Check Pay</title>
</head>
<body>
   <form action="#" method="post">
       <input type="text" placeholder="RegNo" name="RegNo"><br />
       <input type="text" placeholder="Level" name="Lvl"><br />
       <input type="text" placeholder="Semester" name="Sem"><br />
       <input type="text" placeholder="Payment ID" name="PayID"><br />
       <input type="submit" value="Check" name="sub">
</form> 
</body>
</html>