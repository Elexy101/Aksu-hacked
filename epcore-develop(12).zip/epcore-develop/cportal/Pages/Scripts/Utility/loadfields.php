<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//exit('ssss');
require_once("../../../../general/getinfo.php");

$sch = GetSchool();
$userID = 0; $staffID = 0;$loadcond="";
$user = $_POST['USER'];
$deptasign = "";
if($user != ""){
  $userdet = explode("~",$user);
  if(count($userdet) > 0){
    $userID = $userdet[0];
    //get the staffdet
    $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
    if(is_array($staffDet)){
       $staffID = $staffDet["StaffID"];
       //$courses = trim($staffDet['Courses']);
       /* if($courses != ""){
         $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
       } */
      $deptasign = $staffDet['DeptIDs'];

    }
  }
}
$UID = $userID;
$studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
$intStudyID = key($studyarr); //get the selected study
if(trim($deptasign) != ""){ //if dept assign to user
   
    //check if one dept asign
    $deptasignarr = explode("~",$deptasign); //get all asign departids
    $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
  //get study based on the assigned dept
  $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
 /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
  if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
    if(count($deptasignarr) < 2){ //if one dept/prog assigned
     
      //load level based on the prog
      //$lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
      $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
      $spillStr = ExtraLevelString();
      $lstlvl = end($lvlarr);
      $lstkey = key($lvlarr);
      for($s=1;$s <= 4; $s++){
        $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
      }
      
      //load all classes
      $classarr = TextBoxSQL("(select 0, 'NONE') UNION (select ID, Name from studentclass_tb where ProgID=".$dbo->SqlSafe(trim($deptasign)).")");
  } 
  }
Box("class=zoomInShort animated faster");
TextBoxGroup("width:100%");
$schStruc = json_decode($sch['SchStrucContr'],true);
$classTextbox = "";
 //LoadFac
if(trim($deptasign) == ""){ //if no dept/prog assing
  $scharr = TextBoxSQL("select * from school_grp_tb");
  if(count($scharr) > 1){
    TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadschtb,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
  }
  $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";
  TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadstudy,required=true,selected=$selestu,logo=building-o,onchange=Student.PreLoad.GenLoaderMigrate.LoadFac",$studyarr);
 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=mpreloadfac,onchange=Student.PreLoad.GenLoaderMigrate.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
 //TextBoxSQL("select * from fac_tb order by FacName")
 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Student.PreLoad.GenLoaderMigrate.LoadProg,id=mpreloaddept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
  TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Student.PreLoad.GenLoaderMigrate.LoadClass",array());
  $classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadclass,required=true,logo=users",array() );
 /*  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoaderMigrate.LoadSemester",array() ); *///TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
}else{ //if dept asign
    //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=cstudy,required=true,selected=-1,logo=building-o,onchange=Course.ManageCourse.GenLoaderMigrate.LoadLevel",$studyarr);
    
    //initial study
     if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
      echo '<input type="hidden" id="mpreloadprog" class="objgrpelemmgecourse" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
      if(!isset($progDet)){
        $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                     }
                     
                    if(is_array($progDet)){
                         Note();
                echo $progDet['FacName']. " - ".$progDet['ProgName'];
        _Note();
                    }
       //Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
       $classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadclass,required=true,logo=users",$classarr);
     /*  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoaderMigrate.LoadSemester,chain=preloadlvl:;preloadsemest:",$lvlarr); //load the lvel drop down */
    }else{ // if multiple dept/prog assigned
    $deptasignsql = "p.ProgID=".str_replace("~", " or p.ProgID=",$deptasign);
      //load prog the textbox
      TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Student.PreLoad.GenLoaderMigrate.LoadClass,chain=preloadprog:;preloadlvl:;preloadsemest:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
      $classTextbox = __TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=mpreloadclass,required=true,logo=users",array() );
      //create lvl dropdown
      /* TextBox("title=Level,style=width:250px;text-transform:uppercase,id=preloadlvl,required=true,logo=list-ol,onchange=Student.PreLoad.GenLoaderMigrate.LoadSemester",array() ); */
    }
  }
/*  TextBox("title=Semester,style=width:250px;text-transform:uppercase,id=preloadsemest,required=true,logo=star-half-o,onchange=",array()); */
TextBox("title=Batch/Start Session,style=width:250px;text-transform:uppercase,id=mpreloadstartses,required=true,onchange=Student.PreLoad.GenLoaderMigrate.GetLevel,logo=calendar",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
  Note("style=font-size:12px");
      echo 'Calculated Level: <b style="font-weight:bold" id="mDisplayLvl">--</b>';
_Note();
$op = "0";
echo $classTextbox;
TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=mpreloadmoe,required=true,logo=university",TextBoxSQL("select Level,Name from modeofentry_tb"));
_TextBoxGroup();
_Box();
//echo 'ddd';

?>