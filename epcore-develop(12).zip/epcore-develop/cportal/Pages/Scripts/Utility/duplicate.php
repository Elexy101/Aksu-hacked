<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
LoadFile("basic","../../../../");

$lookup = [];
$duplcount = [];

//get all payment
$allpay = $dbo->Select('payhistory_tb','','1=1 ORDER BY TransID');
if(is_array($allpay)){
    $cnt = 1;
    while($pay = $allpay[0]->fetch_array()){
       $TransID = $pay['TransID'];
       if(in_array($TransID,$lookup)){
           //delete
           $del = $dbo->Delete('payhistory_tb','ID='.$pay['ID']);
           if(is_array($del)){
            echo $cnt.": ".$TransID." | ". $pay['RegNo']." | ". $pay['Amt']." | ". $pay['Lvl']." | ". $pay['Sem']." | ". $pay['PayID']." | ". $pay['PayDate']."<br />";
            $cnt++;
           }
       }else{
        $lookup[] = $TransID;
       }

    }

}

?>