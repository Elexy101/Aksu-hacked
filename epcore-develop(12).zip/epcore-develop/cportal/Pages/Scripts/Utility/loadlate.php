<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
LoadFile("basic","../../../../");

//get all student
$allstud = $dbo->Select('studentinfo_tb');
if(is_array($allstud)){
    if($allstud[1] > 0){
        $CurSes = CurrentSes();
        $CurSesID = $CurSes['SesID'];
        $cnt = 1;
        while($stud = $allstud[0]->fetch_array()){
            //if()
            $regno = $stud['RegNo'];
            $jambno = $stud['JambNo'];
            $id = $stud['id'];
            if(trim($regno) == "" && trim($jambno) != ""){
                $regno = $jambno;
            }
            if(trim($jambno) == "" && trim($regno) != ""){
                $jambno = $regno;
            }
            $Studlvl = StudLevel($regno);
            //get stud last payment
            $lstpay = $dbo->SelectFirstRow('payhistory_tb','',"RegNo='$regno' OR RegNo = '$jambno' AND PayID = 2 ORDER BY Ses DESC, Lvl DESC, Sem DESC");
            if(is_array($lstpay)){
                //continue;
                $Ses = $lstpay['Ses'];$Sem = $lstpay['Sem'];$Lvl = $lstpay['Lvl'];
                $lstudlvl = $Studlvl - 1;
                $lses = $CurSesID - 1;
                if($Ses < $lses || $Lvl < $lstudlvl || (($Ses == $lses || $Lvl == $lstudlvl) && $Sem < 2) ){ //if owing
                    $insertSem = 1;
                    $inserLvl = $Lvl;
                   if($Sem < 2){
                    $insertSem = 2;
                   }else{
                       $inserLvl = $Lvl + 1;
                   }
                   //update stud rec
                   $upd = $dbo->Update('studentinfo_tb',array('LateAmt'=>2000,'LateLvl'=>$inserLvl,'LateSem'=>$insertSem),"id=$id");
                   if(is_array($upd)){
                       echo $cnt.": ".$regno."<br />";
                       $cnt++;
                   }
                   
                }
            }else{
               //if student is not in 100 level
               if($Studlvl > 1){
                   //update stud rec
                   $upd = $dbo->Update('studentinfo_tb',array('LateAmt'=>2000,'LateLvl'=>$Studlvl - 1,'LateSem'=>2),"id=$id");
                   if(is_array($upd)){
                       echo $cnt.": ".$lstpay['RegNo']."<br />";
                       $cnt++;
                   }
               } 
            }

        }
    }
}


?>