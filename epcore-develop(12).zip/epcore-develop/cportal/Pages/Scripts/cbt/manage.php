<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".urldecode($_POST['SubDir']);
require_once("../../../../general/config.php");

//{SubDir:encodeURIComponent(configdata['SubDir']),QID:QID,Mark:Mark,QBody:QBody,QAnswerType:optiondistag,QAnswerBody:optiondiscon}
//check entering
if(!isset($_POST['QID']))exit("#Invalid Question");

$upd = $dbo->Update("cbt_questions_tb",["Mark"=>$_POST['Mark'],"QBody"=>$_POST['QBody'],"QAnswerType"=>$_POST['QAnswerType'],"QAnswerBody"=>urldecode($_POST['QAnswerBody'])],"ID=".$_POST['QID']);
if(is_array($upd)){
  exit("*Question Saved Successfully");
}else{
    exit("#Error Occcur - ");
}


?>