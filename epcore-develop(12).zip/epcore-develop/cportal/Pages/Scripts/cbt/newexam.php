<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
$sch = $dbo->SelectFirstRow("school_tb");
//require("../../../../general/getinfo.php");
//AllowUser('ptype');
//get the 
Form("groupname=ExamParamGrp,action=javascript:void(0),id=ExamParamGrpid");
TextBoxGroup("width:95%;margin:auto;font-size:0.9em;margin-bottom:10px");
TextBox("title=Exam Code,style=width:250px;text-transform:uppercase,id=cbtexmcode,logo=list-alt");
TextBox("title=Exam Name,style=width:250px;text-transform:uppercase,id=cbtexmname");
_TextBoxGroup();
TextBoxGroup("width:95%;margin:auto;font-size:0.9em");
$scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title=school,style=width:250px;text-transform:uppercase,id=cbtexm,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
TextBox("title=Study,style=width:250px;text-transform:uppercase,id=cbtexmstudy,required=true,onchange=Cbt.Manage.GenLoader.LoadFac,logo=building-o",$studyarr);
TextBox("title=Faculty,style=width:250px;text-transform:uppercase,id=cbtexmfac,onchange=Cbt.Manage.GenLoader.LoadDept,logo=server",array(""));
TextBox("title=Department,style=width:250px;text-transform:uppercase,onchange=Cbt.Manage.GenLoader.LoadProg,id=cbtexmdept,logo=tasks",array(""));
TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=cbtexmprog,required=true,onchange=Cbt.Manage.GenLoader.LoadLevel,logo=list-alt",array(""));
TextBox("title=Level,style=width:250px;text-transform:uppercase,id=cbtexmlvl,required=true,logo=list-ol",array(""));

TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=cbtexmpaysem,required=true,logo=star-half",TextBoxSQL("select IF(Num=0,ID,Num) as Num, Sem from semester_tb where Enable = 1"));
_TextBoxGroup();
_Form();
/*  */



?>