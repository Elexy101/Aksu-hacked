<?php
if(!isset($exmdetincluded) || !$exmdetincluded){
    //check if required data sent
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
}
$alq = NULL;
if(isset($_POST['EID'])){
    //get the exam details
$ExmDet = $dbo->SelectFirstRow("cbt_exam_tb","","ExamID=".$_POST['EID']);
if(!is_array($ExmDet))$ExmDet = ["ExamAbbr"=>"--","ExamName"=>"--"];
//get all questions
$alq = $dbo->RunQuery("SELECT count(ID) as Tot, QAnswerType FROM `cbt_questions_tb` WHERE ExmID={$_POST['EID']} GROUP BY QAnswerType");

}else{
    $_POST['EID'] = "";
    $ExmDet = ["ExamAbbr"=>"--","ExamName"=>"--"];
}

Table("rowselect=false,style=width:calc(100% - 12px);font-size:0.8em;margin:10px auto;text-align:left,id=schexamdettb,multiselect=false,data-type=table,onselect=,rowalt=true,rowfilter=false,class=ep-animate-opacity");
THeader(array("CODE","TITLE"),"");
TRecord(array($ExmDet['ExamAbbr'], $ExmDet['ExamName']),"style=text-transform:uppercase");
_Table();
Table("rowselect=false,style=width:calc(100% - 12px);font-size:0.8em;margin:10px auto;text-align:left,id=schexamdettbq,multiselect=false,data-type=table,onselect=,rowalt=true,rowfilter=false,class=ep-animate-opacity");
$tot = 0;
$indtot = ["OBJECTIVE"=>0,"SUBJECTIVE"=>0,"THEORY"=>0,"AUDIO"=>0,"VIDEO"=>0];
THeader(array("QUESTION","STATS"),"");
if(!is_array($alq) || $alq[1] < 1){
    TRecord(array("Objective", "--"),"style=text-transform:uppercase");
TRecord(array("Subjective", "--"),"style=text-transform:uppercase");
TRecord(array("Theory", "--"),"style=text-transform:uppercase");
TRecord(array("Audio", "--"),"style=text-transform:uppercase");
TRecord(array("Video", "--"),"style=text-transform:uppercase");
TRecord(array("Total", "--"),"style=font-weight:bold");
}else{
    
  while($indcnt = $alq[0]->fetch_assoc()){
    TRecord(array($indcnt['QAnswerType'], $indcnt['Tot']),"style=text-transform:uppercase");
    $indtot[$indcnt['QAnswerType']] = (int)$indcnt['Tot'];
    $tot += (int)$indcnt['Tot'];
  }
  TRecord(array("TOTAL", $tot),"style=font-weight:bold");
}
echo '<div id="indtotquestion" style="display:none;visibility:hidden">'.json_encode($indtot).'</div>';
echo '<input type="hidden" id="loadtotquestion" value="'.$tot.'" data-value="'.$tot.'" />';
echo '<input type="hidden" id="loadexmid" value="'.$_POST['EID'].'" data-value="'.$_POST['EID'].'" />';
_Table();
?>