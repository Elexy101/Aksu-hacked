<?php
// sleep(3);
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");



if(!isset($_POST['ClassID']) || trim($_POST['ClassID']) == "")exit("#Invalid class selected");
$LevelDB = [];

//function to get levelname
function GetLevelName($StudyID,$Lvl=1){
    if(!isset($StudyID) || (int)$StudyID < 1)return "--";
    global $dbo;
    global $LevelDB;
    if(isset($LevelDB[$StudyID."_".$Lvl]))return $LevelDB[$StudyID."_".$Lvl];
    $lvldet = $dbo->SelectFirstRow("schoollevel_tb","IF(Descr='',Name,Descr) as LevelName","Level=$Lvl AND StudyID=$StudyID");
    if(is_array($lvldet)){
        $LevelDB[$StudyID."_".$Lvl] = $lvldet['LevelName'];
        return $lvldet['LevelName'];
    }else{
        return "--";
    }
}

//get all student in the selected class
$preloadstudy = (int)$_POST['StudyID'];
$preloadprog = (int)$_POST['ProgID'];
$preloadstartses = (int)$_POST['StartSes'];
$preloadclass = (!isset($_POST['ClassID']) || (int)$_POST['ClassID'] < 1) ?0:(int)$_POST['ClassID'];
$preloadmoe = (!isset($_POST['MOE']) || (int)$_POST['MOE'] < 1) ?1:(int)$_POST['MOE'];

$query = "SELECT s.id, s.RegNo, s.JambNo, s.SurName, s.FirstName, s.Passport, s.OtherNames, s.Phone, s.StudyID,st.Name as StudyName, p.ProgName, COALESCE(a.AccessCode,'') as AccessCode, c.Name as ClassName FROM studentinfo_tb s LEFT JOIN accesscode_tb a ON ((a.JambNo = s.RegNo OR a.JambNo = s.JambNo) AND a.JambNo != '') LEFT JOIN studentclass_tb c ON s.ClassID = c.ID LEFT JOIN study_tb st ON st.ID = s.StudyID LEFT JOIN programme_tb p ON p.ProgID = s.ProgID  WHERE s.ProgID = ".$dbo->SqlSafe($preloadprog)." AND s.StartSes = ".$dbo->SqlSafe($preloadstartses)." AND s.ClassID = ".$dbo->SqlSafe($preloadclass)." AND s.ModeOfEntry = ".$dbo->SqlSafe($preloadmoe)." ORDER BY s.id" ;

$data = json_decode($_POST['Data'],true);


$qrst = $dbo->RunQuery($query);
		if((is_array($qrst) && $qrst[1] > 0) || count($data) > 0){
            CardList("action=Cbt.CbtSchedule.AddCandidate(),id=schcandidate");
            if(count($data) > 0){
                foreach($data as $dkey => $ddata){
                    Card($ddata);
                }
            }
            if(is_array($qrst) && $qrst[1] > 0){
                while($candrst = $qrst[0]->fetch_assoc()){
                 $temp = "";
                 $RegNo = trim($candrst['RegNo']) == ""?$candrst['JambNo']:$candrst['RegNo'];
                 if(isset($data[$RegNo]))continue;
                 if(is_null($candrst['Passport']) || trim($candrst['Passport']) == ""){
                    $candrst['Passport'] = "Files/UserImages/General/image.png";
                 }else{
                     $splitpassp = explode("UserImages/",$candrst['Passport']);
                     if(count($splitpassp) > 1){
                         array_shift($splitpassp);
                         $candrst['Passport'] = "Files/UserImages/".implode("UserImages/",$splitpassp);
                         if(!file_exists("../../../../../../".$dbo->Config['SubDir'].$candrst['Passport'])){
                          //  $temp = $dbo->Config['SubDir2'].$candrst['Passport'];
                            $candrst['Passport'] = "Files/UserImages/General/image.png"; 
                         }
                         
                     }
                 }
                 //get the student last course registration 
                 $lastcoursereg = $_->SelectFirstRow("coursereg_tb","Lvl","RegNo ='".$candrst['RegNo']."' OR JambNo='".$candrst['JambNo']."' ORDER BY Lvl DESC LIMIT 1");
                 $lvl = 1;
                 if(is_array($lastcoursereg))$lvl = $lastcoursereg['Lvl'];
                 $LvlName = GetLevelName($candrst['StudyID'],$lvl);
                 
                 Card(["Image"=>$candrst['Passport'],"Text1"=>strtoupper($candrst['SurName']." ".$candrst['FirstName']." ".$candrst['OtherName']." (".$RegNo.")"),"Text2"=>$candrst['StudyName']. " / ".$candrst['ProgName'],"Text3"=>$LvlName." (".$candrst['ClassName'].")","AccessCode"=>$candrst['AccessCode'],"Phone"=>$candrst['Phone'],"Level"=>$LvlName,"Study"=>$candrst['StudyName'],"Prog"=>$candrst['ProgName'],"Name"=>strtoupper($candrst['SurName']." ".$candrst['FirstName']." ".$candrst['OtherName']),"key"=>$RegNo]);
             } 
            }
            
            _CardList();

        }else{
            exit("#No student exist in selected class");
        }

?>