<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

TextBoxGroup("border-top-color:transparent; width:95%;margin:auto");
 TextBoxGroupItem();echo "Name";TextBoxGroupItemMore();echo "2017/2018 Uses Of English";_TextBoxGroupItem();
 TextBoxGroupItem();echo "Code";TextBoxGroupItemMore();echo "GSS 111";_TextBoxGroupItem();
 TextBoxGroupItem();echo "Period";TextBoxGroupItemMore();echo "2/4/2019 - 8/7/2019, 1:45 AM - 2:30AM";_TextBoxGroupItem();
 TextBoxGroupItem();echo "Duration";TextBoxGroupItemMore();echo "1:30:00";_TextBoxGroupItem();
 TextBoxGroupItem();echo "Candidates";TextBoxGroupItemMore();echo "80";_TextBoxGroupItem();
 _TextBoxGroup();

Box("style=height:200px;overflow:auto; width:95%;margin:auto; margin-top:10px;border-top:#CCC solid thin;position:relative; border-bottom:#CCC solid thin, class=greyShadow");
 Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent,id=selcandcbt,multiselect=false,data-type=table,onselect=Student.RegReport.NullFunc,rowalt=true,rowfilter=true,filtertitle=Filter Selected Candidate,filterstyle=width:100%");
 THeader(array("S/N","REGNO.","NAME"));

    $rw = 1;
    while($rw < 20){
//$sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
TRecord(array($rw,"AK12/FGF/JHHG/".$rw,"CANDIDATE ".$rw),"");
$rw++;
//TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
    }
 /*   }
} */

 _Table();
 _Box();

?>