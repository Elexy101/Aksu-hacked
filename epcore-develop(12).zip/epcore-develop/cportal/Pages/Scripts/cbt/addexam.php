<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");

//check if required data send
//cbtexmcode=COM%20101&cbtexmname=Computer%20APRECIATION&cbtexmstudy=5&cbtexmfac=4&cbtexmdept=2&cbtexmprog=2&cbtexmlvl=1&cbtexmpaysem=1
extract($_POST);
if(!isset($cbtexmcode) || trim($cbtexmcode) == "" || !isset($cbtexmname) || trim($cbtexmname) == "" || !isset($cbtexmprog) || (int)$cbtexmprog == 0 || !isset($cbtexmlvl) || (int)$cbtexmlvl == 0 || !isset($cbtexmpaysem) || (int)$cbtexmpaysem == 0){
    exit("#Invalid Entering: All Fields are Required");
}

//check if user supplied
if(!isset($UID) || (int)$UID < 1){
    exit("#Login User Identification Failed"); 
}

//check if course code already exist, for the supplied programme, level and semester
$coursecodeexist = $dbo->SelectFirstRow("cbt_exam_tb","","ExamAbbr = '$cbtexmcode' AND ProgID = $cbtexmprog AND LevelID = $cbtexmlvl AND SemID = $cbtexmpaysem",MYSQLI_ASSOC);
if(is_array($coursecodeexist))exit("#Exam/Test Already Exist");

//add exam
$ins = $dbo->InsertID2("cbt_exam_tb",["ExamAbbr"=>$cbtexmcode,"ExamName"=>$cbtexmname,"UserID"=>$UID,"ProgID"=>$cbtexmprog,"LevelID"=>$cbtexmlvl,"SemID"=>$cbtexmpaysem]);

if(!is_numeric($ins))exit("#Operation Failed: ".$ins);
exit(json_encode(["EID"=>$ins,"EName"=>$cbtexmname,"ECode"=>$cbtexmcode]));
// exit("*".$cbtexmname." ($cbtexmcode) Added Successfully");




?>