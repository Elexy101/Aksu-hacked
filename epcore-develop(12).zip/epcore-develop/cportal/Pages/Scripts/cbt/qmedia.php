<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
//AllowUser('ptype');
//get the 


//get set walpapers
Box("style=background-color:#FFF;height:calc(100% - 50px);width:100%;margin:auto;padding:4px 0px,id=wallpaperbx,class=greyShadow greyBorder");
ThumbNailBox("onselect=Portal.WallPaper.SelectFunc,id=wallpapertn");
//break the string
//$walpaperarr = explode("~",$wallpaper);
//$wallidcond = "ID=".implode(" OR ID=",$walpaperarr);
//foreach($walpaperarr as $wallID){
  //get wallpaper details
$walldet = $dbo->Select("wallpapers_tb");
if(is_array($walldet) && $walldet[1] > 0){
  while($waldetind = $walldet[0]->fetch_assoc()){
    ThumbNail("src=../epconfig/UserImages/wallpapers/bgs/".$waldetind['wallpaper'].",title=,text=,base=../../../../,id=wall_".$waldetind['ID']);
  }
}

  
//}
            
            _ThumbNailBox();
_Box();

Box("id=removeqmedia,style=margin-right:10px;margin-top:5px;font-weight:bold;font-size:1em;float:right;width:30px;height:30px;background-color: ; cursor:pointer, title=Remove Media,class=altColor2Hover altColor, onclick=CBT.Manage.RemoveMedia()");
//echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
echo '<i class="fa fa-trash " aria-hidden="true" style="margin-top:5px; font-size:1.3em"></i>';
_Box();

Box("id=refreshqmedia,style=margin-right:10px;margin-top:5px;font-weight:bold;color:rgba(0\,0\,0\,.5);font-size:1em;float:right;width:30px;height:30px;background-color: ; cursor:pointer, title=Reload,class=altColor2Hover, onclick=CBT.Manage.RefreshMedia()");
		    //echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
			echo '<i class="fa fa-sync " aria-hidden="true" style="margin-top:5px; font-size:1.3em"></i>';
    _Box();

    
    Box("id=addnewqmedia,style=margin-right:10px;margin-top:5px;font-weight:bold;color:rgba(0\,0\,0\,.5);font-size:1em;float:right;width:30px;height:30px;background-color: ; cursor:pointer, title=Add Media,class=altColor2Hover, onclick=CBT.Manage.AddMedia()");
		    //echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
			echo '<i class="fa fa-plus " aria-hidden="true" style="margin-top:5px; font-size:1.3em"></i>';
    _Box();
    
	
		ClearFloat(); 



?>