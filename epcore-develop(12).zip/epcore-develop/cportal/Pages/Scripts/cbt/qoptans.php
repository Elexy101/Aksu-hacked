<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
//AllowUser('ptype');
//get the 
Form("groupname=ExamQOpAnsParamGrp,action=javascript:void(0),id=ExamQOpAnsParamGrpid");
TextBoxGroup("width:95%;margin:auto;font-size:1em;margin-bottom:10px");
Switcher("id=exmqtype,state=0,text=Option Type,style=width:100%;margin-top:3px,info=Objective - Subjective - Theory,ontext=Theory,offtext=Objective,defaulttext=Subjective,align=right,showstate=true,onchange=CBT.Manage.OptionChange");
_TextBoxGroup();
//TextBoxGroup("width:95%;margin:auto;font-size:0.9em");
Box('id=cbtobjbx');
$headerl = array(
    "*cbtobjind"=>"INDICATOR",
   "*cptobjopt"=>"OPTION",
  "*cbtobjans"=>array("ANSWER","YES|NO")
 );
SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=spexamoptansst,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=5,rowdelete=true,case=none",$headerl);
_Box();
Box('id=cbtsbjbx,style=display:none');
$headers = array(
    "*cbtsubjind"=>"INDICATOR",
   "*cbtsubjans"=>"ANSWER"
 );
SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=spexamoptsubj,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=5,rowdelete=true,case=none",$headers);
_Box();
Box('id=cbttheorybx,style=display:none');
TextBoxGroup("width:95%;margin:auto;font-size:1em;margin-bottom:10px");
TextBox("title=ANSWER,style=width:250px,type=multiline,id=cbttheoryans,logo=edit,text=");
_TextBoxGroup();
_Box();

//_TextBoxGroup();
_Form();



?>