<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");

//check if required data send
//cbtexmcode=COM%20101&cbtexmname=Computer%20APRECIATION&cbtexmstudy=5&cbtexmfac=4&cbtexmdept=2&cbtexmprog=2&cbtexmlvl=1&cbtexmpaysem=1
extract($_POST);

if(!isset($newschcode) || trim($newschcode) == "" || !isset($newschname) || trim($newschname) == ""){
    exit("#Invalid Entering: Both the Schedule Code and Name are Required");
}

//check if user supplied
if(!isset($UID) || (int)$UID < 1){
    exit("#Login User Identification Failed"); 
}

//check if course code already exist, for the supplied programme, level and semester
$coursecodeexist = $dbo->SelectFirstRow("cbt_schedule_tb","","SchCode = '$newschcode'",MYSQLI_ASSOC);
if(is_array($coursecodeexist))exit(json_encode(["Message"=>"Schedule Already Exist","SchID"=>$coursecodeexist['ID']]));

//add exam
$ins = $dbo->InsertID2("cbt_schedule_tb",["SchCode"=>$newschcode,"SchName"=>$newschname,"UserID"=>$UID]);

if(!is_numeric($ins))exit("#Operation Failed: ".$ins);

exit(json_encode(["Message"=>"Schedule Created Successfully","SchID"=>$ins]));




?>