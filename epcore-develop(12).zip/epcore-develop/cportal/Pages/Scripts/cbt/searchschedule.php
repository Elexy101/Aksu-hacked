<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
Box("style=font-size:1.1em");
SearchBox("id=examsearch2,title=Search Exam,onselect=Cbt.CbtSchedule.AssignExm,onunselect=,info=Search Exam by Abbr or Name,logo=search,domain=cbt_exam_tb,criteria=ExamID;ExamAbbr:Code;ExamName:Name;UserID,img=UserID,dir=Files/UserImages,ext=jpg,thumbnailtext=Name,thumbnailtitle=ExamAbbr,sticky=false,groupbox=false");
_Box();

?>
