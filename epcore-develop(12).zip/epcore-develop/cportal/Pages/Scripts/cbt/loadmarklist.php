<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

/* if(isset($_POST['exid']) && (int)$_POST['exid'] > 0 && isset($_POST['bases'])){

} */
if((int)$_POST['type'] == 0){
Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent,id=mkquestlist,multiselect=false,data-type=table,onselect=Student.RegReport.NullFunc,rowalt=true,rowfilter=true,filtertitle=Filter Exam Question,filterstyle=width:100%");
 THeader(array("#","Question"));

    $rw = 1;
    while($rw < 20){
//$sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
TRecord(array($rw,"Question Question Question ".$rw),"");
$rw++;
//TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
    }
 /*   }
} */

 _Table();
}else{
    Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent,id=mkcandlist,multiselect=false,data-type=table,onselect=Student.RegReport.NullFunc,rowalt=true,rowfilter=true,filtertitle=Filter Candidate,filterstyle=width:100%");
    THeader(array("#","Reg.No.","Name"));
   
       $rw = 1;
       while($rw < 20){
   //$sel = ((int)$PayID == (int)$rw['ID'])?'-1':'';
   TRecord(array($rw,"AK/hdjj/djjd".$rw,"Adegbayi dh
   dhhdh ".$rw),"");
   $rw++;
   //TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
       }
    /*   }
   } */
   
    _Table();
}



?>