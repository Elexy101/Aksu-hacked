<?php
// sleep(3);
// require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");

//function to map the post element with the database equivalent
function Mapper($map=[],$source){
 if(count($map) < 1)return [];
 $rtnmap = [];
 foreach($map as $dbfield=>$sourcefield){
    $rtnmap[$dbfield] = isset($source[$sourcefield])?$source[$sourcefield]:"";
 }
 return $rtnmap;
}

function ProccessTime($timestr="",$ampm = 0){
  if(trim($timestr) == "")return "00:00:00";
  $timearr = explode(":",$timestr);
  $hr = (int)$timearr[0];
  $min = isset($timearr[1])?(int)$timearr[1]:0;
  $sec = isset($timearr[2])?(int)$timearr[2]:0;
  if($ampm > 0)$hr = $hr + 12;
  if($hr > 24)$hr = 24;
    return PadTime($hr).":".PadTime($min).":".PadTime($sec);
}

function PadTime($val){
    $val = trim($val."");
    $valen = strlen($val);
    return $valen < 2?"0".$val:$val;

}

//encode user suplied date format(D/M/Y) to Mysql format (Y-m-d)
//#MysqlDateEncode
function MysqlDateEncode($userdate){
    //if empty date sent
   if(trim($userdate) == "")return NULL;
//check if range date specified
$userdatearrs = explode("-",trim($userdate));
//return $userdatearrs;
$rtndates = [];
foreach($userdatearrs as $udate){
//replace user delimiters to mysql delimeter
   $udate = str_replace(array("/","\\"," "),"-",trim($udate));
   //split the date
   $userdatearr = explode("-",$udate);
   if(count($userdatearr) < 3){
    continue;
   }else{
    $rtndates[] = $userdatearr[2]."-".$userdatearr[1]."-".$userdatearr[0];
   }
   //return $userdatearr[2]."-".$userdatearr[1]."-".$userdatearr[0];
}

if(count($rtndates) < 1)return "";
if(count($rtndates) == 1)return $rtndates[0];
if(count($rtndates) > 1)return $rtndates;
   
}

//decode Mysql date format(Y-m-d) to user format (D/M/Y)
//#MysqlDateDecode
function MysqlDateDecode($mysqldate){
    //if empty date sent
   if(trim($mysqldate) == "" || trim($mysqldate) == "0000-00-00" || is_null($mysqldate))return "";
   //split the date
   $mysqldatearr = explode("-",$mysqldate);
   if(count($mysqldatearr) < 3)return "";
   $rempartarr = explode(" ",trim($mysqldatearr[2]));
   return $rempartarr[0]."/".$mysqldatearr[1]."/".$mysqldatearr[0];
}

function BoolValue($val){
    return (int)$val < 1?'FALSE':'TRUE'; 
}
//validate
if(trim($_POST['newschname']) == "" || trim($_POST['newschcode']) == "")exit("#Invalid Schedule Name or Code Supplied");
if((int)$_POST['cbtschtotquest'] < 1)exit("#No Question Allocated");
if((int)$_POST['asignExmID'] < 1)exit("#No Exam Assigned");
if(((int)$_POST['cbtschtimehr'] + (int)$_POST['cbtschtimemin'] + (int)$_POST['cbtschtimesec']) < 1)exit("#Invalid Duration Set");
if(trim($_POST['canddatestr']) == '{}' || trim($_POST['canddatestr']) == '[]')exit("#No Candidate Added");
//check if user supplied


if(!isset($_POST['UID']) || (int)$_POST['UID'] < 1){
    exit("#Login User Identification Failed"); 
}


$durbasesarr = ["Exam","Question",'Mark'];
$directionarr = array("Forward","Backward","Both");
$sorderarr = array("Sequential","Random","Manual");
$animtypearr = array("Horizontal","Vertical","Fadding","Zooming");
$scoreformatarr = array("Percentage","Value","Point");

$map = [
    "SchName"=>$_POST['newschname'],
    "SchCode"=>$_POST['newschcode'],
    "Duration"=>(int)$_POST['cbtschtimehr'] .":". (int)$_POST['cbtschtimemin'] .":". (int)$_POST['cbtschtimesec'],
    "Unit"=>"",
    "Bases"=>$durbasesarr[(int)$_POST['cbtschdurbases']],
    "Direction"=>$directionarr[(int)$_POST['cbtschquetdirection']],
    "SOrder"=>$sorderarr[(int)$_POST['cbtschquetorder']],
    "TotQuestion"=>(int)$_POST['cbtschtotquest'],
    "TotQuestionAllocation"=>$_POST['aloc'],
    "DisControl"=>BoolValue($_POST['cbtdiscntr']),
    "DisTimmer"=>BoolValue($_POST['cbtdistimmer']),
    "DisNumbring"=>BoolValue($_POST['cbtdisnum']),
    "AllowAllQuestion"=>BoolValue($_POST['cbtdisallquset']),
    "DisRst"=>BoolValue($_POST['cbtdisrst']),
    "AnimType"=>$animtypearr[(int)$_POST['cbtschdisanimtype']],
    "AutoMark"=>BoolValue($_POST['cbtschautomark']),
    "ScoreFormat"=>$scoreformatarr[(int)$_POST['cbtschdisscore']],
    "CandidateStr"=>$_POST['canddatestr'],
    "ExmID"=>$_POST['asignExmID'],
    "UserID"=>$_POST['UID'],
    "Scope"=>$_POST["cbtschscope"]
];

if(trim($_POST['cbtschperiod']) != ""){
    $examperiod = MysqlDateEncode($_POST['cbtschperiod']);
    $examperiod = !is_array($examperiod)?[$examperiod,$examperiod]:$examperiod;
    $map['StartDate'] = $examperiod[0];
    $map['EndDate'] = $examperiod[1];
 }
 
 if(trim($_POST['cbtschstarttime']) != ""){
    $map['StartTime'] = ProccessTime($_POST['cbtschstarttime'],(int)$_POST['cbtschstarttimeap']);
 }

 if(trim($_POST['cbtschendtime']) != ""){
    $map['EndTime'] = ProccessTime($_POST['cbtschendtime'],(int)$_POST['cbtschendtimeap']);
 }



 if((int)$_POST['SchID'] == 0){
     //insert
     $inst = $dbo->InsertID2("cbt_schedule_tb",$map);
     if(is_numeric($inst)){
         exit($inst."");
     }else{
         exit("#Saving Schedule Failed");
     }
 }else{
    $inst = $dbo->Update("cbt_schedule_tb",$map,"ID=".$_POST['SchID']);
    if(is_array($inst)){
        exit($_POST['SchID']."");
    }else{
        exit("#updating Schedule Failed");
    }
 }


/*cbtschassignexambtn=&cbtschedulesearchsearchtxt=&cbtschedulesearch_crtlb=&cbtschedulesearch_crimgl=&newschcode=rre&newschname=fggf&cbtschscope=0&cbtschtimehr=1&cbtschtimemin=0&cbtschtimesec=0&cbtschdurbases=0&cbtschperiod=3/5/2021%20-%2028/5/2021&cbtschstarttime=2%3A45&cbtschstarttimeap=0&cbtschendtime=10%3A30&cbtschendtimeap=1&cbtschquetdirection=2&cbtschquetorder=0&cbtschautomark=1&cbtschtotquest=5&cbtdiscntr=1&cbtdistimmer=1&cbtdisnum=1&cbtdisallquset=1&cbtdisrst=1&cbtschdisanimtype=2&cbtschdisscore=0&asignExmID=1&aloc=%5B2%2C1%2C1%2C1%2C0%5D&canddatestr=%7B%2208100187574d%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22ADEBAYO%20SALAMI%20%20(08100187574D)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%2208100187574d%22%2C%22AccessCode%22%3A%22%22%2C%22Phone%22%3A%2208100187574%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22ADEBAYO%20SALAMI%20%22%7D%2C%22AK2019%5C%2FNAS%5C%2FBOT%5C%2F003%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22KEJEMILOBI%20ABAYOMI%20%20(AK2019%5C%2FNAS%5C%2FBOT%5C%2F003)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22AK2019%5C%2FNAS%5C%2FBOT%5C%2F003%22%2C%22AccessCode%22%3A%22myschool%22%2C%22Phone%22%3A%2208066096978%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22KEJEMILOBI%20ABAYOMI%20%22%7D%2C%22SH256710%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22SHOLA%20BADAMOS%20%20(SH256710)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22SH256710%22%2C%22AccessCode%22%3A%22myschool%22%2C%22Phone%22%3A%2207022667788%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22SHOLA%20BADAMOS%20%22%7D%2C%22AD917401%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22ADE%20BAYO%20%20(AD917401)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22AD917401%22%2C%22AccessCode%22%3A%22myschool%22%2C%22Phone%22%3A%22%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22ADE%20BAYO%20%22%7D%2C%22AJ284258%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22AJAYI%20BAMIDELE%20%20(AJ284258)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22AJ284258%22%2C%22AccessCode%22%3A%22lkbddviz%22%2C%22Phone%22%3A%22%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22AJAYI%20BAMIDELE%20%22%7D%2C%22YO586600%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FStudent%5C%2FYO586600.jpg%22%2C%22Text1%22%3A%22YOMI%20BAYO%20%20(YO586600)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22YO586600%22%2C%22AccessCode%22%3A%22myschool%22%2C%22Phone%22%3A%22782982929%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22YOMI%20BAYO%20%22%7D%2C%22AD120144%22%3A%7B%22Image%22%3A%22Files%5C%2FUserImages%5C%2FGeneral%5C%2Fimage.png%22%2C%22Text1%22%3A%22ADEBAYO%20DAVID%20%20(AD120144)%22%2C%22Text2%22%3A%22Undergraduate%20%5C%2F%20Botany%20%22%2C%22Text3%22%3A%22100%20Level%20(B)%22%2C%22key%22%3A%22AD120144%22%2C%22AccessCode%22%3A%22myschool%22%2C%22Phone%22%3A%2208077886655%22%2C%22Level%22%3A%22100%20Level%22%2C%22Study%22%3A%22Undergraduate%22%2C%22Prog%22%3A%22Botany%20%22%2C%22Name%22%3A%22ADEBAYO%20DAVID%20%22%7D%7D&SchID=0 */
// 



?>