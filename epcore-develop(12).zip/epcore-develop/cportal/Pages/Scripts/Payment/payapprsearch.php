<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
function Error($title,$text){
  Box("class=defaultTabText");
  Box("style=color:red");Icon("exclamation-triangle fa-3x");_Box();
  Box();echo $title;_Box();  
  Box();echo $text;_Box();  
_Box();
}
AllowUser("voffline");
require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request
//Get the UserID
$UID = $_POST['UID'];
$limit = $_POST['limit'];
$val = $dbo->SqlSafe($_POST['val']);
         $deptCond = "(1=1)";
         $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=$UID");
          if(isset($staffDet)){
            $Depts = trim($staffDet['DeptIDs']);
            if($Depts != ""){//"ProgID":"10"
              //$deptCond = "(st.ProgID = ".str_replace("~"," OR st.ProgID = ",$Depts).")";
              $deptCond = "(od.Info LIKE '%\"ProgID\":\"".str_replace("~","\" OR od.Info LIKE '%\"ProgID\":\"",$Depts)."\")";
            }
          }
          //f.FacName,d.DeptName,p.ProgName
          /* $fields = "od.*,CONCAT_WS(' ',st.SurName,st.FirstName,st.OtherNames) as StudName, f.FacID,d.DeptID,s.SesName,f.FacName,d.DeptName,p.ProgName,l.Name as LvlName,se.Sem as Semester,it.ItemName, sy.Name as StudyName,FORMAT(od.Amt,2) as FAmt, IF(od.SemPart = 1,'PART',IF(od.SemPart = 2,'COMPLETE','FULL')) as PayPol, DATE_FORMAT(od.RegDate, '%M %d %Y') as ODate"; */
          if(trim($val) != ""){
              $deptCond .= " AND ((od.Info LIKE '%$val%' OR l.Name LIKE '%$val%' OR IF(od.Sem = 1,'FIRST',IF(od.Sem = 2,'SECOND','FULL')) LIKE '%$val%' OR s.SesName LIKE '%$val%' OR od.ReceiptNum LIKE '%$val%' OR od.RegNo LIKE '%$val%' OR sy.Name LIKE '%$val%' OR IF(od.SemPart = 1,'PART',IF(od.SemPart = 2,'COMPLETE','FULL')) LIKE '%$val%' OR DATE_FORMAT(od.RegDate, '%M %d %Y') LIKE '%$val%' OR FORMAT(od.Amt,2) LIKE '%$val%')";
              //if has space
          $valarr = explode(" ",$val);
          if(count($valarr) > 1){
            $deptCond .= " OR (";
            foreach($valarr as $indval){
              $deptCond .= " (od.Info LIKE '%$indval%' OR l.Name LIKE '%$indval%' OR IF(od.Sem = 1,'FIRST',IF(od.Sem = 2,'SECOND','FULL')) LIKE '%$val%' OR s.SesName LIKE '%$indval%' OR od.ReceiptNum LIKE '%$indval%' OR od.RegNo LIKE '%$indval%' OR sy.Name LIKE '%$indval%' OR IF(od.SemPart = 1,'PART',IF(od.SemPart = 2,'COMPLETE','FULL')) LIKE '%$indval%' OR DATE_FORMAT(od.RegDate, '%M %d %Y') LIKE '%$indval%' OR FORMAT(od.Amt,2) LIKE '%$indval%') AND";  
            }
            $deptCond = rtrim($deptCond,"AND");
            $deptCond .= " )";
          }
         //exit($deptCond);
          $deptCond .=")";
          }

          
         // $limit = round((0.0816 * (5000 - 100)) + 100);
          //print_r($_POST);
          $filter = $_POST['filter'];
          LoadPaymentAppr($deptCond,$limit,$val,$filter);
         
          

?>