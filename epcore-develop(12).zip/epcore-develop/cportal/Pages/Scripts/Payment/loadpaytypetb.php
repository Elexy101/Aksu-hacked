<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".urldecode($_POST['SubDir']);
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
$PayID = $_POST['sel'];
Table("rowselect=false,style=width:calc(100% - 10px);font-size:0.8em;margin:auto;text-align:left;margin-top:10px,id=paytbpaym,multiselect=false,data-type=table,onselect=Payment.PaymentType.LoadPayType,rowalt=true,rowfilter=true,filtertitle=FILTER PAYMENT TYPE");
   //THeader(array("PAYMENT TYPE"),"style=text-align:left");
  //$PayID = $allset['PayID'];
  $allitem = $dbo->Select("item_tb");
  if(is_array($allitem)){
     if($allitem[1] > 0){
      while($rw = $allitem[0]->fetch_assoc()){
  $sel = ((int)$PayID == (int)$rw['ID'])?',selected=-1':'';
  TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID']."".$sel);
  //TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
      }
     }
  }
  //  THeader(array("PAYMENT ITEM"),"style=text-align:left");
  // TRecord(array("Accptance Fee"),"style=text-align:left");
  // TRecord(array("School Fee"),"style=text-align:left");
  // TRecord(array("Convocation Fee"),"style=text-align:left");
  // TRecord(array("PUTME Fee"),"style=text-align:left");
   _Table();

?>