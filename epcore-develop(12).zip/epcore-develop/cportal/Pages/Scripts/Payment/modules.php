<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".urldecode($_POST['SubDir']);
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

 if(!isset($_POST['DB']))echo "INVALID PARAMETER";
 $PayID = $_POST['PayID'];
 //get all from database
 $controltbarr = [1=>"putme","form_tb","schoolpayment_tb"];
 $controltxtarr = [1=>["Entrance Controls","Esetting","Entrance Settings"],["Registration Controls","SSetting","Registration Settings"],["School Payments Controls","ssettings","School Payment Settings"]];
 //Get the payment item details
$PDet = NULL;
if((int)$PayID > 0)$PDet = $dbo->SelectFirstRow("item_tb","","ID=".$PayID);
 //get the controls
 $all = $dbo->Select($controltbarr[$_POST['DB']]);
 Table("class=ep-animate-opacity,rowselect=true,style=width:calc(100% - 16px);font-size:0.8em;margin:auto;text-align:left;margin-top:8px,id=modulecntrtb,multiselect=false,data-type=table,onselect=Payment.PaymentType.LoadPayTypeByModule,rowalt=true,rowfilter=false,filtertitle=FILTER MODULE CONTROLS,filterstyle=width:calc(100% - 16px);margin:auto;margin-top:8px");
 if(is_array($all) && $all[1] > 0){
    THeader(array("TITLE","STATUS","PART PAY","PART SHARE"));
     while($cntr = $all[0]->fetch_assoc()){ //loop through all created control record
$sel = (is_array($PDet) && $controltbarr[$_POST['DB']] == $PDet['ControlTable'] && $cntr['ID'] == $PDet['ControlTableID'])?",selected=-1":"";
$partsh = "NONE";
if($cntr['PartPay'] == "TRUE" || $cntr['PartPay'] == "STRICT")$partsh = $cntr['PartPayShare'] == "HALF"?"TWO TIMES":"FOUR TIMES";
if($cntr['PartPay'] == "TRUE" || $cntr['PartPay'] == "STRICT"){
   $stdis = $cntr['PartPay'] == "STRICT"?"ENABLED (STRICT)":"ENABLED";
}else{
   $stdis = "DISABLED";
}

        TRecord(array($cntr['Title'],$cntr['Status'],$stdis,$partsh),"style=text-align:left,id=".$cntr['ID'].$sel);
        
     }
 }
 _Table();
 /* TextBoxGroup("width:calc(100% - 16px);margin:auto;border-top-color:transparent");
 Note();
 echo '<strong style="font-weight:bold">'.$controltxtarr[$_POST['DB']][0]."</strong> are Managed in ".'<a href="javascript:Page.OpenByTabName(\''.$controltxtarr[$_POST['DB']][1].'\')">'.$controltxtarr[$_POST['DB']][2].'</a>';
_Note();
_TextBoxGroup(); */
?>