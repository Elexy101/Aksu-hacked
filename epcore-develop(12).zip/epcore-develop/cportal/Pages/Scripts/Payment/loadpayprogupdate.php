<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

//get the Ref
function Error($mess){
  Note();
echo $mess;
  _Note();
  exit();
}

$sch = GetSchool('SchStrucContr');
$schStruc = json_decode($sch['SchStrucContr'],true);

if(!isset($_POST['Ref']))Error("Payment Reference NOT FOUND");
$Ref = $_POST['Ref'];
//get the paymen details and student details
$paystuddet = $dbo->RunQuery("SELECT Info,RegNo,ProgID FROM order_tb WHERE TransNum = '".$dbo->SqlSafe($Ref)."'");
if(!is_array($paystuddet))Error("Error Reading Payment Record");
if($paystuddet[1] < 1)Error("Payment Record NOT FOUND");
$paydet = $paystuddet[0]->fetch_assoc();
$info = (isset($paydet['Info']) || trim($paydet['Info']) != "")?json_decode($paydet['Info'],true):[];
Box("style=overflow:auto,class=zoomInShort animated faster asignpayprog");
Box("style=margin-bottom:10px,class=asignpayproghead");
Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;margin-bottom:10px;border-top-color:transparent;text-transform:uppercase,id=paytblldet,multiselect=false,data-type=table,rowalt=true");
  // $info = json_decode($paydet['Info'],true);
  THeader(["NAME","REG. NO.","PAY. REFERENCE"]);
  TRecord([isset($info['Name'])?$info['Name']:"-",$paydet['RegNo'],$Ref]);
  /* TRecord(['REG. NO:',$paydet['RegNo']]);
  TRecord(['Ref:',$Ref]); */
  _Table();
_Box();
Box("class=asignpayprogfrom");
// if(isset($paydet['Info']) || trim($paydet['Info']) != ""){
  Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;margin-bottom:10px;border-top-color:transparent;text-transform:uppercase,id=paytblldet,multiselect=false,data-type=table,rowalt=true");
  THeader(["CHANGE FROM"],"cspan=d1:2");
  if(is_array($info) && count($info) > 0 && (int)$paydet['ProgID'] > 0){
    if(isset($info["StudyID"]) && $schStruc['StudyID']['SilentMode'] == false){
     //get the study name
    //  $StudyN = $dbo->SelectFirstRow("study_tb s,fac_tb f,dept_tb d,programme_tb p","s.Name","ID=".$info["StudyID"]);
     $StudyN = $dbo->SelectFirstRow("study_tb s,fac_tb f,dept_tb d,programme_tb p","s.Name","s.ID=f.StudyID AND d.FacID=f.FacID AND p.DeptID = d.DeptID AND p.ProgID=".$paydet['ProgID']);
     $StudyName = is_array($StudyN)?$StudyN['Name']:"-";
     if($schStruc['StudyID']['SilentMode'] == false){TRecord([strtoupper($schStruc['StudyID']['Name']).":",$StudyName]);}
    }
    
    if($schStruc['FacID']['SilentMode'] == false){TRecord([strtoupper($schStruc['FacID']['Name']).":",isset($info['FacName'])?$info['FacName']:"-"]);}
    if($schStruc['DeptID']['SilentMode'] == false){TRecord([strtoupper($schStruc['DeptID']['Name']).":",isset($info['DeptName'])?$info['DeptName']:"-"]);}
    if($schStruc['ProgID']['SilentMode'] == false){TRecord([strtoupper($schStruc['ProgID']['Name']).":",isset($info['ProgName'])?$info['ProgName']:"-"]);}
  
  
      /* {"Name":"Adegoke John bunmi","ProgID":"23","ProgName":"Botany ","DeptID":"22","DeptName":"Biological Science","FacID":"1","FacName":"Sciences","StartSes":"10","ModeOfEntry":"1","StudyID":"5","RegID":"1","ClassName":"A","LevelName":"400","PayName":"IMP STUDENT WALLET"} */
  }else{
    //get the payment programme
    TRecord(["Student's Payment Academic Details Not Assigned"],"cspan=d1:2,style=color:red");
  }
  _Table();
// }
_Box();
Box("class=asignpayprogto");
Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent;text-transform:uppercase,id=paytblldet,multiselect=false,data-type=table,rowalt=true");
THeader(["CHANGE TO"],"cspan=d1:2");
$studDet = GetBasicInfo($paydet['RegNo']);
    if(is_array($studDet)){
      if($schStruc['StudyID']['SilentMode'] == false){TRecord([strtoupper($schStruc['StudyID']['Name']).":",$studDet['StudyName']]);}
      if($schStruc['FacID']['SilentMode'] == false){TRecord([strtoupper($schStruc['FacID']['Name']).":",$studDet['Fac']]);}
      if($schStruc['DeptID']['SilentMode'] == false){TRecord([strtoupper($schStruc['DeptID']['Name']).":",$studDet['Dept']]);}
      if($schStruc['ProgID']['SilentMode'] == false){TRecord([strtoupper($schStruc['ProgID']['Name']).":",$studDet['Prog']]);}
    }else{
    
      TRecord(["Reading Student Current Academic Details Failed"],"cspan=d1:2,style=color:red");
    }

_Table();

_Box();
echo '<div style="clear:left"></div>';
_Box();


?>