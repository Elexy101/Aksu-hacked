<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
 function DisablePayType($NewPayID, $OldPayID = 0){
     global $dbo;
     if($OldPayID > 0)$dbo->Update("item_tb",["studType"=>"r"],"ID=".$OldPayID);
     $upd = $dbo->Update("item_tb",["studType"=>"w"],"ID=".$NewPayID);

 }
 //check priv
 AllowUser("wallet");
extract($_POST);
if(!isset($MenuID) || (int)$MenuID == 0)exit("#No Portal Wallet Menu Selected");
 $AmtsObj = $dbo->DataArray($Amts);
 $newAmts = [];
$maxrow = (int)$AmtsObj['MaxDataRow'];
if($maxrow < 1)exit("#No Wallet Payable Amount Set");
//$MinBal
for($c=1;$c <= $maxrow; $c++){
    if(trim($AmtsObj[$c."_1"]) == "" || trim($AmtsObj[$c."_deleted"]) == "true")continue;
   $amt = (float)str_replace(",","",$AmtsObj[$c."_1"]);
   if(!in_array($amt,$newAmts) && $amt > 0)$newAmts[]=$amt;
}

//get the control details
$wcntr = $dbo->SelectFirstRow("walletcontrol_tb","","1=1 LIMIT 1");
if(is_array($wcntr)){
    //perform update
    $upd = $dbo->Update("walletcontrol_tb",["Amts"=>json_encode($newAmts),"PayID"=>$PayID,"MinBalance"=>$MinBal,"MenuID"=>$MenuID,"DynamicAmt"=>$DynamicAmt],"ID=".$wcntr['ID']);
    if(is_array($upd)){
        if($wcntr['PayID'] != $PayID){
            DisablePayType((int)$PayID,(int)$wcntr['PayID']);
        }
        exit("*Wallet Settings Saved Successfully");
    }else{
        exit("#Saving Wallet Settings Failed");
    }
}else{
    $insert = $dbo->InsertID2("walletcontrol_tb",["Amts"=>json_encode($newAmts),"PayID"=>$PayID,"MinBalance"=>$MinBal,"MenuID"=>$MenuID,"DynamicAmt"=>$DynamicAmt]);
    if(is_numeric($insert)){
        DisablePayType((int)$PayID);
        exit("*Wallet Settings Saved Successfully");
    }else{
        exit("#Saving Wallet Settings Failed");
    }
}

//echo implode(",",$newAmts);
?>