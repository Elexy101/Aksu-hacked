<?php
$vialwalletTxt = " (Wallet Inclusive)";
//form the report query
  function ReportQuery(){
      global $searchstr;
      global $ses;
      global $datefilter;
      global $lmt;
      global $loadwallet;
      global $vialwalletTxt;
      $loadwallet = (int)$loadwallet;
      $cond = "";
      if($loadwallet == 0){//exclude
        $cond = " AND p.FromWallet=0";
        $vialwalletTxt = " (Wallet Exclusive)";
      }else if($loadwallet == 2){ //wallet only
        $cond = " AND p.FromWallet=1";
        $vialwalletTxt = " (Wallet Only)";
      }
    $searchcond = ($searchstr != "")?" WHERE i.ItemName LIKE '%$searchstr%'":"";
    $query = "SELECT  COUNT(p.PayID) as Payments, SUM(p.Amt) as Sums FROM  payhistory_tb p WHERE 1=1 $ses $datefilter $cond";

    $querylim = "SELECT SQL_CALC_FOUND_ROWS i.ItemName, COUNT(p.PayID) as Payments, SUM(p.Amt) as Sums,i.ID FROM item_tb i LEFT JOIN payhistory_tb p ON i.ID = p.PayID $ses $datefilter $cond"."$searchcond GROUP BY i.ID"." LIMIT ".$lmt;
    return [$query,$querylim];
  }

  //Form the spreadsheet records
  function FormRecord(){
    global $searchstr;
    global $totstat;
    global $totamt;
    global $rec;
    global $BackPOST;
    global $dbo;
    global $dump;
    $itemName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
    $totstat += (int)$rec[1];
    $totamt += (float)$rec[2];
  $recarr = array($itemName,$rec[1],number_format($rec[2], 2, '.', ','));
  $_POST['itemID'] = $rec[3];
  $_POST['reportType'] = "paytypeitem";
  $_POST['pg'] = 1;
  //$BackPOST['displaytext'] = $_POST['displaytext'];
  $_POST['displaytext'] = strtoupper($rec[0])." PAYMENT REPORT";
  $datastr = $dbo->DataString($_POST);

  $recarr["logo"] =  "*chevron-right";
$recarr["info"] =  $_POST['displaytext'];
$recarr["Action"] =  "Payment.PaymentReport.PerformLoad('$datastr')";

if(isset($BackPOST['back'])){unset($BackPOST['back']);}
return $recarr;
  }


  //Form the spread sheet fields
  function Fileds(){
    return array("*ItemDesc"=>"ITEM DESCRIPTION",
    "*Stat"=>"PAYMENT",
     "*Amt"=>"AMOUNT(N)"
    );
  }

  //form the sumary fields and data
  function Summary(){
      global $from;
      global $to;
      global $rses;
      global $chaneldis;
      global $totpays;
      global $totAmts;
      global $vialwalletTxt;
    $arrhed = ($from != "" && $to != "")?array("REPORT SESSION","CHANNEL","DATE FILTER","TOTAL PAYMENT","OVERALL AMOUNT"):array("REPORT SESSION","CHANNEL","TOTAL PAYMENT","OVERALL AMOUNT");
    $fromarr = explode("-",$from);
    $toarr = explode("-",$to);
    $sesName = (int)$rses == 0?"ANY":SessionName($rses);
      // THeader($arrhed,"style=text-align:center,rspan=d1:2");
       $arrRec = ($from != "" && $to != "")?array("<strong>".$sesName."</strong>",$chaneldis,date("j-M-Y",mktime(0,0,0,$fromarr[1],$fromarr[2],$fromarr[0]))." "._Icon("arrow-right")." ".date("j-M-Y",mktime(0,0,0,$toarr[1],$toarr[2],$toarr[0])),"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>".$totAmts."</strong>"):array("<strong>".$sesName."</strong>",$chaneldis,"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>N ".$totAmts."</strong>");
       return [$arrhed,$arrRec];
  }


?>