<?php
$vialwalletTxt = " (Wallet Inclusive)";
//form the report query
  function ReportQuery(){
      global $searchstr;
      global $ses;
      global $datefilter;
      global $lmt;
      global $loadwallet;
      global $vialwalletTxt;
      $loadwallet = (int)$loadwallet;
      $cond = "";
      if($loadwallet == 0){//exclude
        $cond = " AND p.FromWallet=0";
        $vialwalletTxt = " (Wallet Exclusive)";
      }else if($loadwallet == 2){ //wallet only
        $cond = " AND p.FromWallet=1";
        $vialwalletTxt = " (Wallet Only)";
      }

      $query = "SELECT  COUNT(p.PayID) as Payments, SUM(p.Amt) as Sums FROM payhistory_tb p WHERE 1=1 $ses $datefilter $cond ";

      //$searchcond = ($searchstr != "")?" WHERE f.FacName LIKE '%$searchstr%'":"";
      $searchcond = ($searchstr != "")?" WHERE CONCAT(f.FacName,' (',s.Name,')') LIKE '%$searchstr%'":"";
     // $querylim = "SELECT SQL_CALC_FOUND_ROWS CONCAT(f.FacName,'(',s.Name,')'), f.FacID, COUNT(p.PayID) as Payments, SUM(p.Amt) as Sum FROM fac_tb f LEFT JOIN payhistory_tb p ON p.Info LIKE CONCAT('%\"FacID\":\"',f.FacID,'\"%') $ses $datefilter "."$searchcond GROUP BY f.FacID LIMIT ".$lmt;
      $querylim = "SELECT SQL_CALC_FOUND_ROWS CONCAT(f.FacName,' (',s.Name,')'), f.FacID, COUNT(p.PayID) as Payments, SUM(p.Amt) as Sum FROM fac_tb f LEFT JOIN study_tb s ON s.ID = f.StudyID LEFT JOIN payhistory_tb p ON p.Info LIKE CONCAT('%\"FacID\":\"',f.FacID,'\"%') $ses $datefilter "."$searchcond $cond GROUP BY f.FacID LIMIT ".$lmt;
    return [$query,$querylim];
  }

  //Form the spreadsheet records
  function FormRecord(){
    global $searchstr;
    global $totstat;
    global $totamt;
    global $rec;
    global $BackPOST;
    global $dbo;
    global $dump;
   //breakdown info
                        //echo $rec['Info'];
                        $totstat += (int)$rec[1];
                    $totamt += (float)$rec[2];
                     $facName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
                  $recarr = array($facName,$rec['Payments'],number_format($rec['Sum'], 2, '.', ','));
                  $_POST['facID'] = $rec['FacID'];
                  $_POST['reportType'] = "paytypeprog";
                  $_POST['pg'] = 1;
                  //$BackPOST['CurrentDisplayText'] = $_POST['displaytext'];
                   $_POST['displaytext'] = strtoupper($rec[0])." FACULTY/SCHOOL PAYMENT REPORT";
                  $datastr = $dbo->DataString($_POST);
                  
                  $recarr["logo"] =  "*chevron-right";
				$recarr["info"] =  $_POST['displaytext'];
				$recarr["Action"] =  "Payment.PaymentReport.PerformLoad('$datastr')";
               // $dump[] = $recarr;
                if(isset($BackPOST['back'])){unset($BackPOST['back']);}
return $recarr;
  }


  //Form the spread sheet fields
  function Fileds(){
    return array("*ItemDesc"=>"FACULTY/SCHOOL",
           "*Stat"=>"PAYMENT",
            "*Amt"=>"AMOUNT(N)"
           );
  }

  //form the sumary fields and data
  function Summary(){
      global $from;
      global $to;
      global $rses;
      global $chaneldis;
      global $totpays;
      global $totAmts;
      global $vialwalletTxt;
    $arrhed = ($from != "" && $to != "")?array("REPORT SESSION","CHANNEL","DATE FILTER","TOTAL PAYMENT","OVERALL AMOUNT"):array("REPORT SESSION","CHANNEL","TOTAL PAYMENT","OVERALL AMOUNT");
    $fromarr = explode("-",$from);
    $toarr = explode("-",$to);
    $sesName = (int)$rses == 0?"ANY":SessionName($rses);
      // THeader($arrhed,"style=text-align:center,rspan=d1:2");
       $arrRec = ($from != "" && $to != "")?array("<strong>".$sesName."</strong>",$chaneldis,date("j-M-Y",mktime(0,0,0,$fromarr[1],$fromarr[2],$fromarr[0]))." "._Icon("arrow-right")." ".date("j-M-Y",mktime(0,0,0,$toarr[1],$toarr[2],$toarr[0])),"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>".$totAmts."</strong>"):array("<strong>".$sesName."</strong>",$chaneldis,"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>N ".$totAmts."</strong>");
       return [$arrhed,$arrRec];
  }


?>