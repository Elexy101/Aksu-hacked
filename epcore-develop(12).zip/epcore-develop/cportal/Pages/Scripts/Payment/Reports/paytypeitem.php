<?php
$vialwalletTxt = " (Wallet Inclusive)";
//form the report query
  function ReportQuery(){
      global $searchstr;
      global $ses;
      global $datefilter;
      global $lmt;
      global $itemID;
      global $loadwallet;
      global $vialwalletTxt;
      $loadwallet = (int)$loadwallet;
      $cond = "";
      if($loadwallet == 0){//exclude
        $cond = " AND p.FromWallet=0";
        $vialwalletTxt = " (Wallet Exclusive)";
      }else if($loadwallet == 2){ //wallet only
        $cond = " AND p.FromWallet=1";
        $vialwalletTxt = " (Wallet Only)";
      }
      $searchcond = ($searchstr != "")?" AND (p.Info LIKE '%".$searchstr."%' OR p.TransID LIKE '%$searchstr%' OR p.Amt LIKE '%$searchstr%' OR DATE_FORMAT(p.PayDate,'%d/%m/%Y') = '$searchstr' OR p.RegNo LIKE '%$searchstr%' OR p.CollectBank LIKE '%$searchstr%' OR IF(LCASE(p.Bank) = 'manual pay','OFFLINE','ONLINE') LIKE '%$searchstr%')":"";
      //$itemID = 2;
    $query = "SELECT COUNT(p.PayID) as Payments, SUM(p.Amt) as Sums FROM payhistory_tb p WHERE p.PayID = $itemID $ses $datefilter $cond ORDER BY p.PayDate DESC,p.ID DESC";
    $querylim = "SELECT SQL_CALC_FOUND_ROWS p.RegNo, p.Info, p.Amt, DATE_FORMAT(p.PayDate,'%d/%m/%Y') as PayDate,p.CollectBank, p.itemNum, p.PayID, IF(LCASE(p.Bank) = 'manual pay','OFFLINE','ONLINE') as Channel,p.Lvl FROM payhistory_tb p WHERE p.PayID = $itemID  $ses $datefilter $searchcond $cond ORDER BY p.PayDate DESC,p.ID DESC"." LIMIT ".$lmt;
    return [$query,$querylim];
  }

  //Form the spreadsheet records
  function FormRecord(){
    global $searchstr;
    global $totstat;
    global $totamt;
    global $rec;
    global $BackPOST;
    global $dbo;
    global $dump;
    global $schStruc;
   //breakdown info
                        //echo $rec['Info'];
                        $rinfo = json_decode($rec['Info']);
                        $rec['Name'] = $rinfo->Name;
                        if($schStruc['ProgID']['SilentMode'] == false){
                          $rec['DeptName'] = $rinfo->ProgName;
                      }
                      if($schStruc['FacID']['SilentMode'] == false){
                      $rec['FacName'] = $rinfo->FacName;
                      }

                      if(isset($rinfo->LevelName)){
                        $rec['LevelName'] = $rinfo->LevelName;
                      }else{
                        //get the StudyID
                        if(isset($rinfo->StudyID)){
                          $StudyID = $rinfo->StudyID;
                        }else{
                          //get the student study
                          $StudyID = GetStudStudyID($rec['RegNo']);
                        }
                        //get student payment level
                        $rec['LevelName'] = LevelName($rec['Lvl'], $StudyID);
                      }

                      if(isset($rinfo->ClassName)){
                        $rec['ClassName'] = $rinfo->ClassName;
                      }else{
                        //get student className
                        $classdet = StudClass($rec['RegNo']);
                        $rec['ClassName'] = $classdet['Name']; 
                      }
                       /*  $rec['DeptName'] = $rinfo->DeptName;
                        $rec['FacName'] = $rinfo->FacName; */
                        
                        $rec['Bank']  =  $rec['CollectBank'];
                        

                        //;$rinfo = $rec['Amt'];
                     $totstat += 1;
                     $totamt += (float)$rec['Amt'];
                     $amtstr = $rec['Amt']."";
                     $rec[3] = number_format($rec['Amt'], 2, '.', ',');
                     if($searchstr == $amtstr){
                       $searchstr = $rec[3];
                     }
                     
                     foreach($rec as &$erec){
                         $erec = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($erec));
                     }
                     
                     $BackPOST['reportType'] = 'paytypesumrpt';
                     $BackPOST['back'] = true;
                     //$dt = new DateTime($rec[4]);
                     $recarr = array($rec[0],$rec['Name'],$rec['LevelName']."(".$rec['ClassName'].")",$rec[3],$rec['PayDate']);
                     if($schStruc['FacID']['SilentMode'] == false){
                      $recarr[] = $rec['FacName'];
                    }
                    if($schStruc['ProgID']['SilentMode'] == false){
                      $recarr[] = $rec['DeptName'];
                  }
                  
                  $recarr[] = $rec['Bank'];
                     if((int)$offline == 1 && (int)$online == 1){
                        $recarr[] = $rec['Channel'];
                      }
                     $recarr["logo"] =  "*print";
				$recarr["info"] =  "Print";
				$recarr["Action"] =  "Payment.PaymentReport.PrintRc('{$rec['itemNum']}')";
return $recarr;
  }


  //Form the spread sheet fields
  function Fileds(){
    global $schStruc;
    $header=array("*RegID"=>"REG. ID",
           "*PName"=>"PAYEE NAME",
           "*CName"=>"CLASS",
            "*Amt"=>"AMOUNT(N)",
            "*PayDate"=>"DATE" );
           if($schStruc['FacID']['SilentMode'] == false){
            $header["*FacName"] = strtoupper($schStruc['FacID']['Name']);
          }
           if($schStruc['ProgID']['SilentMode'] == false){
            $header["*DeptName"] = strtoupper($schStruc['ProgID']['Name']);
        }
        
        $header["*RBank"] = "RECEIVING BANK";
           if((int)$offline == 1 && (int)$online == 1){
            $header['*PChannel'] = "CHANNEL";
           }
           return $header;
  }

  //form the sumary fields and data
  function Summary(){
      global $from;
      global $to;
      global $rses;
      global $chaneldis;
      global $totpays;
      global $totAmts;
      global $vialwalletTxt;
    $arrhed = ($from != "" && $to != "")?array("REPORT SESSION","CHANNEL","DATE FILTER","TOTAL PAYMENT","OVERALL AMOUNT"):array("REPORT SESSION","CHANNEL","TOTAL PAYMENT","OVERALL AMOUNT");
    $fromarr = explode("-",$from);
    $toarr = explode("-",$to);
    $sesName = (int)$rses == 0?"ANY":SessionName($rses);
      // THeader($arrhed,"style=text-align:center,rspan=d1:2");
       $arrRec = ($from != "" && $to != "")?array("<strong>".$sesName."</strong>",$chaneldis,date("j-M-Y",mktime(0,0,0,$fromarr[1],$fromarr[2],$fromarr[0]))." "._Icon("arrow-right")." ".date("j-M-Y",mktime(0,0,0,$toarr[1],$toarr[2],$toarr[0])),"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>".$totAmts."</strong>"):array("<strong>".$sesName."</strong>",$chaneldis,"<strong>".$totpays.$vialwalletTxt."</strong>","<strong>N ".$totAmts."</strong>");
       return [$arrhed,$arrRec];
  }


?>