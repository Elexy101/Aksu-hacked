<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
// $sch = $dbo->SelectFirstRow("school_tb");
//require("../../../../general/getinfo.php");
//AllowUser('ptype');
//get the 
sleep(2);
function MessageBack($str,$exitt = true){
    $str = EscapeString($str);
Box("style=color:red;width:100%;text-align:center; margin-top:20px;");
    Box("style=font-size:2em");Icon("exclamation-triangle");_Box();
    Text("text=$str,style=color:inherit;text-transform:uppercase;font-size:1.0em");
_Box();
if($exitt){
    exit();
}
}
if(!isset($_POST['Ref'])){
Form("groupname=ReqByRefGrp,action=javascript:void(0),id=ReqByRefGrpid");
TextBoxGroup("width:95%;margin:auto;font-size:0.9em;margin-bottom:10px");
TextBox("title=Payment Reference,style=width:250px,id=reqpayref,logo=credit-card,textchange=Payment.ManualPay.LoadDetailsByRef");
_TextBoxGroup();
Box("id=payreqdetailsBx");


_Box();

_Form();
}else{
    //get the details
    $ref = $_POST['Ref'];
    $refdet = $dbo->SelectFirstRow("order_tb","","transNum='$ref'",MYSQLI_ASSOC);
    if(is_array($refdet)){
        echo json_encode($refdet);
    }else{
         MessageBack("Invalid Reference Number");;
    }
    //get from database

}

/*  */



?>