<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
 //check priv
 AllowUser("ptype");

 extract($_POST);

//exit();
$rule = ProccessRuleSet();
echo $rule;

?>