<?php 

include("../../AppTemp/objects.php");

include("../../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../UserScript/Custom/custom.php");

include("../../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request
//exit('aa');

if(isset($_POST['RegNo']) && isset($_POST['PayId'])){
	$AdminArr = array();
	//exit('aaaa');
$RegID = isset($_POST["RegID"]) && (int)$_POST["RegID"] > 0?(int)$_POST["RegID"]:1; //the putme reg type that is calling the script, sent from the sub menu param in db (putme table ID field)
$RegNo = $_POST['RegNo'];
$PayID = $_POST['PayId'];
$Sem = $_POST['Sem'];
$pre = $_POST['pre'];
$lvl = $_POST['lvl'];
$sempart = isset($_POST['sempart'])?$_POST['sempart']:3;
$loadlvl = isset($_POST['loadlvl'])?$_POST['loadlvl']:'null';
define("ERR", '<h1 style="font-size:1.2em; font-weight: lighter">Error: Invalid Payment Reference</h1><h1 style="font-size:1.2em; font-weight: lighter">Sorry, we encountered some errors while proccessing your Payment <br /> Try again Later.</h1>');
define("ERR2", '<h1 style="font-size:1.2em; font-weight: lighter">Error: Invalid Payment Details<h1/><h1 style="font-size:1.2em; font-weight: lighter">Sorry, we encountered some errors while identifying your Payment Details<br /> Try again Later.</h1>');
//represent the level loaded for payment analysis, typically used to load correct payment breakdown for student like DE whose level is 2 or 3 yet a fresh student

//New Patern (Initiated cos of Remita API/system procedure). Creating Order should be done here before loading the payment options
//Hense, Code for request pay will come here
//===============================================================================================
//get the thridparty platform
$thirdP = $dbo->Select4rmdbtbFirstRw("school_tb","PayThirdPartyID");
$thirdP = is_array($thirdP)?$thirdP[0]:1;


//sending order request to pay4me

if(isset($_POST['PayId'])){
	
	//$prstr = "gggg";
/*var ItemNo =escape(_('ItemNo').value);
		var Amt = escape(_('Amt').value);
		var RegNo = escape(_('SRegNo').value);
		var Sem = escape(_('Sems').value);
		var Lvl =escape( _('SLvl').value);
$RegNo = $_POST['RegNo'];
$PayID = $_POST['PayId'];
$Sem = $_POST['Sem'];
$pre = $_POST['pre'];
$lvl = $_POST['lvl'];
$loadlvl = isset($_POST['loadlvl'])?$_POST['loadlvl']:'null';		

*/
//$ItemNo = $_POST['PayId']; //the code for the item to pay for 1-acceptance fee 2-school fee etc
//$RegNo = $dbo->SqlSave($_POST['RegNo']);
//$Sem = $_POST['Sem'];
$studType = $pre;
$Lvl = $lvl; //the payment level
$loadlvl = (int)$loadlvl == 0?$Lvl:(int)$loadlvl; //the analysis loaded level

/*if((int)$ItemNo == 3){
	$studType = "p"; 
}*/
 
$studinfo = GetBasicInfo($RegNo,"",$studType,$RegID);
if(!is_array($studinfo)){
 $studinfo = $dbo->SelectFirstRow("payee_tb","","PayeeID = '$RegNo' LIMIT 1");
      
       if(is_array($studinfo)){
           
           $otherdet = $studinfo['OtherDet'];
           if(trim($otherdet) != ""){
               $otherdet = json_decode($otherdet,true);
               $studinfo = array_merge($studinfo,$otherdet);
           }
       }
}
//echo print_r($studinfo);
//$Lvl = StudLevel($RegNo, $studType);
$paymentitem = GetPaymentItem(trim($PayID));

if($paymentitem == NULL){
	echo ERR;
	exit;
}
$pabrDwn = PaymentBreakDown($paymentitem['PayBrkDn'],$loadlvl,$Sem,$studinfo,$sempart);
//print_r($paymentitem['PayBrkDn']);
if(!is_array($pabrDwn)){
	echo ERR;
	exit;
}
$prstr = "";
$Amt = (isset($_POST['Amt']))?$_POST['Amt']:$pabrDwn[0];	
$item_name = $paymentitem['ItemName'];
                //check if order has been placed or payment has been mede
				$order = $dbo->Select4rmdbtbFirstRw("order_tb","","RegNo='".$RegNo."' and Sem=".$Sem." and Lvl=".$Lvl." and ItemID=".$PayID." AND SemPart = {$sempart} AND ProgID=".$studinfo['ProgID']);

				//check user specified amount and the order amount if not desame clear the order for a new order
				$OrderDelete = false;
				if(is_array($order) && (float)$order['Amt'] != (float)$Amt && isset($_POST['from'])){
					//if a dynamic amount is set, reset the amount
					if(isset($_POST['Amt'])){
                      $del = $dbo->Delete("order_tb","ID=".$order["ID"]);
					  if(is_array($del)){
						  $OrderDelete = true;
					  }
					}else{//use the order amt
                       $Amt = (float)$order['Amt'];
					}
					
				}
				//echo $order == NULL?"1":"0";
				if(is_array($order) && $OrderDelete == false){
					if((int)$order['Paid'] == 1){
						exit("INVALID OPERATION, ALREADY PAID");
					}
                  
					
					$item_num = $order['ItemNo'];
					$trans_nums = $order['TransNum'];
					$item_name = $dbo->SqlSave($order['ItemName']);
					$item_description = $dbo->SqlSave($order['ItemDescr']);
					$Amt = $dbo->SqlSave($order['Amt']);
					$dts = $order['RegDate'];
					$ses = $order['Ses'];
					$paid = $order['Paid'];
					$BrkDwn = $order['BrkDwn'];
					$rst = "#";
				}else{
					//insert into Order Table
					
		      $trandet = generateTransInfo();
			  //echo $trandet;
			  if(!is_array($trandet)){echo $trandet; exit;}
				$item_num = $trandet[0];
					$trans_nums = $trandet[1];
					$dts = new DateTime();
				  $dts = $dts->format("Y-m-d");
				  $ses = CurrentSes();
				  if($ses !== false){
					$ses  = $ses['SesID'];  
				  }else{
					 $ses = 0; 
				  }
				  $paid = 0;
				 // $BrkDwn = $paymentitem['PayBrkDn'];
				  $item_name = $paymentitem['ItemName'];
                $fields = array('ItemNo'=>$item_num,'ItemID'=>$PayID,'TransNum' =>$trans_nums , 'Amt' => $Amt, 'RegNo'=>$RegNo, 'Sem'=>$Sem, 'Lvl'=>$Lvl, 'SemPart'=>$sempart, 'ItemName'=> $item_name, 'ItemDescr'=>$paymentitem['ItemDescr'], 'RegDate'=>$dts, 'Ses'=>$ses, 'BrkDwn'=> $pabrDwn[2],'Info'=>StudPatchDet($RegNo,$PayID,$Lvl),"ProgID"=>$studinfo['ProgID']);
                $rst = $dbo->Insert2DbTb($fields,"order_tb");
				}
                
                if($rst == "#"){
                   $prstr = "ItemNo=".$item_num;
				   //$Amtr = $Amt;
				  // $prstr = "ff";
				}else{
					
					echo ERR;
					exit;
					 }
   //
    

//header("Location:http://www.pay4me.com");

}else{
	exit(ERR2);
}

//=========================================================================================
if(!isset($_POST['from'])){
?>

<div style="font-size:0.8em;">
<?php
}
//echo 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/finish.php";
if($prstr != ""){
	//$prstr = str_replace(array("=",","),array("\=","\,"),$prstr);Pay.PrintPay(res,function(){Pay.LinkLoading();MessageBox.Close()})
	if(!isset($_POST['from'])){
ButtonImgBg("bank","BANK",'onclick=Pay.PrintPay(\'ItemNo\='.$item_num.'&RegID\='.$RegID.'\'\,function(){MessageBox.Close()});return false,title=Print Pre-Payment Analysis Slip\, for Bank Payment',false);
	}else{
		$AdminArr[] = array("Logo"=>"bank","Name"=>"BANK","Action"=>'Pay.PrintPay(\'ItemNo='.$item_num.'&RegID='.$RegID.'\',function(){},function(){},\'../portal/\')',"Title"=>"Print Pre-Payment Analysis Slip, for Bank Payment");
	}
//LinkImgBg("university","BANK","onclick=this.StartLoading(\'Bank\');Pay.PrintOrder(\''.$item_num.'\');return false,title=Print Pre-Payment Analysis Slip, style=margin-left:10px,href=#, target=newwin",false);
}
$dataurl = $trans_nums;
//$furl = 'Admin/Payment/cardpayredirect.php?h\='.urlencode($dataurl);
$furl = 'javascript:void()';
if((int)$thirdP == 1){ //REMITA
	//URL,MID,RRR,Hash,PayType
	$new_hash_string = $MERCHANTID . $trans_nums . $APIKEY;
$new_hash = hash('sha512', $new_hash_string);
	
	//$furl .= '&op\=';
	//$dataurl = hash('sha512', $dataurl); 
if(!isset($_POST['from'])){
LinkImgBg("credit-card-alt","VERVE","onclick=Pay.CardPay(this\,'{$dataurl}'\,'Interswitch');return false,title=Make Payment Using Verve Card, style=margin-left:10px,href={$furl}Interswitch, target=newwin",false);
LinkImgBg("cc-mastercard","MasterCard","onclick=Pay.CardPay(this\,'{$dataurl}'\,'UPL');return false,title=Make Payment Using Master Card, style=margin-left:10px,href={$furl}UPL, target=newwin",false);
LinkImgBg("cc-visa","VISA","onclick=Pay.CardPay(this\,'{$dataurl}'\,'UPL');return false,title=Make Payment Using Visa Card, style=margin-left:10px,href={$furl}UPL, target=newwin",false);
LinkImgBg("money","Remita","onclick=Pay.CardPay(this\,'{$dataurl}'\,'REMITA_PAY');return false,title=Make Payment Using Remita Platform, style=margin-left:10px,href={$furl}REMITA_PAY, target=newwin",false);
//ButtonImgBg("Resource/Images/CardOptionn.png","PocketMoni","title=Make Payment Using Card, style=margin-left:10px",false);
LinkImgBg("fax","POS","onclick=Pay.CardPay(this\,'{$dataurl}'\,'RRRGEN');return false,title=Make Payment Using Card, style=margin-left:10px,href={$furl}RRRGEN, target=newwin",false);
LinkImgBg("credit-card","ATM","onclick=Pay.CardPay(this\,'{$dataurl}'\,'ATM');return false,title=Make Payment Using Card, style=margin-left:10px,href={$furl}ATM, target=newwin",false);
}else{
	/*$AdminArr[] = array("Logo"=>"credit-card-alt","Name"=>"VERVE","Action"=>"Pay.CardPay(this,'{$dataurl}','Interswitch');return false","Title"=>"Make Payment Using Verve Card");
	$AdminArr[] = array("Logo"=>"cc-mastercard","Name"=>"MasterCard","Action"=>"Pay.CardPay(this,'{$dataurl}','UPL');return false","Title"=>"Make Payment Using Master Card");
	$AdminArr[] = array("Logo"=>"cc-visa","Name"=>"VISA","Action"=>"Pay.CardPay(this,'{$dataurl}','UPL');return false","Title"=>"Make Payment Using Visa Card");*/
	$AdminArr[] = array("Logo"=>"tv","Name"=>"ONLINE","Action"=>"Pay.CardPay(this,'{$dataurl}','REMITA_PAY','','../portal/')","Title"=>"Make Payment via online platform");
}
//ButtonImgBg("Resource/Images/CardOptionn.png","BANK INTERNET","title=Make Payment Using Internet Banking System, style=margin-left:10px",false);
}else{//if etransact
//etranzact BankIT
$Amt = urlencode($Amt);$itemName = urlencode($item_name);$RegNo = urlencode($RegNo);
if(!isset($_POST['from'])){
//$item_name = urlencode($item_name); 
LinkImgBg("tv","ONLINE","onclick=Pay.CardPay(this\,'{$dataurl}'\,'BankIT'\,'Amt\={$Amt}&ItNme\={$itemName}&rg\={$RegNo}&PayID\={$PayID}');return false,title=Make Payment Online through your Bank Account, style=margin-left:10px,href={$furl}",false);
}else{
	$AdminArr[] = array("Logo"=>"tv","Name"=>"ONLINE","Action"=>"Pay.CardPay(this,'{$dataurl}','BankIT','Amt={$Amt}&ItNme={$itemName}&rg={$RegNo}&PayID={$PayID}','../portal/')","Title"=>"Make Payment via online platform");
}
}
if(!isset($_POST['from'])){
?>
</div>

<?php
}else{
	$json = json_encode($AdminArr);
	exit($json);
}
}else{
?>

<div>Sorry!! we can't Identify the Payment Details. <br /> Click Cancel and Try Again</div>

<?php
}
?>