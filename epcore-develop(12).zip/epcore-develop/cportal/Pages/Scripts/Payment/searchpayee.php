<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
 $str = $_POST['str'];
 if(trim($str) == ""){
     exit("");
 }
 //search in student tb
 //$studrec = $dbo->SelectFirstRow("studentinfo_tb","","RegNo = '$str' OR JambNo = '$str' LIMIT 1");
 $studrec = GetBasicInfo($str, "sch", "");
 $pre = "";
 if(!is_array($studrec)){
   $studrec = GetBasicInfo($str, "sch", "p");
   $pre = "p";  
    if(!is_array($studrec)){
       $studrec = $dbo->SelectFirstRow("payee_tb","","PayeeID = '$str' LIMIT 1");
       $pre = "#";
       if(!is_array($studrec)){
           exit("");
       }else{
           $otherdet = $studrec['OtherDet'];
           if(trim($otherdet) != ""){
               $otherdet = json_decode($otherdet,true);
               $studrec = array_merge($studrec,$otherdet);
           }
       }
    }
 }
 $studrec['Pre'] = $pre;
 echo json_encode($studrec);
?>