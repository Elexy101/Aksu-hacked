<?php
$configdir = "../../../../../../academa/";
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
$totfailed = 0;
$totsuccess = 0;
//get all the courses
$course = $dbo->Select("coursereg_tb");
if(is_array($course) && $course[1] > 0){
    while ($indcours = $course[0]->fetch_assoc()) {
        $RegNo = $indcours['RegNo'];$studType="";
$RegID = 1; //the putme reg type that is calling the script, sent from the sub menu param in db (putme table ID field)

$PayID = 2;
$Sem = $indcours['Sem'];
//$pre = $_POST['pre'];
$lvl = $indcours['Lvl'];
$sempart = 3;
$ses = $indcours['SesID'];//fron course reg
$studinfo = GetBasicInfo($RegNo,"",$studType,$RegID);
if(!is_array($studinfo)){
    $totfailed++;
    continue;
}
//echo print_r($studinfo);
//$Lvl = StudLevel($RegNo, $studType);
$paymentitem = GetPaymentItem(trim($PayID));

if($paymentitem == NULL){
	//continue
}
$pabrDwn = PaymentBreakDown($paymentitem['PayBrkDn'],$lvl,$Sem,$studinfo,$sempart);
//print_r($paymentitem['PayBrkDn']);
if(!is_array($pabrDwn)){
    $totfailed++;
	continue;
}
$prstr = "";
$Amt = $pabrDwn[0];	
$item_name = $paymentitem['ItemName'];
                //check if order has been placed or payment has been mede
                $order = $dbo->Select4rmdbtbFirstRw("order_tb","","RegNo='".$RegNo."' and Sem=".$Sem." and Lvl=".$lvl." and ItemID=".$PayID." AND SemPart = {$sempart} AND ProgID=".$studinfo['ProgID']);
                if(is_array($order)){
                    $totfailed++;
                    continue;
                }

				
					
		      $trandet = generateTransInfoOnly();
			  //echo $trandet;
			  if(!is_array($trandet)){$totfailed++;continue;}
				$item_num = $trandet[0];
					$trans_nums = $trandet[1];
					$dts = $indcours['RegDate'];
				 // $dts = $dts->format("Y-m-d"); fom coursereg
				 /*  $ses = CurrentSes();
				  if($ses !== false){
					$ses  = $ses['SesID'];  
				  }else{
					 $ses = 0; 
				  } */
				  $paid = 0;
				 // $BrkDwn = $paymentitem['PayBrkDn'];
				  $item_name = $paymentitem['ItemName'];
                /* $fields = array('ItemNo'=>$item_num,'ItemID'=>$PayID,'TransNum' =>$trans_nums , 'Amt' => $Amt, 'RegNo'=>$RegNo, 'Sem'=>$Sem, 'Lvl'=>$lvl, 'SemPart'=>$sempart, 'ItemName'=> $item_name, 'ItemDescr'=>$paymentitem['ItemDescr'], 'RegDate'=>$dts, 'Ses'=>$ses, 'BrkDwn'=> $pabrDwn[2],'Info'=>StudPatchDet($RegNo,$PayID)); */
                //$rst = $dbo->Insert2DbTb($fields,"order_tb");
                $paydet = ["ItemNo"=>$item_num,
                "TransNum"=>$trans_nums,
                "ItemName"=>$item_name,
                "ItemDescr"=>$paymentitem['ItemDescr'],
                "Amt"=>$Amt,
                "Currency"=>"1",
                "RegNo"=>$RegNo,
                "SemPart"=>$sempart,
                "Sem"=>$Sem,
                "Lvl"=>$lvl,
                "ItemID"=>$PayID,
                "Paid"=>0,
                "Ses"=>$ses,
                "RegDate"=>$dts,
                "BrkDwn"=>$pabrDwn[2],
                "PayGatewayID"=>6,
                "Info"=>StudPatchDet($RegNo,$PayID,$lvl),
                "PayScope"=> $paymentitem['studType'],
                "SchSem"=>$Sem,
                "ProgID"=>$studinfo['ProgID']
                ];
                $insorder = $dbo->InsertID2("order_tb",$paydet);
 if(is_numeric($insorder)){
                    $Paidd = MakePaidByRef($trans_nums,$paydet,["Amt"=>$Amt,"Bank"=>"Manual Pay","Branch"=>"Manual Pay","DateTime"=>$dts]);
                    if(!is_array($Paidd)){
                        $totfailed++;
                        continue;
                      }
                      //exit(json_encode($Paidd));
                      if($Paidd[0] == 0){
                        $totfailed++;
                        continue;
                      }
                   //update payhistoru
				   //$Amtr = $Amt;
				  // $prstr = "ff";
				}else{
                    $totfailed++;
					continue;
                     }
                     $totsuccess++;
    }
    echo "Total Success: ".$totsuccess;
    echo "Total Failed: ".$totfailed;
}


?>