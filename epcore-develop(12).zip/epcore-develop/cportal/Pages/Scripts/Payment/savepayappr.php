<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//AllowUser("RAprov");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

if(!isset($_POST["MaxDataRow"]) || !isset($_POST["UID"]))exit("#Invalid Parameter");
//exit("*Maxmum Row = ".$_POST['MaxDataRow']);
$qr = "";
$maxrw = (int)$_POST["MaxDataRow"];
if($maxrw > 0){
    $cnt = 0;
    for($i=1;$i<=$maxrw;$i++){
        if(!isset($_POST[$i."_1"]) || $_POST[$i.'_deleted'] == "true")continue;
        $OrderID = $_POST[$i."_1"];
        $Status =(int)$_POST[$i."_13"];
        //get the order details
        $OrderDet = $dbo->SelectFirstRow("order_tb","","ID=".$OrderID);
        if(!is_array($OrderDet))continue;
        $PayStatus = (int)$OrderDet['Paid'];
        if($Status == $PayStatus)continue; //no changes
         if($Status == 1){ //if to approve
            $paid = MakePaidByRef($OrderDet['TransNum'],$OrderDet);
            if($paid[0] != 1){

            }
           //Insert in payhitory
          /*  $qr .= "INSERT INTO payhistory_tb SET 
           RegNo = '{$OrderDet['RegNo']}', 
          SemPart = {$OrderDet['SemPart']}, 
          Sem = {$OrderDet['Sem']},
          Lvl = {$OrderDet['Lvl']},
          Amt = {$OrderDet['Amt']},
          Ses = {$OrderDet['Ses']},
          TransID = '".$OrderDet['TransNum']."',
          PayID = {$OrderDet['ItemID']},
          PayBrkDn = '{$OrderDet['BrkDwn']}',
          Bank = 'Manual Pay',
          BnkBranch = 'Manual Pay',
          itemNum = '".$OrderDet['ItemNo']."',
          PayDate = '".$OrderDet['RegDate']. "',
          Info = '".StudPatchDet($OrderDet['RegNo'],$OrderDet['ItemID'])."',
          TransAmt = {$OrderDet['Amt']},
          CollectBank = '".GetCollectBank($OrderDet['ItemID'])."',
          ApproveUserID =  {$_POST["UID"]},
          ApproveDate = '".date("Y-m-d")."',
          PayScope = '{$_POST["PayScope"]}',
          ProgID = {$OrderDet['ProgID']};"; */
         }else{
//check if student already register for course
$regcouse = $dbo->SelectFirstRow("coursereg_tb","","RegNo = '{$OrderDet['RegNo']}' AND Lvl = {$OrderDet['Lvl']} AND Sem = {$OrderDet['Sem']}");
if(is_array($regcouse))continue;
           //delete from payhistory
           $qrst = $dbo->RunQuery("DELETE FROM payhistory_tb WHERE RegNo = '{$OrderDet['RegNo']}' AND TransID = '".$OrderDet['TransNum']."' AND PayID = {$OrderDet['ItemID']} AND itemNum = '".$OrderDet['ItemNo']."'");
         }
         //update order
         $qrst2 = $dbo->RunQuery("UPDATE order_tb SET Paid= $Status WHERE ID = {$OrderDet['ID']}");
        //echo $OrderID . "=" . $Status . "<br />";
        $cnt++;
    }
    /* if(trim($qr) == "")exit("No Changes Found");
    $dump = $dbo->Connection->multi_query($qr);
    if(!$dump){
      exit("#Server Error: ".$dbo->Connection->error);
    }else{
        do {
        
                            if ($result = $dbo->Connection->store_result()) {
                                
                                $result->free();
                            }
                           
                            if ($dbo->Connection->more_results()) {
                                //printf("-----------------\n");
                            }
                        } while ($dbo->Connection->next_result());
                    
                    } */
    if($cnt < 1){
        echo "No Changes Found";
    }/* else if($cnt == 1){
        echo "*1 Offline Payment Request Updated";
    } */else{
        echo "*$cnt Offline Payment Request Updated";
    }
}else{
    echo "#No Request Found";
}

?>