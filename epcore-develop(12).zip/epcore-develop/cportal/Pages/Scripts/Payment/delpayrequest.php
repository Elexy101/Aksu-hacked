<?php
$EpModuleName = "voffline";
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

if(!isset($_POST['OrderID']))exit("#INVALID PARAMETER");

//get payment details
$orderDet = $dbo->SelectFirstRow("order_tb","","ID=".$_POST['OrderID']);
if(!is_array($orderDet))exit("#INVALID OFFLINE PAYMENT REQUEST");

//check if already approved
if($orderDet['Paid'] == 1)exit("#APPROVED OFFLINE PAYMENT CANNOT BE DELETED");

//delete the payment
$del = $dbo->Delete("order_tb","ID=".$_POST['OrderID']);
if(is_array($del)){
//remove the receipt
$fn = $configdir."Files/Payment/Receipt/".str_replace("/","_",$orderDet['RegNo'])."_".$orderDet['ItemID']."_".$orderDet['Lvl']."_".$orderDet['Sem']."-".$orderDet['SemPart'].".jpg";
if(file_exists($fn))unlink($fn);
    exit("#"); //OFFLINE PAYMENT APPROVAL REQUEST DELETED SUCCESSFULLY
}else{
    exit("#INTERNAL ERROR: DELETE FAILED - ".$del);
}

?>