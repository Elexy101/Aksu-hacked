<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("psetting");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");


extract($_POST);
//if((int)$PayGateWayID < 1)exit("#INVALID PAYMENT GATEWAY SPECIFIED");

$ordervalidity = (int)$OrderValidity < 1?1:(int)$OrderValidity; //default is 1 days 
$AutoSem = (int)$AutoSem < 0?"FALSE":((int)$AutoSem == 0?"ALL":"TRUE");
$AutoLvl = (int)$AutoLvl < 1?"FALSE":"TRUE";
$uniquetranid = (int)$uniquetranid == 1?"TRUE":"FALSE";
$schbulkupdate = (int)$schbulkupdate == 1?"TRUE":"FALSE";
//-1 = default - Active Semester - FALSE
//0 = off - All Semester - ALL
//1 = on - Auto Semester - TRUE
//if($maxdata < 1)exit ("")
$queryArray = ["UPDATE school_tb SET OrderValidity=$ordervalidity, UniqueTransID='$uniquetranid', BulkPayUpdate = '$schbulkupdate'"];
//process partpay restrict
$partpaylvlrst = $dbo->DataArray($partpaylvlrst);
$ppmaxrow = $partpaylvlrst['MaxDataRow'];
$lvlsarr = [];$rstrstr = "-1";
for($ps=1;$ps<=$ppmaxrow;$ps++){
    $Level = (int)rawurldecode($partpaylvlrst[$ps.'_2']);
    $Status = (int)rawurldecode($partpaylvlrst[$ps.'_3']);
    if($Status == 1){
        $lvlsarr[] = $Level;
    } 
}

if(count($lvlsarr) > 0){ //if restrict level found
    $rstrstr = implode("~",$lvlsarr);
}

$queryArray[]= "UPDATE schoolpayment_tb SET PartPayRestrict='$rstrstr' , AutoSem='$AutoSem', AutoLevel='$AutoLvl'";


$loaded = [];

$PayItems = $dbo->DataArray($PayItems);
//max row
$maxdata = (int)$PayItems['MaxDataRow'];
//loop through all courses
for($s=1;$s<=$maxdata;$s++){
    //get individual course details
    $ID = (int)rawurldecode($PayItems[$s.'_3']);
    $Deleted = rawurldecode($PayItems[$s.'_deleted']);
    $ItemName = trim($dbo->SqlSafe(rawurldecode($PayItems[$s.'_1'])));
   
    
    $ItemAmt = trim($dbo->SqlSafe(rawurldecode($PayItems[$s.'_2'])));
    //check if already loaded (duplicate entering)
    if($ItemName == "" && (float)$ItemAmt > 0)continue; //ignore the record if itemname is not set
    //if(in_array(strtolower($ItemName."_".$ItemAmt),$loaded))continue; //ignore the record
    //if id is greater than zero, meaning is an update operation
    $ItemAmt = (float)str_replace(",","",$ItemAmt);

    if($ID > 0){ //update or delete
        //check if delete
        if(($ItemName == "" && $ItemAmt < 1) || $Deleted == "true"){
            $queryArray[] = "DELETE FROM payitem_tb WHERE ID = $ID";
        }else{//update
            $queryArray[] = "UPDATE payitem_tb SET ItemName = '$ItemName', Amt='$ItemAmt' WHERE ID = $ID";
        }
        //$queries[] = "";
    }else{ //if insert operation
        $queryArray[] = "INSERT payitem_tb SET ItemName = '$ItemName', Amt='$ItemAmt'";
    }
    //$loaded[] = strtolower($ItemName."_".$ItemAmt);
    
   // $ids[] = $ID;
}

if(count($queryArray) > 0){
    $query = implode(";",$queryArray);
    //exit($query);
    $dump = $dbo->Connection->multi_query($query);
    if(!$dump){
      echo "#Server Error: ".$dbo->Connection->error;
    }else{
        do {
            /* store first result set */
                            if ($result = $dbo->Connection->store_result()) {
                                /*while ($row = $result->fetch_row()) {
                                    printf("%s\n", $row[0]);
                                }*/
                                $result->free();
                            }
                            /* print divider */
                            if ($dbo->Connection->more_results()) {
                                //printf("-----------------\n");
                            }
                        } while ($dbo->Connection->next_result());
                        $headerd = array(
                            "*PItem"=>"ITEM",
                           "*PItemAmt"=>"AMOUNT",
                           "-PID"=>"PIID"
                          );
                          //reload the payment item spread sheet
                          echo "~"; SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-bottom:6px,id=payitems,multiselect=false,cellfocus=,cellblur=Payment.PaySetting.FormatAmt,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=12,rowfilter=true,filtertitle=FILTER PAYMENT ITEMS,filterstyle=width:calc(100% - 16px);margin:auto,disable=PID",$headerd,"SELECT ItemName,FORMAT(Amt,2) as Amt,ID FROM payitem_tb");
       //echo "*Payment Settings Saved";
                    }
                }else{
                    echo "No Changes Found";
                }
//echo implode(";",$queryArray);




?>