<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//check priv
AllowUser("ptype");
$sch= GetSchool();
if(!isset($_POST['PayID']) || trim($_POST['PayID']) == "")exit("#Invalid Payment Type Selected");
$allpartarr = [];
//get the id
$PayID = (int)$_POST['PayID'];
//get the payment type details
$PayTypeDet = $PayID > 0?$dbo->SelectFirstRow("item_tb","","ID=".$PayID,MYSQLI_ASSOC):[];
if((!is_array($PayTypeDet) || count($PayTypeDet) == 0) && (!isset($_POST['Type']) || (int)$_POST['Type'] == 0))exit("#Reading Payment Type Details Failed");
   //control table
   $controltbarr = [1=>"putme","form_tb","schoolpayment_tb"];
   if(!isset($_POST['Type']) || (int)$_POST['Type'] == 0){ //represent payment analysis is loaded when the payment type is selected

$ownermodule = array_search($PayTypeDet['ControlTable'],$controltbarr);
$ownermodule = $ownermodule === FALSE?3:$ownermodule; //if payment settings tb not found use the schoolpayment_tb(3)
$MID = $PayTypeDet['ControlTableID'];
   }else{ //if payment settings tb and id sent from ui (i.e user changes the settings lookup). Resset to user specified data
    $PayTypeDet['ControlTable'] = $controltbarr[$_POST['Type']];
    $ownermodule = $_POST['Type'];
    $MID = $_POST['MID'];
   }

   //Get all the current school semesters
   $sems = $dbo->Select("semester_tb","","Enable=1 ORDER BY Num, ID");
   if(!is_array($sems) || $sems[1] < 1)exit("#Reading School {$sch['SemLabel']} Details Failed, Make sure {$sch['SemLabel']} are Setup ".$sems[1]);
   $SchSems = [];
   $SemPartStructure = [];
   $semstruccnt = 0;
   $partstruccnt = 0;
   $disableQuaterSum = [];
   $DisplayTableHeader = ["HALF"=>[],"QUATER"=>[]];
   //get all semsesters in an array
   while($indsem = $sems[0]->fetch_assoc()){
      $SchSems[] = $indsem;
      $SemNum = (int)$indsem['Num'] > 0?(int)$indsem['Num']:(int)$indsem['ID'];
      $SemPartStructure[$SemNum.""] = $semstruccnt;
      $semstruccnt++;
      $DisplayTableHeader["HALF"]["*F".$SemNum."F3"] = [strtoupper($indsem['Sem']),".amtfield"];
      foreach([1,2,3] as $partNum){
         $SemPartStructure[$SemNum."_".$partNum] = $partstruccnt;
         $partstruccnt++;
         $DF = $partNum;
          if($partNum == 3){
             $DF = "FULL";
             $disableQuaterSum[] = "F".$SemNum."F".$partNum;
          }
         $DF = ($partNum == 3)?"FULL":$partNum;

         $DisplayTableHeader["QUATER"]["*F".$SemNum."F".$partNum] = [strtoupper($indsem['Sem']."-".$DF),".amtfield"];
      }
   }

   $disableQuaterSum["QUATER"] = count($disableQuaterSum) > 0?implode(";",$disableQuaterSum):"";

   //Maximum Semester Num
   $MaxSemNum = (int)$SchSems[count($SchSems)-1]['Num'] > 0?(int)$SchSems[count($SchSems)-1]['Num']:(int)$SchSems[count($SchSems)-1]['ID'];
   $MaxEnter = $MaxSemNum; //the total number of payment field will be displayed in the rule table

//exit("#".$ownermodule);
$PayTypeDet['OwnerModule'] = $ownermodule; //the id of the tb to manage the payment settings (1|2|3)

//get the payment control details
$paycntrdet = $dbo->SelectFirstRow($PayTypeDet['ControlTable'],"","ID=".$MID);

//if(!is_array($paycntrdet))exit("#Reading Owner Module Settings Failed - ".$PayTypeDet['ControlTable']);
//if(!is_array($paycntrdet) || $paycntrdet[0] < 1)exit("#Reading Owner Module Settings Failed - ".$_POST['Type']);
$partpayshare = is_array($paycntrdet) && isset($paycntrdet['PartPayShare'])?$paycntrdet['PartPayShare']:"HALF";
$partpaystatus = is_array($paycntrdet) && isset($paycntrdet['PartPay'])?$paycntrdet['PartPay']:"FALSE";
$payanalysis = trim(isset($PayTypeDet['PayBrkDn'])?$PayTypeDet['PayBrkDn']:"");
$dump = [];

if($payanalysis != ""){
    
//get individual payment items
$payanalysisarr = explode("***",$payanalysis);
//exit($payanalysisarr);

if(count($payanalysisarr) > 0){
    
    foreach($payanalysisarr as $indpayanal){
       
        $newarr = [];
        //check if banner
  if(substr(trim($indpayanal),0,2) == "##"){
     //it is a banner
     $dump[] = ["banner"=>substr(trim($indpayanal),2)];
     continue;
  }
        //breakdown conditional part
   $condpratsbrkdn = explode("?",$indpayanal);

   $CondAttrID=[0];$CondVal=[""];$useop = [""];
   if(count($condpratsbrkdn) > 1){ //if conditon exist
   
   //Proccess Condition Section
 //******************************************** */
 $pcond = $condpratsbrkdn[0];
 $currop = [1=>"==","!=","<=",">=","<",">"];
 $condarr = array("None","StateId","Gender","MaritalStatus","StartSes","ModeOfEntry","ProgID","FacID","StudyID","FacGrpID","Degree","AdmSes","ClassID");
 //breakdown to get multiple condition
 $multicond = explode("&&",$pcond);
 foreach($multicond as $ind => $cond){
   $useop[$ind] = "";
$condbrkdn=[];
 foreach($currop as $k=>$opr){
    $condbrkdn = explode($opr,$cond);
    if(count($condbrkdn) == 2){
        $useop[$ind] = $k;break;
    }
 }
 //breakdown condition
 
 //for now != not handled @@@@@@@@@@@@@@@@@@@@@@
 $CondAttrID[$ind]=0;$CondVal[$ind]="";
 if($useop[$ind] !== ""){
    
     //array("None","State of Origin","Gender","Marital Status","Set/Batch","Mode Of Entering","Department","Faculty/School","Study")
    $CondAttr = $condbrkdn[0]; $CondVal[$ind] = $condbrkdn[1];
$CondAttrID[$ind] = array_search($CondAttr,$condarr);
if($CondAttrID[$ind] === FALSE){$CondAttrID[$ind]=0;$CondVal[$ind]="";}
 }
 }
 
 
 //******************************************** */

    $indpayanalr = $condpratsbrkdn[1];
   }else{
    
    $indpayanalr = $condpratsbrkdn[0];
   }
     //get the individual breakdown items
     $indbrkdnitarr = explode("|",$indpayanalr);
     //exit(count($indbrkdnitarr)."");
     if(count($indbrkdnitarr) > 2){
       
       $itemname = $indbrkdnitarr[0]; //The name of the item in json ({"ID":1,"Name":"Tuition Fee"}) - details from payitem_tb
       $lvlamt = $indbrkdnitarr[1]; //the total amounts base on level (2=5000~3=5000~4=5000~5=5000)
       $parts = $indbrkdnitarr[2]; //the part share percentage of the amounts HALF-(1=0.5~2=0.5) QUATER-(1_1=0.25~1_2=0.25~1_3=0.5~2_1=0.25~2_2=0.25~2_3=0.5)
       $status = isset($indbrkdnitarr[3])?$indbrkdnitarr[3]:"1"; //The Status Enable - 1, Disable - 0
       $period = isset($indbrkdnitarr[4])?$indbrkdnitarr[4]:""; //The validity period (Date)
       $option = isset($indbrkdnitarr[5])?$indbrkdnitarr[5]:"0"; //Optional -1 , Compulsary - 0

 //Proccess ItemName Section
 //******************************************** */
$itemnameobj = json_decode($itemname,true);
$id = 0; $itemnamer = "";
if(is_array($itemnameobj)){ //if valid json name
    $id = $itemnameobj['ID'];
    if($id < 0)continue; //meaning is a technical included payment item e.g Transaction Charge i.e they cannot be modified by user
    $itemnamer = $itemnameobj['Name'];
}else{//if not valid, assume is the old format
 //add it to the payitem_tb and modify the break down
 //get the payment item by name in payitem_tb
 $payitemdet = $dbo->SelectFirstRow("payitem_tb","","TRIM(LCASE(ItemName)) = '".trim(strtolower($itemname))."'");
 if(!is_array($payitemdet)){ //if not exist add new
    $newid = $dbo->InsertID2("payitem_tb",["ItemName"=>$itemname]);
if(is_numeric($newid))$id = $newid;
$itemnamer = $itemname;
 }else{
    $id = $payitemdet['ID'];
    $itemnamer = $payitemdet['ItemName'];
 }
  
}
//Form the new item name string
$ItemNameString = json_encode(["ID"=>$id,"Name"=>$itemnamer]);
//******************************************** */


//Proccess Levels Section
//******************************************** */ 
$otherlvlamts = []; //hold the level and its coresponding amt if defferent from the first
$otherlvlshare = [];
$firstAmt = 0; //hold the am
 $lvls = [];
//breakdown levels
if(trim($lvlamt) != ""){
   
 $lvlamtarr = explode("~",$lvlamt); //breakdown all levels
 
 foreach($lvlamtarr as $indlvlamt){ //loop through
    $indlvlamtarr = explode("=",$indlvlamt); //get the level and its amt
if(count($indlvlamtarr) == 2){ //if valid
 $lvlID = (int)$indlvlamtarr[0]; //level id
 $lvlAmt = (float)$indlvlamtarr[1]; //amt
 if($lvlID < 0){ //if any level rule is set (meaning all the level applies) - set only it and descard other settings if exist
    $lvls = [];
    $lvls[$lvlAmt] = [$lvlID];
    break;
 }
 if(isset($lvls[$lvlAmt])){ //check if entering for the amt is already entered
   $lvls[$lvlAmt][] = $lvlID;
 }else{ //f not start its entering
    $lvls[$lvlAmt] = [$lvlID];
 }
 
 //check if the current level amt is not equal to the previous one
 /* if($lvlAmt != $firstAmt && $firstAmt != 0){
     //add to new level entreing
     $otherlvlamts[$lvlID] = $lvlAmt;
     $otherlvlshare[$lvlID] = [];
     continue;
 }
$lvls[] = $lvlID; //add to levels array
 if($firstAmt == 0)$firstAmt = $lvlAmt; //use the first level amount as the amount
if($lvlID < 0)$firstAmt = $lvlAmt; //set the amt if all level found */
}else{
 //if not valid level amt
}
 }
}
//******************************************** */

//Proccess Part Payment Section
//******************************************** */
$partsharearr = [];
$info = [];
//The Part Share applies to each Amt Group
foreach($lvls as $firstAmt=>$idarr){
    //$partsharearr = [];
//if(!isset($partsharearr[$firstAmt])){
   // $partsharearr[$firstAmt] = $partpayshare == "HALF"?["",""]:["","","",""];
    $partsharearr[$firstAmt] = [];
//} 
$partseen = [];
$quatertype = false; //help determine if the sent structure is quaterly
//break it down
//braekdown the part structure
$partsarr = explode("~",$parts);

//loop trough each part structure
foreach($partsarr as $indpart){
   
  //get the part and the share
  $partshare = explode("=",$indpart);
  
//if(count($partshare) == 2){
  $key = $partshare[0];
  
$keyst = explode("_",$key); //breakdown key to determin partshare type
//$info[] = $keyst;
   if($quatertype == false && count($keyst) > 1)$quatertype = true;
   
  //perform for all level $lvls[$lvlAmt] = [$lvlID]
  
   //if(trim($key) == '3'){ //if its full payment
      //($MaxSemNum+1) represent full payment
   if(trim($key) == ($MaxSemNum+1).""){ //if its full payment
    $partsharearr[$firstAmt][0] = $firstAmt;
    $partseen[0] = $partsharearr[$firstAmt][0];
    //break;
   }


   //form the structure
   //foreach($SchSems)
   //$partsharearr[$firstAmt][3] = $partsharearr[$firstAmt][2];
   //if it is part half (first)
   if($partpayshare != 'HALF' && $quatertype == false){ //if its quater structure but the current structure from db is half
      //check if the current $p
      //use position $key_1
      $key = $key."_1";
   }elseif($partpayshare == 'HALF' && $quatertype == true){
      
      if((int)$keyst[1] > 2)continue; //if the semester total, no point adding it (we need the part and balance to form the total for half share)
      
     $key = $keyst[0]; //add to the semster
   }
   //$info[] = $key;
   $keyind = $SemPartStructure[$key];
   if(!isset($partsharearr[$firstAmt][$keyind]))$partsharearr[$firstAmt][$keyind]=0; //intialize
   $partsharearr[$firstAmt][$keyind] += isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
   $partseen[$keyind] = $partsharearr[$firstAmt][$keyind];

   

   
   /* if(trim($key) == '1' || trim($key) == '1_1'){
    $partsharearr[$firstAmt][0] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
    $partseen[0] = $partsharearr[$firstAmt][0];
   }

   //if it is part half (second)
   if(trim($key) == '2' || trim($key) == '1_2'){
    $partsharearr[$firstAmt][1] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
    $partseen[1] = $partsharearr[$firstAmt][1];
   }

   //if its is first full
   if(trim($key) == '1_3'){
      $partsharearr[$firstAmt][2] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
      $partseen[2] = $partsharearr[$firstAmt][2];
   }

   if(trim($key) == '2_1'){
    $partsharearr[$firstAmt][3] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
    $partseen[3] = $partsharearr[$firstAmt][3];
   }

   if(trim($key) == '2_2'){
    $partsharearr[$firstAmt][4] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
    $partseen[4] = $partsharearr[$firstAmt][4];
   }

   if(trim($key) == '2_3'){
      $partsharearr[$firstAmt][5] = isset($partshare[1])?round((float)$partshare[1]*$firstAmt):$firstAmt;
      $partseen[5] = $partsharearr[$firstAmt][5];
     }
 */
  

   }

   
   //reform based on the partpay share
   $totpart = count($partseen);
   
   /*if($partpayshare == "HALF" && $quatertype == true){
         $partsharearr[$firstAmt][0] = !isset($partsharearr[$firstAmt][0])?0:$partsharearr[$firstAmt][0];
        $partsharearr[$firstAmt][1] = !isset($partsharearr[$firstAmt][1])?0:$partsharearr[$firstAmt][1];
        $partsharearr[$firstAmt][2] = !isset($partsharearr[$firstAmt][2])?0:$partsharearr[$firstAmt][2];
        $partsharearr[$firstAmt][3] = !isset($partsharearr[$firstAmt][3])?0:$partsharearr[$firstAmt][3];
        $partsharearr[$firstAmt][4] = !isset($partsharearr[$firstAmt][4])?0:$partsharearr[$firstAmt][4];
        $partsharearr[$firstAmt][5] = !isset($partsharearr[$firstAmt][5])?0:$partsharearr[$firstAmt][5];
        if($partsharearr[$firstAmt][2] == 0){ //if first full payment not found
          //sum the first 1 and 2
          $partsharearr[$firstAmt][2] = $partsharearr[$firstAmt][0] + $partsharearr[$firstAmt][1];
        }

        if($partsharearr[$firstAmt][5] == 0){ //if second full payment not found
         //sum the second 1 and 2
         $partsharearr[$firstAmt][5] = $partsharearr[$firstAmt][3] + $partsharearr[$firstAmt][4];
       }

        $partsharearr[$firstAmt] = [$partsharearr[$firstAmt][2],$partsharearr[$firstAmt][5]]; //first payment
        
        //$partsharearr[$firstAmt] = [$partsharearr[$firstAmt][0] + $partsharearr[$firstAmt][1],$partsharearr[$firstAmt][2] + $partsharearr[$firstAmt][3]];
   }

   //if is to form quater based and load structure is half
 if($partpayshare != 'HALF'){

   if($quatertype == false){
//transfer any thing in position 1 to 3
  if(isset($partsharearr[$firstAmt][1]) && trim($partsharearr[$firstAmt][1]) != "" ){
   $partsharearr[$firstAmt][3] = $partsharearr[$firstAmt][1];
  }
   }
  

  //form the quater fulls
if(!isset($partsharearr[$firstAmt][2])){
   $f1 = isset($partsharearr[$firstAmt][0])?(float)$partsharearr[$firstAmt][0]:0;
   $f2 = isset($partsharearr[$firstAmt][1])?(float)$partsharearr[$firstAmt][1]:0;
  if($f1 > 0 || $f2 > 0){
      $partsharearr[$firstAmt][2] = $f1 + $f2;
  }
   
}

if(!isset($partsharearr[$firstAmt][5])){
   $f3 = isset($partsharearr[$firstAmt][3])?(float)$partsharearr[$firstAmt][3]:0;
   $f4 = isset($partsharearr[$firstAmt][4])?(float)$partsharearr[$firstAmt][4]:0;
   if($f3 > 0 || $f4 > 0){
   $partsharearr[$firstAmt][5] = $f3 + $f4;
   }
}

} */



   /* if($partpayshare == "HALF" && $totpart < 2){
    $partsharearr[$firstAmt][1]="";
    
    } */

    // if($partpayshare != "HALF" && $totpart < 3){
     
   /*  if(isset($partsharearr[$firstAmt][1]) && trim($partsharearr[$firstAmt][1]) != ""){
      $partsharearr[$firstAmt][3] =$partsharearr[$firstAmt][1];
      $partsharearr[$firstAmt][1] = "";
      $partsharearr[$firstAmt][4] = !isset($partsharearr[$firstAmt][4])?"":$partsharearr[$firstAmt][4];
      $partsharearr[$firstAmt][2] = $partsharearr[$firstAmt][0];
      $partsharearr[$firstAmt][5] = $partsharearr[$firstAmt][3];
      
    }else{
        $partsharearr[$firstAmt][1] = "";
        $partsharearr[$firstAmt][2] = $partsharearr[$firstAmt][0];
      $partsharearr[$firstAmt][3] = "";
      $partsharearr[$firstAmt][4] = "";
      $partsharearr[$firstAmt][5] = "";
    } */

    //make sure no unset array element
    if($partpayshare == "HALF"){
       //$MaxEnter = $MaxSemNum;
     /* if(!isset($partsharearr[$firstAmt][0]) || $partsharearr[$firstAmt][0] == 0)$partsharearr[$firstAmt][0]="";
     if(!isset($partsharearr[$firstAmt][1]) || $partsharearr[$firstAmt][1] == 0)$partsharearr[$firstAmt][1]="";
     if(isset($partsharearr[$firstAmt][2]))unset($partsharearr[$firstAmt][2]);
     if(isset($partsharearr[$firstAmt][3]))unset($partsharearr[$firstAmt][3]);
     if(isset($partsharearr[$firstAmt][4]))unset($partsharearr[$firstAmt][4]);
     if(isset($partsharearr[$firstAmt][5]))unset($partsharearr[$firstAmt][5]); */
     
    }else{
      $MaxEnter = $MaxSemNum * 3;
      /* if(!isset($partsharearr[$firstAmt][0]) || $partsharearr[$firstAmt][0] == 0)$partsharearr[$firstAmt][0]="";
      if(!isset($partsharearr[$firstAmt][1]) || $partsharearr[$firstAmt][1] == 0)$partsharearr[$firstAmt][1]="";
      if(!isset($partsharearr[$firstAmt][2]) || $partsharearr[$firstAmt][2] == 0)$partsharearr[$firstAmt][2]="";
      if(!isset($partsharearr[$firstAmt][3]) || $partsharearr[$firstAmt][3] == 0)$partsharearr[$firstAmt][3]="";
      if(!isset($partsharearr[$firstAmt][4]) || $partsharearr[$firstAmt][4] == 0)$partsharearr[$firstAmt][4]="";
      if(!isset($partsharearr[$firstAmt][5]) || $partsharearr[$firstAmt][5] == 0)$partsharearr[$firstAmt][5]=""; */
      
    }

    $sum = 0; //hold the sumation of the amount field
    $sumcnt = 1; //hold the curent index to know if sumation index
    for($s=0;$s<$MaxEnter;$s++){ //loop throug all amount entreing
      if(!isset($partsharearr[$firstAmt][$s]))$partsharearr[$firstAmt][$s]=0;
       $default = ""; //the default value
       if($sumcnt == 3){ //if its a sumation field
         if($sum > 0)$default =  $sum; //set the default to the accumulated sum
         $sum = 0; //reset sumation
         $sumcnt = 1; //resset counter
       }else{
          $sum += $partsharearr[$firstAmt][$s];
          $sumcnt++;
       }
       if($partsharearr[$firstAmt][$s] == 0)$partsharearr[$firstAmt][$s]=$default;
     }
   // $partsharearr[$firstAmt][3] = isset($partsharearr[$firstAmt][3])?$partsharearr[$firstAmt][3]:"";;
   

 /* }else{
   // $partsharearr[$firstAmt][3] = $dtarrstr;
 } */

}

   
//}
}
//exit($partsharearr);
//******************************************** */
foreach($lvls as $firstAmt=>$idarr){
     //form new array
     if(count($idarr) < 1){
        $idarr = 0;
     }else if(count($idarr) == 1){
        $idarr = $idarr[0];
     }else{
        $idarr = ":".implode("::",$idarr).":";
     }
     $fCondAttrID = array_shift($CondAttrID);
     $fuseop = array_shift($useop);
     $fCondVal = array_shift($CondVal);
     $newarr = [$id,$idarr,$fCondAttrID,$fuseop,$fCondVal,$period];
     $sm = 0;
     ksort($partsharearr[$firstAmt]);
     foreach($partsharearr[$firstAmt] as $indamt){ //loop through individual amt
        if($partpaystatus == "TRUE" || $partpaystatus == "STRICT")$newarr[] = trim($indamt) != ""?[number_format($indamt,2),'class=amtfield']:["",'class=amtfield'];
        //$newarr[] = trim($indamt) != ""?$indamt:"";
        $sm += $indamt;
     }
    // $newarr = array_merge([$id,$lvls,$CondAttrID,$useop,(int)$CondVal],$partsharearr);
     $newarr[] = number_format($firstAmt,2);
     $newarr[] = $status;
     $newarr[] = $option;
     
     $dump[] = $newarr;
     if(count($CondAttrID) > 0){ //meaning multiple conditions exist
       foreach($CondAttrID as $ckey=>$CAttrID){
         $newarr = ['-1',['','disabled=true'],$CAttrID,$useop[$ckey],$CondVal[$ckey],['','disabled=true']];
         if($partpaystatus == "TRUE" || $partpaystatus == "STRICT"){
            foreach($partsharearr[$firstAmt] as $indamt){ //loop through individual amt
            $newarr[] = ['','disabled=true'];
         }
         }
         
        // $newarr = array_merge([$id,$lvls,$CondAttrID,$useop,(int)$CondVal],$partsharearr);
         $newarr[] = ['','disabled=true'];
         $newarr[] = [1,'disabled=true'];
         $dump[] = $newarr;
       }
     }
    }
    $allpartarr[] = [$parts,$partsharearr];
     }


     
//check if other level amt exist

    }
}

echo json_encode($PayTypeDet);
echo "~~!!";
//echo json_encode($allpartarr);
//echo $partpayshare.json_encode($dump);
//echo $partpayshare;
$studys = $dbo->RunQuery("SELECT ID, Name FROM study_tb WHERE SchoolType = (SELECT Type FROM school_tb LIMIT 1)");
    // $studyData = [];
    
     if(is_array($studys) && $studys[1] > 0){
         $qstrs = "";
         while($indstudys = $studys[0]->fetch_assoc()){
            //$qstrs .= "A"; continue;
             $qstrs .= " UNION SELECT '-1' as Level, 'ANY' as Name";
             
             $qstrs .= " UNION ";
            
             //get all programme in the faculty
             $qstrs .= "select Level, CONCAT('LEVEL',Level) as Name from schoollevel_tb where StudyID = {$indstudys['ID']}  and SchoolTypeID = (select Type from school_tb limit 1)";
             //$studyData[$indstudys['ID']] = $indstudys['Name'];
            // continue;
         }
         $qstrs = ltrim($qstrs," UNION ");
        }
        //select '#' as ID, '".$dbo->SqlSafe('<a class="altColor2" href="javascript:Payment.PaymentType.MoreCond(this)"><i class="fa fa-tasks" ></i> MORE CONDITION</a>')."' as ItemName
$headerd = array(
    "*PItems"=>array("ITEM","#select ID,ItemName from payitem_tb UNION select '-1' as ID, '[MORE CONDITION]' as ItemName UNION select '#' as ID, '".$dbo->SqlSafe('<a href="javascript:Page.OpenByTabName(\'psetting\')"><i class="fa fa-plus"></i> NEW PAYMENT ITEM</a>')."' as ItemName"),
    /* "*PStudys"=>array("STUDY",$dbo->DataString(TextBoxSQL("select ID,Name from study_tb WHERE SchoolType = (select Type from school_tb limit 1)"))),
   "*PLevel"=>array("LEVEL","#select Level, Name from schoollevel_tb where StudyID = ?PStudys? and SchoolTypeID = (select Type from school_tb limit 1) order by Level",true), */
   //"*PLevel"=>array("LEVEL","@cportal/Pages/Scripts/Payment/paytypecond.php PayTypeLevel",true),
   "*PLevel"=>array("LEVEL",$dbo->DataString(TextBoxSQL($qstrs)),true),
   "*PCond"=>array("CONDITION",$dbo->DataString(
    array("None","State of Origin","Gender","Marital Status","Set/Batch","Mode Of Entering","Department","Faculty/School","Study","Faculty Group","Degree","Admission Session","Class")
   )),
   "*CondOp"=>array("OPERATOR","1=IS&2=IS NOT&3=IS OR LESS THAN&4=IS OR GREATER THAN&5=LESS THAN&6=GREATER THAN"),
   "*PVal"=>array("VALUE","@cportal/Pages/Scripts/Payment/paytypecond.php PayTypeCondValue Cond=?PCond?"));
   $headerd["*PPeriod"]=array("PERIOD","_CALENDAR_RANGE_");
   $totdis = "";
   $disables = "";
   $columnclass = "";
   if($partpaystatus == "TRUE" || $partpaystatus == "STRICT"){
   // $headerdamt = $partpayshare == "HALF"?["*Fpay"=>"FIRST","*Spay"=>"SECOND"]:["*Fpay"=>"FIRST-1","*FpayComplete"=>"FIRST-2","*FpayFull"=>"FIRST-FULL","*Spay"=>"SECOND-1","*SpayComplete"=>"SECOND-2","*SpayFull"=>"SECOND-FULL"];
   $headerdamt = $DisplayTableHeader[$partpayshare];
   $headerd = array_merge($headerd,$headerdamt);
   //$columnclass .= ""
   $disables = "PTot;".$disableQuaterSum[$partpayshare];
   //$totdis = ",disable=PTot";
   $totdis = "";
   }else{

   }
   $headerd["*PTot"] = "FULL";
   $headerd["*PStatus"]=array("ENABLED","YES|NO");
   $headerd["*POption"]=array("OPTIONAL","YES|NO");

   //print_r($headerd);
  
  
  SpreadSheet("class=ep-animate-opacity,rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-top:0px;margin-bottom:6px,id=paytypeanal,multiselect=false,cellfocus=,cellblur=Payment.PaymentType.FormatAmt,cellkeypress=Payment.PaymentType.TotalAmt,dynamiccolumn=false,dynamicrow=true,onchange=Payment.PaymentType.CheckItem,minrow=50,rowfilter=true$totdis,filtertitle=FILTER RULE LIST,filterstyle=width:calc(100% - 16px);margin:auto;margin-top:10px,disable=PID;".$disables,$headerd,$dump);
  TextBoxGroup("width:calc(100% - 16px);margin:auto;text-align:center");
  Note();
  echo "Simulate to view Payment Breakdown based on the Ruleset (Student Payment Analysis Slip) <br/>****** Save Updates before Performing Simulation ******";
  _Note();
  _TextBoxGroup();
  FlatButton("text=Run a Simulation on the Payment Type, style=margin:auto; margin-top:5px; width:500px,onclick=Payment.PaymentType.Test(),logo=tasks,id=testpaytypebtn");
  Hidden("maxsem",$MaxSemNum);
  Hidden("partshare",$partpayshare);
  Hidden("partstatus",$partpaystatus);
  //echo json_encode($partsharearr)." - ".json_encode($partsarr). " - ".json_encode($SemPartStructure). " - ".json_encode($info);

   

//echo $PayID;


?>