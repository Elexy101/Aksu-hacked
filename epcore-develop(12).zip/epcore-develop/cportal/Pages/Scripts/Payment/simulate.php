<?php
/* var titlehtml = '<table class="tbl rwb greyShadow" style="width:95%;font-size:0.8em;margin:auto" bordercolor="#CCCCCC" border="1"><tr class=""  ><th style="text-align:left">Session</th><td>' + detarr['sestb'] + '</td></tr><tr><th style="text-align:left">Programme</th><td>' + detarr['rstudprog'] + '</td></tr><tr><th style="text-align:left">Level</th><td>' + detarr['rstudlvl'] + '</td></tr><tr><th style="text-align:left">Semester</th><td>' + detarr['semest'] + '</td></tr><tr><th style="text-align:left">Course</th><td>' + detarr['rcourse'] + '</td></tr></table>'; */
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser('ptype');
$PayID = $_POST['PayID'];
$paydet = $dbo->SelectFirstRow("item_tb","","ID=".$PayID);
if(!is_array($paydet)){
  exit("#");
}
$cntrltab = $paydet['ControlTable'];
$cntrltabid = $paydet['ControlTableID'];
//get the control details
$cntrdet = $dbo->SelectFirstRow($cntrltab,"","ID=".$cntrltabid);
$partpayShare = $cntrdet['PartPayShare'];
$partpayStatus = $cntrdet['PartPay'];
//get the 
Box("class=zoomInShort animated faster");
Form("groupname=SimulataParamGrp,action=javascript:void(0),id=SimulataParamGrpid");
TextBoxGroup("width:95%;margin:auto;font-size:0.9em");
TextBox("title=Payment Date,style=width:250px;text-transform:uppercase,id=simpaydate,logo=calendar,type=calendar,text=".date("d/m/Y"));
TextBox("title=Batch/Set,style=width:250px;text-transform:uppercase,id=simbatch,required=true,logo=group,selected=-1",TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"));
$scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title=school,style=width:250px;text-transform:uppercase,id=sim,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
TextBox("title=Study,style=width:250px;text-transform:uppercase,id=simstudy,required=true,onchange=Payment.PaymentType.GenLoader.LoadFac,logo=building-o",$studyarr);//,chain=simstudy:;simfac:;simdept:;simprog:;simlvl:
TextBox("title=Faculty,style=width:250px;text-transform:uppercase,id=simfac,onchange=Payment.PaymentType.GenLoader.LoadDept,logo=server",array(""));
TextBox("title=Department,style=width:250px;text-transform:uppercase,onchange=Payment.PaymentType.GenLoader.LoadProg,id=simdept,logo=tasks",array(""));
TextBox("title=Programme,style=width:250px;text-transform:uppercase,id=simprog,required=true,onchange=Payment.PaymentType.GenLoader.LoadClass,logo=list-alt",array(""));
TextBox("title=Class,style=width:250px;text-transform:uppercase,id=simclass,required=true,onchange=Payment.PaymentType.GenLoader.LoadLevel,logo=users",array(""));
TextBox("title=Level,style=width:250px;text-transform:uppercase,id=simlvl,required=true,logo=list-ol",array(""));
TextBox("title=State of Origin,style=width:250px;text-transform:uppercase,id=simstate,required=true,logo=map",TextBoxSQL("select * from state_tb ORDER BY StateName"));
TextBox("title=Gender,style=width:250px;text-transform:uppercase,id=simgender,required=true,selected=-1,logo=female",array("M"=>"Male","F"=>"Female"));
TextBox("title=Marrital Status,style=width:250px;text-transform:uppercase,id=simstatus,required=true,logo=heart,selected=-1",array("S"=>"Single","M"=>"Married"));
TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=simmodeentry,logo=sign-in,selected=-1",TextBoxSQL("select Level, Name from modeofentry_tb"));
//get the payment control table
$partpaypol = array("3"=>"Full Payment");
if($partpayStatus == "TRUE"){
	if($partpayShare == "HALF"){
		$partpaypol = array("1"=>"First Payment","2"=>"Second Payment","3"=>"Full Payment");
	}else{
		$partpaypol = array("1-1"=>"First Payment (Part)","1-2"=>"First Payment (Complete)","1-3"=>"First Payment (Full)","2-1"=>"Second Payment (Part)","2-2"=>"Second Payment (Complete)","2-3"=>"Second Payment (Full)","3"=>"Full Payment");
	}
}
TextBox("title=Payment Policy,style=width:250px;text-transform:uppercase,id=simpaypol,required=true,logo=star-half",$partpaypol);
_TextBoxGroup();
_Form();
_Box();
//TextBox("title=Mode of Entry,style=width:270px;text-transform:uppercase,id=modeentry,logo=sign-in",TextBoxSQL("select Level, Name from modeofentry_tb"));


/* TextBox("title=Entrance Number,style=width:270px;text-transform:uppercase,id=jambNo,logo=graduation-cap,required=true");
		 TextBox("title=Study,style=width:270px;text-transform:uppercase,id=studstudy,required=true,onchange=Student.BioData.LoadFac,logo=building-o,chain=studstudy:;studfac:;studdept:;studprog:;studlvl:",TextBoxSQL("select * from study_tb where SchoolType = (select Type from school_tb limit 1)"));
		 TextBox("title=Faculty,style=width:270px;text-transform:uppercase,id=studfac,onchange=Student.BioData.LoadDept,logo=server",array(""));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title=Department,style=width:270px;text-transform:uppercase,onchange=Student.BioData.LoadProg,id=studdept,logo=tasks",array(""));
		  TextBox("title=Programme,style=width:270px;text-transform:uppercase,id=studprog,required=true,onchange=Student.BioData.LoadLevel,logo=list-alt",array(""));
		  TextBox("title=Level,style=width:270px;text-transform:uppercase,id=studlvl,required=true,logo=list-ol",array(""));//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)")
		  TextBox("title=Mode of Entry,style=width:270px;text-transform:uppercase,id=modeentry,logo=sign-in",TextBoxSQL("select Level, Name from modeofentry_tb")); */


?>