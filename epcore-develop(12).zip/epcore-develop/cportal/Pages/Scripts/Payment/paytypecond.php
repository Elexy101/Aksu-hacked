<?php
//so far will be called for popup/dropdown
//config.php and Elements.php is already set
 function PayTypeCondValue($param){
     global $dbo;
     //$txt = array("None","State of Origin","Gender","Marital Status","Set/Batch","Mode Of Entering","Department","Faculty/School","Study");
     //$txt = array("None","StateId","Gender","MaritalStatus","StartSes","ModeOfEntry","ProgID","FacID","StudyID");
    global $dbo;
    $cond = (int)$param["Cond"];
    //return "A=".$cond;
    if($cond == 0)return "";
    if($cond == 1)return "#SELECT StateID,StateName FROM state_tb";
    if($cond == 2)return "M=Male&F=Female";
    if($cond == 3)return "S=Single&M=Married";
    if($cond == 4)return "#SELECT SesID, SesName FROM session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC";
    if($cond == 5)return "#SELECT ID, Name FROM modeofentry_tb";
    if($cond == 6){
      //get all faculties
    $facs = $dbo->Select("fac_tb f, study_tb s","f.FacName,f.FacID,s.Name as StudyName","f.StudyID=s.ID");
     if(is_array($facs) && $facs[1] > 0){
         $qstr = "";
        while($indfacs = $facs[0]->fetch_assoc()){
            $qstr .= " UNION SELECT '#' as ProgID, CONCAT('".$dbo->SqlSafe($indfacs['StudyName'])."','-','".$dbo->SqlSafe($indfacs['FacName'])."') as ProgName";
            $qstr .= " UNION ";
            //get all programme in the faculty
            $qstr .= "SELECT p.ProgID, CONCAT('".$dbo->SqlSafe($indfacs['StudyName'])."','-',p.ProgName) as ProgName FROM programme_tb p, dept_tb d, fac_tb f WHERE p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.FacID = ".$indfacs['FacID']; 
        }
        $qstr = ltrim($qstr," UNION ");
        return "#".$qstr;
     }else{
        return "0=Unknown";
     }  
    }
    $studyquery = "SELECT ID, Name FROM study_tb WHERE SchoolType = (SELECT Type FROM school_tb LIMIT 1)";
    if($cond == 7){ //faculty
        //run study query
        $studys = $dbo->RunQuery($studyquery);
        $studyData = [];
        if(is_array($studys) && $studys[1] > 0){
            $qstrs = "";
            while($indstudys = $studys[0]->fetch_assoc()){
                $qstrs .= " UNION SELECT '#' as FacID, '".$dbo->SqlSafe($indstudys['Name'])."' as FacName";
                $qstrs .= " UNION ";
                //get all programme in the faculty
                $qstrs .= "SELECT f.FacID, CONCAT('".$dbo->SqlSafe($indstudys['Name'])."','-',f.FacName) as FacName FROM fac_tb f, study_tb s WHERE f.StudyID = s.ID  AND s.ID = ".$indstudys['ID'];
                $studyData[$indstudys['ID']] = $indstudys['Name'];
            }
            $qstrs = ltrim($qstrs," UNION ");
            return "#".$qstrs;
        }else{
            return "0=Unknown";
         }      
        //return "#SELECT FacID, FacName FROM fac_tb";
    }
    if($cond == 8){
        if(count($studyData)){
         return $dbo->DataString($studyData);
        }else{
          return "#".$studyquery;  
        }
        
    }

    if($cond == 9){ //faculty Group
        return $dbo->DataString(TextBoxSQL("select FacGrpID,FacGrpName from facgroup_tb"));        
    }

    if($cond == 10){ //faculty Group
        return $dbo->DataString(TextBoxSQL("select ID,Name from school_degrees_tb"));        
    }

    if($cond == 11){ //Admision session
        //return "#SELECT SesID, SesName FROM session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC"
        return $dbo->DataString(TextBoxSQL("SELECT 0 as SesID, 'Current' as SesName UNION (SELECT SesID, SesName FROM session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC)"));        
    }

    if($cond == 12){ //prodramme classes
        
        //get all faculties
    $facs = $dbo->Select("fac_tb");
    if(is_array($facs) && $facs[1] > 0){
        
        $qstr = "";
       while($indfacs = $facs[0]->fetch_assoc()){
        //return "#SELECT '#' as ID,'".$dbo->SqlSafe($indfacs['FacName'])."' as Name";
        $qstr .= " SELECT '#' as ClassID, '".$dbo->SqlSafe($indfacs['FacName'])."' as ClassName";
        $qstr .= " UNION ";
           //get the programmes
           $progs = $dbo->RunQuery("SELECT p.ProgID, p.ProgName FROM programme_tb p, dept_tb d, fac_tb f WHERE p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.FacID = ".$indfacs['FacID']);
           if(is_array($progs) && $progs[1] > 0){
            while($indprogs = $progs[0]->fetch_assoc()){
                //$qstr .= "SELECT '#' as ClassID, '".$dbo->SqlSafe($indprogs['ProgName'])."' as ClassName";
                //$qstr .= " UNION ";
                //get all programme in the faculty
                $qstr .= "SELECT ID as ClassID, CONCAT(Name,' - ','".$dbo->SqlSafe($indprogs['ProgName'])."') as ClassName FROM studentclass_tb WHERE ProgID = ".$indprogs['ProgID']." UNION "; 
            }
           }
           
       }
       $qstr = rtrim($qstr," UNION ");
       return "#".$qstr;
    }else{
       return "0=Unknown";
    }
    }
    
    //if($cond == 6)return "#SELECT ID, Name FROM modeofentry_tb";
    return "";
 }

 function PayTypeLevel($param){
     global $dbo;
     
     //select Level, Name from schoollevel_tb where StudyID = ?PStudys? and SchoolTypeID = (select Type from school_tb limit 1) order by Level
     $studys = $dbo->RunQuery("SELECT ID, Name FROM study_tb WHERE SchoolType = (SELECT Type FROM school_tb LIMIT 1)");
    // $studyData = [];
    
     if(is_array($studys) && $studys[1] > 0){
         $qstrs = "";
         while($indstudys = $studys[0]->fetch_assoc()){
            //$qstrs .= "A"; continue;
             $qstrs .= " UNION SELECT '0' as Level, 'ANY' as Name";
             
             $qstrs .= " UNION ";
            
             //get all programme in the faculty
             $qstrs .= "select Level, CONCAT('LEVEL ',Level) as Name from schoollevel_tb where StudyID = {$indstudys['ID']}  and SchoolTypeID = (select Type from school_tb limit 1)";
             //$studyData[$indstudys['ID']] = $indstudys['Name'];
            // continue;
         }
         $qstrs = ltrim($qstrs," UNION ");
         //return "0=".$qstrs;
         return "#".$qstrs;
     }else{
         return "0=Unknown";
      }  
 }
?>