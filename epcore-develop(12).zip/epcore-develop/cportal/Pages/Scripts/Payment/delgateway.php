<?php
$EpModuleName = "pgateway";
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
 function RemoveUpload($data){
    //global $data;
    if(isset($data['Script']) && trim($data['Script']) != "")unlink("../../../../".$data['Script']);
     if(isset($data['ResponseURL']) && trim($data['ResponseURL']) != "")unlink("../../../../".$data['ResponseURL']);
     if(isset($data['RequestURL']) && trim($data['RequestURL']) != "")unlink("../../../../".$data['RequestURL']);
     if(isset($data['FooterImage']) && trim($data['FooterImage']) != "")unlink("../../../../".$data['FooterImage']);
}
 extract($_POST);
  if(!isset($gid) || (int)$gid < 1 || !isset($tpid) || trim($tpid) == "")exit('{"Message":"INVALID DATA SUPPLIED"}');
  if($tpid != $EPTPID)exit('{"Message":"#INVALID TECHNICAL PERSONEL ID (TPID)"}');

  //get the current gatway to delete
  $gatway = $dbo->SelectFirstRow("thirdparty_tb","","ID=".$gid);
  if(!is_array($gatway))exit('{"Message":"INVALID PAYMENT GATEWAY SELECTED"}');

  //delete from database
  $del = $dbo->Delete("thirdparty_tb","ID=".$gid);
  if(!is_array($del))exit('{"Message":"DELETE FAILED"}');
  
  //delete all the files
  RemoveUpload($gatway);
  echo '{"GID":0,"Message":"*'.$gatway['Name'].' DELETED Successfully"}';
 ?>