<?php

//Use to load required detail form for Payment item report
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
 $sch = GetSchool();

 
 Box("style=width:300px,class=zoomInShort animated faster");


      
      TextBoxGroup();
      TextBox("title={$sch['SemLabel']},style=width:280px;text-transform:uppercase,id=preloadsemestp,required=true,logo=star-half-o,selected=-1",TextBoxSQL("(select 0,'ALL ".strtoupper($sch['SemLabel'])."') UNION (select Num,Descr from semester_tb ORDER BY Num)"));
      //  TextBox("title=Class Fee List Type,style=width:250px;text-transform:uppercase,id=classlistfeetype,required=true,logo=list-alt",["paytypeclassdet"=>"Detailed-All","paytypeclass"=>"Sumarized-All","paytypeclassp"=>"Sumarized-Paid","paytypeclassup"=>"Sumarized-Debtors","paytypeclassdetp"=>"Detailed-Paid"]);
      /*  TextBox("title=Order Report By,style=width:250px;text-transform:uppercase,id=orderrept,logo=list-ol",["ordregno"=>"Registration Number","ordpaid"=>"Amount","orddate"=>"Date"]); */
      _TextBoxGroup();
      Line();
      Box("style=width:295px;/*float:left;*/overflow:auto;max-height:355px,class=zoomInShort animated faster");
      $headerd = array(
        "*PItem"=>"ITEM",
       "*Include"=>array("INCLUDE","YES|NO"),
       "-PID"=>"PIID"
      );
      //reload the payment item spread sheet
      SpreadSheet("rowselect=false,style=width:calc(100% - 5px);margin:auto;margin-bottom:6px,id=payitemsreport,multiselect=false,dynamiccolumn=false,dynamicrow=false,minrow=12,rowfilter=true,filtertitle=FILTER PAYMENT ITEMS,filterstyle=width:calc(100% - 5px);margin:auto,disable=PID;PItem",$headerd,"SELECT ItemName,1 as Inc,ID FROM payitem_tb");
      _Box();

     /*  Box("style=width:295px;float:left;overflow:auto;max-height:355px");
    
      SpreadSheet("rowselect=false,style=width:calc(100% - 5px);margin:auto;margin-bottom:6px,id=payreportuserdet,multiselect=false,dynamiccolumn=false,dynamicrow=true,minrow=9",["*Attr"=>"TITLE","*Val"=>"CONTENT"]);
      _Box();
      echo '<div style="clear:both"></div>'; */
      _Box();
   
   

?>