<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

if(!isset($_POST['Ref']))exit(json_encode(["Success"=>false,"Message"=>"#Payment Reference NOT FOUND"]));
$Ref = $_POST['Ref'];
//get payment details
$PayDet = $dbo->SelectFirstRow("order_tb","","TransNum='".$Ref."'");
if(!is_array($PayDet))exit(json_encode(["Success"=>false,"Message"=>"#Payment Record NOT FOUND"]));
$RegNo = $PayDet['RegNo'];

//get the student details
$studDet = GetBasicInfo($RegNo);
if(!is_array($studDet))exit(json_encode(["Success"=>false,"Message"=>'#Reading Student Details Failed']));

//get the student programme
$ProgID = (int)$studDet['ProgID'];
if($ProgID < 1)exit(json_encode(["Success"=>false,"Message"=>'#INVALID STUDENT ACADEMIC RECORD']));

//update the order details
$UpdOrd = $dbo->Update('order_tb',["ProgID"=>$ProgID],"ID=".$PayDet['ID']);


if(is_array($UpdOrd)){ //
    //update payhistory as well if exist
$UpdPayh = $dbo->Update('payhistory_tb',["ProgID"=>$ProgID],"TransID='".$Ref."'");
 exit(json_encode(["Success"=>true,"Message"=>"*Payment Academic Details Updated","ProgName"=>$studDet['Prog'],"Ref"=>$Ref]));
}else{
    exit(json_encode(["Success"=>false,"Message"=>'#UPDATING PAYMENT FAILED']));  
}



?>