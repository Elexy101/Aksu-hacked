<?php
$EpModuleName = "ptype";
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
 
 extract($_POST);
  if(!isset($ptypeid) || (int)$ptypeid < 1)exit('{"Message":"INVALID DATA SUPPLIED"}');

  //get the current gatway to delete
  $ptypearr = $dbo->SelectFirstRow("item_tb","","ID=".$ptypeid);
  if(!is_array($ptypearr))exit('{"Message":"INVALID PAYMENT TYPE SELECTED"}');

  //delete from database
  $del = $dbo->Delete("item_tb","ID=".$ptypeid);
  if(!is_array($del))exit('{"Message":"DELETE FAILED"}');
  
  //delete all the files
 // RemoveUpload($gatway);
  echo '{"GID":0,"Message":"*'.$ptypearr['ItemName'].' DELETED Successfully"}';
 ?>