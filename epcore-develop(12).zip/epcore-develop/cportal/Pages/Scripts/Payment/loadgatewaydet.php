<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
 AllowUser('pgateway');
function NulltoString($obj){
return is_null($obj)?"":$obj;
}
//check if to load only the gateway tbs
if(isset($_POST['gatewaytb'])){
    $selid = isset($_POST['gid'])?$_POST['gid']:0;
    Table("rowselect=false,style=font-size:0.8em;margin:auto;text-align:left;margin-bottom:6px,id=paytbpaygate,multiselect=false,data-type=table,onselect=Payment.PayGateway.LoadPayGateway,rowalt=true,rowfilter=true,filtertitle=FILTER PAYMENT GATEWAY");
    //THeader(array("PAYMENT TYPE"),"style=text-align:left");
   //$PayID = $allset['PayID'];
   $allgatew = $dbo->Select("thirdparty_tb");
   if(is_array($allgatew)){
      if($allgatew[1] > 1){
       while($rw = $allgatew[0]->fetch_assoc()){
   $sel = ((int)$selid == (int)$rw['ID'])?'-1':'';
   TRecord(array($rw['Name'].""),"style=text-align:left,id=".$rw['ID'].",selected=".$sel);
   //TRecord(array($rw['ItemName'].""),"style=text-align:left,id=".$rw['ID'].",selected=true");
       }
      }
   }
   //  THeader(array("PAYMENT ITEM"),"style=text-align:left");
   // TRecord(array("Accptance Fee"),"style=text-align:left");
   // TRecord(array("School Fee"),"style=text-align:left");
   // TRecord(array("Convocation Fee"),"style=text-align:left");
   // TRecord(array("PUTME Fee"),"style=text-align:left");
    _Table();
    exit;
}
//$EPTPID static in config.php
 //get parameter
 if(!isset($_POST['gid']) || (int)$_POST['gid'] <  1)exit('{"Error":"Invalid Payment Gateway Selected"}');
 if($_POST['tpid'] != $EPTPID)exit('{"Error":"INVALID TECHNICAL PERSONEL ID (TPID)"}');
 $gid = $_POST['gid'];
 //get all the gate record
 $gatewrec = $dbo->SelectFirstRow("thirdparty_tb","","ID=".$dbo->SqlSafe($gid));
 if(!is_array($gatewrec))exit('{"Error":"Payment Gateway Not Found"}');
 $curu = _CURURL_;
 $curuarr = explode("cportal/",$curu);
 //reform the result
 $reform[] = ['paygatenametb',NulltoString($gatewrec['Name'])];
 $reform[] = ['paydateedecrtb', NulltoString($gatewrec['Descr'])];
 $reform[] = ['paygateemailtb',NulltoString($gatewrec['Email'])];
 $reform[] = ["paygatephonetb",NulltoString($gatewrec['Phone'])];
 $reform[] = ["paygateaddrtb",NulltoString($gatewrec['Addr'])];
 $reform[] = ["paygatepremtdtb",NulltoString($gatewrec['PrePayMethod'])];
 $reform[] = ["paygatepostmtdtb",NulltoString($gatewrec['PostPayMethod'])];
 $reform[] = ["paygatequerytb",NulltoString($gatewrec['QueryStatusMethod'])];
 $reform[] = ["paygatefinishtb",NulltoString($gatewrec['FinishPayMethod'])];
 $requrl = NulltoString($gatewrec['RequestURL']);
//  $requrl = trim($requrl) != ""?$curuarr[0].$requrl:$requrl;
if(trim($requrl) != ""){
    $requrlarr = explode("/",$requrl);
    $requrl = $requrlarr[count($requrlarr) - 1];
}
 $reform[] = ["paygaterequesturltb",$requrl];
 $resurl = NulltoString($gatewrec['ResponseURL']);
//  $resurl = trim($resurl) != ""?$curuarr[0].$resurl:$resurl;
if(trim($resurl) != ""){
    $resurlarr = explode("/",$resurl);
    $resurl = $resurlarr[count($resurlarr) - 1];
}
 $reform[] = ["paygateresponsetb",$resurl];//RefIndicator
 $scripturl = NulltoString($gatewrec['Script']);
 if(trim($scripturl) != ""){
    $scripturlarr = explode("/",$scripturl);
    $scripturl = $scripturlarr[count($scripturlarr) - 1];
}
 $reform[] = ["paygatescripttb",$scripturl];
 //$reform[] = ["paygatefinishtb",NulltoString($gatewrec['FinishPayMethod'])];
 $reform[] = ["paygatetransindtb",NulltoString($gatewrec['RefIndicator'])];
 $reform[] = ["paygateresponseidtb",NulltoString($gatewrec['NotificationRefID'])];
 //$reform[] = ["payGatefoot",NulltoString($gatewrec['FooterImage'])];

 //get the startus
$staus = $gatewrec['USE'] == "LIVE"?1:0;

$dump = [];

//form the parameter spreadsheet
$demo = $gatewrec['DEMO_PARAM'];
$live = $gatewrec['PARAM'];

//break live to dataarray
$livedataarr = $dbo->DataArray($live);
$demodataarr = $dbo->DataArray($demo);
if(is_array($livedataarr) && $livedataarr > 0){
foreach($livedataarr as $key=>$val){
    $demoval = "";
    if(isset($demodataarr[$key])){
        $demoval = $demodataarr[$key];
        unset($demodataarr[$key]);
    }
    $dump[] = [$key,$demoval,$val];
}
foreach($demodataarr as $dkey=>$dval){
    $dump[] = [$dkey,$dval,""];
}
}




 echo json_encode(["Textbox"=>$reform,"USE"=>$staus,"FooterImage"=>$gatewrec['FooterImage']])."~#split_gateway#~";
 $headerd = array(
    "*GateParam"=>"PARAMETER",
   "*GateDemo"=>"DEMO",
   "*GateLive"=>"LIVE"
  );
  SpreadSheet("rowselect=false,style=width:calc(100% - 16px);margin:auto;margin-bottom:6px,case=none,id=paygateparamspreadsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,rowfilter=true,filtertitle=FILTER GATEWAY PARAMETERS,filterstyle=width:calc(100% - 16px);margin:auto,minrow=12",$headerd,$dump);
?>