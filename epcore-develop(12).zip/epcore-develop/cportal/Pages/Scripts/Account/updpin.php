<?php
 //require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
//check priv
AllowUser("Pin");
/*
"cpin="+cpin+
		             "&npin="+npin+
					 "&cnpin="+cnpin+
					 "&pmaxtry="+maxentry+
					 "&locksw="+pinstate+
					 "&pidletime="+idleTime
                     "&userID="+userID;
*/
//get all post param in var
extract($_POST);

if(trim($cpin) == ""){
    exit("#Invalid Pin");
    }

//check if Pin exist
$exist = $dbo->CheckDbValue(array("Pin"=>$cpin,"UserID"=>$userID),"user_tb");
//exit($cpin);
if($exist === true){
    $query = "UPDATE user_tb SET ";
    //check if new pin $exist
    if(trim($npin) != ""){
        if($npin != $cnpin){
           exit("#New Pin Confirmation Failed, Check and try again");
        }
        //form query Part 
        $query .= "Pin = '".$dbo->SqlSafe($npin)."',";
    }
$query = $query."MaxEntry=".$dbo->SqlSafe($pmaxtry).",IdleTime=".$dbo->SqlSafe($pidletime).",PinStatus=".$dbo->SqlSafe($locksw)." WHERE UserID = $userID";

$rst = $dbo->RunQuery($query);
if(is_array($rst)){
  exit("#");
}
exit("#Update Failed");
    //exit("Pin Correct");
}else{
    exit("Wrong Pin");
}


?>