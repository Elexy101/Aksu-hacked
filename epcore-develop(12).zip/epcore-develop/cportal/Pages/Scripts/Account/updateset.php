<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//check priv
AllowUser("asetting");
//get and validate the login name
if(!isset($_POST['asettingLName'])){
    exit("#Invalid Login Name");
}
if(!isset($_POST['UID'])){
    exit("#Invalid User");
}
$logname = $_POST['asettingLName'];
$UID = (int)$_POST['UID'];
if($UID < 1){exit("#Invalid User");}
$psptup = false;
if(isset($_FILES["userpst_image_file"])){
  $fileTmpLoc = $_FILES["userpst_image_file"]["tmp_name"]; // File in the PHP tmp folder
  if($fileTmpLoc){
      if(move_uploaded_file($fileTmpLoc, $configdir."Files/UserImages/{$UID}.jpg")){
                $psptup = true;
               // $data["Passport"] = $fn."?".mt_rand();
            } else {
               // echo "#Operation Aborted: Cannot Upload Payment Receipt";
                exit("#Operation Aborted: Cannot Upload/Update Passport Photograph");
            }
  }
}

//update user login name
$upd = $dbo->Update("user_tb",array("UserName"=>$logname),"UserID = {$UID}");
if(is_array($upd)){
  exit("#");
}else{
    exit("#Server Error: Update Failed");
}


?>