<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//check priv
AllowUser("Password");
//Get All sent parameters and validate
/* "cpassw="+escape(cpassw)+
					   "&ccpassw="+escape(ccpassw)+
					   "&npassw="+escape(npassw)+
					   "&cnpassw="+escape(cnpassw)+
					   "&remail="+escape(remail)+
					   "&rphone="+escape(rphone)+
					   "&hint="+escape(hint)+
					   "&userlogname="+escape(userlogname);  */
if(!isset($_POST['cpassw']) || !isset($_POST['remail']) || !isset($_POST['rphone']) || trim($_POST['cpassw']) == "" || trim($_POST['remail']) == "" || trim($_POST['rphone']) == ""){
   exit("Password, Recovery Email and Phone Number are Required");
}

extract($_POST);
if($cpassw != $ccpassw){
    exit("Password Confirmation Failed, Check your Password");
}
$ULG = $dbo->SqlSafe($userlogname);
//Confirm from Database the Username and Password 
$enc = $dbo->Select4rmdbtbFirstRw("user_tb","enc","UserLogName = '$ULG'");
if(is_array($enc)){
	  $enc = $enc[0]; //salt
	  $hash = $dbo->Hash($cpassw,$enc); //hash password using the salt
      $hashpw = $dbo->SqlSafe($hash[0]); //get the hashed version
	  //$salt = $hash[1];
	 $rec = $dbo->Select4rmdbtbFirstRw("user_tb","","UserLogName = '$ULG' and UserPassw = '$hashpw'");
     if(!is_array($rec)){
        exit("#Invalid Password");
     }
    //correct password supplied
    $userID = $rec['UserID'];
    $query = "";
    //check if new password exist and confirm
    if(trim($npassw) != ""){
        if($npassw != $cnpassw){
            exit("New Password Confirmation Failed, Check your New Password");
        }
        $nwHash = $dbo->Hash($npassw);

      $query = "UserPassw='". $dbo->SqlSafe($nwHash[0]) ."', enc='". $dbo->SqlSafe($nwHash[1]) ."',";
    }
    //Hint, email and phone Part 
    $hint = $dbo->SqlSafe($hint);
    $remail = $dbo->SqlSafe($remail);
    $rphone =  $dbo->SqlSafe($rphone);
    $query .= "Hint='$hint', remail='$remail', rphone='$rphone'";
    
    //form $query
    $query = "UPDATE user_tb SET ".$query." WHERE UserID = $userID";
    //Run Query 
    $upd = $dbo->RunQuery($query);
    if(is_array($upd)){
       exit("#"); //successful
    }else{
        exit("#Update Failed, Try Again");
    }
}else{
    exit("#Server Error:Invalid User");
}

?>