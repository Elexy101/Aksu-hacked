<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//get the preset name
if(!isset($_POST['PID']) || (int)$_POST['PID'] < 1){
    exit('#INVALID RESULT SETTING PRESET SELECTED');
}
$del = $dbo->Delete("resultinfo_tb","ID=".$_POST['PID']);
if(!is_array($del))exit('#INVALID RESULT SETTING PRESET SELECTED');
exit('*DELETED');

?>