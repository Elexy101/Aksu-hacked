<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
require_once("../../../../general/getinfo.php");
//echo $_POST['RstInfoID'];
if(!isset($_POST['RstInfoID']) || (int)$_POST['RstInfoID'] < 1){
    
        Note();
      echo "INVALID RESULT SETTING SELECTED";
        _Note();
        exit;
    
}
$grdstrc = $dbo->SelectFirstRow("resultinfo_tb","","ID=".$_POST['RstInfoID']);
$gstr = $grdstrc['Grading'];
$grarr = $dbo->DataArray($gstr);
//form spreatsheet data dump
foreach($grarr as $gkey=>$gval){
  $gdump[] = [$gkey,$gval];
}
$headerdd = array(
    "*GrStrRange"=>"RANGE",
    "*GrStrGrade"=>array("GRADE","#SELECT ID,Grade FROM schgrade_tb WHERE RstInfoID=".$_POST['RstInfoID']." AND Status = 1 ORDER BY Level DESC")
   );
SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=grstrsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=all",$headerdd,$gdump);

?>