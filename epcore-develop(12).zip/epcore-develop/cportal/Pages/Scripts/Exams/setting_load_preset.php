<?php

    $configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
require_once("../../../../general/getinfo.php");
if(!isset($_POST['PresetID']) || (int)$_POST['PresetID'] == 0)exit("#INVALID PRESET SELECTED");
$FromScript = 1;
   $_POST['RstInfoID'] = $_POST['PresetID'];
   include "setting_loadui.php";

?>