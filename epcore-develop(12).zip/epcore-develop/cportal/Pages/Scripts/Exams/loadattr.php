<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
require_once("../../../../general/getinfo.php");
$rstattrobj = [];

$stDet = $dbo->SelectFirstRow("result_tb r, studentinfo_tb s","r.*,s.ProgID,s.ClassID,s.StartSes","r.ID=".$_POST['RstID']." AND (r.RegNo=s.RegNo OR r.RegNo=s.JambNo) LIMIT 1");

$OtherResult = [];
$TComment = "";
$HTComment = "";
if(is_array($stDet)){
   
 if(isset($stDet['OtherResult']) && !empty($stDet['OtherResult'])){
    $OtherResult = json_decode($stDet['OtherResult'],true); 
 }
 if(!empty($stDet['TComment']))$TComment = $stDet['TComment']; 
 if(!empty($stDet['HTComment']))$HTComment = $stDet['HTComment']; 
 
}
//get the result other attr
$rstattr = $dbo->SelectFirstRow("resultinfo_tb","ResultAttr,PortalResultDisplay","ID = (SELECT GrdStrucID FROM school_tb LIMIT 1)");
$sumarrydis = [];
if(is_array($rstattr)){
    $rstattrstr = $rstattr['ResultAttr'];
    if(!is_null($rstattrstr) && trim($rstattrstr) != ""){
        $rstattrobj = json_decode($rstattrstr,true);
          if(!$rstattrobj)$rstattrobj=[];
    }

    $portaldisstr = $rstattr['PortalResultDisplay'];
    if(!is_null($portaldisstr) && trim($portaldisstr) != ""){
        $sumarrydis = json_decode($portaldisstr,true);
          if(!$sumarrydis)$sumarrydis=[];
    }
}

//the result summary lookup
$arraysdis = [
    "GPA"=>["GPA",(is_array($stDet)?$stDet["GPA"]:"")],
    "CGPA"=>["CGPA",(is_array($stDet)?$stDet["CGPA"]:"")],
    "TOT"=>["TOTAL SCORE",(is_array($stDet)?$stDet["OTS"]:"")],
    "AVG"=>["AVERAGE SCORE",(is_array($stDet)?$stDet["OAS"]:"")],
    "POS"=>["POSITION (LEVEL)",(is_array($stDet)?GetStudentResultPosition($stDet,["ProgID"=>$stDet['ProgID'],"StartSes"=>$stDet['StartSes']]):"")],
    "POSClass"=>["POSITION (CLASS)",(is_array($stDet)?GetStudentResultPosition($stDet,["ProgID"=>$stDet['ProgID'],"ClassID"=>$stDet['ClassID'],"StartSes"=>$stDet['StartSes']],true):"")],
    "COP"=>["CLASS OF PASS",(is_array($stDet)?$stDet["COP"]:"")]
  ];
  //GetStudentResultPosition($indrst,["ProgID"=>$ProgID])

if(count($rstattrobj) < 1)die("");
$arrhed = $arrRec = [];
foreach($arraysdis as $key=>$pdis){
    if(isset($sumarrydis[$key]) && (int)$sumarrydis[$key] == 1){
        $arrhed[] = $pdis[0];
        $arrRec[] = $pdis[1];
    }
}

//Summary table
Table("style=width:calc(100% - 12px);font-size:0.8em;margin:auto;margin-top:10px;text-align:left,id=totalrpt,multiselect=false,data-type=table");
//form the sumary table data

  THeader($arrhed,"style=text-align:center");
 
  TRecord($arrRec,"data-id=rstsum,style=font-weight:bolder");

 _Table();

 Line();

Box("style=width:100%;overflow:auto");
Box("style=width:590px;overflow:auto");
Box("style=overflow:auto;max-height:280px;width:320px;float:left");
$ids = [];
$header = ["*AItemN"=>"ITEMS","*ATRemark"=>"REMARK"];
foreach($rstattrobj as $inattr){
    $dump = [];
   if((int)$inattr["ENABLE"] != 1)continue;
   $allattr = trim($inattr["ATTR"]);
   if($allattr == "")continue;
   //echo '<div class="grpbxtitle">'.$inattr["GN"].'</div>';
   $header["*AItemN"] = $inattr["GN"];
   $rmk = $inattr["REMARK"];
   $rmkarr = explode(",",$rmk);
   if(count($rmkarr) > 0){
       
       foreach($rmkarr as $k=>$v){
        $rmkarr[$k] = trim($v);
       }
    $header["*ATRemark"] = array("REMARK",$dbo->DataString($rmkarr));
   }
   $allattrs = explode(",",$allattr);
   foreach($allattrs as $indallattrs){
    $remark = "";
    if(isset($OtherResult[str_replace(" ","_",strtolower(trim($inattr["GN"])))][str_replace(" ","_",strtolower(trim($indallattrs)))][0])){
        $remark = $OtherResult[str_replace(" ","_",strtolower(trim($inattr["GN"])))][str_replace(" ","_",strtolower(trim($indallattrs)))][0];
    }
   
    $dump[] = [trim($indallattrs),$remark];
   }
   //echo json_encode($dump);
   $ids[] = [strtolower(str_replace(" ","_",$inattr["GN"]))."sprsheet",$inattr["GN"],$rmk];
   /* echo '<div style="display:none" id="'.str_replace(" ","_",strtolower($inattr["GN"])).'GN">';
   echo $inattr["GN"];
   echo '</div>'; */
   SpreadSheet("rowselect=false,style=width:280px;margin:auto;margin-top:6px;margin-bottom:6px,id=".str_replace(" ","_",strtolower($inattr["GN"]))."sprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,readonly=AItemN,dynamicrow=false,minrow=-1",$header,$dump);
}
echo '<div style="display:none" id="otherResults">';
echo json_encode($ids);
echo '</div>';
_Box();
Box("style=overflow:auto;max-height:300px;width:270px;float:left");
echo '<div class="grpbxtitleot">COMMENTS</div>';
TextBoxGroup();
TextBox("title=CLASS TEACHER,style=width:250px;font-size:1.2em,id=rstclassteachercoment,required=false,logo=edit,type=multiline,text=".CleanText($TComment));

_TextBoxGroup();
_Box();
_Box();
TextBox("title=HEAD TEACHER,style=width:250px;font-size:1.2em;display:none,id=rstheadteachercoment,required=false,logo=edit,type=multiline,text=".CleanText($HTComment));
echo '<div style="clear:left"></div>';
_Box();
?>