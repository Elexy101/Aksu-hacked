<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser("exsetting");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

$sch = $dbo->SelectFirstRow("school_tb","Type");
$data =  json_decode($_POST['data'],true);
$rstattrsprsheet = $dbo->DataArray($data['rstattrsprsheet']);
 $attrstr = "";
 $attrarr = [];
	if(isset($rstattrsprsheet['MaxDataRow']) && (int)$rstattrsprsheet['MaxDataRow'] > 0){
    
		for($rw = 1; $rw <= (int)$rstattrsprsheet['MaxDataRow']; $rw++){
      if(isset($rstattrsprsheet[$rw.'_deleted']) && $rstattrsprsheet[$rw.'_deleted'] == "true")continue;
      //get the items
      $GN = trim($rstattrsprsheet[$rw.'_2']);
      
      $attr = trim($rstattrsprsheet[$rw.'_3']);
      
      $remarks  = $rstattrsprsheet[$rw.'_4'];
      $def = $rstattrsprsheet[$rw.'_5'];
      $enable = (int)$rstattrsprsheet[$rw.'_6'];
      if($GN == "" && $attr == "")continue;
      
      $attrarr[] = ["GN"=>$GN,"ATTR"=>$attr,"REMARK"=>$remarks,"DEF"=>$def,"ENABLE"=>$enable];
    }
    //exit("#". $dbo->DataString($attrarr));
  }
  if(count($attrarr) > 0){
    $attrstr = json_encode($attrarr);
  }
 
//exit("#".$attrstr);
//$gradesprsheet = $data['gradesprsheet'];$tb = "schgrade_tb";
//$fieldArray = [1=>"ID","Desc","Grade","Level","PASS","Status"];
//$Req = [2,3,4,5];$keyIndex = 1;
$rstinfoID = $data['rpreset'];
//exit("#".$rstinfoID);
$errarr = [];
$grdsh = SheetDatabind($data['gradesprsheet'],"schgrade_tb",[1=>"ID","Desc","Grade","Level","PASS","Status","RstInfoID || $rstinfoID"],[2,3,4,5],-1,"","RstInfoID = $rstinfoID");
//SheetDatabind($data,$tb,$fieldArray,$Req=[],$keyIndex=-1,$keyRelation="",$deletecond="1=1")
if ($grdsh !== true) $errarr[] = "Error occured while updating Grading. : ".$grdsh;

$classofpass = SheetDatabind($data['classpsprsheet'],"classofpass_tb",[1=>"ID","ClassName","Point","Descr","Abbr","RstInfoID || $rstinfoID","SchoolID || ".$sch['Type']],[2,3,5],-1,"","RstInfoID = $rstinfoID");
if ($classofpass !== true) $errarr[] = "Error occured while updating Class Of Pass. : ".$classofpass;

$rstreport = SheetDatabind($data['rstrptsetsprsheet'],"report_tb",[1=>"ID","Title","Descr","Param","Logo","Signatories","Enable","Marker"],[2,3,4]);
if ($rstreport !== true) $errarr[] = "Error occured while updating Report Sheets Details : ".$rstreport;

$scrstruc = SheetDatabind($data['scrstrsprsheet'],"scorestruc_tb",[1=>"ID","Title","MaxScore","RstInfoID || $rstinfoID"],[2,3],-1,"","RstInfoID = $rstinfoID");
if ($scrstruc !== true) $errarr[] = "Error occured while updating Score Structure : ".$scrstruc;

$gradestr = $dbo->DataString(SheetToArray($data['grstrsprsheet'],1,2));
$clofpassstr = $dbo->DataString(SheetToArray($data['clspstrsprsheet'],1,2));

$textfarr = $dbo->DataArray($data['TextData']);//paycheckID
//exit();

if((int)$textfarr['paycheckStatus'] == 1 && (int)$textfarr['paycheckID'] == 0)$textfarr['paycheckStatus'] = 0;
$textfarr['paycheckBases'] = (int)$textfarr['paycheckBases']; //reset status to off if no payment type set

//reset status to off if no payment type set
//showgpa=1&showcgpa=-1&showtot=0&showavg=0&showpos=0
//form the display sttings
$DisSet = '{"GPA":'.$textfarr['showgpa'].',"CGPA":'.$textfarr['showcgpa'].',"TOT":'.$textfarr['showtot'].',"AVG":'.$textfarr['showavg'].',"AVGClass":'.$textfarr['showavgclass'].',"POS":'.$textfarr['showpos'].',"POSClass":'.$textfarr['showposclass'].',"POSCourse":'.$textfarr['showposcourse'].',"COP":'.$textfarr['showcop'].'}';
$insdata = ["ProbationLimit"=>$textfarr['problimttb'],"ProbationFlag"=>$textfarr['probflagtb'],"WithdrawFlag"=>$textfarr['withflagtb'],"ProbationTCH"=>$textfarr['probtchtb'],"Grading"=>$gradestr,"ClassOfPass"=>$clofpassstr,"PrePayID"=>$textfarr['paycheckID'],"PrePayBases"=>$textfarr['paycheckBases'],"PrePayStatus"=>$textfarr['paycheckStatus'],"PortalResultDisplay"=>$DisSet,"ResultAttr"=>$attrstr,"ViewOnApprove"=>$textfarr['allowapr']];
//exit("*".json_encode($insdata));
$up = $dbo->Update("resultinfo_tb",$insdata,"ID = ".$rstinfoID);
if(!is_array($up)) $errarr[] = "Error occured while updating Grading Structure, Class of Pass Structure and Settings - ".$data['TextData'];
if(count($errarr) > 0){
  echo "#".implode("</br>",$errarr);
}else{
  //update result control table
  $rstcntrup = $dbo->Update("resultcontrol_tb",["CheckRstMenuID"=>$textfarr['rstsubmenudd']]);
   echo "*SAVED SUCCESSFULLY";
}
//echo $dbo->DataString($insdata) ;

/* data['TextData'] = Page.DataString("rstsetgrpelem");problimttb=1.50&probflagtb=PROBATION&withflagtb=WITHDRAWAL&probtchtb=18
				data['gradesprsheet'] = _('gradesprsheet').GetDataString();
				data['classpsprsheet'] = _('classpsprsheet').GetDataString();
				data['grstrsprsheet'] = _('grstrsprsheet').GetDataString();
                data['clspstrsprsheet'] = _('clspstrsprsheet').GetDataString(); */
                //exit($data['gradesprsheet']);

?>