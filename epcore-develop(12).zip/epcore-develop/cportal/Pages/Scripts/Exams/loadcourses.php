<?php

//sleep(4);
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
LoadFile("basic","../../../../");
//AllowUser("RUpload");
/*require_once("../../../../epconfig/TaquaLB/Elements/Elements.php"); 
require("../../../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
/*var fields = ["sestb","rstudstudy","rstudfac","rstuddept","rstudprog","rstudlvl","semest"];
		 var datstr = "";
		 for(var dd=0; dd<fields.length; dd++){
			 var fobj = _(fields[dd]);
             datstr += fields[dd] + "=" + fobj.ValueContent() + ":" + rawescape(fobj.TextDisplay()) +  "&"
		 }*/
extract($_POST);
//print_r($_POST);
//exit();
if(isset($dept) && isset($sem) && isset($lvl) && isset($stid)){
    //LoadStaffCourses("c.Lvl = " .$lvl." AND c.Sem = ".$sem." AND c.DeptID = ".$dept." AND c.StudyID = ".$stid." AND StartSesID <= $ses AND (EndSesID >= $ses OR EndSesID = 0)");
    LoadStaffCourses("c.Lvl = " .$lvl." AND c.Sem = ".$sem." AND c.DeptID = ".$dept." AND StartSesID <= $ses AND (EndSesID >= $ses OR EndSesID = 0) AND CourseStatus = 0");
    FlatButton("text=Reload,logo=undo,onclick=Exams.ResultUpload.LoadCourse(),style=width:262px;margin:auto;border-radius:0px;margin-top:10px,title=Reload Courses,id=rstuploadrelodc");
    /*$courses = $dbo->Select("course_tb c,fac_tb f, dept_tb d, study_tb s, session_tb se, programme_tb p, schoollevel_tb l, semester_tb sem","c.CourseCode,c.Title,c.CH,c.CourseID,c.StudyID,c.Lvl,c.Sem,c.DeptID, p.ProgName, s.Name, se.SesID, se.SesName,f.FacID, f.FacName, d.DeptID as Dept, d.DeptName,l.Name as Level,sem.Sem as Semester","c.Lvl = " .$lvl." AND c.Sem = ".$sem." AND c.DeptID = ".$dept." AND c.StudyID = ".$stid." AND f.FacID = d.FacID AND d.DeptID = p.DeptID AND p.ProgID = c.DeptID AND c.Lvl = l.Level AND l.SchoolTypeID = (select Type from school_tb limit 1) AND l.StudyID = c.StudyID AND se.SesID = $ses AND sem.ID = c.Sem AND s.ID = c.StudyID");
    if(is_array($courses)){
       if($courses[1] > 0){
           Table("rowselect=true,style=width:250px;font-size:0.7em;margin:auto,id=coursetb,onselect=Exams.ResultUpload.Load,onunselect=,multiselect=false,data-type=table");
             //$rtnstr .= __TRecord(array(""),"id=0");
             THeader(array("CODE","TITLE","CH"));
          while($course = $courses[0]->fetch_array()){
              $trid = $course[3];
             TRecord(array(str_replace(" ","&nbsp;",$course[0]),'<div style="text-align:left">'.$course[1].'</div>',$course[2]),"data-id={$trid}");//"data-id=$reglw"
             //get fac and dept det 
             //$facDept = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p","f.FacID,f.FacName,d.DeptID,d.DeptName,p.ProgID,p.ProgName","f.DeptID = d.DeptID and p.DepID = d.DeptID and p.ProgID = ".$course['DeptID']);
             $SesID = $course['SesID'];$SesName = rawurlencode($course['SesName']);$StudyID = $course['StudyID'];$StudyName = rawurlencode($course['Name']);$FacID = $course['FacID'];$FacName = rawurlencode($course['FacName']);$DeptID = $course['Dept'];$DeptName = rawurlencode($course['DeptName']);$ProgName = rawurlencode($course['ProgName']);$LvlName = rawurlencode($course['Level']);$Lvl = $course['Lvl'];$SemID = $course['Sem'];$SemName = rawurlencode($course['Semester']);$ProgID = $course['DeptID'];
             Hidden($trid."_det","sestb=$SesID:$SesName&rstudstudy=$StudyID:$StudyName&rstudfac=$FacID:$FacName&rstuddept=$DeptID:$DeptName&rstudprog=$ProgID:$ProgName&rstudlvl=$lvl:$LvlName&semest=$SemID:$SemName");
          }
          _Table();
       }else{
          Icon("exclamation-triangle");
        echo " NO COURSE FOUND";  
       }
    }else{
        Icon("exclamation-triangle");
    echo " INTERNAL ERROR: CANNOT LOAD COURSES ".$courses; 
    }*/
}else{
    Icon("exclamation-triangle");
    echo " INVALID SELECTION";
}


?>