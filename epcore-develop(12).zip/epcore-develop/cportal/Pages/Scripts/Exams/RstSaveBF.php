<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//discol&sdatastr&rstparam
if(isset($_POST['discol'])){
  extract($_POST);
  //form data strings
  $discolDS = $dbo->DataArray($discol);
  $sdatastrDS = $dbo->DataArray($sdatastr);
  $rstparamDS = $dbo->DataArray($rstparam);

  //var fields = ["sestb","rstudstudy","rstudfac","rstuddept","rstudprog","rstudlvl","semest"];
  $Lvl = rawurldecode($rstparamDS["rstudlvl"]);
  $Sem = rawurldecode($rstparamDS["semest"]);
  $Ses = rawurldecode($rstparamDS["sestb"]);
  $progid = rawurldecode($rstparamDS["rstudprog"]);
  $courseID = rawurldecode($rstparamDS["rcourse"]);
  $studyID = rawurldecode($rstparamDS["rstudstudy"]);
  //Check if Approval row Exist
    $queryapprv = "SELECT * FROM resultapprove_tb WHERE ProgID = $progid AND Ses = $Ses AND Lvl = $Lvl AND Sem = $Sem AND CourseID = $courseID AND StudyID = $studyID LIMIT 1";
  $apprst = $dbo->RunQuery($queryapprv);
  $apprv = null;//hold the result approval status 
  if(is_array($apprst)){
      if($apprst[1] > 0){
          $apprstrw = $apprst[0]->fetch_array();
          if($apprstrw['Status'] == "TRUE"){
              exit("INVALID OPERATION: ALREADY APPROVED");
          }else{
            $apprv = false;
          }
      }
  }
  //SheetID=sprstupload&MaxDataRow=10
  $totrw = (int)$sdatastrDS["MaxDataRow"];
  //$update string;
  $updstr = "";
  $inststr = "";
 //exit($sdatastr);
  //loop through each row
  for($rw=1; $rw <= $totrw; $rw++){
      $RegNo = rawurldecode($sdatastrDS[$rw."_".$discolDS['RegNo']]);
      if(trim($RegNo) == ""){
        continue;
      }
     $CA = (int)rawurldecode($sdatastrDS[$rw."_".$discolDS['CA']]);
     $Exm = (int)rawurldecode($sdatastrDS[$rw."_".$discolDS['Exm']]);
     $RstID = (int)rawurldecode($sdatastrDS[$rw."_ID"]);
     $cond = $RstID > 0?"ID=$RstID":"RegNo='$RegNo' AND Lvl=$Lvl AND Sem=$Sem AND SesID=$Ses";
     //check if result exist;
     $strest = $dbo->SelectFirstRow("result_tb","",$cond);
     $newrst = "$courseID=$CA|$Exm";
     //$perfinst = true;
     if(is_array($strest)){ //if exist
        //get rst 
        $rstarr = $dbo->DataArray($strest["Rst"]);
        $rstarr[$courseID] = $CA."|".$Exm;
        //form the datastring
        $newrst = $dbo->DataString($rstarr,false); //no data encoding
        //$updstr .= "UPDATE result_tb SET Rst = '$newrst' WHERE ID = ".$strest["ID"].";";
        if($strest["Rst"] == $newrst){ //if no changes continue
          continue;
        }else{ //if update found
          //check if apprv row not exist (i.e not approved at least one)
          if($apprv === null){
            //perform update
            $updstr .= "UPDATE result_tb SET Rst = '$newrst' WHERE ID = ".$strest["ID"].";";
          }else{
            //insert
            $inststr .= "INSERT INTO result_tb (`ID`, `RegNo`, `Lvl`, `Sem`, `SesID`, `Rst`, `outst`) VALUES (NULL,'$RegNo',$Lvl,$Sem,$Ses,'$newrst','');";
          }
        }

       // $vvv .= $strest["Rst"]." <==> ".$newrst. " ; ";
     }else{ //if not exist - insert
        $inststr .= "INSERT INTO result_tb (`ID`, `RegNo`, `Lvl`, `Sem`, `SesID`, `Rst`, `outst`) VALUES (NULL,'$RegNo',$Lvl,$Sem,$Ses,'$newrst','');";
     }
  }
//echo $inststr.$updstr;
 // echo $vvv;
 if(trim($inststr.$updstr) != ""){
  $dump = $dbo->Connection->multi_query($inststr.$updstr);
  if(!$dump){
    echo "#Server Error: ".$convar->error;
  }else{
     echo "*Result Saved : ".$inststr.$updstr;
  }
 }else{
   echo "No Change Found";
 }
  
}



?>