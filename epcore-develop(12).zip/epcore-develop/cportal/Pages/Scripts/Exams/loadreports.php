<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");

//get all result reports (broad sheet)
$dump = [];
       $reports = $dbo->RunQuery("Select ID, `Title`,`Descr`,`Param`,`Logo`,`Enable`, `Script` FROM report_tb WHERE Marker = 'ResultBroadSheet' AND Enable = 1");
       if(is_array($reports) && $reports[1] > 0){ //
          while($indreports = $reports[0]->fetch_assoc()){
            $dump[] = $indreports;
          }
       }

       echo json_encode($dump);


?>