<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
function Error($title,$text){
  Box("class=defaultTabText");
  Box("style=color:red");Icon("exclamation-triangle fa-3x");_Box();
  Box();echo $title;_Box();  
  Box();echo $text;_Box();  
_Box();
}
AllowUser("RAprov");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request
//Get the UserID
$UID = $_POST['UID'];
$limit = $_POST['limit'];
$val = $dbo->SqlSafe($_POST['val']);
         $deptCond = "(ra.ProgID > 0)";
         $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=$UID");
          if(isset($staffDet)){
            $Depts = trim($staffDet['DeptIDs']);
            if($Depts != ""){
              $deptCond = "(ra.ProgID = ".str_replace("~"," OR ra.ProgID = ",$Depts).")";
            }
          }
          //f.FacName,d.DeptName,p.ProgName
          if(trim($val) != ""){
              $deptCond .= " AND ((c.CourseCode LIKE '%$val%' OR c.Title LIKE '%$val%' OR l.Name LIKE '%$val%' OR se.Sem LIKE '%$val%' OR s.SesName LIKE '%$val%' OR st.Name LIKE '%$val%' OR f.FacName LIKE '%$val%' OR d.DeptName LIKE '%$val%' OR p.ProgName LIKE '%$val%' OR ra.ID LIKE '$val')";
              //if has space
          $valarr = explode(" ",$val);
          if(count($valarr) > 1){
            $deptCond .= " OR (";
            foreach($valarr as $indval){
              $deptCond .= " ( c.CourseCode LIKE '%$indval%' OR c.Title LIKE '%$indval%' OR l.Name LIKE '%$indval%' OR se.Sem LIKE '%$indval%' OR s.SesName LIKE '%$indval%' OR st.Name LIKE '%$indval%' OR f.FacName LIKE '%$indval%' OR d.DeptName LIKE '%$indval%' OR p.ProgName LIKE '%$indval%' OR ra.ID LIKE '$indval') AND";  
            }
            $deptCond = rtrim($deptCond,"AND");
            $deptCond .= " )";
          }
         //exit($deptCond);
          $deptCond .=")";
          }

          
         // $limit = round((0.0816 * (5000 - 100)) + 100);
          //print_r($_POST);
          $filter = $_POST['filter'];
          LoadResultAppr($deptCond,$limit,$val,$filter);
         
          

?>