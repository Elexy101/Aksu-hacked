<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
//get the preset name
if(!isset($_POST['PrID']) || (int)$_POST['PrID'] < 1){
    Note();
echo 'INVALID RESULT SETTING PRESET SELECTED';
    _Note();
    exit();
}
$preset = $dbo->SelectFirstRow("resultinfo_tb","SettingName","ID=".$_POST['PrID']);
if(!is_array($preset)){
    Note();
echo 'ERROR READING SETTING DETAILS';
    _Note();
    exit();
}
if(!isset($_POST['isdelete'])){

TextBoxGroup("font-size:0.9em;margin:auto");
TextBox("title=Preset Name,style=width:250px,id=updaterstpreste,logo=cogs,text=".CleanText($preset['SettingName']));
_TextBoxGroup();
}else{
    Note();
echo 'You are about to delete Preset:<br/> <b style="font-size:1.2em">'.$preset['SettingName'].'</b><br/>Note: All result saved with this preset will require an <b>Update-Save</b> to another preset';
    _Note();
}

?>