<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("RAprov");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

if(!isset($_POST["MaxDataRow"]))exit("#Invalid Parameter");
//exit("*Maxmum Row = ".$_POST['MaxDataRow']);
$maxrw = (int)$_POST["MaxDataRow"];
if($maxrw > 0){
    $cnt = 0;
    for($i=1;$i<=$maxrw;$i++){
        if(!isset($_POST[$i."_9"]))continue;
        $RSID = $_POST[$i."_9"];
        $Lock =(int) $_POST[$i."_10"];
        $Status =(int) $_POST[$i."_11"];
        $RstStatus = $dbo->SelectFirstRow("resultapprove_tb","Status,Editable","ID = $RSID");
        if(is_array($RstStatus)){
            $DbStaus = $RstStatus[0] == 'TRUE'?1:0;
            $DbLock = $RstStatus[1] == 'TRUE'?0:1; //if editable is true meaning it is not lock (0) else if false => Lock(1)
            if($DbStaus == $Status && $DbLock == $Lock){ //check if desame i.e no changes needed
                continue;
            }
            $UbpStatus = $Status == 1?"TRUE":"FALSE";
            $UbpLock= $Lock == 1?"FALSE":"TRUE"; //if lock meaning noy editable
            $GINc = $DbStaus != $Status && $Status == 0?", GroupID = GroupID + 1":"";//if disabeld
                //GroupID Increament 
            
          
         $query = "UPDATE resultapprove_tb SET Editable='".$UbpLock."', Status = '".$UbpStatus."'".$GINc." WHERE ID = $RSID";
         $rst = $dbo->RunQuery($query);
         if(is_array($rst)){
            $cnt++;
         }
        }
        //echo $RSID . "=" . $Status . "<br />";
    }
    if($cnt < 1){
        echo "No Changes Found";
    }else if($cnt == 1){
        echo "*1 Result Updated";
    }else{
        echo "*$cnt Results Updated";
    }
}else{
    echo "#No Result Found";
}

?>