<?php
//require_once("../../../../general/TaquaLB/Elements/Elements.php");

$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
if(!isset($_POST['otherRst']) || !isset($_POST['RID'])){
    die("#INVALID PARAMETER");
}

$otherRsts =  [];
if(trim($_POST['otherRst']) != ""){
    $otherRsts = json_decode($_POST['otherRst'],true);
    if(!$otherRsts){
$otherRsts = [];
    }
}

if(count($otherRsts) > 0){
    $attrarr = [];
    foreach($otherRsts as $indotherRsts){
        $sheetid = $indotherRsts[0];
        $GN = $indotherRsts[1];
        $Remarks = explode(",",$indotherRsts[2]);
        $attrarr[str_replace(" ","_",strtolower(trim($GN)))] = [];
        if(!isset($_POST[$sheetid]))continue;
        $sheetdata = $_POST[$sheetid];
        $sheetdataArr = $dbo->DataArray($sheetdata);
// $attrstr = "";
 
	if(isset($sheetdataArr['MaxDataRow']) && (int)$sheetdataArr['MaxDataRow'] > 0){
    
		for($rw = 1; $rw <= (int)$sheetdataArr['MaxDataRow']; $rw++){
      if(isset($sheetdataArr[$rw.'_deleted']) && $sheetdataArr[$rw.'_deleted'] == "true")continue;
      //get the items
      $Attr = trim($sheetdataArr[$rw.'_1']);
      
      $rmk = "";
      if(trim($sheetdataArr[$rw.'_2']) != ""){
          $rmk = (int)$sheetdataArr[$rw.'_2'];
      $rmk = isset($Remarks[$rmk])?trim($Remarks[$rmk]):$sheetdataArr[$rw.'_2'];
      }
      
      
      if($Attr == "" && trim($rmk) == "")continue;
      
      $attrarr[str_replace(" ","_",strtolower(trim($GN)))][str_replace(" ","_",strtolower(trim($Attr)))] = [$sheetdataArr[$rw.'_2'],$Attr,$GN,$rmk];
    }
    //exit("#". $dbo->DataString($attrarr));
  }
    }
}

$attrrst = json_encode($attrarr);
$TComment = $_POST['TComment'];
$HTComment = $_POST['HTComment'];

//update
$upd = $dbo->Update("result_tb",["OtherResult"=>$attrrst,"TComment"=>$TComment,"HTComment"=>$HTComment],"ID=".$_POST['RID']);

if(!is_array($upd))die("#More Result Update Failed");

die("*Student Result Updated");

?>