<?php
//exit($_FILES["sprstupload_file"]["tmp_name"]);
$SubDir = urldecode($_POST['SubDir']);
$Require = urldecode($_POST['Require']);
require_once("../../../../../../".$SubDir.$Require"Excel/CLASSES/PHPExcel.php");
include "../Gen/loadexcel.php";
$colregno = (int)$_POST['colregno'];
    $colca = (int)$_POST['colca'];
    $colexam = (int)$_POST['colexam'];
$excellarray = ExcelToArray("sprstupload_file",$colregno,[$colca,$colexam]);
if(is_array($excellarray)){
    echo json_encode($excellarray);
}else{
    echo $excellarray;
}
/* if(!isset($_FILES["sprstupload_file"])){
    exit("@"); //no file
}
$path_parts = pathinfo($_FILES["sprstupload_file"]["name"]);
$extension = $path_parts['extension'];
if($extension != 'xls' &&  $extension != 'xlsx')exit("@@"); //invalid file
//move file to temp location
do{
    $randnum = mt_rand(3000000,9000000000);
}while(file_exists($randnum.".".$extension));

//move the file
if(move_uploaded_file($_FILES["sprstupload_file"]["tmp_name"],$randnum.".".$extension)){
   // $exceltype = strtolower(trim($extension)) == "xls"?"Excel5":"Excel2007";
   $exceltype = PHPExcel_IOFactory::identify($randnum.".".$extension);
    $objReader = PHPExcel_IOFactory::createReader($exceltype);
    //exit($exceltype);
    if ($exceltype === 'Excel5' || $exceltype === 'Excel2007') {
        $objReader->setReadDataOnly(true);
    }
    //$objReader->setReadDataOnly(true);
    
    $objPHPExcel = $objReader->load($randnum.".".$extension);
    $objWorksheet = $objPHPExcel->getActiveSheet();
    
    $highestRow = $objWorksheet->getHighestRow(); // e.g. 10
    $highestColumn = $objWorksheet->getHighestColumn(); // e.g 'F'
    
    $highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);
    //get the reg,ca and exam lookup col
    //rstudstudy=2&rstudfac=4&rstuddept=34&rstudprog=34&rstudlvl=1&semest=1&sestb=8&rcourse=1420&sprstupload_file=?&colregno=2&colca=4&colexam=5
    //"sestb","rstudstudy","rstudfac","rstuddept","rstudprog","rstudlvl","semest","rcourse"
    $colregno = (int)$_POST['colregno'];
    $colca = (int)$_POST['colca'];
    $colexam = (int)$_POST['colexam'];
    $highestColumnNumber = $highestColumnIndex + 1;
    if($highestColumnNumber < 3 || $highestColumnNumber < $colregno || $highestColumnNumber < $colca || $highestColumnNumber < $colexam)exit("@@@@"); //invalid data in excel or invalid column number specified
    $colregnoIndex = $colregno - 1;
    $colcaIndex = $colca - 1;
    $colexamIndex = $colexam - 1;
    
    //loop to convert the excel to array
    //using the regNo as key
    $DataArray = [];
    for ($row = 1; $row <= $highestRow; ++$row) {
        $regNo = $objWorksheet->getCellByColumnAndRow($colregnoIndex, $row)->getValue();
        if(trim($regNo) == "")continue;
        $ca = $objWorksheet->getCellByColumnAndRow($colcaIndex, $row)->getValue();
        $exam = $objWorksheet->getCellByColumnAndRow($colexamIndex, $row)->getValue();
        $DataArray[strtolower(trim($regNo))] = [(float)$ca,(float)$exam];
    }
    //get the regno,ca and exam column num
    
    unlink($randnum.".".$extension);
    echo json_encode($DataArray);
}else{
  echo "@@@"; //cannot read/move file 
} */



//$fileName = $_FILES["studpassp_image_file"]["name"]; // The file name
//$fileTmpLoc = $_FILES["studpassp_image_file"]["tmp_name"]; // File in the PHP tmp folder
/* if(isset($_FILES["sprstupload_file"])){
    echo $_FILES["sprstupload_file"]["name"];
}else{
    echo "not seen";
} */


?>