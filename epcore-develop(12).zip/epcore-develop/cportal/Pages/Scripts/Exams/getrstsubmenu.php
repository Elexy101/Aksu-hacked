<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
$rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=,id=rstmenuddtb");
$GroupID = isset($_POST["GroupID"])?$dbo->SqlSafe($_POST["GroupID"]):0;
//get all subs
$allsub = $dbo->RunQuery("select ID, Name from new_apply_tb WHERE GroupID=$GroupID ORDER BY MenuOrder");
if(is_array($allsub)){
    if($allsub[1] > 0){
        while($indallsub = $allsub[0]->fetch_assoc()){
            $txt = $indallsub['Name'];
            $idtxt = (int)$indallsub['ID'];
            $rtnstr .= __TRecord(array($txt),"id={$idtxt}");
        }
    }
}
$rtnstr .= ___Table(); 
echo $rtnstr;

?>