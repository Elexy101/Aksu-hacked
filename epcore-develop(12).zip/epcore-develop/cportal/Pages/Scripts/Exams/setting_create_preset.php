<?php

    $configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
require_once("../../../../general/getinfo.php");
if(!isset($_POST['PresetName']) || trim($_POST['PresetName']) == "")exit("#INVALID PRESET NAME");
if(!isset($_POST['PID'])){//create
    //check if already exix
$presetexixt = $dbo->SelectFirstRow("resultinfo_tb","ID","SettingName='".$dbo->SqlSafe($_POST['PresetName'])."'");
if(is_array($presetexixt))exit("#RESULT SETTINGS PRESET ALREADY EXIST");
//insert the new resultinfo
$newrstinfoID = $dbo->InsertID2("resultinfo_tb",["SettingName"=>$_POST['PresetName'],"Grading"=>"","ClassOfPass"=>"","ProbationLimit"=>0,"ProbationFlag"=>"PROBATION","WithdrawFlag"=>"WITHDRAWAL"]);
if(is_numeric($newrstinfoID)){
   $FromScript = 1;
   $_POST['RstInfoID'] = $newrstinfoID;
   include "setting_loadui.php";
}else{
    exit("#CREATING RESULT SETTING PRESET FAILED - ".$newrstinfoID);
}
}else{
    $PID = (int)$_POST['PID'];
    if($PID < 1)exit("#INVALID RESULT PRESET SELECTED");
    $presetexixt = $dbo->SelectFirstRow("resultinfo_tb","ID","ID=".$PID);
    if(!is_array($presetexixt))exit("#RESULT SETTINGS PRESET NOT FOUND");
    $upd = $dbo->Update("resultinfo_tb",["SettingName"=>$_POST['PresetName']],"ID=".$PID);
    if(is_array($upd)){
        exit("*PRESET NAME UPDATED");
    }
}


?>