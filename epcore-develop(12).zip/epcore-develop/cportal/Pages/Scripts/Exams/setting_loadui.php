<?php

//echo 'sss';
if(!isset($FromScript)){
    $configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
require_once("../../../../general/getinfo.php");
}

if(!isset($sch)){
    $sch = GetSchool();
   }

//********Special Update************** */
if(!isset($settinarr)){
       //get all the exam settings
     $allexamset = $dbo->Select("resultinfo_tb");
     $settinarr = [];
     $grdstrc = [];
     if(is_array($allexamset) && $allexamset[1] > 0){
      $settinarr = [];
      $selectedsteID = 1;
      $setselect = isset($_POST['RstInfoID'])?(int)$_POST['RstInfoID']:1;
      while($indexamset = $allexamset[0]->fetch_assoc()){

if(count($grdstrc) < 1 || (int)$indexamset['ID'] == $setselect){
  $grdstrc = $indexamset;
  $selectedsteID = $indexamset['ID'];
}
$settinarr[$indexamset['ID']] = $indexamset['SettingName'];
      }
     }
}
 
$themesetp = "";
if(count($settinarr) == 0){
    $settinarr["-1"] = DropDownLineLogoItem("No Preset Found","exclamation-triangle");
    $themesetp = "error";
    $selectedsteID = "-1";
}
// $settinarr["2"] = "Testing Setting";
     $settinarr["0"]=DropDownLineLogoItem("New Preset","plus");
     Form("groupname=rstsetgrpelem,action=javascript:Exams.ResultSetting.PerformSave(),id=grprstsetfrm");
    // echo $selectedsteID;
     DropDownLine("id=rpreset,selected=$selectedsteID,onselect=Exams.ResultSetting.Load,onedit=Exams.ResultSetting.Edit,theme=$themesetp",$settinarr);
     //[1=>"General Settings","New Settings","Remedier Settings"]
     //********Special Update************** */

     GroupBox("title=Grading,id=rstsetgradegrp,size=2*1,logo=thermometer-quarter ");
     Box("style=overflow:auto; max-height:350px");
     $headerd = array(
      "-GrID"=>"ID",
      "*GrTitle"=>"TITLE",
      "*GrCode"=>"CODE",
      "*GrPoint"=>"POINT",
      "*GrStatus"=>array("STATUS","0=FAIL&1=PASS"),
      "*GrEnable"=>array("ENABLE","YES|NO"),
      "-RstInfoID"=>'RstInfoID'
     );
     SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=gradesprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=7,class=sortable",$headerd,"Select ID, `Desc`,`Grade`,`Level`,`PASS`,`Status`,`RstInfoID` FROM schgrade_tb WHERE RstInfoID=".$selectedsteID);
     _Box();
      _GroupBox();

      //class of pass
      GroupBox("title=Class of Passs,id=rstsetclasspassgrp,size=2*1,logo=check-circle ");
      Box("style=overflow:auto; max-height:350px");
      $headerdc = array(
        "-ClID"=>"ID",
       "*ClClass"=>"CLASS",
       "*ClPoint"=>"POINT",
       "*ClDescr"=>"DESCRIPTION",
       "*ClAbr"=>"ABBREVIATION",
       "-CRstInfoID"=>'RstInfoID',
       "-SchoolID"=>'RstInfoID'
      );
      
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=classpsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9",$headerdc,"Select ID, `ClassName`,`Point`,`Descr`,`Abbr` FROM classofpass_tb WHERE SchoolID = ".$sch['Type']." AND RstInfoID=".$selectedsteID);
      _Box();
       _GroupBox();

       //grade str
      GroupBox("title=GRADING STRUCTURE,id=rstsetdradestrucgrp,size=1*1,logo=table ");
      Box("style=overflow:auto; max-height:350px");
      $headerdd = array(
       "*GrStrRange"=>"RANGE",
       "*GrStrGrade"=>array("GRADE","#SELECT ID,Grade FROM schgrade_tb WHERE RstInfoID=".$selectedsteID." AND Status = 1 ORDER BY Level DESC")
      );
      if(count($grdstrc) < 1){
      //get the grade structure
      $grdstrc = $dbo->SelectFirstRow("resultinfo_tb","","RstInfoID=".$selectedsteID);
      }
      $gdump = array();
      $clsofpassdump = array();
      $problimit = '';
      $probflag = '';
$withflag = '';
$probtch = '';
$rstattr = [];
      if(is_array($grdstrc)){
        $problimit = $grdstrc['ProbationLimit'];
        $probflag = $grdstrc['ProbationFlag'];
        $withflag = $grdstrc['WithdrawFlag'];
        $probtch = $grdstrc['ProbationTCH'];

        if(!is_null($grdstrc['ResultAttr']) && trim($grdstrc['ResultAttr']) != ""){
          $rstattr = json_decode($grdstrc['ResultAttr'],true);
          if(!$rstattr)$rstattr=[];
        }
$gstr = $grdstrc['Grading'];
$grarr = $dbo->DataArray($gstr);
//form spreatsheet data dump
foreach($grarr as $gkey=>$gval){
  $gdump[] = [$gkey,$gval];
}

//classof pass
$clstr = $grdstrc['ClassOfPass'];
$clarr = $dbo->DataArray($clstr);
//form spreatsheet data dump
foreach($clarr as $cpkey=>$cpval){
  $clsofpassdump[] = [$cpkey,$cpval];
}
      }
      
      //get all grade from database
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=grstrsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9",$headerdd,$gdump);
      _Box();
       _GroupBox();

       //class of pass str
      GroupBox("title=CLASS OF PASS STRUC.,id=rstsetclpassstrucgrp,size=1*1,logo=th ");
      Box("style=overflow:auto; max-height:350px");
      $headerdc = array(
       "*ClStrRange"=>"RANGE",
       "*ClStrGrade"=>array("CLASS","#SELECT ID,ClassName FROM classofpass_tb WHERE SchoolID = ".$sch['Type']." AND RstInfoID=".$selectedsteID." ORDER BY Point DESC")
      );
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=clspstrsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9",$headerdc,$clsofpassdump);
      _Box();
       _GroupBox();

       //Score Fields
      GroupBox("title=SCORE STRUCTURE,id=rstsetscorestrucgrp,size=1*1,logo=percent");
      Box("style=overflow:auto; max-height:350px");
      $headerdg = array(
        "-ScrStrID"=>"ID",
       "*ScrStrTitle"=>"TITLE",
       "*ScrStrTotal"=>"MAXIMUM",
       "-SRstInfoID"=>"RstInfoID"
      );
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=scrstrsprsheet,multiselect=false,cellfocus=,cellblur=Exams.ResultSetting.ToFloat,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9",$headerdg,"Select ID, Title, MaxScore from scorestruc_tb where RstInfoID=".$selectedsteID);
      _Box();
       _GroupBox();

       GroupBox("title=Payment,id=rstsetpaygrp,size=1*1,logo=money");
       //Line();
       TextBoxGroup();
       $prepaystatus = (int)$grdstrc['PrePayStatus'];
       $display = $prepaystatus == 1?"block":"none";
       Switcher("id=paycheckStatus,state=$prepaystatus,text=Payment Verification,style=width:100%,info=Verify Student Payment before Result Display,ontext=yes,offtext=no,align=right,onchange=Exams.ResultSetting.TogglePaySel");
       _TextBoxGroup();

       Box("id=selprepaybx,style=display:$display");
       Line();
       TextBoxGroup();
       TextBox("title=Pre-Payment Type,style=width:250px;text-transform:uppercase,id=paycheckID,logo=money,selected={$grdstrc['PrePayID']}",TextBoxSQL("select ID, ItemName from item_tb WHERE studType = 'r' ORDER BY ItemName",array(0=>"SELECT PRE-PAYMENT TYPE")));
       Note();
        echo "Student Portal will verify Student Payment Status of the Selected Payment Type, before Result is made visible";
       _Note();
       _TextBoxGroup();
       Line();
       TextBoxGroup();
       
       TextBox("title=Pre-Payment Bases,style=width:250px;text-transform:uppercase,id=paycheckBases,logo=money,selected={$grdstrc['PrePayBases']}",array(1=>"FULL ".$sch['SemLabel']." Payment","PART ".$sch['SemLabel']." Payment"));
       Note();
        echo "<b>FULL</b> - Student must Pay FULL {$sch['SemLabel']} Payment before Result can be viewed <br/>
        <b>PART</b> - Student must Pay atleast PART {$sch['SemLabel']} Payment before Result can be viewed";
       _Note();
       _TextBoxGroup();
       _Box();

       _GroupBox();

       

         GroupBox("title=Display,id=rstsetdispcgrp,size=1*1,logo=laptop");
         Box("style=max-height:350px; overflow:auto");
TextBoxGroup();
$displayset = is_null($grdstrc['PortalResultDisplay'])?'{"GPA":1,"CGPA":-1,"TOT":0,"AVG":0,"POS":0,"COP":1,"POSClass":0,"POSCourse":0}':$grdstrc['PortalResultDisplay'];
$displaysetobj = json_decode($displayset,true);
Switcher("id=showgpa,state={$displaysetobj['GPA']},text=GPA Display,style=width:100%;font-size:1.1em,info=Show Grade Point Average,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showcgpa,state={$displaysetobj['CGPA']},text=CGPA Display,style=width:100%;font-size:1.1em,info=Show Cumulative Grade Point Average,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showtot,state={$displaysetobj['TOT']},text=Total Score Display,style=width:100%;font-size:1.1em,info=Show Total Score,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showavg,state={$displaysetobj['AVG']},text=Average Display,style=width:100%;font-size:1.1em,info=Show Average Score,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showavgclass,state={$displaysetobj['AVGClass']},text=Class Average Display,style=width:100%;font-size:1.1em,info=Show Class Average Score,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showpos,state={$displaysetobj['POS']},text=Position Display (Level),style=width:100%;font-size:1.1em,info=Show Position by Level,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showposclass,state={$displaysetobj['POSClass']},text=Position Display (Class),style=width:100%;font-size:1.1em,info=Show Position by Class,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
Switcher("id=showposcourse,state={$displaysetobj['POSCourse']},text=Position Display (Course),style=width:100%;font-size:1.1em,info=Show Position by Course,ontext=Visible,offtext=Disabled,align=right,showstate=true");
Switcher("id=showcop,state={$displaysetobj['COP']},text=COP Display,style=width:100%;font-size:1.1em,info=Show Class of Pass,ontext=Visible,offtext=Disabled,defaulttext=Hidden,align=right,showstate=true");
_TextBoxGroup();
         _Box();
         _GroupBox();

                
GroupBox("title=Other Attribute,id=rstsetoattrgrp,size=2*1,logo=graduation-cap ");
/*  TextBoxGroup();
 TextBox("title=Probation TCH,style=width:250px;text-transform:uppercase,id=probtchtb,required=true,logo=tasks,text=".str_replace(array("=",","),array('\=','\,'),$probtch));
 _TextBoxGroup(); */
 $dumpa = [];
 if(count($rstattr) > 0){
   foreach($rstattr as $rind=>$rstattrdet){
     $valus = isset($rstattrdet['REMARK'])?$rstattrdet['REMARK']:"";
     $rstattrdet['DEF'] = isset($rstattrdet['DEF'])?$rstattrdet['DEF']:"";
     $dumpa[] = [$rind,$rstattrdet['GN'],$rstattrdet['ATTR'], $valus,$rstattrdet['DEF'],$rstattrdet['ENABLE']];
   }
 }
/*  $dumpa=[
   [1,"PSYCHOMOTOR","Honesty, Obedience, Punctuality, Self Control, Sociality",1],
   [2,"AFFECTIVE","Sports, Handling of Tools, Communication Skills, Painting & Drawing, Politness",1],
 ]; */
 $headerrra = array(
  "-AttrGrpID"=>"ID",
  "*AttrGroup"=>"GROUP",
  "*Attrs"=>"ATTRIBUTES",
  "*Rmk"=>"REMARKS", 
  "*AttrDefault"=>"DEFAULT",
  "*AttrEnable"=>array("ENABLE","YES|NO")
 );
 Box("style=width:100%;overflow:auto");
 SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=rstattrsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=5,case=none",$headerrra,$dumpa);
 _Box();
 _GroupBox();

       GroupBox("title=Controls,id=rstsetsettcgrp,size=1*1,logo=wrench ");
       /* $problimit = '';
      $probflag = '';
$withflag = '';
$probtch = ''; */

          TextBoxGroup();
          TextBox("title=Probation Limit,style=width:250px;text-transform:uppercase,id=problimttb,logo=tachometer-alt,required=true,text=".str_replace(array("=",","),array('\=','\,'),$problimit));
          TextBox("title=Probation Flag,style=width:250px;text-transform:uppercase,id=probflagtb,required=true,logo=flag,text=".str_replace(array("=",","),array('\=','\,'),$probflag));
          TextBox("title=Withdrawal Flag,style=width:250px;text-transform:uppercase,id=withflagtb,required=true,logo=flag,text=".str_replace(array("=",","),array('\=','\,'),$withflag));
          TextBox("title=Probation TCH,style=width:250px;text-transform:uppercase,id=probtchtb,required=true,logo=tasks,text=".str_replace(array("=",","),array('\=','\,'),$probtch));
          Note();
          echo 'Total Allowable Credit Hours on Probation';
         _Note();
         
     
        
        _TextBoxGroup();
        Line();

        TextBoxGroup();
        Switcher("id=allowapr,state={$grdstrc['ViewOnApprove']},text=VIEW ON APPROVED,style=width:100%;font-size:1.1em,info=Make visible when Approved,ontext=on,offtext=off,align=right,showstate=false");
        _TextBoxGroup();
       _GroupBox();

       
     

       TitleLine("text=Global Settings,style=margin-top:15px");
       //report settings
       GroupBox("title=Portal Menu,id=rstsetpmenugrp,size=1*1,logo=cogs ");
       TextBoxGroup();
       //get the menu id for result
       $menuid = $dbo->SelectFirstRow("resultcontrol_tb");
       $MainMenuId = 0; $SubMenuId = 0;$wherepart = "";
       if(is_array($menuid)){ //if result control found
        $SubMenuId = (int)$menuid['CheckRstMenuID'];
        if($SubMenuId > 0){
          //get the mainid
          $curenGID = $dbo->SelectFirstRow('new_apply_tb','GroupID','ID='.$SubMenuId);
          if(is_array($curenGID)){ //if the current group id is set
            $MainMenuId = (int)$curenGID['GroupID'];
            if($MainMenuId > 0)$wherepart = 'WHERE GroupID='.$MainMenuId;
          }
        }
       }
       TextBox("title=Main Menu,style=width:250px;text-transform:uppercase,id=rstmainmenudd,onchange=Exams.ResultSetting.LoadMenu,logo=sitemap,selected=$MainMenuId",TextBoxSQL("select ID, Name from new_apply_group_tb WHERE Enable =1 ORDER BY MenuOrder"));
       TextBox("title=Sub Menu,style=width:250px;text-transform:uppercase,id=rstsubmenudd,logo=sitemap,selected=".$SubMenuId,TextBoxSQL("select ID, Name from new_apply_tb $wherepart ORDER BY MenuOrder"));
      
     _TextBoxGroup();
       _GroupBox();

         //report settings
         GroupBox("title=Reports,id=rstsetreportgrp,size=3*1,logo=cogs ");
         Box("style=overflow:auto");
         Note();
          echo 'PARAMETER - Data String Format (Key1=Value1&key2=Value2 ...)<br />SIGNATARIES - Json Data Format ({"SIGNATORY1":{"Field1":"Default1","Field2":"Default2",...,"SUB SIGNATORY":{"Field1":"Default1","Field2":"Default2",...}}},"SIGNATORY2":{"Field1":"Default1","Field2":"Default2",...} ......)<br />Note: Feild IDs - "1"=>Signature, "2"=>Name, "3"=>Date ';
         _Note();
         $headerrr = array(
          "-RstRptID"=>"ID",
          "*RptTitle"=>"TITLE",
          "*RptDescr"=>"DESCRIPTION",
          "*RptParam"=>"PARAMETER",
          "*RptLogo"=>"LOGO",
          "*RptSig"=>"SIGNATORIES",
          "*RptEnable"=>array("ENABLE","YES|NO"),
          "-RptMarker"=>"Marker"
         );
         $dump = [];
         $reports = $dbo->RunQuery("Select ID, `Title`,`Descr`,`Param`,`Logo`,`Enable`, `Script`, `Marker`, `Signatories` FROM report_tb WHERE Marker = 'ResultBroadSheet'");
         if(is_array($reports) && $reports[1] > 0){ //
            while($indreports = $reports[0]->fetch_assoc()){
              $dump[] = [$indreports['ID'],$indreports['Title'],$indreports['Descr'],$indreports['Param'],$indreports['Logo'],$indreports['Signatories'],$indreports['Enable'],$indreports['Marker']/* ,"logo"=>"*upload","info"=>"Set Report","action"=>"Exam.ResultSetting.SetReport(".$indreports['ID'].")" */];
            }
         }
  /* ["logo"] = "#history";
                    $dump[count($dump) - 1]["info"] = "Outdated Copy";
                    $dump[count($dump) - 1]["disable"] = "true"; */
         SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=rstrptsetsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=1,case=none",$headerrr,$dump);
         _Box();
          _GroupBox();
          _Form();



?>