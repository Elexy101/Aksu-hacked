<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request

$rtnstr = "";
  
      $paypol = "";
	 $id = $dbo->SqlSafe($_POST["tbid"]);
	 //$paypol = trim(GetPayPolicy($_REQUEST['RegNo'],$_REQUEST['Lvl'],$_REQUEST['PayID'],true));
	  //$schpay = $dbo->Select4rmdbtbFirstRw("schoolpayment_tb");
	 /* $payItem = $dbo->Select4rmdbtbFirstRw("item_tb","","ID=".$_REQUEST['PayID']);
	  $studType = trim($payItem["studType"]);
	  //$partpay = $schpay['PartPay'];
	  if($studType  == "f"){
		  $paypol = "3=FULL PAYMENT";
	  }else{
         $partpayShare = $schpay['PartPayShare'];
		 if($partpayShare == "HALF"){
			 $paypol = "1=FIRST PAYMENT&2=SECOND PAYMENT&3=FULL PAYMENT";
		 }else{
			 $paypol = "1_1=FIRST PAYMENT(PART)&1_2=FIRST PAYMENT(COMPLETE)&1_3=FIRST PAYMENT(FULL)&2_1=SECOND PAYMENT(PART)&2_2=SECOND PAYMENT(COMPLETE)&2_3=SECOND PAYMENT(FULL)&3=FULL PAYMENT";
		 }
		 GetPayPolicyRem($RegNo,$Lvl,$PayID)
	  }*/
     $paypolarr = GetPayPolicyRem($_REQUEST['RegNo'],$_REQUEST['Lvl'],$_REQUEST['PayID']);  
	 //echo $paypolarr;exit();
	//if($paypol != "" && $paypol != "#"){
		//$phpf is created in config.php
		//$paypolarr = $phpf -> DataArray($paypol);
		$sel = isset($_REQUEST['Sel'])?$_REQUEST['Sel']:"";
		if(count($paypolarr) > 0){
			$paypol = __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=,id={$id}tb");
			foreach($paypolarr as $pid => $val){
				$selstr = "";
				if($sel == $pid){
                   $selstr = ",selected=-1";
				}
				$pid = str_replace("_","-",$pid);
              $paypol .= __TRecord(array(ucwords(strtolower($val))),"id={$pid}{$selstr}");
			}
			$paypol .= ___Table();
		}
	//}	
	if($sel != ""){
		Hidden("selectseen","true");
	}
 
echo $paypol;
?>