<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
$_POST['CORE'] = $_POST['Core'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
$crit = $dbo->SqlSafe($_POST['crit']);
$val = $dbo->SqlSafe($_POST['val']);
$callerId = isset($_POST['callId'])?$_POST['callId']:"";
$onselect = isset($_POST['onselect'])?$_POST['onselect']:"";
$onunselect = isset($_POST['onunselect'])?$_POST['onunselect']:"";
$domain = $dbo->SqlSafe($_POST['domain']);
$criteria = $_POST['criteria']; 
$startindex = (int)$dbo->SqlSafe($_POST['startindex']);
$imgdis = isset($_POST['img'])?$_POST['img']:"Passport";
$dir = isset($_POST['dir'])?$_POST['dir']:"";
$ext = isset($_POST['ext'])?".".trim($_POST['ext']):""; //thumbnailtext
$thumbnailtext = isset($_POST['thumbnailtext'])?trim($_POST['thumbnailtext']):"";
$thumbnailtitle = isset($_POST['thumbnailtitle'])?trim($_POST['thumbnailtitle']):"";
//$pre = $dbo->SqlSafe(trim($_POST['pre']));
//

$criteriaArr = explode(";",$criteria);
$cond = "";
$orderBy = "";
$img = $crit == "imgsc"?true:false;
$shrtcd = substr($val,0,2);
$cond = "";
$fieldsarr = array(); //hold the database field
$displcolNmArr = array(); //hold the display
$queryfieldArr = array(); //hold the select fields in query string
$firstID = "";$ordby = "";
foreach($criteriaArr as $indcrit){ //get individual criterias
	$indcritArr = explode(":",$indcrit); //get the db fieldname and the displayname
	$haveAS = 0;
	$queryfield = $indcritArr[0];
	if(count($indcritArr) > 1){ //if it has a display column name set it
	//$displcolNmArr[$indcritArr[0]] = $indcritArr[1];
	$displcolNmArr[] = $indcritArr[1];
	$queryfield = $queryfield. " AS `".$indcritArr[1]."`";
	$haveAS = 1;
	}
	$fieldsarr[] = $indcritArr[0];
	$queryfieldArr[] = $queryfield;
	
	$cond .= $indcritArr[0] . " LIKE '%{$val}%' or ";
	if($firstID == ""){ //if the first field form order query
        $ordby = "ORDER BY `".$indcritArr[$haveAS]."`";
		$firstID = $indcritArr[$haveAS];
	}
	
}
$cond = rtrim($cond," or ");
if($val == "::first" || $val == "::last" || $val == "::all"){ //if short code
   $cond = "1=1";
}
if($val == "::first"){
 
  $orderBy = $ordby." LIMIT 1"; //order by first criteria
}else if($val == "::last"){
   $orderBy = $ordby." desc LIMIT 1";
}else {
$orderBy = $ordby." LIMIT {$startindex},500";
}
$val = strtoupper($val);

if($img == false){
	/* tbl rwb greyShadow */
  Table("rowselect=true,style=width:100%;font-size:0.7em;margin:auto,id={$callerId},onselect={$onselect},onunselect={$onunselect},multiselect=false,data-type=table");
 // Hidden($callerId."_objtype","tbl");
}else{
	if($startindex == 0 ){
		ThumbNailBox("id={$callerId},onselect={$onselect},onunselect={$onunselect},data-type=thumbnail");
	}else{
		$curthumbNGroup = $callerId;
        $curthumbSelFunc = $onselect;
        $curthumbUnSelFunc = $onunselect;
	}

}

global $rwcnter;		   
if($startindex == 0 && $img == false){ //if first trip and not image critaria create the table headers
 THeader($displcolNmArr); //give the header
}else{ //if other trip, set the rowcounter to start from the new row number
	
	$rwcnter = $startindex;		 
}
//$difField = $pre == "p"?"Accept AS det":"id AS det";
//will be used to differentiate studentinfo_tb  and pstudentinfo_tb i.e Accept will always be 0 which is used for pstudentinfo_tb while id will always be greater than 0, for studentinfo_tb
//if($pre != "a"){
	
	$dbfie = implode(", ",$queryfieldArr);
	$addf = array($imgdis,$thumbnailtext,$thumbnailtitle);
	foreach($addf as $indaddf){
       if(!in_array($indaddf,$displcolNmArr)){
         $dbfie = $dbfie . ", ".$indaddf;
	   }
	}
	//echo "SELECT ".$dbfie . " FROM $domain WHERE ". $cond ." ".$orderBy;
   $studs = $dbo->Select4rmdbtb($domain,$dbfie,$cond ." ".$orderBy);
//}else{
 //  $studs = $dbo->RunQuery("select RegNo, JambNo, SurName, FirstName, OtherNames, Passport, id AS det from studentinfo_tb where $cond union select RegNo, JambNo, SurName, FirstName, OtherNames, Passport, Accept AS det from pstudentinfo_tb where $cond ".$orderBy);
//}
		  if(is_array($studs)){
			   $tot = $studs[1];
			  // echo "total: {$tot}";
			   if($studs[1] > 0){
				   $cnt = 1;
				   while($stud = $studs[0]->fetch_array()){
					   //loop through all display fields to format value (color the search value in the result)
					   $rwarr = array();
					   $rwid = $stud[$firstID]; //the value of the first dbfield
					  // print_r($stud);
					   $ThumbNtxt = isset($stud[$thumbnailtext])?$stud[$thumbnailtext]:$rwid;
					   $ThumbNtitle = isset($stud[$thumbnailtitle])?$stud[$thumbnailtitle]:$rwid;
					   foreach($displcolNmArr as $displayNm){
                           $dbval = strtolower($stud[$displayNm]);
						   $vallw = strtolower($val);
						   $fval = str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",$dbval);
						  // echo $vallw . " => ". $dbval."<br />";
						  // echo $fval;
                          $rwarr[] = strtoupper($fval);
					   }
					  /* $regno = $stud[$fieldsarr[0]]."";
					   //if(trim($regno) == ""){
						//   $regno = trim(strtoupper($stud["JambNo"]));
					  // }
					  if($regno == ""){continue;}
					  // $Name = strtoupper($stud["UserLogName"]);
					  //format the ID (First D)
					  $reglw = strtolower($regno);
						   $vallw = strtolower($val);
						   $regno = strtoupper(str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",$reglw));
                       $UName = strtoupper($stud["UserName"]);
					 //  $det = $stud["det"];
					  // if($crit == "regsc"){
						   
					  // }else{
					   $nmlw = strtolower($UName);
						   //$vallw = strtolower($val);
					   $NameS = strtoupper(str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",$nmlw));*/
					  // }
					   $sel = "";
					  /* if($cnt == 1 || $cnt == 2 || $cnt == 4){
						   $sel = "selected=1:2";
					   }*/

					   if($img == false){
                         TRecord($rwarr,"data-id=$rwid,id=$rwid");
						// Hidden($callerId."_rw_".$rwcnter."_1_det",$det);
					   }else{
						   $passpval = $stud[$imgdis];
						   $dir = trim($dir) != ""?rtrim($dir,"/")."/":"";
                          $passp = $dir.$passpval.$ext;
						  $id = $callerId."_user_".$passpval;
						  //echo $id;
						  
						   $ThumbNtxt = strtoupper(str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",strtolower($ThumbNtxt)));
						  // echo $ThumbNtxt;
						  $NameS = EscapeString($ThumbNtxt);
						  $TitleS = EscapeString($ThumbNtitle);
						  ThumbNail("src=$passp ,title=$TitleS , text=$NameS, id=$id, data-id=$rwid, base=".$configdir);
						 Hidden($rwid."_det",$passp);
						 /* $path = "";
						  if(file_exists("../../../".$passp) && trim($passp) != ""){
						list($width, $height, $type, $attr) = getimagesize("../../../".$passp);
	                     // list($width, $height, $type, $attr) = getimagesize("../../../../epconfig/UserImages/Student/777777777AD.jpg");
	                    list($w,$h,$o) = AutoFit(75,80,$width,$height,10);
						  }else{
							  $passp = "../epconfig/TaquaLB/Elements/Images/imglogosm.jpg";
							  list($w,$h) = array(65,43);
						  }
                          Box("class=ThumbNail,title=$Name,onclick={$onselect}(this)");
	                       Box("class=ImgBox");
						  echo '<img src="'.$passp.'" style="width:'.$w.'px;height:'.$h.'px " alt="'.$Name.'" /> ';
							_Box();
							Box("class=TextBox");
								echo $regno;
							_Box();
							_Box();*/
						
						
					   }
					   
					   
					   $cnt++;
				   }
				   if($img){ClearFloat();}
			   }
		   }
		   if($studs[1] < 500){ //if record seen is less thean the total per trip, cover the table (meaning end the loading)
		   //echo "ssss";
		   if($img == false){
		     _Table($callerId);
		   }else{
			   Hidden("totrw_{$callerId}",$studs[1]+1);
			   _ThumbNailbox();
		   }
			 //echo "<input type=\"hidden\" id=\"totrw_{$callerId}searchStud\" value=\"{$studs[1]}\" />
			  // ";
			// echo '<div id="searchlst"></div>';
		   }else{
			 if($img == false){
			   if($startindex == 0){//first trip only
			   echo "<input type=\"hidden\" id=\"sel_{$callerId}\" value=\"\" />
			   <input type=\"hidden\" id=\"data_{$callerId}\" value=\"\"
	            data-multiselect=\"false\" 
			    data-lastselect=\"\"
		       />";
			   }
			   echo "</table>";
			 }
		   }

?>