<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request
//get the student payment parameters
$rtnstr = "";
$spillStr = ExtraLevelString();
$candidate = false;
$noncandidate = false;
  if(isset($_POST["StudyID"]) || isset($_POST["progID"])){
	$StudyID = isset($_POST["StudyID"])?$dbo->SqlSafe($_POST["StudyID"]):0;
	 $progID = isset($_POST["progID"])?$dbo->SqlSafe($_POST["progID"]):0;
  }else if(isset($_POST["RegNo"]) ){
	  $RegNo = $dbo->SqlSafe($_POST["RegNo"]);
     $studdet = $dbo->Select4rmdbtbFirstRw("studentinfo_tb","","RegNo='{$RegNo}' or JambNo='{$RegNo}'");
	 $studType = "r";
	 if(isset($_REQUEST['PayID'])){
        $payItem = $dbo->Select4rmdbtbFirstRw("item_tb","","ID=".$_REQUEST['PayID']);
	    $studType = trim($payItem["studType"]);
	 }
	 $studdetp = NULL;
	 //check p stud
	 if(!is_array($studdet)){
	 $studdetp = $dbo->Select4rmdbtbFirstRw("pstudentinfo_tb","","RegNo='{$RegNo}' or JambNo='{$RegNo}'");
	 }
	 //if entrance student
	 if($studType == "f"){
		 $StudyID = 0;
      $candidate = true;
	  //if not a student and a candidate
	  if(!is_array($studdet) && !is_array($studdetp)){
        $noncandidate = true;
	  }
	 }else{
	 if(is_array($studdet)){
       $StudyID = $dbo->SqlSafe($studdet["StudyID"]);
	 $progID = $dbo->SqlSafe($studdet["ProgID"]);
	 }else{
		
		if(is_array($studdetp)){
          $StudyID = $dbo->SqlSafe($studdet["StudyID"]);
	      $progID = $dbo->SqlSafe($studdet["ProgID"]);
		  $candidate = true;
		}else{//if not a candidate as well 
		$StudyID = 0;
           $candidate = true;
		   $noncandidate = true;
		}
	 }
	 }
  }
  if(isset($StudyID)){
	if((int)$StudyID < 1){
		//get based on prog
		$sudobj = $dbo->SelectFirstRow("study_tb s, programme_tb p, dept_tb d, fac_tb f","s.ID","p.ProgID = $progID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
		if(is_array($sudobj))$StudyID = $sudobj['ID'];
	}
	 $id = $dbo->SqlSafe($_POST["tbid"]);
	 if($candidate){
        $rst = $noncandidate == true?array("PAYEE",1):array("ENTRANCE",1);
	 }else{
		 
	 $rst = $dbo->RunQuery("select Level, Name from schoollevel_tb where StudyID = $StudyID and SchoolTypeID = (select Type from school_tb limit 1) order by Level");
	 }
	 if(is_array($rst)){ //if no error
		if(isset($_POST['def']) && trim($_POST['def']) != ""){ //if default drop down option set
			//get the key and value;
			$exp = explode(":",$_POST['def']);
			if(count($exp) > 0){ //if key exist
			   $defkey = $exp[0];
			   $defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[1]);
			}else{
				$defkey = 0;
			  $defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[0]); 
			}
		  }
		 if($rst[1] > 0){ //if levels found
		  $rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=,id={$id}tb");
		  if(isset($defval)){
			$rtnstr .= __TRecord(array($defval),"id={$defkey}");
		  }
		    if(!$candidate){
				$yearstud = 0;

				if($progID > 0){
					//get the total years for the prog
			 $rst2 = $dbo->Select4rmdbtbFirstRw("programme_tb","YearOfStudy","ProgID = $progID");
			 
			 if(is_array($rst2)){
				 $yearstud = (int)$rst2[0];
			 }
				}
			 
			 $counter = 1;
			 $lstlvl = 0;
			 while($lvl = $rst[0]->fetch_array()){
				 if($counter > $yearstud && $yearstud > 0){break;}
				 $txt = $lvl['Name'];
				$idtxt = (int)$lvl['Level'];
				if($yearstud == 0 || ($yearstud > 0 && $counter <= $yearstud)){
				 $rtnstr .= __TRecord(array($txt),"id={$idtxt}");
				 $lstlvl = $idtxt;
				}/*else{
					
					$rtnstr .= __TRecord(array($txt),"id={$idtxt}");
				}*/
				$counter++;
			 }
			 //loop to add abretiary splill over of 5 extra
			 for($d=1;$d<=4;$d++){
				 
				  $rtnstr .= __TRecord(array($spillStr." ".$d),"id=".($lstlvl + $d));
				  
			 }
			}else{
				$rec = $noncandidate == true?array("Payee"):array("Entrance");
				$rtnstr .= __TRecord($rec,"id=1");
			}
			 
			$rtnstr .= ___Table(); 
		 }else{ //if no level found
			if(isset($defval)){
				$rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=,id={$id}tb");
				$rtnstr .= __TRecord(array($defval),"id={$defkey}");
				$rtnstr .= ___Table(); 
			  }
		 }
		 
	 }
  }
echo $rtnstr;
?>