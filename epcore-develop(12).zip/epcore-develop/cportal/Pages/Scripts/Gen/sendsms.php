<?php

$configdir = "../../../../../../".$_POST['SubDir'];
// $_POST['CORE'] = $_POST['Core'];
require_once("../../../../general/config.php");
if(!isset($_POST['Phone']) || trim($_POST['Phone']) == "")die("#Invalid or No Phone Number Found");
if(!isset($_POST['Msg']) || trim($_POST['Msg']) == "")die("#Invalid or No Message Found");
//die(nl2br($_POST['Msg']));
$sch = $dbo->SelectFirstRow("school_tb","Abbr,OpUName,OpUPassw,OpSMSLive");
if(!is_array($sch))die("#Reading SMS Parameters Failed");
if($sch['OpSMSLive']=="FALSE")die("SMS System Disabled");
$msg = $_POST['Msg'];
$sendmail = $dbo->SendSMS($sch['Abbr'],$msg,$_POST['Phone'],"234",$sch['OpUName'],$sch['OpUPassw'],$sch['OpSMSLive']=="FALSE"?false:true);
if($sendmail){
    die("*Message Sent successfully");
}else{
    die("#Sending Message Failed");
}
?>