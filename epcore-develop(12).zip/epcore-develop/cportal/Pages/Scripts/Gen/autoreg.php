<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request

//get all victimised student
$stud = $dbo->RunQuery("select * from studentinfo_tb where id >= 4878 and id <= 5631");
if(is_array($stud)){
    if($stud[1] > 0){
        $cnt = 1;
       while($studinfo = $stud[0]->fetch_array()){
           $autreg = AutoGenRegNo($studinfo['RegNo']);
           if(is_array($autreg)){
             $newreg = $autreg[0];
           }else{
              $newreg = $autreg; 
           }
           
           $dbo -> Update("studentinfo_tb",["AutoRegIssue"=>$studinfo['RegNo']],"id = ".$studinfo['id']);
           echo $cnt.": ",$studinfo['RegNo']. " => ".$newreg . "<br />";
       }
    }
}

?>