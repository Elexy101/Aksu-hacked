<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request
//exit("aaaa");
$id = $_POST['tbid'];
$query = "select * from study_tb where SchoolType = (select Type from school_tb limit 1)";
//exit($query);
$rst = $dbo->RunQuery($query);

      if(is_array($rst)){
		//if($_POST['table'] == "course_tb"){var_dump($rst);exit();}
		if(isset($_POST['def']) && trim($_POST['def']) != ""){ //if default drop down option set
			//get the key and value;
			$exp = explode(":",$_POST['def']);
			if(count($exp) > 0){ //if key exist
			   $defkey = $exp[0];
			   $defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[1]);
			}else{
				$defkey = 0;
			  $defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[0]); 
			}
		  }
		if($rst[1] > 0){
			
			Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=false,id={$id}tb");
			if(isset($defval)){
				TRecord(array($defval),"id={$defkey}");
			}
			while($rec = $rst[0]->fetch_array()){
				$txt = $rec[1];
				$idtxt = $rec[0];
				if(!is_array($txt)){
				 TRecord(array($txt),"id={$idtxt}");
				}else{
				   TRecord($txt,"id={$idtxt}");
				}
			}
			_Table();
			
		}else{
			Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=false,id={$id}tb");
			if(isset($defval)){
				TRecord(array($defval),"id={$defkey}");
			}
             //$rtnstr .= __TRecord(array(""),"id=0");
			_Table();
		
  }
}

?>