<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

$lvldet = GetLevel($_POST['StartSes'],$_POST['ProgID'],$_POST['StudyID']);
echo json_encode(["ExLevelName"=>$lvldet['LevelName'],"ExLevelID"=>$lvldet['LevelID']]);

/* $studlvl = LevelStartSes((int)$_POST['StartSes']);

        $yearofSt = YearOfStudy($_POST['ProgID']);
       
		if(((int)$studlvl - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
            $LvlName = strtoupper($spilstr)." ".((int)$studlvl - $yearofSt);
            
		}else{
			$LvlName = LevelName($studlvl,$_POST['StudyID']);
        } */
       // $cursem = GetCurrentSem();
        

        //$studlvlsem = GetStudLvlSemDetails($regno);
/*         
$studlvlop = is_array($studlvlsem)?$studlvlsem['LevelName']:"--";
$studsemop = is_array($studlvlsem)?$studlvlsem['SemesterName']:"--"; */
//exit($studlvlop);
/* oplvl.textContent = dt.OpLevelName + " | "+dt.OpSemesterName;
			exlvl.textContent = dt.ExLevelName + " | "+dt.ExSemesterName; */
//echo json_encode(["ExLevelName"=>$LvlName]);
?>