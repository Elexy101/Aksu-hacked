<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
$sch = GetSchool();
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

//cstudy=2&coursefac=5&coursedept=48&courseprog=49&courselvl=1&coursesemest=1
extract($_POST);
if(!isset($importtype) || trim($importtype) == "")exit("#INVALID IMPORT PARAMETER");
if($importtype == 0){
  if(!isset($icourseprog) || (int)$icourseprog == 0 || !isset($icourselvl) || (int)$icourselvl == 0 || !isset($icoursesemest) || (int)$icoursesemest == 0){
    exit("#INVALID PARAMETER: The Course/Subject Programme, Level and {$sch['SemLabel']} are required");
  // exit;
}
$semcourses = $dbo->Select("course_tb","","DeptID=$icourseprog AND Lvl=$icourselvl AND Sem=$icoursesemest ORDER BY CourseID ASC");

         if(!is_array($semcourses)){
          exit("INTERNAL ERROR: Loading {$sch['SemLabel']} Courses Failed");
            
         }

         $dump = [];
         if($semcourses[1] > 0){
            
             //form all courses dump file
             while($indcourse = $semcourses[0]->fetch_array()){
                 //condition for gettin session
                 //$sescond = $indcourse['StartSesID'] == 0?"1=1 ORDER BY SesID LIMIT 1":"SesID=".$indcourse['StartSesID'];
                 //get start session
                // $sesArr = $dbo->SelectFirstRow("session_tb","",$sescond);
                 $dumparr = array($indcourse['CourseCode'],$indcourse['Title'],$indcourse['CH'],$indcourse['StartSesID'],$indcourse['EndSesID'],$indcourse['CourseStatus'],$indcourse['Elective'],$indcourse['GroupID'],$indcourse['Former'],0);
                 //$dumparr["ID"] = $indcourse['CourseID'];
                /*  $dumparr["logo"] =  "*print";
                 $dumparr["info"] =  "Print";
                $dumparr["Action"] =  "Course.ManageCourse.PrintCourse({$indcourse['CourseID']})"; */
                $dump[] = $dumparr;
             }
         }
}else{
  //Other type of import
}


//package parameter back
$cdet = json_encode($_POST);
$allset = COURSE();



          //$procgrde = ; //return all grade structure with the grade symbole
         // Hidden("gradeStruc",GetGrade(-1));
$electgroup = array(1=>"ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE","TEN");
$datastr = '';
for($i=1;$i<=(int)$allset['MaxElectiveGrp'];$i++){
  $datastr .= "&".($i+1)."=".$electgroup[$i]." ONLY";
}
$sessarr = TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC");
//array_unshift($sessarr,"MAX SESSION");
ksort($sessarr);
$endsesarr = $sessarr+["0"=>"MAX SESSION"];
$startses = ["0"=>"MIN SESSION"]+$sessarr;

         $header=array(
           "*CCode"=>"CODE",
           "*CTitle"=>"TITLE",
           "*CH"=>"CH",
           "*StartSes"=>array("START",$dbo->DataString($startses)),
           "*EndSes"=>array("END",$dbo->DataString($endsesarr)),
           "*CStatus"=>array("STATUS","0=ENABLED&1=DISABLED"),
           "*Elective"=>array("ELECTIVE",'0=COMPULSORY&1=NONE OR ABOVE'.$datastr),
           "*GroupID"=>array("GROUP",$dbo->DataString(TextBoxSQL("select * from coursegroup_tb"))),
           "*NewCourseID"=>array("NEW","#select CourseID, CONCAT(CourseCode,' (',CH,')') as CourseCode from course_tb WHERE DeptID=$icourseprog AND Lvl=$icourselvl AND Sem=$icoursesemest AND CourseID != ?CourseID? ORDER BY CourseID ASC"),
           "*CourseID"=>"CID");
         //get all courses
         //$semcourses = $dbo->Select("course_tb","","DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest AND StudyID=$cstudy ORDER BY CourseID ASC");
         
         /* $recarr = array($rec[0],$rec['Name'],$rec[3],$rec['PayDate'],$rec['DeptName'],$rec['FacName'],$rec['Bank']);
                      // $BackPOST['displaytext'] = $_POST['displaytext'];
                      $BackPOST['reportType'] = 'paytypeprog';
                     $BackPOST['back'] = true;
                     $recarr["logo"] =  "*print";
				$recarr["info"] =  "Print";
				$recarr["Action"] =  "Payment.PaymentReport.PrintRc('{$rec['itemNum']}')";
                $dump[] = $recarr; */
               
        
        SpreadSheet("rowselect=false,style=width:100%;margin:auto;margin-top:0px;border-top-color:transparent;margin-bottom:6px,id=sprstcourses,multiselect=false,cellfocus=,dynamiccolumn=false,dynamicrow=true,minrow=-1,disable=CourseID,rowfilter=true,filtertitle=FILTER COURSES,filterstyle=width:100%",$header,$dump);
        Hidden("loadtype","import");
       
//echo "Load Course";

?>