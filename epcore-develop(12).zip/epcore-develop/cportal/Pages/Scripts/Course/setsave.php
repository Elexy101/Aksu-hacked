<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
AllowUser("csetting");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

extract($_POST);
if(!isset($OpenPortal)){
  exit ("#Invalid Parameter");
}

//format all settings to database format
//OpenPortal=0&SemControl=0&LowerLevel=1&UnregCourse=0&Prob=0&Duplicate=0&PrevCourse=1&PayID=2
$updarr = [];
$updarr['Status'] = (int)$OpenPortal == 1?"OPENED":"CLOSED";
$updarr['SemStrict'] = (int)$SemControl == 1?"TRUE":"FALSE";
$updarr['LowerLevel'] = (int)$LowerLevel == 1?"TRUE":"FALSE";
$updarr['UnRegCourses'] = (int)$UnregCourse == 1?"TRUE":"FALSE";
$updarr['ReptCourses'] = (int)$ReptCourse == 1?"TRUE":"FALSE";
$updarr['CheckProb'] = (int)$Prob == 1?"TRUE":"FALSE";
$updarr['DuplicateCourse'] = (int)$Duplicate == 1?"TRUE":"FALSE";
$updarr['AutoRegStatus'] = (int)$AutoRegStatus == 1?"TRUE":"FALSE";
$updarr['CheckPrevReg'] = (int)$PrevCourse == 1?"TRUE":"FALSE";//AdminPrePay
$updarr['AdminPrePay'] = (int)$AdminPrePay == 1?"TRUE":"FALSE";//AdminPrePay
$updarr['DynamicBulkRegLvl'] = (int)$dymlvl == 1?"TRUE":"FALSE";//AdminPrePay
$updarr['PayID'] = $PayID;
$updarr['MaxElectiveGrp'] = $MaxElective;



//exit(GetMaxCH(16,4,1));
//exit($maxch);
$grdsh = SheetDatabind($maxch,"maxch_tb",[1=>"ID", "int StudyID", "int FacID", "int DeptID", "int ProgID", "int Lvl", "int Sem", "int MaxCH"],[2,8]);
if ($grdsh !== true) exit("Error occured while updating Max CH Settings. : ".$grdsh);

//exit($dbo->DataString($updarr));
//update the coursecontrol table
$upd = $dbo->Update("coursecontrol_tb",$updarr);
if(is_array($upd)){
   // exit("~".$CGrps);
    //update the course group table
    $CGrps = $dbo->DataArray($CGrps);
$maxdata = (int)$CGrps['MaxDataRow'];
$query = "";

for($s=1;$s<=$maxdata;$s++){
    //get individual course details
    //$GrpID = $dbo->SqlSafe(rawurldecode($CGrps[$s.'_1']));
    $GrpName = $dbo->SqlSafe(rawurldecode($CGrps[$s.'_1']));
    $AllowFail = $dbo->SqlSafe(rawurldecode($CGrps[$s.'_2']));
    $Deleted = rawurldecode($CGrps[$s.'_deleted']);
    if(isset($CGrps[$s.'_3']) && (int)$CGrps[$s.'_3'] > 0){ //if id set meaning update operation
        //if all entring cleared meaning delete operation
if((trim($GrpName) == "" && trim($AllowFail) == "") || $Deleted == "true"){ //if all cleared meaning delete operation
    $query .= "DELETE FROM coursegroup_tb WHERE ID = {$CGrps[$s.'_3']} ;";
}else{
$query .= "UPDATE coursegroup_tb SET Descr='$GrpName', AllowFail = $AllowFail WHERE ID={$CGrps[$s.'_3']};";
}   
    }else{ //if no id set meaning
        if(trim($GrpName) != "" || trim($AllowFail) != ""){
        $query .= "INSERT coursegroup_tb SET Descr='$GrpName', AllowFail = $AllowFail, Param='' ;"; 
        }
    }

}
//exit("~".$query);
$qu = true;
$str = [];
if(trim($query) != ""){
  //run the query
$qu = $dbo->Connection->multi_query($query);

}
    if($upd[1] > 0 && $qu !== FALSE){
        $str['Msg']= "*Course Settings Saved Successfully";

    }else if($upd[1] > 0 && $qu === FALSE){
        $str['Msg']= "Error in Course Group, Other Settings Saved Successfully";
    }else{
        $str['Msg'] = "*Course Settings Saved Successfully";
    }
    if($qu){
        do {
            /* store first result set */
                            if ($result = $dbo->Connection->store_result()) {
                                /*while ($row = $result->fetch_row()) {
                                    printf("%s\n", $row[0]);
                                }*/
                                $result->free();
                            }
                            /* print divider */
                            if ($dbo->Connection->more_results()) {
                                //printf("-----------------\n");
                            }
                        } while ($dbo->Connection->next_result());
                        $headerd = array(
                            
                            "*CGrpName"=>"GROUP NAME",
                                 "*Resit"=>array("RESIT ALLOWED","-1=INFINITE&0=NONE&1=ONCE&2=TWICE&3=THREE TIMES&4=FOUR TIMES&5=FIVE TIMES&6=SIX TIMES"),
                                 "-CGrpID"=>"#ID"
                           );
                           echo "~";
                        SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=cgrpsprsheet,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=7,disable=CGrpID",$headerd,"SELECT Descr, AllowFail,ID FROM coursegroup_tb");

// form the update spread sheet

    }else{
echo $str['Msg'];
    }
}else{
    echo "#Internal Error Saving Course Module Settings";
}
//echo $str['Msg'];
?>