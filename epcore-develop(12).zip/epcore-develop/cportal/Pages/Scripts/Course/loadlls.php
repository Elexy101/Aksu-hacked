<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
$regdump2 = [];
$LCoursese = [];$regdump2 = [];
$curses = CurrentSes();

             $lvlses = $curses['SesID'];
                  //Push('Reading Lower Level Courses ...');
                  $lCourses = $dbo->Select("course_tb","","DeptID=".$_POST['ProgID']." AND Lvl<".$_POST['LevelID']." AND Sem=".$_POST['SemesterID']."  AND CourseStatus = 0 ORDER BY Lvl Desc");
                  if(!is_array($lCourses)){
                    Box("class=defaultTabText");
                    Box();Icon("exclamation-triangle fa-3x altColor");_Box();
                    //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
                    Box();echo"Error Loading Lower Level Courses";_Box();  
                  _Box(); 
                  }else{
                    if($lCourses[1] > 0){
                        $LevelSesArr = [];
                        //Push('Populating Lower Level Courses ...'); 
                        while($lindcourse = $lCourses[0]->fetch_assoc()){
                            if(!isset($LevelSesArr[$lindcourse['Lvl']])){
                                //check if student register for course at the Lvl Sem
                                $courseregll = $dbo->SelectFirstRow("coursereg_tb","","RegNo='{$_POST['RegNo']}' AND Lvl=".$lindcourse['Lvl']." AND Sem=".$lindcourse['Sem']);
                                if(is_array($courseregll)){ //if course registration exist for the lower level
                                //get the sesid
                                $LevelSesArr[$lindcourse['Lvl']] = (int)$courseregll["SesID"];
                                }else{
                                    //if the student does not register for the level which is abnormal
                                    //use the current session
                                    $LevelSesArr[$lindcourse['Lvl']] = $lvlses;  
                                }
                            }
      
                            //check if course not expired 
                            //StartSesID <= $lvlses AND (EndSesID >= $lvlses OR EndSesID = 0)
                            
                            if((int)$lindcourse['StartSesID'] <= $LevelSesArr[$lindcourse['Lvl']] || ((int)$lindcourse['EndSesID'] >=  $LevelSesArr[$lindcourse['Lvl']] || (int)$lindcourse['EndSesID'] == 0)){
                                $lindcourse['Class'] = $llcclass;
                                $lindcourse['CourseCode'] = strtoupper($lindcourse['CourseCode']);
                                $lindcourse['Title'] = ucwords($lindcourse['Title']);
                                $regdump2[] = [$lindcourse['CourseID'],$lindcourse['CourseCode'],$lindcourse['Title'],$lindcourse['CH'],0];
                            //get the ch
                           /*  $accCH += (int)$indcourse['CH'];
                            if($accCH <= $maxch){
                                $indcourse['Class'] .= " ".$autoclass;
                            } */
                            $LCoursese[] = $lindcourse;
                            }else{
                                //Push('Couses '.$lindcourse['CourseCode'].' Expired as at the time student first Register for the course','err');
                            }
                            
                            
                          }
                          $headerd2 = ["-RegCID2"=>"CourseID","*RegCCode2"=>"CODE","*RegCTitle2"=>"TITLE","*RegCCH2"=>"CH","*RegCStatus2"=>array("REGISTER","YES|NO")];
            SpreadSheet("rowselect=true,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px;font-size:1em,id=llccregsheet|{$_POST['RegNo']},multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=RegCID2;RegCCode2;RegCTitle2;RegCCH2,onswitchchange=Course.Register.UpdateReg",$headerd2,$regdump2);
                    }else{
                        Box("class=defaultTabText,style=margin-top:10px");
                        Box();Icon("exclamation-triangle fa-3x altColor");_Box();
                        //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
                        Box();echo"No Lower Level Course Found";_Box();  
                      _Box();
                    }
                    
                  }

?>