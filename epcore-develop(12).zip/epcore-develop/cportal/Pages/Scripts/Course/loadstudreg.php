<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../api/engine/v1.php");
require("../../../../general/getinfo.php");
//AllowUser("cregister");

//exit(json_encode(($_POST)));
/* {"GetRegNos":"{\"StudyID\":5,\"Type\":\"1\",\"RegNos\":[\"AK2019\/AGR\/AEC\/001\"],\"AutoLS\":\"0\",\"LvlID\":0,\"SemID\":1,\"LvlName\":\"--\",\"SemName\":\"First\"}","SubDir":"academa\/"} */
//check if to get valid student only
if(isset($_POST['GetRegNos'])){
  
    $RegNos = trim($_POST['GetRegNos']);
    if($RegNos == "")exit("#"); //no valid reg no supplid
    
    //convert to object
    $RegNos = json_decode(urldecode($RegNos),true);
    $LvlID = isset($RegNos['LvlID']) && (int)$RegNos['AutoLS'] == 0?$RegNos['LvlID']:0;
    $SemID = isset($RegNos['SemID']) && (int)$RegNos['AutoLS'] == 0?$RegNos['SemID']:0;

    $LvlName = "AUTO";
    $SemName = "AUTO";
    if((int)$RegNos['AutoLS'] == 0){ //if auto level semester is disabled
        $LvlName = $RegNos['LvlName'];
        $SemName = $RegNos['SemName'];
    }
    //exit($RegNos['AutoLS']."kk");
    //check if it is to be loaded
    if((int)$RegNos['Type'] == 0){//1-> RegNos, 0->Range
        $field = "GROUP_CONCAT((IF(TRIM(s.RegNo) = '',s.JambNo,s.RegNo)) SEPARATOR ',') as RegNos";
        $fields = "s.id,s.RegNo";
        $tbs = "studentinfo_tb s";
        //{"SesID":0,"StudyID":0,"FacID":0,"DeptID":0,"ProgID":0,"LvlID":0}
        $studq = ((int)$RegNos['StudyID'] > 0)? "IF(TRIM(s.RegNo) = '',s.JambNo,s.RegNo) != '' AND s.StudyID = ".$RegNos['StudyID']:"IF(TRIM(s.RegNo) = '',s.JambNo,s.RegNo) != ''";
        
        if((int)$RegNos['ProgID'] > 0){
            $studq .= " AND s.ProgID = ".$RegNos['ProgID'];
        }else{
             if((int)$RegNos['DeptID'] > 0){
                    $studq .= " AND s.ProgID = p.ProgID AND d.DeptID = p.DeptID AND d.DeptID = ".$RegNos['DeptID'];
                    $tbs .= ",programme_tb p, dept_tb d";
                }else if((int)$RegNos['FacID'] > 0){
                    $studq .= " AND s.ProgID = p.ProgID AND d.DeptID = p.DeptID AND d.FacID = f.FacID AND f.FacID = ".$RegNos['FacID'];
                    $tbs .= ",programme_tb p, dept_tb d, fac_tb f";
                }
               // $facq = ((int)$RegNos['FacID'] > 0)? "StudyID = ".$RegNos['StudyID']:"StudyID != 0";
        }
        if((int)$RegNos['Batch'] > 0){
            
            /* $CurSes = CurrentSes();
            $CurSes = $CurSes['SesID'];
            $studq .= " AND ($CurSes - s.StartSes + IF(TRIM(s.ModeOfEntry) = '',1,IF(s.ModeOfEntry = 'UTME',1,IF(s.ModeOfEntry = 'Direct-Entry',2,(0+s.ModeOfEntry)))))  = ".(int)$RegNos['LvlID']; */

            $studq .= " AND s.StartSes = ".$RegNos['Batch'];
            //calculate the startses
        }

        if((int)$RegNos['Mode'] > 0){
            
            

            $studq .= " AND IF(TRIM(s.ModeOfEntry) = '',1,IF(s.ModeOfEntry = 'UTME',1,IF(s.ModeOfEntry = 'Direct-Entry',2,(0+s.ModeOfEntry)))) = ".$RegNos['Mode'];
            //calculate the startses
        }
        //get the total number character of all student regno + number of regno (to takecare of the commas)
        $extimatedchars = $dbo->SelectFirstRow("studentinfo_tb","(sum(CHAR_LENGTH(if(trim(RegNo)='',JambNo,RegNo)))+count(id)) as len");
         $totalch = !is_array($extimatedchars)?5353674748:$extimatedchars['len'];
        $setmax = $dbo->RunQuery("SET SESSION group_concat_max_len=$totalch;");

        $query = "SELECT $field FROM $tbs WHERE s.RegLevel>6 AND $studq";
        $runquery = $dbo->RunQuery($query);
        if(!is_array($runquery)){
            exit("##"); //Internal Error
        }
$queryrst = $runquery[0]->fetch_assoc();
if(!is_null($queryrst['RegNos'])){
$RegNo = $queryrst['RegNos'];
$RegNoarr = explode(",",$RegNo);
$rtn = array("Total"=>count($RegNoarr),"RegNos"=>$RegNoarr,"TotalBad"=>0,"BadRegNos"=>array(),"Q"=>$query,"LvlID"=>$LvlID,"SemID"=>$SemID,"AutoLS"=>$RegNos['AutoLS'],"Specific"=>$RegNos['Type'],"LvlName"=>$LvlName,"SemName"=>$SemName);
}else{
    $rtn = array("Total"=>0,"RegNos"=>array(),"TotalBad"=>0,"BadRegNos"=>array(),"Q"=>$query,"LvlID"=>$LvlID,"SemID"=>$SemID,"AutoLS"=>$RegNos['AutoLS'],"Specific"=>$RegNos['Type'],"LvlName"=>$LvlName,"SemName"=>$SemName);  
}

//exit(json_encode($rtn));
      //exit($query);
    }else{
        //get valid students
        
      if(count($RegNos) < 1)exit("#");
      $GoodStud = array(); $BadStud = array();
      
      $StudRegs = $RegNos['RegNos'];
      $StudRegs = array_unique($StudRegs);
      if(count($StudRegs) < 1)exit("#");
     // sort($RegNos);
      foreach($StudRegs as $RegNo){
          if(trim($RegNo) == "")continue;
          //$RegNo = urldecode($RegNo);
          //check if exist
          //$chkreg = $dbo->SelectFirstRow("studentinfo_tb st, order_tb od","st.id","(st.RegNo=od.RegNo OR st.JambNo OR (TRIM(st.RegNo)='' && st.JambNo='$RegNo') OR LIMIT 1");
          $chkreg = $dbo->RunQuery("
          SELECT IF(TRIM(st.RegNo) = '',st.JambNo,st.RegNo) as RegNo FROM studentinfo_tb st WHERE (st.RegNo='".$dbo->SqlSafe($RegNo)."' OR st.JambNo='".$dbo->SqlSafe($RegNo)."') LIMIT 1
          ");
          if(is_array($chkreg) && $chkreg[1] > 0){
              $sturtn = $chkreg[0]->fetch_array();
            $GoodStud[] = $sturtn[0];
          }else{
              //check if 
            $BadStud[] = $RegNo;
          }
      }
      $rtn = array("Total"=>count($GoodStud),"RegNos"=>$GoodStud,"TotalBad"=>count($BadStud),"BadRegNos"=>$BadStud,"LvlID"=>$LvlID,"SemID"=>$SemID,"AutoLS"=>$RegNos['AutoLS'],"Specific"=>$RegNos['Type'],"LvlName"=>$LvlName,"SemName"=>$SemName);
      
    }
exit(json_encode($rtn));
}

//function to convert an array to datastring without escaping the values
function DataString2($darr){
$rst = "";
    foreach($darr as $k=>$v){
$rst .= $k."=".$v."&";
    }
    return rtrim($rst,"&");
}


$res = "";
//$_POST['RegNo'] ='AK16/NAS/MTH/019';
$dump = '';
$errs = 0; $fix =0; $note = 0;$rsthtml='';$paids=0;$unpaids = 0;$updated = 0;$disnote = 'Not Registered';
//function to write response
function Push($txt,$err = ''){
    global $dump; global $errs; global $fix; global $note; global $fixnow;
    $cnt = "";
    $logo = "terminal";
    if($err == "err"){
        $errs++;
      $cnt = "<strong>(".$errs.")</strong>";
      $logo = "ban";
    }else if($err == "ok"){
        $fix++;
      $cnt = "<strong>(".$fix.")</strong>";
      $logo = $fixnow?"check":"exclamation-triangle";
    }else if($err == "note"){
        $note++;
        $cnt = "<strong>(".$note.")</strong>";
        $logo = "list-alt";
    }
    $dump .= '<div class="'.$err.'"><i style="opacity:0.5" class="fa fa-'.$logo.'"></i>&nbsp;&nbsp;&nbsp;'.$txt.' '.$cnt.'</div>';
}
$sch = GetSchool();
Push("STARTING...");
//Get the student regno
if(!isset($_POST['RegNo']) || trim($_POST['RegNo']) == "")exit ('<div class="err">Invalid RegNo</div>');
$RegNo = $_POST['RegNo'];
$num = $_POST['Num'];//regno counter
$tot = $_POST['Tot'];
//get the school details
$sch = GetSchool();
//$type = $_POST['Type'];
$Details = json_decode(urldecode($_POST['Details']),true);
//$fixnow = (int)$_POST['Type'] == 1?true:false; //indicate if fix is to be done
$query = ""; //the fix query
//get the student details

//$studDet = $dbo->SelectFirstRow("studentinfo_tb","","RegNo='".$RegNo."' OR JambNo='".$RegNo."'");
$studDet = GetBasicInfo($RegNo,"","a");
$cnt = 0;
$studName = "Unknown";

if(!is_array($studDet)){
    Push('<div class="err">Invalid Student - Could not read Student Data - '.$studDet.'</div>','note');
    $disnote = '<span class="err">Invalid Student - Could not read Student Data</span>';
    //exit();
}else{
    $AlreadyRegDet = [];
    $LevelID = 0;
    $SemesterID = 0;
    $registered = false;
    $CregID = 0; //the id of the registered courses in coursereg_tb. 0 - not registered
    //get the course control detaisl
    Push("Reading System Course registration Settings ...");
    $courseCntr = $dbo->SelectFirstRow("coursecontrol_tb");
    //if(!is_array($courseCntr))
    $studName = $studDet['Name'];
    //check if auto level semester
    Push("Checking Auto-Select Level and {$sch['SemLabel']} ...");
    if((int)$Details['AutoLS'] == 1){
        Push("Auto-Select Level and {$sch['SemLabel']} is Enabled",'ok');
        //get the student last course Registered
        Push("Reading Student Highest Course Registration ...");
       
    //get last course Registered
    $coursereg = $dbo->SelectFirstRow("coursereg_tb","*,Lvl as LevelID, Sem as SemesterID","RegNo='".$dbo->SqlSafe($RegNo)."' ORDER BY Lvl DESC, Sem DESC",MYSQLI_ASSOC);
            if(!is_string($coursereg)){
                if(!is_array($coursereg)){
                    Push("No Course Registration Found !!!!");
                    
                    $coursereg = [];
                    $coursereg['LevelID'] = 1;
                    $coursereg['SemesterID'] = 0;
                }else{
                    Push("Highest Course Registration Found (Level: {$coursereg['LevelID']}, {$sch['SemLabel']}: {$coursereg['SemesterID']})",'ok');
                }
                Push("Calculating Next Level and {$sch['SemLabel']}",'');
                 //Copied from api v1
        $maxsem = 2;
        Push("Reading the Maximum {$sch['SemLabel']} ...");
    //get the maximum semester number
    $semma = $dbo->SelectFirstRow("semester_tb","count(ID)","Enable = 1");

    if(is_array($semma)){
        $maxsem = (int)$semma[0];
    }
    Push("Maximum {$sch['SemLabel']}: ".$maxsem,"ok");
                $LevelID = $coursereg['LevelID'];
                $SemesterID = $coursereg['SemesterID'];
                $SemesterID++;
            if($SemesterID > $maxsem){
                $SemesterID = 1;
                $LevelID++;
            }

            Push("Next Course Registration Level/{$sch['SemLabel']} Calculated (Level: {$LevelID}, {$sch['SemLabel']}: {$SemesterID})",'ok');
            //get the student progid
           // $studDet = $dbo->SelectFirstRow("studentinfo_tb","","RegNo='{$Param['LoginName']}' OR JambNo='{$Param['LoginName']}'");
               // return $coursereg;
            }else{
                Push("Internal Error Occur while reading Student Highest Course Registration","err");
            }
    }else{
        Push("Auto-Select Level and {$sch['SemLabel']} is Disabled",'err');
        Push("Using Manual Level and {$sch['SemLabel']} (Level: {$Details['LvlID']}, {$sch['SemLabel']}:{$Details['SemID']})",'err');
        $LevelID = $Details['LvlID'];
    $SemesterID = $Details['SemID'];
    //check if student already register for course
    Push("Checking if Student Already Register For Courses ...");
    //get last course Registered
    $courseregex = $dbo->SelectFirstRow("coursereg_tb","","RegNo='".$dbo->SqlSafe($RegNo)."' AND Lvl=$LevelID AND Sem=$SemesterID LIMIT 1",MYSQLI_ASSOC);
    
    if(is_array($courseregex)){
        $AlreadyRegDet = $courseregex;
        $disnote = '<span class="ok">Already Registered</span>';
        $RegCoursesArr = explode("~",$AlreadyRegDet['CoursesID']);
        Push("Already Registered Courses - (".implode(',',$RegCoursesArr).")");
        $registered = true;
        $CregID = $courseregex['ID'];
    }
    }
    $totregc = 0;
    
    //$$$$$$$
    if(is_array($studDet)){
        $ProgID = $studDet['ProgID'];

        Push("Checking if Admin Pre-Payment Verification is allowed ...");
        if($courseCntr['AdminPrePay'] == "TRUE"){
            Push("Payment Verification is Enabled",'ok');
            Push("Verify Payment ...",'');
           //check payment
        $PayDet = $dbo->SelectFirstRow("payhistory_tb","","RegNo='{$RegNo}' AND Lvl = {$LevelID} AND Sem >= $SemesterID AND SemPart > 0 AND PayID = {$courseCntr['PayID']} AND ProgID=$ProgID"); 
        if(is_array($PayDet))Push("Payment Made",'ok');
        }else{
            Push("Payment Verification is Disabled",'err');
            $PayDet = [];
        }
        $regdump = [];$regdump2 = [];
        $LevelName = GetStudentLevelName($LevelID,$studDet['StudyID']);
            $SemName = GetStudentSemesterName($SemesterID);
            
         if(is_array($PayDet)){
             //get current session
             $curses = GetSchoolSession();
             $lvlses = $curses['SesID'];
            //get the courses
            $Courses = $dbo->Select("course_tb","","DeptID=".$ProgID." AND Lvl=$LevelID AND Sem=$SemesterID AND StartSesID <= $lvlses AND (EndSesID >= $lvlses OR EndSesID = 0) AND CourseStatus = 0");
            if(!is_array($Courses)){
                Push('<div class="err">Error Reading '.$sch['SemLabel'].' Courses</div>','err');
                $disnote = '<span class="err">Error Reading '.$sch['SemLabel'].' Courses</span>';
            }else{
                if($Courses[1] < 1){
                    Push('<div class="err">No '.$sch['SemLabel'].' Courses Found</div>','err');
                      $disnote = '<span class="err">No '.$sch['SemLabel'].' Courses Found</span>';
                }else{
                    Push('Calculating Maximum Credit Hour Allowed ...');
                    //get the max ch
                $maxch = GetMaxCH($ProgID,$LevelID,$SemesterID);
                Push('Maximum Credit Hour Allowed: '.$maxch,'ok');
                $StudCourses = [];
                $semclass = "semcourse";
                $autoclass = "autoreg";
                $llcclass = "llc";
                Push('Pupulating Courses ...');
                $Semcourses = [];
                $SemcoursesID = [];
               // $RegCoursesArr = [];
                $NowReg = [];
                $NowRegID = [];
                $totch = 0;
                $AlreadyReg = count($RegCoursesArr) > 0?true:false;
                //loop through each student courses and add classes as required
                while($indcourse = $Courses[0]->fetch_assoc()){
                  $indcourse['Class'] = $semclass;
                  $indcourse['CourseCode'] = strtoupper($indcourse['CourseCode']);
                  $indcourse['Title'] = ucwords($indcourse['Title']);
                  //get the ch
                  $accCH += (int)$indcourse['CH'];
                  $reg = 0;
                  if($AlreadyReg){ //if reg before
                    //check if course is selected
                    if(in_array($indcourse['CourseID'],$RegCoursesArr)){
                        $key = array_search($indcourse['CourseID'],$RegCoursesArr);
                        //remove
                        unset($RegCoursesArr[$key]);
                        $reg = 1;
                    }
                  }else{
                    if($accCH <= $maxch){
                      $indcourse['Class'] .= " ".$autoclass;
                      $reg = 1;
                  }  
                  }

                  if($reg == 1){ //if to register
                    $rsthtml .= '<div class="indflatbx">
                    <div>'.$indcourse['CourseCode'].' ('.$indcourse['CH'].')</div>
                    <div>'.$indcourse['Title'].'</div>
                    </div>';
                    $totregc++;
                    $NowReg[$indcourse['CourseID']] = $indcourse;
                    $NowRegID[] = $indcourse['CourseID'];
                    $totch += (int)$indcourse['CH'];
                  }
                  
                  $regdump[] = [$indcourse['CourseID'],$indcourse['CourseCode'],$indcourse['Title'],$indcourse['CH'],$reg];
                  $Semcourses[] = $indcourse['CourseCode'];
                  $SemcoursesID[] = $indcourse['CourseID'];
                  //$StudCourses[] = $indcourse;
                }

                Push(count($Semcourses) . ' Courses Populated - ('.implode(",",$Semcourses).')','ok');
                Push(count($Semcourses) . ' Courses Populated By ID - ('.implode(",",$SemcoursesID).')');

                Push('Checking Unprocessed Registered Courses ...');
                if(count($RegCoursesArr) > 0){
                    Push(count($RegCoursesArr).' Unprocessed Registered Courses Found','err');
                    Push('Proccessing Unprocessed Registered Courses ...');
                    $regcourseup = $dbo->Select("course_tb","","CourseID=".implode(" OR CourseID=",$RegCoursesArr));
                    if(is_array($regcourseup)){
                        if($regcourseup[1] > 0){
                            while($iprregc = $regcourseup[0]->fetch_assoc()){
                                $regdump[] = [$iprregc['CourseID'],$iprregc['CourseCode'],$iprregc['Title'],$iprregc['CH'],1];
                                $rsthtml .= '<div class="indflatbx">
                    <div>'.$iprregc['CourseCode'].' ('.$iprregc['CH'].')</div>
                    <div>'.$iprregc['Title'].'</div>
                    </div>';
                    $totregc++;
                    $NowReg[$iprregc['CourseID']] = $iprregc;
                    $NowRegID[] = $iprregc['CourseID'];
                    $totch += (int)$iprregc['CH'];
                            }
                            Push('All Unprocessed Registered Courses Processed - ('.implode(",",$RegCoursesArr).')','ok');
                        }else{
                            Push('All Unproccessed Registered Courses does not exist','err');
                        }

                    }else{
                        Push('Error Occured while reading unprocessed Registered Courses','err');
                    }
                }

                //Check if to perform reg
                Push('Checking if Load and Register Selected ...');
                if((int)$Details['Type'] == 1){
                    Push('Load and Register is Selected','ok');
                    //check if not already register
                    if(!is_array($courseregex)){
                        Push('Registering Courses ...');
                      $inst = $dbo->InsertID2("coursereg_tb",["RegNo"=>$RegNo,"Lvl"=>$LevelID,"CoursesID"=>implode("~",$NowRegID),"SesID"=>$lvlses,"Sem"=>$SemesterID,"RegDate"=>date('Y-m-d'),"MaxCH"=>$maxch,"CouresRegData"=>json_encode($NowReg),"TotCH"=>$totch]);
                      if(is_numeric($inst)){
                        Push('Courses Registered Successfully - '.$inst,'ok');
                        $AllowBulkPayUpdate = $sch['BulkPayUpdate'];
                        $failed = false;
                        $morein = "";
                        if($AllowBulkPayUpdate == "TRUE"){
                            $data = ["RegNo"=>$RegNo,"Lvl"=>$LevelID,"Sem"=>$SemesterID,"SemPart"=>3,"PayID"=>$courseCntr['PayID'],"SubDir"=>urlencode($dbo->Config['SubDir'])];
                           // if(isset($Param['Amt']))$data["Amt"] = $Param['Amt'];
                            //Error(12," : ".$__Root__);
                            $int = $dbo->Post($dbo->Config['Core2']."general/Payment/init.php",$data);
                            //check if error occur
                            if(isset($int['Error'])){
                                $disnote = '<strong class="err">Courses Registered: '.$int['Error'].'</strong>';
                                Push('Student Payment Update Failed - '.$int['Error'],'err');
                                $failed = true;
                            }else{
                                //make student paid
                                $paid = MakePaidByRef($int['Ref'],[],["Bank"=>"Manual Pay","Branch"=>"BULK"]);
                                if($paid[0] != 1){
                                    $disnote = '<strong class="err">Courses Registered: '.$paid[5].'</strong>';
                                Push('Student Payment Update Failed - '.$paid[5],'err');
                                $failed = true;
                                }else{
                                    $morein = " and ".$paid[5];
                                }
                            }
                            
                            //if(!isset($int['Ref']))Error(12," : No Valid Ref");
                       }
                        if($failed == false){
                               $disnote = '<b style="font-weight:bold" class="ok">Courses Registered'.$morein.'</b>';
                        $registered = true;
                        $CregID = $inst;
                        }
                     
                      }else{
                        $disnote = '<strong class="err">Registration Failed</strong>';
                        Push('Courses Registeration Failed - '.$inst,'err');
                      }

                    }

                }
    
                //if lower level courses is enabled
                $LLC = [];
                Push('Checking if Lower Level Selection is Allowed ...');
                $LLCAllowed = false;
                if($courseCntr['LowerLevel'] == 'TRUE'){
                    Push('Lower Level Selection is Allowed','ok');
                    $LLCAllowed = true;                  
                }else{
                    Push('Lower Level Courses Not Allowed','err');
                }
                
               // return ["SLC"=>["Courses"=>$StudCourses],"LLC"=>$LLC,"LevelName"=>$LevelName,"SemesterName"=>$semester,"LevelID"=>$LevelID,"SemesterID"=>$SemesterID,"ProgID"=>$studDet['ProgID'],"RegNo"=>$Param['LoginName'],"SemesterClass"=>$semclass,"AutoClass"=>$autoclass,"LLCClass"=>$llcclass];
                }
                
            }
            
         }else{
             //Make the page auto reload incase user make payment
             Push('Payment Not Made','err');
                $disnote = '<div class="err">Payment Not Made</div>';
         }
      }else{
          Push("Reading Student Details Failed",'err');
      }

    //$$$$$$$

    
    //$rsthtml = $studName. " ($RegNo) <br/>".$Details;

}



//echo '<div id="'.$RegNo.'">&nbsp;</div>';
$distray = (int)$tot > 1?"none":"block";
if((int)$num < 1){
Box("class=ep-animate-opacity");
    echo $rsthtml;
    echo '
        <div style="padding:6px">
    <div style="float:left;width:70%"><strong class="err">'.$errs.' Issues</strong> | <strong class="ok">'.$fix.' Success</strong>  | <strong class="">'.$note.' Notes</strong></div>
    <div style="float:right;width:30%">';
    LogoButton('onclick=_(\''.$RegNo.'_vtray\').ToggleShowHide();return false;,style=display:block;float:right;color:#fff,class=altBgColor2,logo=list-alt,text=Process Tray');
    echo '<div style="clear:both"></div></div><div style="clear:both"></div>
    <div style="margin:auto;padding:6px;margin-top:5px;background-color:#fff;border:#ccc 1px solid;min-height:100px;max-height:200px;display:'.$distray.';overflow:auto" id="'.$RegNo.'_vtray">
    '.$dump.'
    </div>
    </div>
    
    ';
    _Box();
}else{
    FlatTRecord("class=ep-animate-opacity,style=text-align:unset");
    FlatTData($num,"size=5");
    FlatTData("$RegNo - $studName","size=40");
    FlatTData($LevelName,"size=10");
    FlatTData($SemName,"size=10");
    if(count($regdump) > 0){
        $logoo = $registered?"check":"wrench";
     $regbtn = _LogoButton('style=margin-left:10px;color:#fff,class=success indcregbtn,id='.$RegNo.'_cregbtn,onclick=Course.Register.IndReger(this);return false;,logo='.$logoo);
    }else{
        $regbtn = _LogoButton('style=margin-left:10px;color:#fff,class=danger,id='.$RegNo.'_cregbtn,onclick=MessageBox.Show(\''.$disnote.'\'),logo=times');
    }
    FlatTData($regbtn,"size=10,style=font-weight:bold,class=ok");
    $coursesd = $totregc > 0?"($totregc)":"";
    FlatTData($disnote ." " .$coursesd,"size=20,id={$RegNo}_disnote");
    FlatTData('<i class="fa fa-ellipsis-h"></i>',"size=5,style=text-align:left;cursor:pointer,onclick=_('".$RegNo."_cdet').ToggleShowHide(),class=altColor2Hover,title=View Details");
   /* echo '
          <div style="clear:both"></div>

          <div class="subbx" style="display:none" id="'.$RegNo.'_det">'; */
FlatTDataSub("id={$RegNo}_cdet,style=display:$distray");
           // echo $rsthtml;
            if(count($regdump) > 0){
                $savedet = ["SheetData"=>$regdump,"RegNo"=>$RegNo,"ProgID"=>$ProgID,"LevelID"=>$LevelID,"SemesterID"=>$SemesterID,"LLC"=>$LLCAllowed];
                
                echo '
         <div style="padding:10px" id="'.$RegNo.'_sheetbx">';
         echo '<div style="">';
          echo '<div style="font-weight:bold;margin:0px 5px;min-width:100px;float:left" class="altcolor2"><span id="'.$RegNo.'_totregcourse">'.$totregc.'</span> Courses</div>';
          if($registered){
             LogoButton('onclick=Course.Register.Unregister(\''.$RegNo.'\'\,'.$CregID.');return false;,style=display:block;margin:auto;color:#fff;float:right;min-width:80px;margin-left:10px;background-color:rgba(255\,104\,53\,1),logo=trash,text=Unregister,class=unregcbtn,id='.$RegNo.'_'.$CregID.'_unregbtn');
          }
          
          LogoButton('onclick=Course.Register.Modify(\''.$RegNo.'\');return false;,style=display:block;margin:auto;color:#fff;float:right;min-width:100px,class=altBgColor2,logo=cogs,text=Modify Registration,id='.$RegNo.'_modifybtn');
          echo '<div style="clear:both"></div></div>';
          Line();
          Box("id=regdisplays_".$RegNo);
          echo $rsthtml;
          _Box();
         echo '</div>';
         
               
                echo '<div style="display:none" id="'.$RegNo.'_regdatat">';
                echo json_encode($savedet);
                echo '</div>';
           /*  $headerd = ["-RegCID"=>"CourseID","*RegCCode"=>"CODE","*RegCTitle"=>"TITLE","*RegCCH"=>"CH","*RegCStatus"=>array("REGISTER","YES|NO")];
            SpreadSheet("rowselect=true,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px;font-size:1em,id=cregsheet_$RegNo,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=RegCID;RegCCode;RegCTitle;RegCCH",$headerd,$regdump); */
            }
/*if($LLCAllowed){
     echo '
         <div style="padding:10px">';
    LogoButton('onclick=_(\''.$RegNo.'_llc\').ToggleShowHide();Course.Register.LoadLLC(\''.$RegNo.'\','.$ProgID.','.$LevelID.','.$SemesterID.');return false;,style=display:block;margin:auto;color:#fff,class=altBgColor2,logo=arrow-down,text=Lower Level Courses');
    echo'
        </div><div id="'.$RegNo.'_llc" style="display:none">';
         $headerd2 = ["-RegCID2"=>"CourseID","*RegCCode2"=>"CODE","*RegCTitle2"=>"TITLE","*RegCCH2"=>"CH","*RegCStatus2"=>array("REGISTER","YES|NO")];
            SpreadSheet("rowselect=true,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px;font-size:1em,id=llccregsheet_$RegNo,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=RegCID2;RegCCode2;RegCTitle2;RegCCH2",$headerd2,$regdump2); 
        echo'</div>';
}
        */
        
        echo'<div style="padding:6px">
    <div style="float:left;width:70%"><strong class="err">'.$errs.' Issues</strong> | <strong class="ok">'.$fix.' Success</strong>  | <strong class="">'.$note.' Notes</strong></div>
    <div style="float:right;width:30%">';
    LogoButton('onclick=_(\''.$RegNo.'_vtray\').ToggleShowHide();return false;,style=display:block;float:right;color:#fff,class=altBgColor2,logo=list-alt,text=Process Tray');
    /* echo '<button onclick="_(\''.$RegNo.'_tray\').ToggleShowHide()" style="display:block;float:right"  class="altBgColor2 bbtn"><i class="fa fa-list-alt"></i> Process Tray</botton>'; */
    echo'<div style="clear:both"></div></div><div style="clear:both"></div>
    <div style="margin:auto;padding:6px;margin-top:5px;background-color:#fff;border:#ccc 1px solid;min-height:100px;max-height:200px;display:none;overflow:auto" id="'.$RegNo.'_vtray">
    '.$dump.'
    </div>
    </div>';
        //echo '</div>';
        _FlatTDataSub();
          _FlatTRecord();
}

         // echo '<div id="'.$RegNo.'_scroll" style=""></div>';
?>