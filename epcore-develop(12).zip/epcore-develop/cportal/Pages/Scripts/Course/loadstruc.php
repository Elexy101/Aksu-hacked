<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
$sch = $dbo->SelectFirstRow("school_tb","","",MYSQLI_ASSOC);
$studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = (select SchGrpID from school_grp_tb limit 1)");
$userID = 0; $staffID = 0;$loadcond="";
        $user = $_POST['USER'];
        $deptasign = "";
        if($user != ""){
          $userdet = explode("~",$user);
          if(count($userdet) > 0){
            $userID = $userdet[0];
            //get the staffdet
            $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=".$userID);
            if(is_array($staffDet)){
               $staffID = $staffDet["StaffID"];
               //$courses = trim($staffDet['Courses']);
               /* if($courses != ""){
                 $loadcond = "c.CourseID = ".str_replace("~"," OR c.CourseID = ",$courses);
               } */
              $deptasign = $staffDet['DeptIDs'];

            }
          }
        }
        $UID = $userID;
        $intStudyID = key($studyarr); //get the selected study
        if(trim($deptasign) != ""){ //if dept assign to user
           
            //check if one dept asign
            $deptasignarr = explode("~",$deptasign); //get all asign departids
            $deptcond = "p.ProgID = ".implode(" OR p.ProgID = ",$deptasignarr);
          //get study based on the assigned dept
          $studyarrdep = TextBoxSQL("select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID");
         /*  echo "select s.* from study_tb s, fac_tb f, dept_tb d, programme_tb p WHERE ($deptcond) AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"; */
          if(count($studyarrdep) > 0)$studyarr = $studyarrdep;
            if(count($deptasignarr) < 2){ //if one dept/prog assigned
             
              //load level based on the prog
              //$lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb where StudyID = $intStudyID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= (select YearOfStudy from programme_tb where ProgID = ".trim($deptasign).") order by Level");
              $lvlarr = TextBoxSQL("select Level, Name from schoollevel_tb sc, programme_tb p, fac_tb f, dept_tb d where sc.StudyID = f.StudyID and d.FacID=f.FacID and d.DeptID = p.DeptID and SchoolTypeID = (select Type from school_tb limit 1) and Level <= p.YearOfStudy and p.ProgID = ".trim($deptasign)." order by sc.Level");
              $spillStr = ExtraLevelString();
              $lstlvl = end($lvlarr);
              $lstkey = key($lvlarr);
              for($s=1;$s <= 4; $s++){
                $lvlarr[$s+(int)$lstkey] = $spillStr ." ".$s;
              }
          } 
          }
       TextBoxGroup();
       $schStruc = json_decode($sch['SchStrucContr'],true);
         //LoadFac
        if(trim($deptasign) == ""){ //if no dept/prog assing
          $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=ic,required=true,selected=1,logo=university,onchange=Utility.LoadStudy",$scharr);
          }
          $selestu = ($schStruc['FacID']['SilentMode'] == true)?"":"-1";
          TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=icstudy,required=true,selected=$selestu,logo=building-o,onchange=Course.ManageCourse.GenLoaderImport.LoadFac",$studyarr);
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,required=true,id=icoursefac,onchange=Course.ManageCourse.GenLoaderImport.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']}",TextBoxSQL("select FacID, FacName from fac_tb WHERE StudyID = {$intStudyID}"));
		 //TextBoxSQL("select * from fac_tb order by FacName")
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,required=true,onchange=Course.ManageCourse.GenLoaderImport.LoadProg,id=icoursedept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']}",array());
		  TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=icourseprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Course.ManageCourse.GenLoaderImport.LoadLevel",array());
		  TextBox("title=Level,style=width:250px;text-transform:uppercase,id=icourselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoaderImport.LoadSemester",array() );//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)") 
        }else{ //if dept asign
            //TextBox("title=Study,style=width:250px;text-transform:uppercase,id=cstudy,required=true,selected=-1,logo=building-o,onchange=Course.ManageCourse.GenLoaderImport.LoadLevel",$studyarr);
            
            //initial study
             if(isset($lvlarr) && count($lvlarr) > 0){ //if level loaded meaning is one dept/prog asigned
              echo '<input type="hidden" id="icourseprog" class="objgrpelemmgecourse" value="'.trim($deptasign).'" data-value="'.trim($deptasign).'" />';
              if(!isset($progDet)){
                $progDet = $dbo->SelectFirstRow("programme_tb p, fac_tb f, dept_tb d","p.ProgName,f.FacName","p.ProgID=$deptasign AND p.DeptID=d.DeptID AND d.FacID = f.FacID");
                             }
                             
                            if(is_array($progDet)){
                                 Note();
                        echo $progDet['FacName']. " - ".$progDet['ProgName'];
                _Note();
                            }
               //Hidden("rstudprog",trim($deptasign)); //set the prog id as hidden element
              TextBox("title=Level,style=width:250px;text-transform:uppercase,id=icourselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoaderImport.LoadSemester,chain=courselvl:;coursesemest:",$lvlarr); //load the lvel drop down
            }else{ // if multiple dept/prog assigned
            $deptasignsql = "p.ProgID=".str_replace("~", " or p.ProgID=",$deptasign);
              //load prog the textbox
              TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=icourseprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},onchange=Course.ManageCourse.GenLoaderImport.LoadLevel,chain=icourseprog:;icourselvl:;icoursesemest:",TextBoxSQL("select p.ProgID, CONCAT(p.ProgName,' (',s.Name,')') as PName from programme_tb p, study_tb s, fac_tb f, dept_tb d where (".$deptasignsql.") AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = s.ID"));
              //create lvl dropdown
              TextBox("title=Level,style=width:250px;text-transform:uppercase,id=icourselvl,required=true,logo=list-ol,onchange=Course.ManageCourse.GenLoaderImport.LoadSemester",array() );
            }
          }
      TextBox("title={$sch['SemLabel']},style=width:250px;text-transform:uppercase,id=icoursesemest,required=true,logo=star-half-o,onchange=",array());
      $op = "0";
      _TextBoxGroup();

?>