<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");

//get posted data
extract($_POST);
if(!isset($regno) || trim($regno) == "" || !isset($cid) || intval($cid) < 1){
    exit("#Invalid Parameter");
}

//get the coursereg
$cregdet = $dbo->SelectFirstRow("coursereg_tb","","ID=".$dbo->SqlSafe($cid)." AND RegNo='".$dbo->SqlSafe($regno)."'");
if(!is_array($cregdet))exit("#Invalid Registration");

//delete records
$del = $dbo->Delete("coursereg_tb","ID=".$dbo->SqlSafe($cid));
if(!is_array($del)){
    exit("#Deleting $regno course/subject registration failed");
}
exit("#");


?>