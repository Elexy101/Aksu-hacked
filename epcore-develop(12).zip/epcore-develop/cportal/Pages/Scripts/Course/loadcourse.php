<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
 $sch = GetSchool();
function Error($title,$text){
  Box("class=defaultTabText");
  Box("style=color:red");Icon("exclamation-triangle fa-3x");_Box();
  Box();echo $title;_Box();  
  Box();echo $text;_Box();  
_Box();

}
//check priv
AllowUser("MngCourse");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

//cstudy=2&coursefac=5&coursedept=48&courseprog=49&courselvl=1&coursesemest=1
extract($_POST);
if(!isset($courseprog) || (int)$courseprog == 0 || !isset($courselvl) || (int)$courselvl == 0 || !isset($coursesemest) || (int)$coursesemest == 0){
   Error("INVALID PARAMETER","The Course/Subject Programme, Level and {$sch['SemLabel']} are required");
   exit;
}

//package parameter back
$cdet = json_encode($_POST);
$allset = COURSE();


//get course details
$coursdet = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p, schoollevel_tb l, study_tb s, semester_tb sm","f.FacName, s.Name as SName,p.ProgName, l.Name as LName, sm.Sem","d.FacID = f.FacID AND p.DeptID = d.DeptID AND l.Level = $courselvl AND l.StudyID = s.ID AND s.ID = f.StudyID AND p.ProgID = $courseprog AND f.StudyID = s.ID AND (sm.Num > 0 && sm.Num = $coursesemest) LIMIT 1");
//$coursdet = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p, schoollevel_tb l, study_tb s, semester_tb sm","f.FacName, s.Name as SName,p.ProgName, l.Name as LName, sm.Sem","d.FacID = f.FacID AND p.DeptID = d.DeptID AND l.Level = $courselvl AND l.StudyID = s.ID AND s.ID = $cstudy AND p.ProgID = $courseprog AND f.StudyID = s.ID AND sm.ID = $coursesemest LIMIT 1");
if(!is_array($coursdet)){
    Error("INTERNAL ERROR","Loading Course Details Failed");
   exit;
}

Box("style=width:calc(100% - 16px);margin:auto");
Table("style=width:100%;font-size:0.8em;margin:auto;margin-top:10px;text-align:left,id=coursedet,multiselect=false,data-type=table");
          $arrhed = array("SUMMARY:","STUDY","SCHOOL/FACULTY","DEPARTMENT","LEVEL",strtoupper($sch['SemLabel']));
             THeader($arrhed,"style=text-align:center,rspan=d1:2");
             $arrRec = array("<strong>{$coursdet['SName']}</strong>","<strong>{$coursdet['FacName']}</strong>","<strong>{$coursdet['ProgName']}</strong>","<strong>{$coursdet['LName']}</strong>","<strong>{$coursdet['Sem']}</strong>");
             TRecord($arrRec,"data-id=paytypesum,style=font-weight:bolder;text-transform:uppercase");
            _Table();
            // echo "<div style=\"width:100%; height:1px;margin:10px 0px\" class=\"altBgColor2\" > </div>";
            Line();
          //$procgrde = ; //return all grade structure with the grade symbole
         // Hidden("gradeStruc",GetGrade(-1));
$electgroup = array(1=>"ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE","TEN");
$datastr = '';
for($i=1;$i<=(int)$allset['MaxElectiveGrp'];$i++){
  $datastr .= "&".($i+1)."=".$electgroup[$i]." ONLY";
}
$sessarr = TextBoxSQL("select * from session_tb WHERE Enable = 1 ORDER BY Current DESC, SesID DESC");
//array_unshift($sessarr,"MAX SESSION");
ksort($sessarr);
$endsesarr = $sessarr+["0"=>"MAX SESSION"];
$startses = ["0"=>"MIN SESSION"]+$sessarr;

         $header=array(
           "*CCode"=>"CODE",
           "*CTitle"=>"TITLE",
           "*CH"=>"CH",
           "*StartSes"=>array("START",$dbo->DataString($startses)),
           "*EndSes"=>array("END",$dbo->DataString($endsesarr)),
           "*CStatus"=>array("STATUS","0=ENABLED&1=DISABLED"),
           "*Elective"=>array("ELECTIVE",'0=COMPULSORY&1=NONE OR ABOVE'.$datastr),
           "*GroupID"=>array("GROUP",$dbo->DataString(TextBoxSQL("select * from coursegroup_tb"))),
           "*NewCourseID"=>array("NEW","#select CourseID, CONCAT(CourseCode,' (',CH,')') as CourseCode from course_tb WHERE DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest AND CourseID != ?CourseID? ORDER BY CourseID ASC"),
           "*CourseID"=>"CID");
         //get all courses
         //$semcourses = $dbo->Select("course_tb","","DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest AND StudyID=$cstudy ORDER BY CourseID ASC");
         $semcourses = $dbo->Select("course_tb","","DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest ORDER BY CourseID ASC");

         if(!is_array($semcourses)){
            Error("INTERNAL ERROR","Loading {$sch['SemLabel']} Courses Failed");
            exit;
         }

         $dump = [];
         if($semcourses[1] > 0){
            
             //form all courses dump file
             while($indcourse = $semcourses[0]->fetch_array()){
                 //condition for gettin session
                 //$sescond = $indcourse['StartSesID'] == 0?"1=1 ORDER BY SesID LIMIT 1":"SesID=".$indcourse['StartSesID'];
                 //get start session
                // $sesArr = $dbo->SelectFirstRow("session_tb","",$sescond);
                 $dumparr = array($indcourse['CourseCode'],$indcourse['Title'],$indcourse['CH'],$indcourse['StartSesID'],$indcourse['EndSesID'],$indcourse['CourseStatus'],$indcourse['Elective'],$indcourse['GroupID'],$indcourse['Former'],$indcourse['CourseID']);
                 //$dumparr["ID"] = $indcourse['CourseID'];
                /*  $dumparr["logo"] =  "*print";
                 $dumparr["info"] =  "Print";
                $dumparr["Action"] =  "Course.ManageCourse.PrintCourse({$indcourse['CourseID']})"; */
                $dump[] = $dumparr;
             }
         }
         /* $recarr = array($rec[0],$rec['Name'],$rec[3],$rec['PayDate'],$rec['DeptName'],$rec['FacName'],$rec['Bank']);
                      // $BackPOST['displaytext'] = $_POST['displaytext'];
                      $BackPOST['reportType'] = 'paytypeprog';
                     $BackPOST['back'] = true;
                     $recarr["logo"] =  "*print";
				$recarr["info"] =  "Print";
				$recarr["Action"] =  "Payment.PaymentReport.PrintRc('{$rec['itemNum']}')";
                $dump[] = $recarr; */
                TextBoxGroup("width:100%");
                TextBoxGroupItem();
                Note("style=font-size:12px");
                if($allset['DuplicateCourse'] == 'TRUE'){
                  echo ' Duplicate Course (Same Course Code and Credit Hour) is <b style="font-weight:bold" >Allowed</b>';
                }else{
                  echo ' Duplicate Course (Same Course Code and Credit Hour) is <b style="font-weight:bold" >Not Allowed</b>';
                }

                echo '<br /> Allow/Disallow Duplicate Course Entering, Set Maximum Elective Group and Manage Course Groups in <a href="javascript:Page.OpenByTabName(\'csetting\')">Course Settings Module</a>';
                echo '<br/>Code, Title and CH Field are <b style="font-weight:bold" >REQUIRED</b>, If any not set, Record will be Ignored';

                _Note();
                _TextBoxGroupItem();
_TextBoxGroup();
                Line();
        Box("id=loadcsprsheet");
        SpreadSheet("rowselect=false,style=width:100%;margin:auto;margin-top:0px;border-top-color:transparent;margin-bottom:6px,id=sprstcourses,multiselect=false,cellfocus=,dynamiccolumn=false,dynamicrow=true,minrow=-1,disable=CourseID,rowfilter=true,filtertitle=FILTER COURSES,filterstyle=width:100%",$header,$dump);
        Hidden("loadtype","normal");
        _Box();
        Box("style=display:none,id=lcoursesdet");
         echo $cdet;
        _Box();
        _Box();

//echo "Load Course";

?>