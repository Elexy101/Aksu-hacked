<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

$Data = urldecode($_POST['Data']);
$DataObj = json_decode($Data,true);
if(isset($DataObj['SheetData'])){
    $RegNo = $DataObj['RegNo'];$ProgID = $DataObj['ProgID'];$LevelID = $DataObj['LevelID'];$SemesterID = $DataObj['SemesterID'];
    $headerd = ["-RegCID"=>"CourseID","*RegCCode"=>"CODE","*RegCTitle"=>"TITLE","*RegCCH"=>"CH","*RegCStatus"=>array("REGISTER","YES|NO")];
            SpreadSheet("rowselect=true,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px;font-size:1em,id=cregsheet|{$DataObj['RegNo']},multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=RegCID;RegCCode;RegCTitle;RegCCH,onswitchchange=Course.Register.UpdateReg",$headerd,$DataObj['SheetData']);
            if($DataObj['LLC']){ //if lower level courses is allowed
                echo '
                <div style="padding:10px">';
           LogoButton('onclick=Course.Register.LoadLLC(\''.$RegNo.'\'\,'.$ProgID.'\,'.$LevelID.'\,'.$SemesterID.');return false;,style=display:block;margin:auto;color:#fff,class=altBgColor2,logo=arrow-down,text=Lower Level Courses');
           echo'
               </div><div id="'.$RegNo.'_llc" style="">';
               // $headerd2 = ["-RegCID2"=>"CourseID","*RegCCode2"=>"CODE","*RegCTitle2"=>"TITLE","*RegCCH2"=>"CH","*RegCStatus2"=>array("REGISTER","YES|NO")];
                   //SpreadSheet("rowselect=true,style=width:calc(100% - 16px);margin:auto;margin-top:6px;margin-bottom:6px;font-size:1em,id=llccregsheet_$RegNo,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=RegCID2;RegCCode2;RegCTitle2;RegCCH2",$headerd2,$regdump2); 
               echo'</div>';
               Line();
               //$RegNo.'_cregbtn
               echo '<div id="'.$RegNo.'_umessage" style="text-align: center;margin: 10px 10px;box-sizing: border-box;"></div>';
               LogoButton('onclick=Course.Register.IndReger(_(\''.$RegNo.'_cregbtn\'));return false;,style=display:block;margin:auto;color:#fff,class=success,logo=wrench,text=Register Courses');
            }
}else{
    Box("class=defaultTabText");
   Box();Icon("exclamation-triangle fa-3x altColor");_Box();
   //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
   Box();echo"No Sheet Data Found";_Box();  
 _Box(); 
}
?>