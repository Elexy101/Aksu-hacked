<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

extract($_POST);
if(!isset($RegNo) ||  !isset($Data)){
    exit(json_encode(["Error"=>"Invalid Student Details"]));
}

//get the data
$DataObj = json_decode(urldecode($Data),true);

$SheetData = $DataObj["SheetData"];
$LevelID = $DataObj['LevelID'];
$SemesterID = $DataObj['SemesterID'];
$ProgID = $DataObj['ProgID'];

if(count($SheetData) < 1){
    exit(json_encode(["Error"=>"No Course Found"])); 
}

//get all register courses and details
$cnt = 0;
$courseIDs = [];
foreach ($SheetData as $Course) {
    //$CID = $Course[0];
    //$ST = $Course[4];
    if((int)$Course[4] == 0)continue;
    //get the course details
    $courseIDs[] = $Course[0]; 
}

if(count($courseIDs) < 1){
    exit(json_encode(["Error"=>"No Course Selected"]));
}

$regcourseup = $dbo->Select("course_tb","","CourseID=".implode(" OR CourseID=",$courseIDs));
$totregc = 0;
$NowReg = [];
$NowRegID = [];
if(is_array($regcourseup)){
    if($regcourseup[1] > 0){
        while($iprregc = $regcourseup[0]->fetch_assoc()){
            
$totregc++;
$NowReg[$iprregc['CourseID']] = $iprregc;
$NowRegID[] = $iprregc['CourseID'];
$totch += (int)$iprregc['CH'];
        }
        //check if course already registered
    $courseregex = $dbo->SelectFirstRow("coursereg_tb","","RegNo='".$dbo->SqlSafe($RegNo)."' AND Lvl=$LevelID AND Sem=$SemesterID LIMIT 1",MYSQLI_ASSOC);
    $maxch = GetMaxCH($ProgID,$LevelID,$SemesterID);
    //check if not already register
    if(!is_array($courseregex)){
       // Push('Registering Courses ...');
       $curses = CurrentSes();
        $lvlses = $curses['SesID'];
        
      $inst = $dbo->InsertID2("coursereg_tb",["RegNo"=>$RegNo,"Lvl"=>$LevelID,"CoursesID"=>implode("~",$NowRegID),"SesID"=>$lvlses,"Sem"=>$SemesterID,"RegDate"=>date('Y-m-d'),"MaxCH"=>$maxch,"CouresRegData"=>json_encode($NowReg),"TotCH"=>$totch]);
      if(is_numeric($inst)){
        exit(json_encode(["Success"=>"Course Registered Successfully"]));
      }else{
        exit(json_encode(["Error"=>"Registration Failed - ".$LevelID]));
      }

    }else{//perform an update
        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            //we suppose to check if student already have result for the current level and semester
            //if result exist for a course in $courseregex, check if the course is not part of course to update, add it to it 
            //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        $upd  = $dbo->Update("coursereg_tb",["CoursesID"=>implode("~",$NowRegID),"RegDate"=>date('Y-m-d'),"MaxCH"=>$maxch,"CouresRegData"=>json_encode($NowReg),"TotCH"=>$totch], "ID = ".$courseregex['ID']);
        if(is_array($upd)){
            exit(json_encode(["Success"=>"Courses Updated Successfully (".count($NowRegID).")"]));
        }else{
            exit(json_encode(["Error"=>"Update Failed"]));
        }

    }

    }else{
        exit(json_encode(["Error"=>"All Selected Courses does not Exist"]));
    }

}else{
    exit(json_encode(["Error"=>"Loading Selected courses Failed"]));
}

?>