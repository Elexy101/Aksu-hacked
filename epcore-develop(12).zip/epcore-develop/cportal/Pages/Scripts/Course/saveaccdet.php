<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("csetting");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

extract($_POST);
$query = [];
if(!isset($newses) || !isset($activesem))exit("#Invalid Academic Details");
$newses = trim($newses);
if($newses != ""){
    //check if already exist
    $exist = $dbo->SelectFirstRow("session_tb","","SesName='".$dbo->SqlSafe($newses)."'");
if(!is_array($exist)){
    $query[] = "INSERT session_tb SET SesName='".$dbo->SqlSafe($newses)."', Abbr = '".$dbo->SqlSafe($abbr)."'";
}
$query[] = "UPDATE session_tb SET Current = IF(SesName='".$dbo->SqlSafe($newses)."',1,0)";
}

$query[] = "UPDATE semester_tb SET Current = IF(ID=$activesem,1,0)";
//exit("~".$query);
$qu = true;
if(count($query) > 0){
    $query = implode(";",$query).";";
    //exit($query);
  //run the query
$qu = $dbo->Connection->multi_query($query);


    if($qu){
        do {
            /* store first result set */
                            if ($result = $dbo->Connection->store_result()) {
                                /*while ($row = $result->fetch_row()) {
                                    printf("%s\n", $row[0]);
                                }*/
                                $result->free();
                            }
                            /* print divider */
                            if ($dbo->Connection->more_results()) {
                                //printf("-----------------\n");
                            }
                        } while ($dbo->Connection->next_result());
                      
echo "*New School Academic Details Saved Successfully";
// form the update spread sheet

    }else{
echo "#Error Saving New Academic Details";
    }
}
//echo $str['Msg'];
?>