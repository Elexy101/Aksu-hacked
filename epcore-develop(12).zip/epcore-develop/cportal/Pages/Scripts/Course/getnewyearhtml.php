<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 $sch = $dbo->SelectFirstRow("school_tb");
 //require("../../../../general/getinfo.php");
 AllowUser("ssettings");
 //require("../../../../epconfig/GenScript/PHP/getinfo.php");
 TextBoxGroup();
 TextBox("title=New Session Name,style=width:250px;text-transform:uppercase,id=schnewsession,logo=plus");
 Note();
  echo "Add New Session and Set to Active";
 _Note();
 TextBox("title=New Session Abbriviation,style=width:250px;text-transform:uppercase,id=schnewsessionabb,logo=info-circle");
 _TextBoxGroup();

 Line();

 TextBoxGroup();
 TextBox("title={$schDet['SemLabel']},style=width:250px;text-transform:uppercase,id=coursestsem,logo=star-half-o,selected=-1",TextBoxSQL("select * from semester_tb where Enable = 1 ORDER BY Num,ID"));
 Note();
  echo "Set the Active {$schDet['SemLabel']}";
 _Note();
 _TextBoxGroup();
?>