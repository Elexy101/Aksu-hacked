<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
//
//AllowUser("ssettings");
//exit($_POST['SemID']."hhh");
$sch = $dbo->SelectFirstRow("school_tb","SemLabel,SchStartSem","1=1 LIMIT 1",MYSQLI_ASSOC);
$AsStart = !isset($_POST['AsStart'])?0:(int)$_POST['AsStart'];
$DisStr = $AsStart > 0?"School Start":"Current";
//get the ses id
if(!isset($_POST['SemID']))exit("#INVALID ".strtoupper($sch['SemLabel']));

//get the session details

$sesdet = $dbo->SelectFirstRow("semester_tb","","ID=".$_POST['SemID']);
if(!is_array($sesdet))exit("#READING ".strtoupper($sch['SemLabel'])." DETAILS FAILED");
if((int)$sesdet['Enable'] < 1)exit("#{$sesdet['Sem']} {$sch['SemLabel']} is Disabled. Hence, cannot be set as Active/Start.");

//form the query
if($AsStart > 0){
    $q = "UPDATE school_tb SET SchStartSem = {$_POST['SemID']}";
}else{
    $q = "UPDATE semester_tb SET Current = IF(ID = {$_POST['SemID']},1,0)"; 
}

$qrst = $dbo->RunQuery($q);
if(is_array($qrst)){
    if($AsStart == 1){
        $sch['SchStartSem'] = $_POST['SemID'];
    }
    echo '*'.$DisStr.' '.$sch['SemLabel'].' Set Successfully@%7&^%';
    $semheaders = array(
      "-SchSemID"=>"SemID",
      "*ScgSemName"=>strtoupper($sch['SemLabel']),
      "*ScgSemDescr"=>"DESCRIPTION",
      "*SchSemEnable"=>array("ENABLE","YES|NO"));
     // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
     SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schsemspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1",$semheaders, "SELECT ID, Sem, Descr, Enable, IF(Current = 1,'*check',IF(ID={$sch['SchStartSem']},'*university','#wrench')) as logo, IF(Current = 1,'Active ".$sch['SemLabel']."',IF(ID={$sch['SchStartSem']},'School Start ".$sch['SemLabel']."','Set to Current')) as info , CONCAT('School.SchoolSettings.SetSem(',ID,',\'',Sem,'\')') as Action FROM semester_tb ORDER BY Num");
     echo '<input type="hidden" id="SemLabelInp" value="'.$sch['SemLabel'].'" />';

}else{
    echo "#Error Setting $DisStr ".$sch['SemLabel'];
}
?>