<?php
  //require_once("../../../../general/TaquaLB/Elements/Elements.php");
  $configdir = "../../../../../../".$_POST['SubDir'];
  require_once("../../../../general/config.php");
  //require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request
  
  if(!isset($_POST['StaffID']) || !isset($_POST['Type']))exit(json_encode(["Error"=>"Invalid Parameter"]));

  $StaffID = (int)$_POST['StaffID'];
  $cond = "";
  if($StaffID > 0){ //get all staff
    $cond = "AND StaffID = $StaffID LIMIT 1";
  }

  $type = $_POST['Type'];
  if($type == "phone"){
    $setmax = $dbo->RunQuery("SET SESSION group_concat_max_len=53536747480;");
    // $field = "GROUP_CONCAT(Phone SEPARATOR ',') as Result";
    $rst = $dbo->SelectFirstRow("staff_tb","GROUP_CONCAT(Phone SEPARATOR ',') as Result","TRIM(Phone) != '' ".$cond);
    if(!is_array($rst))exit(json_encode(["Error"=>"No Phone Number Found"]));
    $phones = trim($rst['Result']);
    if($phones == '')exit(json_encode(["Error"=>"No Phone Number Found"]));
    $phonetot = count(explode(",",$phones));
    exit(json_encode(["Result"=>$phones,"Count"=>$phonetot,"Message"=>$phonetot>1?"$phonetot Phone Numbers Copied":"Phone Number Copied"]));
    //$rst = "SELECT GROUP_CONCAT(Phone SEPARATOR ',') as Result FROM staff_tb TRIM(Phone) != '' ".$cond;
  }

  exit(json_encode(["Error"=>"Invalid Parameter"]));

?>