<?php
  require_once("../../../../general/TaquaLB/Elements/Elements.php");
  $configdir = "../../../../../../".$_POST['SubDir'];
  require_once("../../../../general/config.php");
  require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or request
  $sch = GetSchool();
$enable = (isset($_POST['enable']) && $_POST['enable'] == "true")?"":",readonly=StudyID;Fac;Dept;ProgID;Lvl;Sem;Courses";
$headers = array(
               "*StudyID"=>array("STUDY TYPE",$dbo->DataString(TextBoxSQL("select * from study_tb where SchoolType = (select Type from school_tb limit 1)"))),
               "*Fac"=>array("FACULTY","#select FacID,FacName from fac_tb where StudyID = ?StudyID?"),
               "*Dept"=>array("DEPARTMENT","#select DeptID,DeptName from dept_tb where FacID = ?Fac?"),
               "*ProgID"=>array("PROGRAMME","#select * from programme_tb where DeptID = ?Dept?"),
               "*Lvl"=>array("LEVEL","#select Level, Name from schoollevel_tb where StudyID = ?StudyID? and SchoolTypeID = (select Type from school_tb limit 1) order by Level"),
               "*Sem"=>array(strtoupper($sch['SemLabel']),$dbo->DataString(TextBoxSQL("select IF(Num=0,ID,Num), Sem from semester_tb where Enable = 1"))),
               "*Courses"=>array("COURSES","#select CourseID,Concat(Title,'(',CourseCode,')') as Name from course_tb where Lvl = ?Lvl? and DeptID = ?ProgID? and Sem = ?Sem? and StudyID = ?StudyID?"));
               Box("id=courselecbx");
               SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=staffcourses,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9$enable",$headers);

?>