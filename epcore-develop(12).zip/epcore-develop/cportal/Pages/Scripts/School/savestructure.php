<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
extract($_POST);
if(!isset($Data) || !isset($Sheet)){
    exit("#INVALID PARAMETERS");
}

//the database default, will be save as default if no structure set in db
$dbdefault = [
    "SchID"=>["Name"=>"School","SilentMode"=>false],
    "StudyID"=>["Name"=>"Study","SilentMode"=>false],
    "FacGrpID"=>["Name"=>"Faculty Group","SilentMode"=>false],
    "FacID"=>["Name"=>"Faculty","SilentMode"=>false],
    "DeptID"=>["Name"=>"Department","SilentMode"=>false],
    "ProgID"=>["Name"=>"Programme","SilentMode"=>false],
    "ClassID"=>["Name"=>"Class","SilentMode"=>false]
];

//get current school type
$schtpe = $dbo->SelectFirstRow('school_tb','Type,SchStrucContr');
$SchStrucContr = $schtpe['SchStrucContr'];
if(is_null($SchStrucContr)){
    $SchStrucContr = [];
}else{
    $SchStrucContr = json_decode($SchStrucContr,true);
}
$Data = json_decode(urldecode($Data),true);
//get the current
$cur = $Data['Details']['Current'];
if(!isset($SchStrucContr[$cur])){
    $SchStrucContr[$cur] = [];
}
$SchStrucContr[$cur]["Name"] = trim($StrucName) == ""?$dbdefault[$cur]["Name"]:$StrucName;
//exit("SilentMode:"+$SilentMode);.$schtpe['Type']
$schid = $Data['SchID']['ID'];
$facgrpid = $Data['FacGrpID']['ID'];
$studyid = $Data['StudyID']['ID'];
$facid = $Data['FacID']['ID'];
$dptid = $Data['DeptID']['ID'];
$progid = $Data['ProgID']['ID'];
$StrData = [
    "SchID"=>["Table"=>"school_grp_tb","Fields"=>[1=>"SchGrpID","SchGrpName","SchGrpAddr","SchGrpCountry","SchGrpHeadUserID","SchGrpHeadTitle","SchGrpDecr"],"Require"=>[2,5],"KeyIndex"=>1,"Relationship"=>"study_tb.StudySchID"],
    "StudyID"=>["Table"=>"study_tb","Fields"=>[1=>"ID","Name","int StudyHeadUserID || 1","StudyHeadTitle","StudyDescr","AcceptLetter || '0'","int AcceptLetterID || 1","int SchoolType || ".$schtpe['Type'],"int StudySchID || ".$Data['SchID']['ID']],"Require"=>[2],"KeyIndex"=>1,"Relationship"=>"fac_tb.StudyID"],
    "FacGrpID"=>["Table"=>"facgroup_tb","Fields"=>[1=>"FacGrpID","FacGrpName","FacGrpDescr"],"Require"=>[2],"KeyIndex"=>1,"Relationship"=>"fac_tb.GroupID"],
    "FacID"=>["Table"=>"fac_tb","Fields"=>[1=>"FacID","FacName","int FacHeadUserID || 1","FacHeadTitle","Abbr","Descr","int GroupID || ".$facgrpid,"int StudyID || ".$studyid],"Require"=>[2,3],"KeyIndex"=>1,"Relationship"=>"dept_tb.FacID"],
    "DeptID"=>["Table"=>"dept_tb","Fields"=>[1=>"DeptID","DeptName","int DeptHeadUserID || 1","DeptHeadTitle","Abbr","int FacID || ".$facid,"Descr"],"Require"=>[2,3],"KeyIndex"=>1,"Relationship"=>"programme_tb.DeptID"],
    "ProgID"=>["Table"=>"programme_tb","Fields"=>[1=>"ProgID","ProgName","Degree","int YearOfStudy || 1","int ProgHeadUserID || 1","ProgHeadTitle","Abbr","RegNoFormat","int RegNumStart || 1","int DeptID || ".$dptid,"Descr"],"Require"=>[2,5],"KeyIndex"=>1,"Relationship"=>"studentclass_tb.ProgID"],
    "ClassID"=>["Table"=>"studentclass_tb","Fields"=>[1=>"ID","Name","int Capacity || 100","int HeadID || 1","HeadTitle","Descr","int ProgID || ".$progid],"Require"=>[2,4],"KeyIndex"=>1,"Relationship"=>""]
];
//Name,Capacity,HeadID, HeadTitle, Descr, ProgID
//if($cur == "SchID"){
   // exit("#".$Sheet);
if(isset($StrData[$cur])){
$grdsh = SheetDatabind($Sheet,$StrData[$cur]['Table'],$StrData[$cur]['Fields'],$StrData[$cur]['Require'],$StrData[$cur]['KeyIndex'],$StrData[$cur]['Relationship']);
    if ($grdsh !== true)exit($grdsh."");
    //update the school structure control
     $upd = $dbo->Update("school_tb",["SchStrucContr"=>json_encode($SchStrucContr)]);
     exit("#");
}
    
//}

//if($cur == "StudyID"){

//}

echo "STRUCTURE IDENTIFICATION FAILED";

?>