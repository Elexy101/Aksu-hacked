<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");//hold basic functions to perform some common database operations or 
 
$grpfield = array("UserID,StaffName,DOB,StateID,LGAID,Nat,Email,Phone,Emergency,Addrs","UserID","Rank,StaffSchID,EduQual,StaffUnit,UserID","DeptIDs","Courses","Sig");
if(isset($_POST['stid'])){
    $stid = $dbo->SqlSafe($_POST['stid']);
    $Grp = (int)$_POST['Grp'];
    $staffinfo = $dbo->SelectFirstRow("staff_tb",$grpfield[$Grp],"StaffID = $stid");
    $sch = GetSchool();
    $StrucObj = json_decode($sch['SchStrucContr'],true);
    if(is_array($staffinfo)){
        if($Grp == 4){ //if course
        $dump = array();
          $coursesID = trim($staffinfo['Courses']);
          if($coursesID != ""){
             $coursesIDArr = explode("~",$coursesID);
             if(count($coursesIDArr) > 0){ //
               foreach($coursesIDArr as $IndcourseID){
                   //if the classid is packaged along side
                   $courseclass=explode(':',$IndcourseID);
                   $classid =count($courseclass)>1?$courseclass[1]:0;
                   $IndcourseID=$courseclass[0];
                   $courseDet = $dbo->SelectFirstRow("course_tb","","CourseID = ".$IndcourseID);
                   if(is_array($courseDet)){ //if course details exist
                     //get fac and dept id 
                     $coursefacDept = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p","f.FacID, d.DeptID","p.DeptID = d.DeptID AND d.FacID = f.FacID AND p.ProgID = ".$courseDet['DeptID']);
                     if(is_array($coursefacDept)){
                         $FacID = $coursefacDept[0];
                         $DeptID = $coursefacDept[1];
                         //getthe class det
                         if($classid==0){
                             $classdet=$dbo->SelectFirstRow("studentclass_tb","ID","ProgID=".$courseDet['DeptID']." LIMIT 1");
                             $classid = is_array($classdet)?$classdet[0]:1;
                         }
                         //form dump record
                         $dump[] = array($courseDet['StudyID'],$FacID,$DeptID,$courseDet['DeptID'],$classid,$courseDet['Lvl'],$courseDet['Sem'],$IndcourseID) ;
                     }
                   }

               }
               //form the 
             }
          }
          // Form the Spread Sheet
          echo "*";
         
          $headers = array(
               "*StudyID"=>array(strtoupper($StrucObj['StudyID']['Name']),$dbo->DataString(TextBoxSQL("select * from study_tb where SchoolType = (select Type from school_tb limit 1)"))),
               "*Fac"=>array(strtoupper($StrucObj['FacID']['Name']),"#select FacID,FacName from fac_tb where StudyID = ?StudyID?"),
               "*Dept"=>array(strtoupper($StrucObj['DeptID']['Name']),"#select DeptID,DeptName from dept_tb where FacID = ?Fac?"),
               "*ProgID"=>array(strtoupper($StrucObj['ProgID']['Name']),"#select * from programme_tb where DeptID = ?Dept?"),
               "*ClassID"=>array(strtoupper($StrucObj['ClassID']['Name']),"#select * from studentclass_tb where ProgID = ?ProgID?"),
               "*Lvl"=>array("LEVEL","#select Level, Name from schoollevel_tb where StudyID = ?StudyID? and SchoolTypeID = (select Type from school_tb limit 1) order by Level"),
               "*Sem"=>array(strtoupper($sch['SemLabel']),$dbo->DataString(TextBoxSQL("select IF(Num=0,ID,Num), Sem from semester_tb where Enable = 1"))),
               "*Courses"=>array("COURSE","#select CourseID,Concat(Title,' (',CourseCode,')') as Name from course_tb where Lvl = ?Lvl? and DeptID = ?ProgID? and Sem = ?Sem? and StudyID = ?StudyID?"));
               Box("id=courselecbx,style=width:calc(100% -12px);margin:auto;position:relative");
               SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=staffcourses,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=12",$headers,$dump);
        }elseif($Grp == 3){ //departments
          $DeptIDs = trim($staffinfo['DeptIDs']);
          $dump = array();
          if(trim($DeptIDs) != ""){
             //get depts 
             $DeptIDArr = explode("~",$DeptIDs);
             if(count($DeptIDArr) > 0){
                 foreach($DeptIDArr as $InDepID){
                     //get the facID
                     $facDept = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p","f.FacID,f.StudyID","p.DeptID = d.DeptID AND d.FacID = f.FacID AND p.ProgID = ".$InDepID);
                     if(is_array($facDept)){
                         $facID = $facDept[0];
                         $studid = $facDept[1];
                         $dump[] = array($studid,$facID,$InDepID);
                     }
                 }
             }
          }
          echo "*";
           $headerd = array(
            "*Studys"=>array(strtoupper($StrucObj['StudyID']['Name']),$dbo->DataString(TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1)"))),
               "*Facd"=>array(strtoupper($StrucObj['FacID']['Name']),"#select FacID,FacName from fac_tb where StudyID = ?Studys?"),
             
               "*ProgIDd"=>array(strtoupper($StrucObj['ProgID']['Name']),"#select p.ProgId, p.ProgName from programme_tb p, dept_tb d where p.DeptID = d.DeptID and d.FacID = ?Facd?")
         );
         SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=staffdepts,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=12",$headerd,$dump);
        }else{
            
            if($Grp == 2){//if school loading
            $RstUpload = 0;//default for result upload priveliege is off
                //get the user priv 
                $userdet = $dbo->SelectFirstRow("user_tb","Privs","UserID = ".$staffinfo['UserID']);
                //$RstUpload = $userdet;
                if(is_array($userdet)){
                    $userPriv = $userdet[0];
                    $userPrivarr = explode(":",$userPriv);
                    
                    if(in_array("RUpload",$userPrivarr)){ //if can upload result
                      $RstUpload = 1;
                    }
                }
                $staffinfo["Priv"] = $RstUpload;
            }
        echo "*".$dbo->DataString($staffinfo);
        }
    }else{
       echo "#INVALID STAFF"; 
    }
}else{
    echo "#INVALID PARAMETER";
}


?>