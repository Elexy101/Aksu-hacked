<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");
extract($_POST);

if(!isset($StudyID) || !isset($Sheet)){
    exit("#INVALID PARAMETERS");
}

$schtype = $dbo->SelectFirstRow('school_tb','Type');
$SchTypeID = $schtype['Type'];
$grdsh = SheetDatabind($Sheet,"schoollevel_tb",[1=>"ID","Name","Level","Descr","StudyID || ".$StudyID,"SchoolTypeID || ".$SchTypeID],[2,3,5]);
    if ($grdsh !== true)exit($grdsh."");
     exit("#");

?>