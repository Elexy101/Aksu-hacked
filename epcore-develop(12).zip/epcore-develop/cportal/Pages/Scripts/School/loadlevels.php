<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
//require("../../../../general/getinfo.php");;
if(!isset($_POST['StudyID']) || (int)$_POST['StudyID'] == 0)exit("#");
$StudyID = $_POST['StudyID'];
//get the schid from study-tb
$StudyDet = $dbo->SelectFirstRow('study_tb','','ID='.$StudyID);
if(!is_array($StudyDet))exit("#"); //invalid study recieved
$SchID = $StudyDet['StudySchID'];
$headerdc = array(
    "-SchLvlID"=>"ID",
    "*SchLvlName"=>"NAME",
    "*SchLvlNum"=>"NUMBER",
    "*SchLvlDescr"=>"DESCRIPTION",
    "*SchLvlStudy"=>["STUDY","#select ID,Name from study_tb where SchoolType = (select Type from school_tb limit 1) and StudySchID = $SchID"],
    "-SchLvlSchType"=>"Type"
   );
   SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schlvldetsprs,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=9,case=none",$headerdc,"Select ID,Name,Level,Descr,StudyID,SchoolTypeID from schoollevel_tb where StudyID = $StudyID");
   Hidden("SchLvlLoadDet",$StudyID);
?>