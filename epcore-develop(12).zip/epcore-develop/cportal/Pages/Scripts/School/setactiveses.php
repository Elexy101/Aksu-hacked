<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 //require("../../../../general/getinfo.php");
//AllowUser("ssettings");
$sch = $dbo->SelectFirstRow("school_tb","SchStartSes","1=1 LIMIT 1");
//get the ses id
if(!isset($_POST['SesID']))exit("#INVALID SESSION");
$AsStart = isset($_POST['AsStart'])?(int)$_POST['AsStart']:0;
$Str = $AsStart == 0?"Current":"Start";
//get the session details
$sesdet = $dbo->SelectFirstRow("session_tb","","SesID=".$_POST['SesID']);
if(!is_array($sesdet))exit("#READING SESSION DETAILS FAILED");
if((int)$sesdet['Enable'] < 1)exit("#{$sesdet['SesName']} Session is Disabled. Hence, cannot be set as $Str Session.");

//form the query
if($AsStart == 1){
    $q = "UPDATE school_tb SET SchStartSes = {$_POST['SesID']}";
}else{
    $q = "UPDATE session_tb SET Current = IF(SesID = {$_POST['SesID']},1,0)";
}

$qrst = $dbo->RunQuery($q);
if(is_array($qrst)){
    if($AsStart == 1){
        $sch['SchStartSes'] = $_POST['SesID'];
    }
    echo '*'.$Str.' Session Set Successfully@%7&^%';
    $sesheaders = array(
        "-SchSesID"=>"SesID",
        "*ScgSessionN"=>"SESSION",
        "*ScgSessionAbb"=>"ABBREVIATION",
        "*SchSesEnable"=>array("ENABLE","YES|NO"));
      // Box("id=coverbox,style=width:inherit;height:inherit;background-color:red;position:absolute;z-index:1");_Box();
       SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:6px;margin-bottom:6px,id=schsessionspsh,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=-1",$sesheaders, "SELECT SesID, SesName, Abbr, Enable, IF(Current = 1,'*check',IF(SesID={$sch['SchStartSes']},'*university','#wrench')) as logo, IF(Current = 1,'Active Session',IF(SesID={$sch['SchStartSes']},'Start Session','Set to Active')) as info , CONCAT('School.SchoolSettings.SetSession(',SesID,',\'',SesName,'\')') as Action FROM session_tb ORDER BY SesID");

}else{
    echo "#Error Setting Active Session";
}
?>