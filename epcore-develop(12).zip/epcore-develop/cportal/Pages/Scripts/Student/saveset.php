<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");



//get the total entered rechords
$TotalRec = (int)$_POST['MaxDataRow'];

$formdissettings = [];
if($TotalRec > 0){
    for($i=1;$i<=$TotalRec;$i++){
        //get the student db id
        if(!isset($_POST[$i.'_1']) || trim($_POST[$i.'_1']) == "")continue;
        //get the old and new regnos
        $GroupID = $_POST[$i.'_1'];
        $GTitle = $_POST[$i.'_2'];
        $GDescr = $_POST[$i.'_3'];
        $GDisplay = (int)$_POST[$i.'_4'];
        $GReq = $_POST[$i.'_5'];
        $formdissettings[$GroupID] = ["Display"=>$GDisplay == 1?true:false,"Title"=>$GTitle,"Descr"=>$GDescr,"Required"=>$GReq == 1?true:false];
     //"Basic"=>["Display"=>true,"Title"=>"Details","Descr"=>"Student Personal Details","Required"=>true]
        //check if student record is deleted
    }
}

//if(count($formdissettings) < 1)exit("Update ")

$formdissettingstr = json_encode($formdissettings);//AdminVerifyPay 
$passpReuire = (int)$_POST['PassportReq'] > 0?"TRUE":"FALSE";
$AdminVerifyPay = (int)$_POST['AdminVerifyPay'] > 0?"TRUE":"FALSE";
$AutoAdmission = (int)$_POST['AutoAdmission'] == 0?"DISABLE":((int)$_POST['AutoAdmission'] == -1?"ADMIT":"CREATE");

//perform update
$updsch = $dbo->Update("studentset_tb",["DisplayStudData"=>$formdissettingstr,"AdminPassportReq"=>$passpReuire,"AdminVerifyPay"=>$AdminVerifyPay,"AutoAdmission"=>$AutoAdmission]);
if(!is_array($updsch))exit("#Saving Settings Failed");
exit("*Settings Saved Successfully");

?>