<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
$crit = $dbo->SqlSafe($_POST['crit']);
$val = $dbo->SqlSafe($_POST['val']);
$callerId = isset($_POST['callId'])?$_POST['callId']:"";
$onselect = isset($_POST['onselect'])?$_POST['onselect']:"";
$onunselect = isset($_POST['onunselect'])?$_POST['onunselect']:"";
$startindex = (int)$dbo->SqlSafe($_POST['startindex']);
$pre = $dbo->SqlSafe(trim($_POST['param']));

$cond = ""; 
$orderBy = "";
$img = $crit == "imgsc"?true:false;

//if($crit == "regsc"){
	//$cond = "RegNo LIKE '%{$val}%' or JambNo LIKE '%{$val}%' ";
	
//}else{
	//$cond = "CONCAT(SurName,' ',FirstName,' ',OtherNames)  LIKE '%{$val}%' ";
//}
if($val == "::all" || $val == "::first" || $val == "::last"){
   $cond = "1=1";
}else{
$cond = "RegNo LIKE '%{$val}%' or JambNo LIKE '%{$val}%' or CONCAT(SurName,' ',FirstName,' ',OtherNames)  LIKE '%{$val}%' ";
}
if($val == "::first"){
  $orderBy = "ORDER BY ID LIMIT 1";
}else if($val == "::last"){
   $orderBy = "ORDER BY ID desc LIMIT 1";
}else{
$orderBy = "ORDER BY RegNo, JambNo, SurName, FirstName, OtherNames LIMIT {$startindex},500";
}
$val = strtoupper($val);
if($img == false){
  Table("rowselect=true,style=width:100%;font-size:0.7em;margin:auto,id={$callerId},onselect={$onselect},onunselect={$onunselect},multiselect=false,data-type=table");
 // Hidden($callerId."_objtype","tbl");
}else{
	if($startindex == 0 ){
		ThumbNailBox("id={$callerId},onselect={$onselect},onunselect={$onunselect},data-type=thumbnail");
		//echo "select RegNo, JambNo, SurName, FirstName, OtherNames, Passport, id AS det from studentinfo_tb where $cond union select RegNo, JambNo, SurName, FirstName, OtherNames, Passport, Accept AS det from pstudentinfo_tb where $cond ".$orderBy;
	}else{
		$curthumbNGroup = $callerId;
        $curthumbSelFunc = $onselect;
        $curthumbUnSelFunc = $onunselect;
	}

}

global $rwcnter;		   
if($startindex == 0 && $img == false){ //if first trip and not image critaria create the table headers
 THeader(array("Reg. No.","Name")); //give the header
}else{ //if other trip, set the rowcounter to start from the new row number
	
	$rwcnter = $startindex;		 
}
$difField = $pre == "p"?"0 AS det":"1 AS det";
//will be used to differentiate studentinfo_tb  and pstudentinfo_tb i.e Accept will always be 0 which is used for pstudentinfo_tb while id will always be greater than 0, for studentinfo_tb - no more in use
if($pre != "a"){
   $studs = $dbo->Select4rmdbtb($pre."studentinfo_tb","ID, RegNo, JambNo, SurName, FirstName, OtherNames, Passport, RegID, $difField ",$cond ." ".$orderBy);
}else{
   $studs = $dbo->RunQuery("select ID, RegNo, JambNo, SurName, FirstName, OtherNames, Passport, RegID, 1 AS det from studentinfo_tb where $cond union select ID, RegNo, JambNo, SurName, FirstName, OtherNames, Passport, RegID, 0 AS det from pstudentinfo_tb where $cond ".$orderBy);
}
		  if(is_array($studs)){
			   $tot = $studs[1];
			  // echo "total: {$tot}";
			   if($studs[1] > 0){
				   $cnt = 1;
				   $curentRegNo = '';
				   while($stud = $studs[0]->fetch_array()){
					   $regno = $stud["RegNo"];
					   if(trim($regno) == ""){
						   $regno = trim(strtoupper($stud["JambNo"]));
					   }
					  if($regno == "" || $regno == $curentRegNo){continue;}//no duplicate reg no
					  $curentRegNo = $regno;
					   $Name = strtoupper($stud["SurName"] . " " .  $stud["FirstName"]. " " .  $stud["OtherNames"]);
					   $det = $stud["det"];
					   $RegID = $stud["RegID"];
					  // if($crit == "regsc"){
						   $reglw = strtolower($regno);
						   $vallw = strtolower($val);
						   $regno = strtoupper(str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",$reglw));
					  // }else{
					   $nmlw = strtolower($Name);
						   //$vallw = strtolower($val);
					   $NameS = strtoupper(str_replace($vallw,"<strong style=\"color:#EB2E12\">{$val}</strong>",$nmlw));
					  // }
					   $sel = "";
					  /* if($cnt == 1 || $cnt == 2 || $cnt == 4){
						   $sel = "selected=1:2";
					   }*/
					   if($img == false){
                         TRecord(array($regno,$NameS),"data-id=$reglw");
						 Hidden($callerId."_rw_".$rwcnter."_1_det",$det);
						 Hidden($callerId."_rw_".$rwcnter."_1_regid",$RegID);
					   }else{
						  $passp = explode("?",$stud["Passport"]);
						  $passp = ResolveFilePath(ResolvePassport($passp[0]));
						  $id = "s".time().$cnt."_".str_replace("/","_",str_replace(" ","",$reglw));
						  //echo $id;
						  $regno = EscapeString($regno);
						  ThumbNail("src=$passp ,title=$Name , text=$regno, id=$id, data-id=$reglw,base=".$configdir);
						  Hidden($id."_det",$det);
						  Hidden($id."_regid",$RegID);
						 /* $path = "";
						  if(file_exists("../../../".$passp) && trim($passp) != ""){
						list($width, $height, $type, $attr) = getimagesize("../../../".$passp);
	                     // list($width, $height, $type, $attr) = getimagesize("../../../../epconfig/UserImages/Student/777777777AD.jpg");
	                    list($w,$h,$o) = AutoFit(75,80,$width,$height,10);
						  }else{
							  $passp = "../epconfig/TaquaLB/Elements/Images/imglogosm.jpg";
							  list($w,$h) = array(65,43);
						  }
                          Box("class=ThumbNail,title=$Name,onclick={$onselect}(this)");
	                       Box("class=ImgBox");
						  echo '<img src="'.$passp.'" style="width:'.$w.'px;height:'.$h.'px " alt="'.$Name.'" /> ';
							_Box();
							Box("class=TextBox");
								echo $regno;
							_Box();
							_Box();*/
						
						
					   }
					   
					   
					   $cnt++;
				   }
				   if($img){ClearFloat();}
			   }
		   }
		   if($studs[1] < 500){ //if record seen is less thean the total per trip, cover the table (meaning end the loading)
		   //echo "ssss";
		   if($img == false){
		     _Table($callerId);
		   }else{
			   Hidden("totrw_{$callerId}",$studs[1]+1);
			   _ThumbNailbox();
		   }
			 //echo "<input type=\"hidden\" id=\"totrw_{$callerId}searchStud\" value=\"{$studs[1]}\" />
			  // ";
			// echo '<div id="searchlst"></div>';
		   }else{
			 if($img == false){
			   if($startindex == 0){//first trip only
			   echo "<input type=\"hidden\" id=\"sel_{$callerId}\" value=\"\" />
			   <input type=\"hidden\" id=\"data_{$callerId}\" value=\"\"
	            data-multiselect=\"false\" 
			    data-lastselect=\"\"
		       />";
			   }
			   echo "</table>";
			 }
		   }

?>