<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
function Error($title,$text){
    Box("class=defaultTabText");
    Box("style=color:red");Icon("exclamation-triangle fa-3x");_Box();
    Box();echo $title;_Box();  
    Box();echo $text;_Box();  
  _Box();
  
  }

  $sch = GetSchool();
  $schStruc = json_decode($sch['SchStrucContr'],true);

/* {"preloadstudy":"5","preloadfac":"1","preloaddept":"22","preloadprog":"23","preloadstartses":"9","preloadclass":"1","loadstudbtn":" Load Students ","SubDir":"nacos\/"}  */
if(!isset($_POST['preloadstudy']) || (int)$_POST['preloadstudy'] < 1 || !isset($_POST['preloadprog']) || (int)$_POST['preloadprog'] < 1 || !isset($_POST['preloadstartses']) || (int)$_POST['preloadstartses'] < 1 ){
    Error("INVALID PARAMETER","Select required academic details");
    exit;
}
$preloadstudy = (int)$_POST['preloadstudy'];
$preloadprog = (int)$_POST['preloadprog'];
$preloadstartses = (int)$_POST['preloadstartses'];
$preloadclass = (!isset($_POST['preloadclass']) || (int)$_POST['preloadclass'] < 1) ?0:(int)$_POST['preloadclass'];
$preloadmoe = (!isset($_POST['preloadmoe']) || (int)$_POST['preloadmoe'] < 1) ?1:(int)$_POST['preloadmoe'];

$query = "SELECT s.id, s.RegNo, s.JambNo, s.SurName, s.FirstName, s.OtherNames, s.Gender, s.StateId, s.LGA, s.Phone, COALESCE(s.Addrs,'') as Addrs, COALESCE(a.AccessCode,'') as AccessCode, s.RegNo as OldRegNo, s.JambNo as OldJambNo,COALESCE(a.ID,0) as AccessCodeID, 1 as `IsInclude`,'*list-alt' as logo, 'Perform Action' as info, CONCAT('Student.PreLoad.Options(\'',IF(TRIM(s.RegNo)='',s.JambNo,s.RegNo),'\',',s.id,')') as Action FROM studentinfo_tb s LEFT JOIN accesscode_tb a ON ((a.JambNo = s.RegNo OR a.JambNo = s.JambNo) AND a.JambNo != '') WHERE ProgID = ".$dbo->SqlSafe($preloadprog)." AND StartSes = ".$dbo->SqlSafe($preloadstartses)." AND ClassID = ".$dbo->SqlSafe($preloadclass)." AND ModeOfEntry = ".$dbo->SqlSafe($preloadmoe)." ORDER BY s.id" ;

/* Student.RegReport.PrintRc(\'',RegNo,'\')' */
$qrst = $dbo->RunQuery($query);
		if(is_array($qrst) && $qrst[1] > 0){
			//$dump = $qrst[0]->fetch_all(MYSQLI_BOTH);
			$dump = $dbo->FetchAll($qrst[0]);
			//echo json_encode($dump);
		}else{
			//echo $qrst;
			$dump = [];	
        }

        $classphone = "";
//get all the phone numbers for sms
$phonnums = $dbo->RunQuery("SELECT GROUP_CONCAT(Phone SEPARATOR ',') as Phones FROM studentinfo_tb WHERE ProgID = ".$dbo->SqlSafe($preloadprog)." AND StartSes = ".$dbo->SqlSafe($preloadstartses)." AND ClassID = ".$dbo->SqlSafe($preloadclass)." AND ModeOfEntry = ".$dbo->SqlSafe($preloadmoe)." AND TRIM(Phone) != ''");
if(is_array($phonnums) && $phonnums[1] > 0){
    $phoneumss = $phonnums[0]->fetch_assoc();
    $classphone = $phoneumss['Phones'];
}


//get all academic detaisl
$acdet = $dbo->SelectFirstRow("study_tb st, fac_tb f, dept_tb d, programme_tb p, session_tb se, modeofentry_tb me ","st.Name as StudyName, f.FacName,p.ProgName,se.SesName,me.Name as MOE","st.ID = $preloadstudy AND d.FacID = f.FacID AND p.DeptID = d.DeptID AND p.ProgID = $preloadprog AND se.SesID = $preloadstartses AND me.Level = $preloadmoe LIMIT 1");
$defdet = !is_array($acdet)?["StudyName"=>"--","FacName"=>"--","ProgName"=>"--","SesName"=>"--","MOE"=>"--"]:$acdet;

//get class group
$classgrp = "--";
if($preloadclass > 0){
    $classdet = $dbo->SelectFirstRow("studentclass_tb","","ID=".$preloadclass);
    if(is_array($classdet)){
        $classgrp = $classdet["Name"];
    }
}

//get Calculated Level
$lvldet = GetLevel($preloadstartses,$preloadprog,$preloadstudy);



Table("style=width:100%;font-size:0.8em;margin:auto;margin-top:10px;text-align:left,id=coursedet,multiselect=false,data-type=table,class=fadeIn animated");
          $arrhed = [];
          if($schStruc['StudyID']['SilentMode'] == false)$arrhed[] = strtoupper($schStruc['StudyID']['Name']);
          if($schStruc['FacID']['SilentMode'] == false)$arrhed[] = strtoupper($schStruc['FacID']['Name']);
          if($schStruc['ProgID']['SilentMode'] == false)$arrhed[] = strtoupper($schStruc['ProgID']['Name']);
          $arrhed[] = "BATCH";
          if($schStruc['ClassID']['SilentMode'] == false)$arrhed[] = strtoupper($schStruc['ClassID']['Name']);
          $arrhed[] = "M.O.E";
          $arrhed[] = "TOTAL";
        //   $arrhed = array($schStruc['StudyID']['Name'],$schStruc['FacID']['Name'],$schStruc['ProgID']['Name'],"BATCH",$schStruc['ClassID']['Name'],"M.O.E","Total");
             THeader($arrhed,"style=text-align:left");
            //  $arrRec = array("<strong>{$defdet['StudyName']}</strong>","<strong>{$defdet['FacName']}</strong>","<strong>{$defdet['ProgName']}</strong>","<strong>{$defdet['SesName']}</strong>","<strong>$classgrp</strong>","<strong>{$defdet['MOE']}</strong>","<strong>".count($dump)."</strong>");
             $arrRec = [];
          if($schStruc['StudyID']['SilentMode'] == false)$arrRec[] = "<strong>{$defdet['StudyName']}</strong>";
          if($schStruc['FacID']['SilentMode'] == false)$arrRec[] = "<strong>{$defdet['FacName']}</strong>";
          if($schStruc['ProgID']['SilentMode'] == false)$arrRec[] = "<strong>{$defdet['ProgName']}</strong>";
          $arrRec[] = "<strong>{$defdet['SesName']}</strong>";
          if($schStruc['ClassID']['SilentMode'] == false)$arrRec[] = "<strong>{$lvldet['LevelName']} ($classgrp)</strong>";
          $arrRec[] = "<strong>{$defdet['MOE']}</strong>";
          $arrRec[] = "<strong>".count($dump)."</strong>";
             TRecord($arrRec,"data-id=paytypesum,style=font-weight:bolder;text-transform:uppercase");
            _Table();
            // echo "<div style=\"width:100%; height:1px;margin:10px 0px\" class=\"altBgColor2\" > </div>";
            Line();

$headers = array("-StudID"=>"StudID","*stRegNo"=>"REG. NO.","#stJambNo"=>"ENTRANCE NO.","#stSurName"=>"SURNAME","#stFirstName"=>"FIRSTNAME",
"#stOtherNames"=>"OTHERNAMES","#stGender"=>array("GENDER","M=MALE&F=FEMALE"),"*stStateIds"=>array("STATE",$dbo->DataString(TextBoxSQL("select * from state_tb order by StateID"))),
"#stLGA"=>array("LGA","#select * from lga_tb where StateID=?stStateIds?"),"*stPhone"=>"PHONE","*stAddrs"=>"ADDRESS","*AccessC"=>"ACCESS CODE","-OldRegNo"=>"OldReg","-OldJambNo"=>"OldJamb","-ACID"=>"AccessCodeID","*stInclude"=>array("MIGRATE","YES|NO"));
echo '<div style="width:calc(100% - 4px);box-sizing:border-box">';
    LogoButton('onclick=Student.PreLoad.Migrate();return false;,style=display:block;float:right;color:#fff,class=success,logo=share-square,text=Migrate All');
    LogoButton('onclick=Student.PreLoad.SendSMS();return false;,style=display:block;float:right;margin-right:4px;color:#fff,class=altBgColor2,logo=envelope,text=Send SMS');
    /* echo '<button onclick="_(\''.$RegNo.'_tray\').ToggleShowHide()" style="display:block;float:right"  class="altBgColor2 bbtn"><i class="fa fa-list-alt"></i> Process Tray</botton>'; */
    echo'<div style="clear:both"></div></div>';
    //Line();
SpreadSheet("rowselect=false,class=fadeIn animated delay-0-2s,style=width:calc(100% - 12px);margin:auto;margin-bottom:6px,id=biodataPreload,multiselect=false,readonly=SurName,disable=stJambNo,dynamiccolumn=false,dynamicrow=true,case=inherit,minrow=10,rowfilter=true,filtertitle=FILTER CLASS LIST,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:6px",$headers,$dump);
echo '<div id="classphones" style="display:none">'.$classphone.'</div>';

?>

