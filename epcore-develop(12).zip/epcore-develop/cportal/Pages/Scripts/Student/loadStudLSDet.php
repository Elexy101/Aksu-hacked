<?php
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
if(!isset($_POST['RegNo'])){
    exit("Invalid RegNo");
}

$regno = urldecode($_POST['RegNo']);

$data = GetBasicInfo($regno,"studsch");

if(!is_array($data))exit("Invalid Student");

$studlvl = StudLevelStartSes($regno,(int)$_POST['StartSes']);

        $yearofSt = StudYearOfStudy($regno,"");
       
		if(((int)$studlvl - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
            $LvlName = strtoupper($spilstr)." ".((int)$studlvl - $yearofSt);
            
		}else{
			$LvlName = LevelName($studlvl,$data['StudyID']);
        }
        $cursem = GetCurrentSem();
        

        $studlvlsem = GetStudLvlSemDetails($regno);
        
$studlvlop = is_array($studlvlsem)?$studlvlsem['LevelName']:"--";
$studsemop = is_array($studlvlsem)?$studlvlsem['SemesterName']:"--";
//exit($studlvlop);
/* oplvl.textContent = dt.OpLevelName + " | "+dt.OpSemesterName;
			exlvl.textContent = dt.ExLevelName + " | "+dt.ExSemesterName; */
echo json_encode(["OpLevelName"=>$studlvlop,"OpSemesterName"=>$studsemop,"ExLevelName"=>$LvlName,"ExSemesterName"=>$cursem['Descr']]);
?>