<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

//get loaded details
$preloadstudy = (int)$_POST['preloadstudy'];
$preloadprog = (int)$_POST['preloadprog'];
$preloadstartses = (int)$_POST['preloadstartses'];
$preloadclass = (!isset($_POST['preloadclass']) || (int)$_POST['preloadclass'] < 1) ?0:(int)$_POST['preloadclass'];
$preloadmoe = (!isset($_POST['preloadmoe']) || (int)$_POST['preloadmoe'] < 1) ?1:(int)$_POST['preloadmoe'];

//get migrate details
$mpreloadstudy  = (int)$_POST['mpreloadstudy'];
$mpreloadprog = (int)$_POST['mpreloadprog'];
$mpreloadstartses = (int)$_POST['mpreloadstartses'];
$mpreloadclass = (!isset($_POST['mpreloadclass']) || (int)$_POST['mpreloadclass'] < 1) ?0:(int)$_POST['mpreloadclass'];
$mpreloadmoe = (!isset($_POST['mpreloadmoe']) || (int)$_POST['mpreloadmoe'] < 1) ?1:(int)$_POST['mpreloadmoe'];

if($mpreloadstudy == 0 || $mpreloadprog == 0 || $mpreloadstartses == 0){

    exit(json_encode(["Success"=>FALSE,"Message"=>"#INVALID MIGRATE DETAILS SPECIFIED - $mpreloadstudy , $mpreloadprog , $mpreloadstartses"]));
}

$queryarr = [];
//check if single student migrate
if(isset($_POST['StudID']) && (int)$_POST['StudID'] > 0){
    $studdet = $dbo->SelectFirstRow("studentinfo_tb","ProgID,IF(RegNo='',JambNo,RegNo) as StudRegNo","id=".$_POST['StudID']);
        if(!is_array($studdet))exit(json_encode(["Success"=>FALSE,"Message"=>"#Invalid Student"])); 
        $ProgID = (int)$studdet['ProgID'];
        $StudRegNo = $studdet['StudRegNo'];

    $queryarr[] = "UPDATE studentinfo_tb SET StudyID=$mpreloadstudy, ProgID=$mpreloadprog, StartSes=$mpreloadstartses, ClassID=$mpreloadclass, ModeOfEntry=$mpreloadmoe WHERE id=".$_POST['StudID'];

    //check if student prog has changed
    if($ProgID > 0 && $mpreloadprog > 0 &&  $ProgID != $mpreloadprog){
        //make all payment and course reg inactive
        // foreach(["coursereg_tb","order_tb","payhistory_tb","result_tb"] as $tbg){
             foreach(["coursereg_tb","result_tb"] as $tbg){
            $queryarr[] = "UPDATE $tbg SET RegNo=CONCAT(RegNo,'_inactive') WHERE RegNo = '$StudRegNo'";
        } 
    }
    
    $query = implode(";",$queryarr).";";
    //exit(json_encode(["Success"=>FALSE,"Message"=>$query])); 
    if(trim($query) != ""){
        $dump = $dbo->Connection->multi_query($query);
         if(!$dump){
            exit(json_encode(["Success"=>FALSE,"Message"=>"#Server Error: ".$dbo->Connection->error]));
         }else{
                 do {
                         /* store first result set */
                                                         if ($result = $dbo->Connection->store_result()) {
                                                                 /*while ($row = $result->fetch_row()) {
                                                                         printf("%s\n", $row[0]);
                                                                 }*/
                                                                 $result->free();
                                                         }
                                                         /* print divider */
                                                         if ($dbo->Connection->more_results()) {
                                                                 //printf("-----------------\n");
                                                         }
                                                 } while ($dbo->Connection->next_result());
                                                 exit(json_encode(["Success"=>TRUE,"Message"=>"*Student Migrated"]));
                                         }
        
    }else{
        exit(json_encode(["Success"=>FALSE,"Message"=>"#No Update Found"])); 
    }
   /*  $rq = $dbo->RunQuery($queryarr);
    if(!is_array($rq)){
        exit(json_encode(["Success"=>FALSE,"Message"=>"#Server Error: ".$rq]));
    }else{
        exit(json_encode(["Success"=>TRUE,"Message"=>"*Student Migrated"]));
    } */
}else{
    $TotalRec = (int)$_POST['MaxDataRow'];

if($TotalRec > 0){
    for($i=1;$i<=$TotalRec;$i++){
        $StudID = (int)$_POST[$i.'_1'];
        $include = (int)$_POST[$i.'_16'];
        if( $include < 1)continue;
        if($StudID < 1)continue;
        //get the student details
        $studdet = $dbo->SelectFirstRow("studentinfo_tb","ProgID,IF(RegNo='',JambNo,RegNo) as StudRegNo","id=".$StudID);
        if(!is_array($studdet))continue;
        $ProgID = (int)$studdet['ProgID'];
        $StudRegNo = $studdet['StudRegNo'];
        $queryarr[] = "UPDATE studentinfo_tb SET StudyID=$mpreloadstudy, ProgID=$mpreloadprog, StartSes=$mpreloadstartses, ClassID=$mpreloadclass, ModeOfEntry=$mpreloadmoe WHERE id=".$StudID;
        //check if student prog has changed
        if($ProgID > 0 && $mpreloadprog > 0 &&  $ProgID != $mpreloadprog){
            //make all payment and course reg inactive
            foreach(["coursereg_tb","result_tb"] as $tbg){
                // foreach(["coursereg_tb","order_tb","payhistory_tb","result_tb"] as $tbg){
                $queryarr[] = "UPDATE $tbg SET RegNo=CONCAT(RegNo,'_inactive') WHERE RegNo = '$StudRegNo'";
            }
        }
    }
    $query = implode(";",$queryarr).";";
    //exit(json_encode(["Success"=>FALSE,"Message"=>$query])); 
    if(trim($query) != ""){
        $dump = $dbo->Connection->multi_query($query);
         if(!$dump){
            exit(json_encode(["Success"=>FALSE,"Message"=>"#Server Error: ".$dbo->Connection->error]));
         }else{
                 do {
                         /* store first result set */
                                                         if ($result = $dbo->Connection->store_result()) {
                                                                 /*while ($row = $result->fetch_row()) {
                                                                         printf("%s\n", $row[0]);
                                                                 }*/
                                                                 $result->free();
                                                         }
                                                         /* print divider */
                                                         if ($dbo->Connection->more_results()) {
                                                                 //printf("-----------------\n");
                                                         }
                                                 } while ($dbo->Connection->next_result());
                                                 exit(json_encode(["Success"=>TRUE,"Message"=>"*Class List Migrated"]));
                                         }
        
    }else{
        exit(json_encode(["Success"=>FALSE,"Message"=>"#No Update Found"])); 
    }

}else{
    exit(json_encode(["Success"=>FALSE,"Message"=>"No Student Found"])); 
}
}

?>