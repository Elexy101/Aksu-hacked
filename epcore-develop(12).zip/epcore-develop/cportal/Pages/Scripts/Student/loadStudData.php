<?php
//sleep(3);
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");


$core = $_POST['Core'];
$subdir = $_POST['SubDir'];

$sch = GetSchool();
//global form group name
$currfrm = "BioDataelem";

//sleep(10);
$regno = $dbo->SqlSafe($_POST['regNo']);
//exit($regno);
$data = GetBasicInfo($regno,"studsch");
$loadlevel = $_POST['loadlevel'];
if(is_array($data)){
	$progID = $data["ProgID"];
	$fac = $data["FacID"];
	$dept = $data["DeptID"];
	$rtndata = [];
//	if($loadlevel == 0){//basic det
	  $gender = (substr(strtolower($data["Gender"]),0,1) != "m")?1:0;
	  $ms = (substr(strtolower($data["MaritalStatus"]),0,1) != "s")?1:0;
	 // echo $data["SurName"]."@#@!".$data["FirstName"]."@#@!".$data["OtherNames"]."@#@!".$data["DOB"]."@#@!".$gender."@#@!".$ms."@#@!".$data["Religion"];
   ob_start();
	 TextBoxGroup();
	    TextBox("title=Surname,style=width:250px;text-transform:uppercase,id=surnametxt,required=true,logo=users,text=".CleanText($data["SurName"]));
		TextBox("title=Firstname,style=width:250px;text-transform:uppercase,id=firstnametxt,required=true,logo=user,text=".CleanText($data["FirstName"]));
		TextBox("title=Othername,style=width:250px;text-transform:uppercase,id=othernametxt,logo=user-plus,text=".CleanText($data["OtherNames"]));
		TextBox("title=Date of Birth,type=calendar,style=width:250px;text-transform:uppercase,id=studDOB,logo=calendar,text=".MysqlDateDecode(CleanText($data["DOB"])));
		
		//DateBox("title=DATE OF BIRTH,id=studDOB,required=true,range=".((int)date("Y") - 10)."-".((int)date("Y") - 61));
		TextBox("title=Gender,style=width:250px;text-transform:uppercase,id=studgender,required=true,logo=female,selected=$gender",array("Male","Female"));
		TextBox("title=Marrital Status,style=width:250px;text-transform:uppercase,id=studstatus,required=true,logo=heart,selected=$ms",array("Single","Married"));
		TextBox("title=Religion,style=width:250px;text-transform:uppercase,id=studreligion,logo=street-view,selected=".CleanText($data["Religion"]),array("Christainity"=>"Christainity","Islamic"=>"Islamic","Others"=>"Others"));
		//echo 'aaa';
		_TextBoxGroup();
		$rtndata['bDatagrpDet'] = ob_get_contents();
		ob_end_clean();

	  //exit;
	//}
	//$rel = (substr(strtolower($data["Religion"]),0,1) != "c")?1:0;
	//if($loadlevel == 3){//contact det
ob_start();
	 $nat = (strtolower($data["Nationality"]) == "nigerian" || strtolower($data["Nationality"]) == "nigeria" )?0:1;
	 //echo $data["StateId"]."@#@!".$data["LGA"]."@#@!".$nat."@#@!".$data["Email"]."@#@!".$data["Phone"]."@#@!".$data["Addrs"];exit;
	 TextBoxGroup();
	 TextBox("title=State of Origin,style=width:250px;text-transform:uppercase,id=stateorig,required=true,logo=map,onchange=Student.BioData.LoadLGA,chain=stateorig:;lga:;,selected=".$data["StateId"],TextBoxSQL("select * from state_tb order by StateName"));
	 $lgas = (int)$data["StateId"] > 0?TextBoxSQL("select * from lga_tb where StateID={$data["StateId"]} order by LGAName"):array("");
 TextBox("title=Local Goverment Area,style=width:250px;text-transform:uppercase,id=lga,logo=map-marker,selected=".$data["LGA"],$lgas);
 TextBox("title=Nationality,style=width:250px;text-transform:uppercase,id=nat,logo=globe,selected=".$nat,array("NIGERIAN","OTHERS"));
 EmailBox("title=Email,style=width:250px;text-transform:uppercase,id=bdemail,logo=envelope,text=".CleanText($data["Email"]));
 PhoneBox("title=Phone Number,style=width:250px;text-transform:uppercase,id=studphone,required=true,logo=phone,text=".CleanText($data["Phone"]));
 TextBox("title=Address,type=multiline,style=width:100%;text-transform:uppercase,id=studaddr,logo=map-signs,text=".CleanText($data["Addrs"]));
 //TextPad("title=ADDRESS,style=width:250px; height:100px,id=studaddr,logo=map-signs");
 _TextBoxGroup();
 $rtndata['bDatagrpCont'] = ob_get_contents();
 ob_end_clean();
//exit;
	//}
	//if($loadlevel == 6){//reg
		$modee = GetMOEID($data["ModeOfEntry"]);
	$acdata = GetBasicInfo($regno,"ac");
	  $ac = "";
	  if(is_array($acdata)){
		  $ac = $acdata["AccessCode"];
		}
		ob_start();
	 //echo $data["RegLevel"]."@#@!".$data["RegDate"]."@#@!".$data["AdminDate"]."@#@!".$ac;
	 TextBoxGroup();
		TextBox("title=Registration Level,style=width:250px;text-transform:uppercase,id=studReglvl,logo=list,selected=".$data["RegLevel"],array("1"=>"Fresh","2"=>"Verfication","3"=>"Basic Details","4"=>"Contact","5"=>"Academic","6"=>"Complete"));
		TextBox("title=Registration Date,type=calendar,style=width:250px;text-transform:uppercase,id=regDate,logo=calendar,text=".MysqlDateDecode(CleanText($data["RegDate"])));
		_TextBoxGroup();
		Line();
		TextBoxGroup();
		TextBox("title=Admission Session,style=width:250px;text-transform:uppercase,id=admisionses,required=false,dropup=false,logo=calendar,selected={$data["AdmSes"]}",TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
		TextBox("title=Admission Date,type=calendar,style=width:250px;text-transform:uppercase,id=adDate,logo=calendar,text=".MysqlDateDecode(CleanText($data["AdminDate"])));
		TextBox("title=Mode of Entry,style=width:250px;text-transform:uppercase,id=modeentry,logo=sign-in,selected=".$modee,TextBoxSQL("select Level, Name from modeofentry_tb"));
		_TextBoxGroup();
		Line();
		TextBoxGroup();
	   //DateBox("title=REGISTRATION DATE,id=regDate,range=".date("Y")."-".((int)date("Y") - 90));
		//DateBox("title=ADMISSION DATE,id=adDate,logo=calender,range=".date("Y")."-".((int)date("Y") - 90));
		TextBox("title=Access Code,style=width:250px,id=studaccescode,required=true,logo=braille,text=".CleanText($ac));
		_TextBoxGroup();
		Line();
		TextBoxGroup("font-size:0.9em;width:95%;margin:auto");
 Switcher("id=studEnable,state={$data['Enable']},text=Active Account,style=width:100%;margin-top:10px,info=Activate/Deactivate Student Account,ontext=yes,offtext=no,align=right");
 _TextBoxGroup();
		$rtndata['bDatagrpReg'] = ob_get_contents();
		ob_end_clean();
	// exit;
	//}
	
	//if($loadlevel == 1){//school det
		$studlvl = StudLevelSes($regno);
		$yearofSt = StudYearOfStudy($regno,"");
		if(((int)$studlvl - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
			$LvlName = strtoupper($spilstr)." ".((int)$studlvl - $yearofSt);
		}else{
			$LvlName = LevelName($studlvl,$data['StudyID']);
		}
		$cursem = GetCurrentSem();
		
		
	//	$data["RegNo"] = (trim($data["RegNo"]) == "")?$data["JambNo"]:$data["RegNo"];
		
    ob_start();
		TextBoxGroup();
		 TextBox("title=Registration Number,style=width:250px;text-transform:uppercase,id=studregNo,logo=eye,required=false,text=".CleanText($data["RegNo"]));
		 
		  //if auto regno is set
		  if($sch['AutoRegNo'] == 'TRUE'){
			TextBoxGroupItem();
			$cleardisplay = "none";
			$generatedisplay = "none";
			$WorkRegNo = $data['RegNo'];
			if(trim($data['RegNo']) != ""){
				$cleardisplay = "inline-block";
			}
			LogoButton('style=margin-left:10px;color:red;display:'.$cleardisplay.',class=card-1,id=clearregno,onclick=Student.BioData.ClearRegNo(this);return false;,type=button,data-regno='.CleanText($WorkRegNo).',logo=edit,text=Clear');
			
			if(trim($data['RegNo']) == "" || $data['AutoGenReg'] == 'FALSE'){
				$generatedisplay = "inline-block";	
				$WorkRegNo = $data['JambNo'];
			}
			LogoButton('style=margin-left:10px;color:green;display:'.$generatedisplay.',class=card-1,id=generateregno,onclick=Student.BioData.GenerateRegNo(this);return false;,type=button,data-regno='.CleanText($WorkRegNo).',logo=sync,text=Generate');
			  _TextBoxGroupItem();
		  }

		 //echo $data["RegNo"]."@#@!".$data["JambNo"]."@#@!".$data["StudyID"]."@#@!".$data["FacID"]."@#@!".$data["DeptID"]."@#@!".$data["ProgID"]."@#@!".$studlvl."@#@!".$modee;
		 TextBox("title=Entrance Number,style=width:250px;text-transform:uppercase,id=jambNo,logo=graduation-cap,required=false,readonly=true,text=".CleanText($data["JambNo"]));
		 
		 _TextBoxGroup();
		 Line();
		 TextBoxGroup();
		 if(is_null($sch['SchStrucContr'])){ //no structure
			Note();
			echo "No Academic Structure Configured, Kindly contact the Admin";
			_Note();
		   }
		   $schStruc = json_decode($sch['SchStrucContr'],true);
		 $scharr = TextBoxSQL("select * from school_grp_tb");
          if(count($scharr) > 1){
						//get the student school
						$studschldet = $dbo->SelectFirstRow('study_tb',"StudySchID","ID = ".$data["StudyID"]);
						$SchID = 0;
						if(is_array($studschldet))$SchID = $studschldet['StudySchID'];
            TextBox("title={$schStruc['SchID']['Name']},style=width:250px;text-transform:uppercase,id=stud,required=true,logo=university,onchange=Utility.LoadStudy,selected=".$SchID,$scharr);
					}
					$otq = $SchID == 0?"(select SchGrpID from school_grp_tb limit 1)":$SchID;

          $studyarr = TextBoxSQL("select * from study_tb WHERE SchoolType = (select Type from school_tb limit 1) AND StudySchID = ".$otq);
		 TextBox("title={$schStruc['StudyID']['Name']},style=width:250px;text-transform:uppercase,id=studstudy,required=true,onchange=Student.GenLoader.LoadFac,logo=building-o,selected=".$data["StudyID"],$studyarr );

		 $facs = TextBoxSQL("select * from fac_tb where StudyID={$data["StudyID"]} order by FacName");
		 TextBox("title={$schStruc['FacID']['Name']},style=width:250px;text-transform:uppercase,id=studfac,onchange=Student.GenLoader.LoadDept,logo=server,silent={$schStruc['FacID']['SilentMode']},selected=".$data["FacID"],$facs);

		 $depts = TextBoxSQL("select * from dept_tb where FacID={$data["FacID"]} order by DeptName");
		 TextBox("title={$schStruc['DeptID']['Name']},style=width:250px;text-transform:uppercase,onchange=Student.GenLoader.LoadProg,id=studdept,logo=tasks,silent={$schStruc['DeptID']['SilentMode']},selected=".$data["DeptID"],$depts);
		 $progs = TextBoxSQL("select * from programme_tb where DeptID={$data["DeptID"]} order by ProgName");
			TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=studprog,required=true,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},selected=".$data["ProgID"],$progs);
			// TextBox("title={$schStruc['ProgID']['Name']},style=width:250px;text-transform:uppercase,id=studprog,required=true,onchange=Student.BioData.LoadLevel,logo=list-alt,silent={$schStruc['ProgID']['SilentMode']},selected=".$data["ProgID"],$progs);
			
			/* $lvls = TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1) and StudyID = ".$data["StudyID"]);
			$spillStr = ExtraLevelString();
//loop to add abretiary splill over of 5 extra
for($d=1;$d<=4;$d++){
				 
	$lvls[] = $spillStr." ".$d;
	
} */

TextBox("title=Start Session,style=width:250px;text-transform:uppercase,id=studstartses,required=true,dropup=true,onchange=Student.GetLevel,logo=calendar,selected=".$data["StartSes"],TextBoxSQL("select SesID, SesName from session_tb ORDER BY Current DESC, SesID DESC"));
//Get the student level
// $studlvlsem = GetStudLvlSemDetails($regno);
$studlvlsem = GetStudLvlSemDetails($regno);
$studlvlop = is_array($studlvlsem)?$studlvlsem['LevelName']:"--";
$studsemop = is_array($studlvlsem)?$studlvlsem['SemesterName']:"--";
//$studlvlop = $regno;
		  Note("style=font-size:10px");
			  echo 'Operational: <b style="font-weight:bold" id="oplvl">'.$studlvlop.' | '.$studsemop.'</b><br/>Calculated: <b style="font-weight:bold" id="exlvl">'.$LvlName.' | '.$cursem['Descr'].'</b>';
		_Note();
		$classes = TextBoxSQL("select * from studentclass_tb where ProgID={$data["ProgID"]} order by Name");
		TextBox("title={$schStruc['ClassID']['Name']},style=width:250px;text-transform:uppercase,id=studclass,required=false,dropup=true,logo=users,silent={$schStruc['ClassID']['SilentMode']},selected=".$data["ClassID"],$classes );
		  //TextBox("title=Level,style=width:250px;text-transform:uppercase,id=studlvl,required=true,logo=list-ol,selected=".$studlvl,$lvls);//TextBoxSQL("select level, Name from schoollevel_tb where SchoolTypeID = (select Type from school_tb limit 1)")
		 
			_TextBoxGroup();
			$rtndata['bDatagrpSch'] = ob_get_contents();
			ob_end_clean();
	//	exit;
	//}
	
	//if($loadlevel == 2){//passport
		ob_start();
		$passp = trim($data["Passport"]) != ""?ResolvePassport($data["Passport"]):"";
		/* if($passp != ""){ //check if exist
			$passp = file_exists("../../../".$passp)?$passp:"";
		} */
		//echo $passp;
		$_POST['CORE'] = $core; //will be use to set default image url
		ImagePad("id=studpassp,maxsize=300000,rel=../../../../../../$subdir,src=".ResolveFilePath($passp));
		//echo "../../../../../../$subdir".ResolveFilePath($passp);
		$rtndata['bDatagrpPassp'] = ob_get_contents();
		ob_end_clean(); 
		//exit;
	//}
	ob_start();
	//if($loadlevel == 4){ //NOK
		//echo $data["NName"]."@#@!".$data["Nphone"]."@#@!".$data["NAddrs"];
		TextBoxGroup();
	 TextBox("title=Name,style=width:250px;text-transform:uppercase,id=nkname,logo=connectdevelop,text=".CleanText($data["NName"]));
	 
		 PhoneBox("title=Phone Number,style=width:250px;text-transform:uppercase,id=nkphone,logo=phone,text=".CleanText($data["Nphone"]));
		 TextBox("title=Address,type=multiline,style=width:250px;text-transform:uppercase,id=nkaddr,logo=map-signs,text=".CleanText($data["NAddrs"]));
		 //TextPad("title=ADDRESS,style=width:250px; height:100px,id=nkaddr,logo=map-signs");
		/* Box("id=txtbxxx");
		
		 _Box();*/
		 _TextBoxGroup();
		 $rtndata['bDatagrpNOK'] = ob_get_contents();
		 ob_end_clean(); 
		 
		//exit;	
	//}
	
	//if($loadlevel == 5){ //rst
		//echo $data["JambAgg"]."@#@!".$data["OlevelRstDetails"]."@#@!".$data["OlevelRst"];
		ob_start();
		TextBoxGroup();
	     TextBox("title=Jamb Aggregate,style=width:250px;text-transform:uppercase,id=jambscor,logo=star-half-o,text=".CleanText($data["JambAgg"]));
		 _TextBoxGroup();

		 Line();
		 $passDataStr = "";
		 $passDataStrID = "";
		// Text("text=OLEVEL,style=display:block;font-weight:bold;color:#BBB;margin-top:10px;width:110px;margin-right:4px");
		//SubHeader("OLEVEL");
		 /*TextBox("title=Sitting,style=width:270px,id=olvrstSitting",array("1"=>"First","2"=>"Second"));*/
		 Box("id=gradebx,style=opacity:0;visibility:hidden;height:310px; margin-top:0px;width:280px;position:absolute;z-index:1;background-color:rgba(0\,0\,0\,.1);overflow:auto;display:flex");
		 Table("rowselect=false,style=width:100px;height:auto;margin-left:90px;align-self:center;text-align:center,id=gradetb,multiselect=false,onselect=Student.BioData.SetGrade,onunselect=Student.BioData.SetGrade");
		  THeader(array("Grade",_Icon('times','" onclick="Student.BioData.SetGrade(this)')),"cspan=d1:2");
		  $grds = $dbo->Select("olvlgrade_tb");
		  if(is_array($grds)){
			  if($grds[1] > 0){
				  $cnt = 0;
				  $tot = 0;
				  $grdarr = array();
				  while($grd = $grds[0]->fetch_array()){
                      $grdarr[] = $grd['Grade'];
					  $passDataStr .= $grd['Grade']."=".$grd['PASS']."&";
					  $passDataStrID .= $grd['ID']."=".$grd['PASS']."&";
					  $cnt++;
					  $tot++;
					  if($cnt == 3){
						  TRecord($grdarr);
						  $cnt = 0;
						  $grdarr = array();
					  }
					  if($tot == $grds[1]){ //if last
                         $rem = 3 - $cnt;
						 if($rem > 0){ //if vacant cell exist
                           TRecord($grdarr);
						 }
					  }
					
				  }
				  $passDataStr = rtrim($passDataStr,"&");
					$passDataStrID = rtrim($passDataStrID,"&");
					$passDataStrArr = ELemDataArray($passDataStr);
					$passDataStrIDArr = ELemDataArray($passDataStrID);
                  Hidden("PassDataStr",$passDataStr);
                  Hidden("PassDataStrID",$passDataStrID);
			  }
		  }
		   /*TRecord(array("A1","B2","B3"));
		   TRecord(array("C4","C5","C6"));
		   TRecord(array("D7","E8","F9"));
		   TRecord(array("NA"),"cspan=d1:3");*/
		 _Table(); 
		 
		 _Box();
/* border-top:1px #D5D5D5 solid;border-bottom:1px #D5D5D5 solid; */
		 Box("id=olvlrst,style=opacity:1;position:absolute;height:300px; padding-top:5px; width:277px;overflow:auto");
		 TextBoxGroup();
		   TextBoxGroupItem("type=head");
		 //Text("text=FIRST SITTING,style=text-align:center;width:100%;font-size:0.8em");
		 echo '<span style="font-size:0.8em">FIRST SITTING</span>';
		 TextBoxGroupItemMore();
		 //echo '</td><td>';
		 //Text("text=SECOND SITTING,style=text-align:center;width:100%;font-size:0.8em");
		 echo '<span style="font-size:0.8em">SECOND SITTING</span>';
		 //get the olvlresult details
		 $OlevelRstDetails = trim($data["OlevelRstDetails"]);
/* var schnme = rstdetarr[0];
								var exmyear = rstdetarr[1];
								var exmno = rstdetarr[2];
								var exmtp = rstdetarr[3].ToNumber();
								exmtp = exmtp == 0?1:exmtp;
								var exmbtch = typeof rstdetarr[4] == _UND?1:rstdetarr[4]; */
		 $OlevelRstDetailssit = [["",0,"",1,0],["",0,"",1,0]];
if($OlevelRstDetails != ""){
$sitall = explode("###",$OlevelRstDetails);
foreach($sitall as $k=>$sitrst){
	if(isset($sitall[$k]) && trim($sitall[$k]) != ""){
		$sit1 = explode("`~",$sitrst);
		$OlevelRstDetailssit[$k][0] = isset($sit1[0])?$sit1[0]:""; //school name 
		$OlevelRstDetailssit[$k][1] = isset($sit1[1])?$sit1[1]:0; //exam year
		$OlevelRstDetailssit[$k][2] = isset($sit1[2])?$sit1[2]:""; //exam num
		$OlevelRstDetailssit[$k][3] = isset($sit1[3])?$sit1[3]:1; //exam type
		$OlevelRstDetailssit[$k][4] = isset($sit1[4])?$sit1[4]:0; //exam batch
	}
}


}
		 
		 _TextBoxGroupItem();
		 $olvelexmtype = TextBoxSQL("select ID, Name from olevelexamtype_tb");
		 TextBoxGroupItem();
		 TextBox("title=Exam Type,style=width:110px;margin-right:4px;display:inline-block,id=olvrstxamtype1,logo=pencil-square-o,selected=".$OlevelRstDetailssit[0][3],$olvelexmtype);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Type,style=width:110px;margin-right:0px;display:inline-block,id=olvrstxamtype2,logo=pencil-square-o,required=false,selected=".$OlevelRstDetailssit[1][3],$olvelexmtype);
		 _TextBoxGroupItem();

		 $daysarry = array();
		for($a=(int)date("Y"); $a >= (int)date("Y") - 50; $a--){
		  $daysarry[$a] = $a;
		}
		TextBoxGroupItem();
		 TextBox("title=Exam Year,style=width:110px;margin-right:4px;display:inline-block,logo=calendar,id=olvrstxamyear1,selected=".$OlevelRstDetailssit[0][1],$daysarry);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Year,style=width:110px;margin-right:0px;display:inline-block,logo=calendar,id=olvrstxamyear2,selected=".$OlevelRstDetailssit[1][1],$daysarry);
		 _TextBoxGroupItem();
		 $batcharr = array(1=>"Internal",2=>"External");
		 TextBoxGroupItem();
		 TextBox("title=Exam Batch,style=width:110px;margin-right:4px;display:inline-block,logo=users,id=olvexmbatch1,selected=".$OlevelRstDetailssit[0][4],$batcharr);
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Batch,style=width:110px;margin-right:0px;display:inline-block,logo=users,id=olvexmbatch2,selected=".$OlevelRstDetailssit[1][4],$batcharr);
		 _TextBoxGroupItem();

		 TextBoxGroupItem();
		 TextBox("title=Exam Number,style=width:110px;margin-right:4px;display:inline-block,id=olvexamno1,logo=user,text=".CleanText($OlevelRstDetailssit[0][2]));
		 TextBoxGroupItemMore();
		 TextBox("title=Exam Number,style=width:110px;margin-right:0px;display:inline-block,id=olvexamno2,logo=user,text=".CleanText($OlevelRstDetailssit[1][2]));
		 _TextBoxGroupItem();

		 TextBoxGroupItem();
		 TextBox("title=School Name,style=width:110px;margin-right:4px;display:inline-block,id=olvrstschn1,logo=university,text=".CleanText($OlevelRstDetailssit[0][0]));
		 TextBoxGroupItemMore();
		 TextBox("title=School Name,style=width:110px;margin-right:0px;display:inline-block,id=olvrstschn2,logo=university,text=".CleanText($OlevelRstDetailssit[1][0]));
		 _TextBoxGroupItem();
		 _TextBoxGroup();
echo '<div style="margin-top:10px"></div>';
//echo $data["OlevelRst"];
$studrst = [];
$rstsit = explode("###",$data["OlevelRst"]);
if(count($rstsit) > 0){
foreach($rstsit as $sit=>$rst){
	$indrst = explode(";",$rst);
	
	if(count($indrst) > 0){
	foreach($indrst as $subrst){
		 $indsubjrst = explode("=",$subrst);
		 if(count($indsubjrst) == 2){
			$studrst[$sit][trim(strtolower($indsubjrst[0]))] = $indsubjrst[1];
		 }
	}
	}
}
}


		   Table("rowselect=false,style=width:95%;font-size:0.7em;margin-top:10px;margin:auto;border-top-color:transparent,id=olevelrst,onselect=Student.BioData.ShowGrade,onunselect=Student.BioData.ClearGrade,multiselect=false,rowfilter=true,filtertitle=Filter Subject,filterstyle=width:95%;margin:auto");
						THeader(array("FIRST SITTING","SUBJECT","SECOND SETTING"));
						
					 $olvelrsts = $dbo->Select4rmdbtb("olvlsubj_tb");
					 $strstylearr = ["color:#FF6835;font-weight:bold", "color:rgba(86,176,55,1);font-weight:bold"];
			  // $grades = array(array("A1"=>"A1","B2"=>"B2","B3"=>"B3","C4"=>"C4","C5"=>"C5","C6"=>"C6","D7"=>"D7","E8"=>"E8","F9"=>"F9"));
			   if(is_array($olvelrsts)){
				   if($olvelrsts[1] > 0){
					   while($olvlrst = $olvelrsts[0]->fetch_array()){
							 $indsubj = trim(strtolower($olvlrst[1]));
							 $rstgrdcolor = ["black;font-weight:lighter","black;font-weight:lighter"];
							 $rstgrd = [["","black;font-weight:lighter"],["","black;font-weight:lighter"]];
							 
                for($rd=0;$rd<2;$rd++){
									$rstgrd[$rd][0] = isset($studrst[$rd][$indsubj])?$studrst[$rd][$indsubj]:"";
									
									 if($rstgrd[$rd][0] != ""){ //if grade set
										 //check if id type
										 $rstgrdid = (int)$rstgrd[$rd][0];
										
										 if($rstgrdid < 1){ //if string grade type
											
											$passdet = $passDataStrArr;
										 }else{
											$passdet = $passDataStrIDArr;
										 }
										 //print_r($passdet);
										 $passdata[$rd] = $passdet[$rstgrd[$rd][0]];
										 //echo $passdata[$rd]." ";
										 //echo $strstylearr[1]." ";
										 if(isset($strstylearr[$passdata[$rd]]))$rstgrd[$rd][1] = $strstylearr[$passdata[$rd]];
									} 
								}
							 
							 
							 /* $passDataStrArr = ELemDataArray($passDataStr);
							 $passDataStrIDArr = ELemDataArray($passDataStrID); */
               
							 
							 
						    TRecord(array($rstgrd[0],'<div style="text-align:center">'.$olvlrst[1].'</div>',$rstgrd[1]),"style=text-align:center,id=".trim(strtolower(str_replace(array(" ",",","="),array(".","\,","\="),$olvlrst[1]))));
					   }
					  // THeader(array("TOTAL","P0|F0|T0","P0|F0|T0"),"style=text-align:center;font-weight:bolder,id=totalrst");
				   }
			   }
			 _Table();
			 //print_r($passDataStrArr);
			_Box();
			$rtndata['bDatagrpRstDet'] = ob_get_contents();
			ob_end_clean();
		//exit;	
//	}

	//if($loadlevel == 7){ //pay records
		//get student payment records
		ob_start();
		$paydet = $dbo->Select("item_tb i, schoollevel_tb l, session_tb s, payhistory_tb p LEFT JOIN programme_tb pr ON p.ProgID = pr.ProgID","p.*, i.ItemName, l.Name as LevelName, s.SesName,FORMAT(p.Amt,2) as PayAmt,DATE_FORMAT(p.PayDate, '%M %d %Y') as PayDate,IF(LCASE(p.Bank) = 'manual pay','OFFLINE','ONLINE') as Channel, COALESCE(pr.ProgName,'UNKNOWN') as ProgName","p.RegNo='$regno' AND p.PayID=i.ID AND p.Lvl = l.Level AND l.SchoolTypeID=(Select Type FROM school_tb LIMIT 1) AND l.StudyID=".$data["StudyID"]." AND p.Ses = s.SesID ORDER BY Lvl, Sem, SemPart");
		if(is_array($paydet)){
			if($paydet[1]>0){
				$header=array(
					"*StudPaySes"=>"SESSION",
					"*StudPayItemName"=>"PAYMENT",
					"*StudPayLvl"=>"LEVEL",
					"*StudPayPol"=>"POLICY",
					"*StudPayAmt"=>"AMOUNT",
					"*StudPayDate"=>"DATE",
					"*StudPayChannel"=>"CHANNEL",
					"*StudPayProg"=>"FOR"
				);
				$partPayShare = "HALF";
				$schpay = SchoolPayDet();
				if(is_array($schpay)){
					$partPayShare = $schpay['PartPayShare'];
				}
				$dump = [];
				while($indpaydet = $paydet[0]->fetch_assoc()){
					$paypol = FormPayPolicy($indpaydet['Sem'], $indpaydet['SemPart'],$partPayShare);
					/* $recarr["info"] =  "Print";
				$recarr["Action"] =  "Payment.PaymentReport.PrintRc('{$rec['itemNum']}')"; */
					$dump[] = [$indpaydet['SesName'],$indpaydet['ItemName'],$indpaydet['LevelName'],$paypol,$indpaydet['PayAmt'],$indpaydet['PayDate'],$indpaydet['Channel'],$indpaydet['ProgName'],"logo"=>"*print","info"=>"Print","Action"=>"Payment.PaymentReport.PrintRc('{$indpaydet['itemNum']}')"];
				}
/* 
				$Readonly = "";
       foreach($header as $k=>$v){
        $Readonly .= ltrim($k,"*").";";
       }
       //echo $Readonly;
       $Readonly = rtrim($Readonly,";"); */
           SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:0px;margin-bottom:6px,id=studpayrec,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=all,trimtext=<strong class=\"altColor\">;</strong>;<strong class=\"altcolor\">,rowfilter=true,filtertitle=FILTER PAYMENTS,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:10px;",$header,$dump);
				
			}else{
				DefaultBox("logo=trash,text=No Payment Record Found,logoclass=altColor");
				//echo "No Payment Record Found";
			}
		}else{
			DefaultBox("logo=exclamation-triangle,text=Error Loading Payment Records,logoclass=altColor");
			//echo "Error Loading Payment Records - ".$paydet;
		}
		$rtndata['bDatagrppayrec'] = ob_get_contents();
		ob_end_clean();
		ob_start();
	//}

	//if($loadlevel == 8){ //course reg details
		//get student payment records
		$courserec = $dbo->Select("coursereg_tb c, schoollevel_tb l, session_tb s, semester_tb se","c.*, DATE_FORMAT(c.RegDate, '%M %d %Y') as RegDate,l.Name as LevelName, s.SesName, se.Sem as SemName","RegNo='$regno' AND c.Lvl = l.Level AND l.SchoolTypeID=(Select Type FROM school_tb LIMIT 1) AND l.StudyID=".$data["StudyID"]." AND c.SesID = s.SesID AND ((se.Num > 0 && se.Num=c.Sem) || c.Sem=se.ID) ORDER BY c.SesID, c.Lvl, c.Sem");
		if(is_array($courserec)){
			if($courserec[1]>0){
				$headerc=array(
					"*StudCRegSes"=>"SESSION",
					"*StudCRegLvl"=>"LEVEL",
					"*StudCRegSem"=>strtoupper($sch['SemLabel']),
					"*StudCRegCourse"=>"COURSES",
					"*StudCRegDate"=>"DATE",
					"*StudCRegTch"=>"TCH"
				);
				$dumpc = [];
				//get all courses
				$allc = GetCourses($data["ProgID"]);
				while($indpaydet = $courserec[0]->fetch_assoc()){
				//	$paypol = FormPayPolicy($indpaydet['Sem'], $indpaydet['SemPart'],$partPayShare);
					/* $recarr["info"] =  "Print";
				$recarr["Action"] =  "Payment.PaymentReport.PrintRc('{$rec['itemNum']}')"; */
				//proccess all courses
$pallcs = explode("~",$indpaydet['CoursesID']);
$coursesreg = [];
if(count($pallcs) > 0){
	$TCH = 0;
  foreach($pallcs as $cid){
		$cdet = isset($allc[$cid])?$allc[$cid]:CourseDetails($cid);
		$succ = (int)$cdet['Lvl'] < (int)$indpaydet['Lvl']?"dangerre":"successse";
		$TCH += (int)$cdet['CH'];
    //$RstHtml .= '<strong class="Labels '.$succ.'">'.$cdet['CourseCode']." (".$cdet['CH'].")  </strong>";
		$coursesreg[] = '<strong class="Labels '.$succ.'">'.$cdet['CourseCode']." (".$cdet['CH'].")  </strong>";
	}
}
$regc = count($coursesreg) > 0?implode("",$coursesreg):"NO COURSE REGISTERED";

					/* $dumpc[] = [$indpaydet['SesName'],$indpaydet['LevelName'],$indpaydet['SemName'],$regc,$indpaydet['RegDate'],$TCH,"logo"=>"*print","info"=>"Print","Action"=>"Course.Register.PrintSlip('{$indpaydet['RegNo']}',{$indpaydet['Lvl']},{$indpaydet['Sem']})"]; */

					$dumpc[] = [$indpaydet['SesName'],$indpaydet['LevelName'],$indpaydet['SemName'],$regc,$indpaydet['RegDate'],$TCH,"logo"=>"*print","info"=>"Print","Action"=>"Course.Register.PrintSlipi({$indpaydet['ID']})"];
					//PrintSlip:function(RegNo,Lvl,Sem)
				}
/* 
				$Readonly = "";
       foreach($header as $k=>$v){
        $Readonly .= ltrim($k,"*").";";
       }
       //echo $Readonly;
       $Readonly = rtrim($Readonly,";"); */
           SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:0px;margin-bottom:6px,id=studcoursereg,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=all,trimtext=<strong class\=\"Labels successse\">;<strong class\=\"Labels dangerre\">;</strong>,rowfilter=true,filtertitle=FILTER REGISTRATION,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:10px;",$headerc,$dumpc);
				
			}else{
				DefaultBox("logo=trash,text=No Course Registration Found,logoclass=altColor");
				//echo "No Payment Record Found";
			}
		}else{
			DefaultBox("logo=exclamation-triangle,text=Error Loading Course Registration,logoclass=altColor");
			//echo "Error Loading Payment Records - ".$paydet;
		}
		$rtndata['bDatagrpcreg'] = ob_get_contents(); 
		ob_end_clean();

	
	//}
	  echo json_encode($rtndata);
}else{
	echo '{"Error":"No Record Found"}';
}

?>