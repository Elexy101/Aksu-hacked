<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//AllowUser("Bdata");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
//sleep(10);
if(isset($_POST['RegNo'])){
    $RegNo = $_POST['RegNo'];
    //update student regno
    $cleardregno = AutoGenRegNo($RegNo,1,"");
    if(!is_array($cleardregno)){
        switch ($cleardregno) {
            case '#':
                exit(json_encode(["Success"=>false,"Message"=>"#Reading School Details Failed"]));
                break;
            case '###':
                exit(json_encode(["Success"=>false,"Message"=>"#Student not Found"]));
                break;
            case '#####':
                exit(json_encode(["Success"=>false,"Message"=>"#Updating Student record globally failed"]));
                break;
            default:
            exit(json_encode(["Success"=>false,"Message"=>"#".$cleardregno]));
                break;
        }
    }else{
      exit(json_encode(["Success"=>true,"Message"=>"#Registration Number Cleared","RegNo"=>$cleardregno[0]])); 
    }

}
echo "#INVALID STUDENT SELECTED";


?>