<?php
 require_once("../../../../general/TaquaLB/Elements/Elements.php");
 $configdir = "../../../../../../".$_POST['SubDir'];
 require_once("../../../../general/config.php");
 require("../../../../general/getinfo.php");
//$mysqli = new mysqli()
function MessageBack($str,$exitt = true){
    $str = EscapeString($str);
Box("style=color:red;width:100%;text-align:center; margin-top:20px;");
    Box("style=font-size:2em");Icon("exclamation-triangle");_Box();
    Text("text=$str,style=color:inherit;text-transform:uppercase;font-size:1.0em");
_Box();
if($exitt){  
    exit();
}
}

AllowUser("StudReg");
 
/* function ToMySQLDate($date){
    $montharr = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    $dtarr = explode("-",$date);
    if(count($dtarr) == 3){ //if valid
      $dtarr[1] = (int)array_search(strtolower($dtarr[1]),$montharr)+1;
      return $dtarr[2]."-".$dtarr[1]."-".$dtarr[0];
    }
    return "";
} */

function ToMySQLDate($date){
    //$montharr = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    $dtarr = explode("/",$date);
    if(count($dtarr) == 3){ //if valid
      //$dtarr[1] = (int)array_search(strtolower($dtarr[1]),$montharr)+1;
      return $dtarr[2]."-".$dtarr[1]."-".$dtarr[0];
    }
    return "";
}

extract($_POST);
//pagenation
//Set data for print operation
Box("id=regrptprintdata,style=display:none;visibility:hidden");
  echo json_encode($_POST);
_Box();
if(isset($reportType)){

    $searchstr = isset($str)?$str:"";
    //remove serach string from post
    //unset($_POST['str']);
    $DPOST = $_POST;
    /*if(!isset($pg)){
    $LastDis = $_POST['LastDis'];
    unset($_POST['LastDis']);
    $BackPOST = $_POST;
    $BackPOST['displaytext'] = $LastDis;
    }*/
  // print_r($_POST);
    //pagenation
    $lastpgindex = 0;
  $recpg = 50;
   //set limit
   if(isset($pg)){
      $pg = (int)$pg;
      if($pg < 2){
        $lmt = $recpg;
      }else{
          $lastpgindex = (($pg - 1) * $recpg);
        $lmt = $lastpgindex.",$recpg";
      }
   }else{
     $pg = 1;
     $lmt = $recpg;
   }
    //$datefilter = ($from != "" && $to != "")?"AND (p.PayDate >= '$from' AND p.PayDate <= '$to')":"";
    
    
    $setfilter = ((int)$set > 0)?"AND s.StartSes = $set":"";
    $entrfilter = ((int)$entr > 0)?"AND s.ModeOfEntry = $entr":"";
    $genderarr = array("","AND s.Gender = 'M'","AND s.Gender = 'F'");
    $genderfilter = $genderarr[$gender];
    $mstatusarr = array("","AND s.MaritalStatus = 'S'","AND s.MaritalStatus = 'M'");
    $mstatusfilter = $mstatusarr[$mstatus];
    $query = "";
    $dump = array();
    $rset = $set;
    //form query based on the report type
    if($reportType == "rpttypefac"){ //Registered student report by fac
    
      $searchcond = ($searchstr != "")?" AND (f.FacName LIKE '%$searchstr%' OR st.Name LIKE '%$searchstr%')":"";
      $query = "SELECT COUNT(s.SurName) as Students FROM studentinfo_tb s,dept_tb d,programme_tb p,fac_tb f,study_tb st WHERE p.DeptID=d.DeptID AND d.FacID = f.FacID AND st.ID = s.StudyID AND s.ProgID = p.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter $searchcond AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo";
      //echo $query;
      $querylim = "SELECT SQL_CALC_FOUND_ROWS f.FacName, COUNT(s.SurName) as Students, f.FacID,st.Name FROM fac_tb f  LEFT JOIN study_tb st ON st.ID = f.StudyID LEFT JOIN dept_tb d ON f.FacID = d.FacID LEFT JOIN programme_tb p ON d.DeptID = p.DeptID LEFT JOIN studentinfo_tb s ON p.ProgID = s.ProgID  $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo"." WHERE 1=1 $searchcond GROUP BY f.FacID"." LIMIT ".$lmt;
      //echo $querylim;
      //$querylim = $query." LIMIT ".$lmt;
    
    }else if($reportType == "rpttypestate"){ //by state
      
        $searchcond = ($searchstr != "")?" AND st.StateName LIKE '%".$searchstr."%'":"";
        //$itemID = 2;
        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, state_tb st WHERE 1=1 $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond AND st.StateID = s.StateId";
      $querylim = "SELECT SQL_CALC_FOUND_ROWS st.StateName, COUNT(s.SurName) as Students, st.StateID FROM state_tb st LEFT JOIN studentinfo_tb s ON st.StateID = s.StateId $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo"." WHERE 1=1 $searchcond GROUP BY st.StateID ORDER BY st.StateName"." LIMIT ".$lmt;
      //$querylim = str_replace(", COUNT(p.PayID) as Payments, SUM(p.Amt) as Sums","",$query);
      //$query = str_replace($searchcond,"",$query);
      //$querylim = $querylim." LIMIT ".$lmt;
     // echo $querylim;
    }else if($reportType == "studrptprog"){
        $searchcond = ($searchstr != "")?" AND p.ProgName LIKE '%$searchstr%'":"";
      $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, dept_tb d, programme_tb p WHERE s.ProgID=p.ProgID AND p.DeptID = d.DeptID AND d.FacID = $FacID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond";
     //echo $query;
      $querylim = "SELECT SQL_CALC_FOUND_ROWS p.ProgName, COUNT(s.SurName) as Students, s.ProgID FROM programme_tb p LEFT JOIN  dept_tb d ON p.DeptID = d.DeptID LEFT JOIN studentinfo_tb s ON s.ProgID = p.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6  AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo WHERE d.FacID = $FacID $searchcond GROUP BY p.ProgID LIMIT ".$lmt;

    }else if($reportType == "studrptlga"){
        //$itemID = 2;$progID
        $searchcond = ($searchstr != "")?" AND l.LGAName LIKE '%$searchstr%'":"";
        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, lga_tb l WHERE s.StateID=$StateID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo AND s.LGA = l.LGAID $searchcond";
        
      $querylim = "SELECT SQL_CALC_FOUND_ROWS l.LGAName, COUNT(s.SurName) as Students, l.LGAID FROM lga_tb l LEFT JOIN studentinfo_tb s ON l.LGAID = s.LGA $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6  AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo WHERE l.StateID = $StateID $searchcond  GROUP BY l.LGAID ORDER BY l.LGAName ASC"." LIMIT ".$lmt;
      
      //print_r($_POST);
    }else if($reportType == "studregtypestud"){
        $searchcond = ($searchstr != "")?" AND (s.RegNo LIKE '%".$searchstr."%' OR s.JambNo LIKE '%$searchstr%' OR s.SurName LIKE '%$searchstr%' OR s.FirstName LIKE '%$searchstr%' OR s.OtherNames LIKE '%$searchstr%' OR s.Phone LIKE '%$searchstr%' OR s.Email LIKE '%$searchstr%' OR p.ProgName LIKE '%$searchstr%')":"";

        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, programme_tb p WHERE p.ProgID = s.ProgID AND s.ProgID=$ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond";
        $querylim = "SELECT SQL_CALC_FOUND_ROWS s.RegNo, s.JambNo, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name, s.Phone, s.Email,p.ProgName FROM studentinfo_tb s, programme_tb p WHERE s.ProgID = p.ProgID AND s.ProgID = $ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond ORDER BY RegNo ASC,JambNo ASC"." LIMIT ".$lmt;

    }else if($reportType == "studregtypelga"){
        $searchcond = ($searchstr != "")?" AND (s.RegNo LIKE '%".$searchstr."%' OR s.JambNo LIKE '%$searchstr%' OR s.SurName LIKE '%$searchstr%' OR s.FirstName LIKE '%$searchstr%' OR s.OtherNames LIKE '%$searchstr%' OR s.Phone LIKE '%$searchstr%' OR s.Email LIKE '%$searchstr%' OR p.ProgName LIKE '%$searchstr%')":"";
        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, programme_tb p WHERE p.ProgID = s.ProgID AND  s.LGA=$LGAID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond";
        $querylim = "SELECT SQL_CALC_FOUND_ROWS s.RegNo, s.JambNo, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name, s.Phone, s.Email,p.ProgName FROM studentinfo_tb s, programme_tb p WHERE s.ProgID = p.ProgID AND s.LGA = $LGAID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond ORDER BY RegNo ASC,JambNo ASC"." LIMIT ".$lmt;
        //echo $querylim;
    }else if($reportType == "studregall"){
        $searchcond = ($searchstr != "")?" AND (s.RegNo LIKE '%".$searchstr."%' OR s.JambNo LIKE '%$searchstr%' OR s.SurName LIKE '%$searchstr%' OR s.FirstName LIKE '%$searchstr%' OR s.OtherNames LIKE '%$searchstr%' OR s.Phone LIKE '%$searchstr%' OR s.Email LIKE '%$searchstr%' OR p.ProgName LIKE '%$searchstr%')":"";

        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, programme_tb p WHERE p.ProgID = s.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 $searchcond";
        $querylim = "SELECT SQL_CALC_FOUND_ROWS s.RegNo, s.JambNo, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name, s.Phone, s.Email,p.ProgName, IF(TRIM(s.RegNo)!='',IF(s.RegNo != s.JambNo,'Registered','Unregistered'),'Unregistered') as Status FROM studentinfo_tb s, programme_tb p WHERE s.ProgID = p.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 $searchcond ORDER BY Status DESC, s.RegNo ASC,s.JambNo ASC"." LIMIT ".$lmt;
        //cho $querylim;
    }else if($reportType == "studregreg"){
        $searchcond = ($searchstr != "")?" AND (s.RegNo LIKE '%".$searchstr."%' OR s.JambNo LIKE '%$searchstr%' OR s.SurName LIKE '%$searchstr%' OR s.FirstName LIKE '%$searchstr%' OR s.OtherNames LIKE '%$searchstr%' OR s.Phone LIKE '%$searchstr%' OR s.Email LIKE '%$searchstr%' OR p.ProgName LIKE '%$searchstr%')":"";

        $query = "SELECT COUNT(s.SurName) as Students FROM  studentinfo_tb s, programme_tb p WHERE p.ProgID = s.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond";
        $querylim = "SELECT SQL_CALC_FOUND_ROWS s.RegNo, s.JambNo, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as Name, s.Phone, s.Email,p.ProgName FROM studentinfo_tb s, programme_tb p WHERE s.ProgID = p.ProgID $setfilter $entrfilter $genderfilter $mstatusfilter AND s.RegLevel = 6 AND TRIM(s.RegNo) != '' AND s.RegNo != s.JambNo $searchcond ORDER BY RegNo ASC,JambNo ASC"." LIMIT ".$lmt;
    }
    $CurPost = $_POST;
    unset($_POST['str']);
    $curdatastr = $dbo->DataString($CurPost);
    $totstat = 0;$totamt=0;$totpays=0;$totAmts=0;$totstud=0;
    if($querylim != ""){
       
       
        $rst = $dbo->RunQuery($query);
        
         $rpt = $dbo->RunQuery($querylim);
        //get the overall number of record and total expected page
        $rsttot = $dbo->RunQuery("SELECT FOUND_ROWS()");
        $rtot = $rsttot[0]->fetch_array();
        $alltot = (int)$rtot[0];
        $totpg = $alltot / $recpg; //get the total expexted page
        $totpg = $totpg < 1?1:ceil($totpg);
        
       // $BackPOST['displaytext'] = $_POST['displaytext'];
        if(is_array($rpt)){
            
            if($rpt[1] > 0){
               // MessageBack($rst);
               //echo $rst;
                $rstrec = $rst[0]->fetch_array();
                $totstud = $rstrec['Students'];
                //$totAmts = $rstrec['Sums'];
                
                while($rec = $rpt[0]->fetch_array()){
                    if($reportType == "rpttypefac"){ //by fc
                    $facName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
                    $studyName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[3]));
                    $totstat += (int)$rec[1];
                  $recarr = array($studyName,$facName,$rec[1]);
                  $_POST['FacID'] = $rec[2];
                  $_POST['reportType'] = "studrptprog";
                  $_POST['pg'] = 1;
                  //$BackPOST['displaytext'] = $_POST['displaytext'];
                  $_POST['displaytext'] = "SCHOOL/FCULTY OF ".strtoupper($rec[0])." REGISTERED STUDENT REPORT";
                  $datastr = $dbo->DataString($_POST);

                  $recarr["logo"] =  "*chevron-right";
				$recarr["info"] =  $_POST['displaytext'];
				$recarr["Action"] =  "Student.RegReport.PerformLoad('$datastr')";
                $dump[] = $recarr;
                if(isset($BackPOST['back'])){unset($BackPOST['back']);}

                    }else if($reportType == "rpttypestate"){ //state
                        $stateName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
                    $totstat += (int)$rec[1];
                  $recarr = array($stateName,$rec[1]);
                  $_POST['StateID'] = $rec[2];
                  $_POST['reportType'] = "studrptlga";
                  $_POST['pg'] = 1;
                  //$BackPOST['displaytext'] = $_POST['displaytext'];
                  $_POST['displaytext'] = strtoupper($rec[0])." STATE REGISTERED STUDENT REPORT";
                  $datastr = $dbo->DataString($_POST);

                  $recarr["logo"] =  "*chevron-right";
				$recarr["info"] =  $_POST['displaytext'];
				$recarr["Action"] =  "Student.RegReport.PerformLoad('$datastr')";
                $dump[] = $recarr;
                if(isset($BackPOST['back'])){unset($BackPOST['back']);}

                    }else if($reportType == "studrptprog"){ //load by programmes
                    $totstat += (int)$rec[1];
                   // $totamt += (float)$rec[2];
                     $progName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
                 $recarr = array($progName,$rec[1]);
                  $_POST['ProgID'] = $rec['ProgID'];
                  $_POST['reportType'] = "studregtypestud";
                  $_POST['pg'] = 1;
                   //$BackPOST['displaytext'] = $_POST['displaytext'];
                  $_POST['displaytext'] = strtoupper($rec[0])." PROGRAMME REGISTERED STUDENT REPORT";
                  $datastr = $dbo->DataString($_POST);
                 $BackPOST['reportType'] = 'rpttypefac';
                     $BackPOST['back'] = true;
                  $recarr["logo"] =  "*chevron-right";
				$recarr["info"] =  $_POST['displaytext'];
				$recarr["Action"] =  "Student.RegReport.PerformLoad('$datastr')";
                $dump[] = $recarr;
            }else if($reportType == "studrptlga"){ //load by lga
                $totstat += (int)$rec[1];
               // $totamt += (float)$rec[2];
                 $lgaName = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($rec[0]));
             $recarr = array($lgaName,$rec[1]);
              $_POST['LGAID'] = $rec['LGAID'];
              $_POST['reportType'] = "studregtypelga";
              $_POST['pg'] = 1;
               //$BackPOST['displaytext'] = $_POST['displaytext'];
              $_POST['displaytext'] = "REGISTERED STUDENT FROM ".strtoupper($rec[0]);
              $datastr = $dbo->DataString($_POST);
             $BackPOST['reportType'] = 'rpttypestate';
                 $BackPOST['back'] = true;
              $recarr["logo"] =  "*chevron-right";
            $recarr["info"] =  $_POST['displaytext'];
            $recarr["Action"] =  "Student.RegReport.PerformLoad('$datastr')";
            $dump[] = $recarr;
            
                    }else if($reportType == "studregtypestud" || $reportType == "studregtypelga" || $reportType == "studregall" || $reportType == "studregreg"){//individual payment for fac-prog report
                        //$rinfo = json_decode($rec['Info']);
                     $totstat += 1;
                     //$totamt += (float)$rec[3];
                        //$amtstr = $rec[3]."";
                     //$rec[3] = number_format($rec[3], 2, '.', ',');
                     /*if($searchstr == $amtstr){
                       $searchstr = $rec[3];
                     }*/

                     if(trim($rec['RegNo'])=="")$rec['RegNo']=$rec['JambNo'];
                     $regno = $rec['RegNo'];
                     foreach($rec as &$erec){
                         $erec = str_replace(strtolower($searchstr),"<strong class=\"altColor\">$searchstr</strong>",strtolower($erec));
                     }
                     //$dt = new DateTime($rec[4]);
                     if($reportType == "studregall"){
                        $recarr = array($rec['RegNo'],$rec['Name'],$rec['Phone'],$rec['Email'],$rec['ProgName'],$rec['Status']);
                     }else{
                        $recarr = array($rec['RegNo'],$rec['Name'],$rec['Phone'],$rec['Email'],$rec['ProgName']);
                     }
                     
                      // $BackPOST['displaytext'] = $_POST['displaytext'];
                      //$BackPOST['reportType'] = 'studrptprog';
                     //$BackPOST['back'] = true;
                     $recarr["logo"] =  "*print";
				$recarr["info"] =  "Print";
				$recarr["Action"] =  "Student.RegReport.PrintRc('{$regno}')";
                $dump[] = $recarr;
                    }
                }
            }
        }
    }
    //$totamt = number_format($totamt, 2, '.', ',');
    //$totAmts = number_format($totAmts, 2, '.', ',');
    

    $dif = 80;
    echo '<div class="fadein">';     
    Box("style=width:100%;display:inline-block;vertical-align:top;margin-bottom:5px"); 
    TextBoxGroup("width:calc(100% - 12px);font-size:0.8em;margin:auto");
$bkstyle = $hist > 0?"style=width:50px":"";
    TextBoxGroupItem($bkstyle);
    if($hist > 0){
    Box("style=width:50px;display:inline-block;margin:0px 10px;vertical-align:top");
    //$refreshpostdatastr = str_replace("=","\=",$curdatastr);
    SmallButton("id=studrptbackbtn,logo=chevron-left,style=margin:0px,title=Back,onclick=Student.RegReport.Back()"); _Box();
    TextBoxGroupItemMore("style=width:calc(100% - 50px)");
    }
    
    TextBox("title=Search Report,style=width:100%,onchange=,id=studregrptsearch,logo=search,info=Inteligent Search: Search by any information you have on the Report,textchange=Student.RegReport.SearchPress(event),text=".str_replace(array("=",","),array("\=","\,"),$searchstr));
    _TextBoxGroupItem();
    _TextBoxGroup();
    _Box();
    Box('id=studrpt_curdatastr,style=display:none');
echo $curdatastr;
_Box();
    /* Box("style=width:50px;display:inline-block;margin:0px 10px;vertical-align:top");
    $refreshpostdatastr = str_replace("=","\=",$curdatastr);
    SmallButton("id=studrptsearchbtn,logo=search,style=margin:0px,title=Search,onclick=Student.RegReport.Search('$refreshpostdatastr')"); _Box(); */
    
    Line(0);

     Table("style=width:calc(100% - 12px);font-size:0.8em;margin:auto;margin-top:10px;text-align:left,id=totalrpt,multiselect=false,data-type=table");
     if(trim($searchstr) == ""){
         $arrhed = array("SUMMARY:","SET","GENDER","MARITAL STATUS","MODE OF ENTRY","OVERALL");
     }else{
        $arrhed = array("SUMMARY:","SET","GENDER","MARITAL STATUS","MODE OF ENTRY","SEARCH","OVERALL");
     }
     
     
     $sesName = (int)$rset == 0?"ALL SET":SessionName($rset);
     $Genderarr = ["MALE & FEMALE","MALE","FEMALE"];
     $Gender = $Genderarr[$gender];
     $MOE = (int)$entr == 0?"ALL ENTRY":GetMOEName(GetMOEID($entr));
     $mastatusarr = ["SINGLE & MARRIED","SINGLE","MARRIED"];
     $maStatus = $mastatusarr[$mstatus];
        THeader($arrhed,"style=text-align:center,rspan=d1:2");
        if(trim($searchstr) == ""){
        $arrRec = array($sesName,$Gender,$maStatus,$MOE,"<strong>".$totstud."</strong>");
        }else{
            $arrRec = array($sesName,$Gender,$maStatus,$MOE,"<i><strong>".$searchstr."</strong></i>","<strong>".$totstud."</strong>");  
        }
        TRecord($arrRec,"data-id=studtypesum,style=font-weight:bolder");

       _Table();
      Line();
       
       
       /*if(isset($BackPOST['back'])){
           
           $backdatastr = $dbo->DataString($BackPOST);
        Box("style=width:50px;display:inline-block;margin:0px 10px;vertical-align:top");
       $backdatastr = str_replace("=","\=",$backdatastr);
       SmallButton("id=payrptbkbtn,logo=chevron-left,style=margin:0px,title=Back,onclick=Payment.PaymentReport.Search('$backdatastr')"); _Box();
       $dif = 160;
       }*/
      
      
       Box("style=clear:both");_Box();
       
       if($reportType == "rpttypefac"){
       $header=array("*StudyName"=>"STUDY",
       "*FacName"=>"SCHOOL/FACULTY",
           "*Numstud"=>"REGISTERED STUDENT"
           );
       }else if($reportType == "rpttypestate"){
        $header=array("*StateName"=>"STATE OF ORIGIN",
        "*Numstud"=>"REGISTERED STUDENT"
        );
       }else if($reportType == "studrptprog"){
       $header=array("*Prog"=>"DEPARTMENT/PROGRAMME",
           "*NumStud"=>"REGISTERED STUDENT"
           );
       }else if($reportType == "studrptlga"){
         $header=array("*lganme"=>"LGA NAME",
           "*NumStud"=>"REGISTERED STUDENT"
           );  
       }else if($reportType == "studregtypestud" || $reportType == "studregtypelga" || $reportType == "studregall" || $reportType == "studregreg"){
        $header=array("*RegID"=>"REG. ID",
        "*SName"=>"NAME",
         "*Phone"=>"Phone",
         "*Email"=>"Email",
         "*ProgName"=>"DEPARTMENT/PROGRAMME"
        );
        if($reportType == "studregall"){
            $header['*Status'] = "STATUS";
        }
       }
      $Readonly = "";
       foreach($header as $k=>$v){
        $Readonly .= ltrim($k,"*").";";
       }
       //echo $Readonly;
       $Readonly = rtrim($Readonly,";");
           SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-top:10px;margin-bottom:6px,id=studrptsumm,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=false,minrow=-1,readonly=$Readonly,trimtext=<strong class=\"altColor\">;</strong>;<strong class=\"altcolor\">,rownumstart=".($lastpgindex + 1),$header,$dump);
           Box();
           if($pg > 1){
               $DPOST['pg'] = $pg - 1;
               $datastr = $dbo->DataString($DPOST);
           SmallButton("id=studprevBtn,logo=arrow-circle-left,style=margin:10px;margin-top:3px;margin-bottom:3px;float:left,title=Previous,onclick=Student.RegReport.PerformLoad('".str_replace(array('=',','),array('\=','\,'),$datastr)."')");
           }
           if($pg != $totpg){
            echo '<div style="width:calc(100% - 125px);text-align:center;float:left;font-size:1.2em;font-weight:bold;margin-top:10px" class="altColor2">'.$pg."/".$totpg."</div>";
           }
           if($pg < $totpg){
               $DPOST['pg'] = $pg + 1;
               $datastr = $dbo->DataString($DPOST);
           SmallButton("id=studnextbtn,logo=arrow-circle-right,style=margin:10px;margin-top:3px;margin-bottom:3px;float:right,title=Next,onclick=Student.RegReport.PerformLoad('".str_replace(array('=',','),array('\=','\,'),$datastr)."')");
           }
           ClearFloat();
           _Box();
           
           echo '</div>';   
}

?>