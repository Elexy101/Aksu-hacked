<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("Bdata");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
//sleep(10);
if(isset($_POST['RegNo'])){ //if regno sent
//loop through all post data sent and make them save for mysql studaccescode
  foreach($_POST as $key => $val){
	  $_POST[$key] = $dbo->SqlSafe($val);
  }
  $regNo = trim($_POST['RegNo']);
            $st = $dbo->RunQuery("START TRANSACTION");
			$trans = $dbo->RunQuery("insert into delstudentinfo_tb select * from studentinfo_tb where (RegNo = '$regNo' or JambNo = '$regNo') and ((select count(id) from delstudentinfo_tb where RegNo = '$regNo' or JambNo = '$regNo' limit 1) = 0) limit 1");
			$del =$dbo->RunQuery("delete from studentinfo_tb where RegNo = '$regNo' or JambNo = '$regNo' limit 1");
			if($trans == false || $del == false){
				echo "#Delete Failed; ".$dbo->RunQuery->Connection->error;
				$rb = $dbo->RunQuery("ROLLBACK");
				
			}else{
				$cm = $dbo->RunQuery("COMMIT");
				echo "*Student Record Deleted Successfully";
			}
			/*//update student passport photograph
			$studinfo = $dbo->Updatedbtb("studentinfo_tb",array("RegNo" => "CONCAT(RegNo,_DEL)","JambNo" => "CONCAT(JambNo,_DEL)"),"RegNo = '{$regNo}' OR JambNo = '{$regNo}'");
			//update in course reg
			$coursereg = $dbo->Updatedbtb("coursereg_tb",array("RegNo" => "CONCAT(RegNo,_DEL)"),"RegNo = '{$regNo}'");
			//update in order 
			$order = $dbo->Updatedbtb("order_tb",array("RegNo" => "CONCAT(RegNo,_DEL)"),"RegNo = '{$regNo}'");
			//update in payment history
			$payhist = $dbo->Updatedbtb("payhistory_tb",array("RegNo" => "CONCAT(RegNo,_DEL)"),"RegNo = '{$regNo}'");
			//update in result tb
			$result = $dbo->Updatedbtb("result_tb",array("RegNo" => "CONCAT(RegNo,_DEL)"),"RegNo = '{$regNo}'");
			//update in screaning screening_tb
			$screening = $dbo->Updatedbtb("screening_tb",array("RegNo" => "CONCAT(RegNo,_DEL)"),"RegNo = '{$regNo}'");
			if(!is_array($studinfo) || !is_array($order) || !is_array($coursereg) || !is_array($payhist) || !is_array($result) || !is_array($screening)){
				
			}*/
			
}else{
	echo "#Error: Cannot identify student"; 
}


?>