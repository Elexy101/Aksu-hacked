<?php
require_once("../../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../../".$_POST['SubDir'];
require_once("../../../../../general/config.php");
require("../../../../../general/getinfo.php");

//function to prepare query string
function Prepare($drpdwnData,$colsarr,$decrypt=true){
	global $dbo;
	//decrypt query
	$drpdwnData = $decrypt === true?$dbo->_($drpdwnData):$drpdwnData;
	$drpdwnData = str_replace('94!`32!asd234','"',$drpdwnData);
	
		$replArr=[];
		$niddArr =[];
		$fseen = -1;
	   for($d=0; $d<strlen($drpdwnData) ; $d++){
		   $char = substr($drpdwnData,$d,1);
		   
		   if($char == "?"){
			   if($fseen > -1){ //if seen first
				 //get string inbetween
				  //alert(d);
				 $instr = substr($drpdwnData,$fseen+1,$d-1-$fseen);
				 //check if column exist
				 if(isset($colsarr[$instr])){ //if column exist
					 
						 //get the entered/selected value 
						 $evalue = $colsarr[$instr];
						 if(trim($evalue[0]) == ""){
							return [$evalue[1]." Cell is Required"];
							//return;
						 }else{
							 //add to replace and niddle array
							$replArr[] = $evalue[0];
							$niddArr[] = "?".$instr."?";
						 }
					 }else{
						 //MessageBox.Show("#Required Cell Not Found");
						 //return;
					 }
				 
				 $fseen = -1; //reset fseen to continue looking for another
			   }else{ //seen for the first time
				  
			   $fseen = $d;
			   }
		   }
	   }
	   
	   //form new string
	   if(count($replArr) > 0){
		$drpdwnData =  str_replace($niddArr,$replArr,$drpdwnData);
	   }
	   return $drpdwnData;
	   //alert(drpdwnData);
	
}
//$regno = $dbo->SqlSafe($_POST['regNo']);
/*Textbox dropdown loader*/

//sleep(5);
$rtnstr = "";
//exit($_POST['knw']);
	if(isset($_POST['knw'])){
		$knw = rawurldecode($_POST['knw']);
		$cols = rawurldecode($_POST['columns']);
		$colsarr = json_decode($cols,true);
		//exit($cols);
		$multi = $_POST['multi'];
		//rawurldecode
		$col = rawurldecode($_POST['column']);
		$selcolarr = isset($colsarr[$col])?explode("::",trim($colsarr[$col][0],":")):[];
		if(count($selcolarr) == 1 && trim($selcolarr[0]) == "")$selcolarr = [];
  //exit(json_encode($selcolarr));
		$id = $_POST['id'];
		$unonselect = $multi == "true"?"SpreadSheet.PopListUnSelect":"";
		$fchar = substr($knw,0,1);
		$decrypt = true;
		if($fchar=="@"){ //script
			
			$q = Prepare(substr($knw,1),$colsarr);
			
			//get the script and parameters
			$qarr = explode(" ",trim($q));
			
			if(count($qarr) < 2)exit("INVALID PARAMETER");
			//get the src and function name
			$scr = $qarr[0];$qarr[0] = "";
			$func = $qarr[1];$qarr[1] = "";
			
			//check if valid src
			if(!file_exists("../../../../../".$scr))exit("INVALID SCRIPT");
			$datastr = $qarr > 1?trim(implode(" ",$qarr)):"";
			
			$dataarr = $dbo->DataArray($datastr); //
			//include script
						
require_once "../../../../../".$scr;
//exit("kkk");
if(!function_exists($func))exit("INVALID FUNC");

$knw = call_user_func($func,$dataarr);
if($knw === FALSE)exit("Loading Dropdown Failed");
if($knw == "")exit("");
//if($knw == "")exit("No Dropdown");
			//check if file exist
			//exit($knw);
			$fchar = substr($knw,0,1); //reset fchar in case new str formed
			$decrypt = false;
		} 
		
		if($fchar == "#"){ //if query string
          
		  $q = Prepare(substr($knw,1),$colsarr,$decrypt);
		  //exit($q);
		 //echo substr($knw,1);exit();
		  if(is_array($q))exit($q[0]);
	  //$rst = $dbo->Select4rmdbtb($_POST['t'],$_POST['k'].",".$_POST['v'],$_POST['c']. " order by ".$_POST['v']." asc");
	  $rst = $dbo->RunQuery($q);
	  $_POST['h'] = isset($_POST['h'])?$_POST['h']:"";
	  if(is_array($rst)){
		  if($rst[1] > 0){
			  $datastr = array();
 			  $rtnstr .= __Table("onselect=SpreadSheet.PopListSelect,onunselect=$unonselect,rowselect=false,multiselect=$multi,id={$id}");
			  $rtnstr .= $_POST['h'] != ""?__THeader(array($_POST['h'])):"";
			  while($rec = $rst[0]->fetch_array()){
				  //$txt = strtoupper($rec[1]);
				  $txt = $rec[1];
				  $idtxt = $rec[0];
				  if($idtxt === "#"){
					$rtnstr .= __THeader(array($txt));
					continue;
				  }
				 // if(!is_array($txt)){
					 //manage current field selection
					 //get the value
					 $selstr = "";
					 //if(isset($colsarr[$col])){

						if(in_array($idtxt,$selcolarr) && trim($idtxt) != ""){
							
							$selstr = ",selected=-1";
							//$dd .= $selstr;
						}
					// }gggg


				   $rtnstr .= __TRecord(array("<span class=\"spreadsheetpopupindex\">".$idtxt."</span>".str_replace(" ","&nbsp;"," : ".$txt)),"id={$idtxt}{$selstr}");
				 /* }else{
					 $rtnstr .= __TRecord("<strong style=\"font-weight:bold\">".$idtxt."</strong>"." : ".$txt,"id={$idtxt}"); 
				  }*/
				  $datastr[] = $idtxt ."=". rawurlencode($txt);
			  }
			 // exit($dd);
			  $datastr = implode("&",$datastr);
			  $rtnstr .= '<input type="hidden" id="'.$id.'_data" value="'.$datastr.'" />';
			  $rtnstr .= ___Table();
			  
		  }
	  }
		}else{
/* 1=Tuition Fee&amp;2=Medical&amp;6=Identity Card&amp;7=GSS Courses&amp;8=Games&amp;9=Examination&amp;10=Laboratory Fess&amp;11=Utility&amp;12=Screening Fee&amp;13=Library Fee&amp;14=Student Union Deus&amp;15=Development Fee&amp;16=Late Penalty&amp;17=Birthday Fee&amp;18=Colege Money&amp;19=Acceptance Fee&amp;#=<a href="javascript:Page.OpenByTabName('ssettings')">School Payments Settings</a> */
			$datArr = is_array($knw)?$knw:$dbo->DataArray($knw);
			//print_r($datArr);
			//exit;
			$newdatastr = [];
          $rtnstr .= __Table("onselect=SpreadSheet.PopListSelect,onunselect=$unonselect,rowselect=false,multiselect=$multi,id={$id}");
		  $rtnstr .= $_POST['h'] != ""?__THeader(array($_POST['h'])):"";
			foreach($datArr as $key => $val){
				//$val = strtoupper($val);
				$selstr = "";
				if($key === "#"){
					$rtnstr .= __THeader(array($val));
					continue;
				  }

				  //form a save datastring
				  $newdatastr[$key] = $val;
					 //if(isset($colsarr[$col])){

						if(in_array($key,$selcolarr) && trim($key) != ""){
							
							$selstr = ",selected=-1";
							//$dd .= $selstr;
						}
					 //}

			$rtnstr .= __TRecord(array("<span class=\"spreadsheetpopupindex\">".$key."</span>".str_replace(" ","&nbsp;"," : $val")),"id=$key{$selstr}");
			}
		
			//$rtnstr .= __TRecord(array(strtoupper("<strong style=\"font-weight:bold\">F</strong> : FEMALE")),"id=F");
			$rtnstr .= '<input type="hidden" id="'.$id.'_data" value="'.$dbo->DataString($newdatastr).'" />';
			$rtnstr .= ___Table();
		}
		
	}

echo $rtnstr;
if($multi == "true"){
	/* Note("style=text-transform: capitalize");
	echo "Multiple Selection is Allowed";
	_Note(); */
	FlatButton("text=Finish, style=margin:auto; margin-top:5px; width:150px,onclick=PopUp.FinishMulti(this),logo=check-square,id={$id}_fin");
	}

?>