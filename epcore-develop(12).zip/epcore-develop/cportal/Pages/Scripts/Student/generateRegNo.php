<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//AllowUser("Bdata");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
//sleep(10);
if(isset($_POST['RegNo'])){
    $RegNo = $_POST['RegNo'];
    //get the student details
    $studDet = GetBasicInfo($RegNo,"studsch","",-1);
    if((int)$studDet['RegLevel'] < 6){
        exit(json_encode(["Success"=>false,"Message"=>"#Registration Number Generation Failed: Incomplete Student Data"]));
    }
    $sch = GetSchool("AutoRegNoTrigger",MYSQLI_ASSOC);

    //if generation is to be triggered by course registration, check if course payment is already made
    if($sch['AutoRegNoTrigger'] == "COURSE"){
        //get the required payment
    $paydet = $dbo->RunQuery("SELECT i.* FROM item_tb i, coursecontrol_tb c WHERE c.PayID = i.ID LIMIT 1");
    if(is_array($paydet) && $paydet[1] > 0){
        $pdet = $paydet[0]->fetch_assoc();
        //check if student has made payment, in his current Department
        $getPaydet = $dbo->RunQuery("SELECT ID FROM payhistory_tb WHERE RegNo='".$dbo->SqlSafe($RegNo)."' AND PayID=".$pdet['ID']." AND ProgID=".$studDet['ProgID']." LIMIT 1");
        if(!is_array($getPaydet))exit(json_encode(["Success"=>false,"Message"=>"#Registration Number Generation Failed: Error occur while verifying payment"]));
        if($getPaydet[1] < 1)exit(json_encode(["Success"=>false,"Message"=>"#Required Payment Not Made (".$pdet['ItemName'].")"]));
    }
    

    }
    //update student regno
    $cleardregno = AutoGenRegNo($RegNo,1,NULL,$studDet);
    if(!is_array($cleardregno)){
        switch ($cleardregno) {
            case '#':
                exit(json_encode(["Success"=>false,"Message"=>"#Reading School Details Failed"]));
                break;
            case '###':
                exit(json_encode(["Success"=>false,"Message"=>"#Student not Found"]));
                break;
            case '#####':
                exit(json_encode(["Success"=>false,"Message"=>"#Updating Student record globally failed"]));
                break;
            case '####':
                exit(json_encode(["Success"=>false,"Message"=>"#Already Has a Registration Number"]));
                break;
            case '##':
                exit(json_encode(["Success"=>false,"Message"=>"#Auto Registration Number Generation Disabled or Not Allowed"]));
                break;
            default:
            exit(json_encode(["Success"=>false,"Message"=>"#".$cleardregno]));
                break;
        }
    }else{
      exit(json_encode(["Success"=>true,"Message"=>"#Registration Number Generated","RegNo"=>$cleardregno[0]])); 
    }

}
echo "#INVALID STUDENT SELECTED";


?>