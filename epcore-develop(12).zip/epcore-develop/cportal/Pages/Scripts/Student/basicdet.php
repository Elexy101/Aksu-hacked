<?php

require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//AllowUser("Bdata");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
//sleep(10);
if(isset($_POST['RegNo'])){
    $RegNo = $_POST['RegNo'];
    //get the school structure
    
    //get the student details
    $studDet = GetBasicInfo($RegNo);
    if(is_array($studDet)){
        $sch = GetSchool('SchStrucContr');
$schStruc = json_decode($sch['SchStrucContr'],true);
Box("style=width:300px;padding-right:10px");
        Table("rowselect=false,style=width:100%;font-size:0.8em;margin:auto;text-align:left;margin-top:0px;border-top-color:transparent;text-transform:uppercase,id=paytbll,multiselect=false,data-type=table,rowalt=true");
         TRecord(['NAME:',$studDet['Name']]);
         TRecord(['REG. NO:',$studDet['Reg']]);
         if($schStruc['StudyID']['SilentMode'] == false){TRecord([strtoupper($schStruc['StudyID']['Name']).":",$studDet['StudyName']]);}
         if($schStruc['FacID']['SilentMode'] == false){TRecord([strtoupper($schStruc['FacID']['Name']).":",$studDet['Fac']]);}
         if($schStruc['DeptID']['SilentMode'] == false){TRecord([strtoupper($schStruc['DeptID']['Name']).":",$studDet['Dept']]);}
         if($schStruc['ProgID']['SilentMode'] == false){TRecord([strtoupper($schStruc['ProgID']['Name']).":",$studDet['Prog']]);}
         //get start session
         $StartSes = $dbo->SelectFirstRow("session_tb","SesName","SesID=".$studDet['StartSes']);
         $StartSesName = is_array($StartSes)?$StartSes['SesName']:"UNKNOWN";
         TRecord(["BATCH:",$StartSesName]);
        _Table();
        Note("style=margin-top:10px");
    echo "All Student record where the Reg. No. is used will be updated to Entrance Number";
    _Note(); 
    _Box();
    }else{
         Note();
    echo "INVALID STUDENT";
    _Note(); 
    }
    
  
/* {"StudID":"16229","Name":"Kejemilobi Abayomi ","Gen":"MALE","DOB":"2017-03-14","Fac":"Sciences","Dept":"Biological Science","Prog":"Botany ","Reg":"AK2019\/NAS\/L12\/004","Date":"2020-06-26","Passport":"UserImages\/Student\/AK2019_NAS_L12_004.jpg","StateId":"3","lga":"49","jamb":"0","pay":"1","RegLevel":"6","Addr":"Tyyy","Email":"Carolinasaka0t01@gmail.com","Phone":"+13565535888","ProgID":"23","StudyID":"5","ModeOfEntry":"1","BloodGroup":null,"FacID":"1","StudyName":"Undergraduate","Degree":null,"RegID":"1","RegNo":"AK2019\/NAS\/L12\/004","JambNo":"CAROLINASAKA0T01@GMAIL.COM","OlevelRstDetails":"Uyo High School`~2020`~87898909`~3`~1###`~`~`~1`~","OlevelRst":"ENGLISH LANGUAGE=C6;GOVERNMENT=C4;LITERATURE IN ENGLISH=C6;GEOGRAPHY=D7;ECONOMICS=E8;MATHEMATICS=C6;BIOLOGY=B3;CHEMISTRY=B3;PHYSICS=B2","OtherDet":"{\"EntranceID\":3,\"__EPAPI_MAPPING_\":[],\"GenderMale_Appl\":\"\",\"GenderFemale\":0,\"GenderFemale_Appl\":\"\",\"StatusSingle\":0,\"StatusSingle_Appl\":\"\",\"StatusMarried_Appl\":\"\",\"ToPageNum\":10,\"__Root_\":\"http:\\\/\\\/live\\\/v5\\\/epcore\\\/\",\"__Core_\":\"..\\\/v5\\\/epcore\\\/\",\"__SubDir_\":\"nacos\\\/\",\"__Domain_\":\"http:\\\/\\\/live\\\/nacos\\\/\",\"SchoolAttt\":\"Uyo High School\",\"SchooAttDate\":\"16\\\/6\\\/2020\",\"SchoolAtttAward\":\"WAEC\",\"FacID\":\"1\",\"Uploads\":{\"Origin\":[\"Carolinasaka0t01@gmail.com.jpg\"],\"Diploma\":[\"\"]},\"Dir\":\"Apply\\\/Entrance\",\"declearation\":[]}","AcceptLetter":"1","FacGrpID":"1","StudType":"STUDENT","FacGrpName":"SCIENCES","StartSes":"10","AdmSes":"10","YearOfStudy":"4","ClassID":"1"} */
}else{
    Note();
    echo 'INVALID PARAMETER SUPPLIED';
    _Note();
}

?>