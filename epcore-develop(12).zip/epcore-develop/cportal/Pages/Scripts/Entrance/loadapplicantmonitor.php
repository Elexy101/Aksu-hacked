<?php
if(!isset($FromPage)){
    $SubDir = $_POST['SubDir'];
$configdir = "../../../../../../".$SubDir;
require_once("../../../../general/config.php"); 
// require_once("../../../../general/getinfo.php"); 
require_once("../../../../general/TaquaLB/Elements/Elements.php");

}else{ //form the page
    $_POST['val'] = "";
$_POST['limit'] = 20;
$_POST['filter'] = 0;
}
Box("style=width:100%;box-sizing:border-box;overflow:auto");
//main container
FlatTable("id=emonregbx,style=min-width:700px");
//header box
FlatTHead();
 FlatTData("#","size=5,style=min-width:10px");
 FlatTData("APPLICANT REG/NAME","size=40,style=min-width:100px");
 
 FlatTData("VER. CODE","size=10,style=min-width:50px");
 FlatTData("DATE/TIME","size=20,style=min-width:80px");
 FlatTData("REGISTRATION LEVEL","size=15,style=min-width:50px");
 FlatTData("SMS","size=5,style=min-width:30px");
 FlatTData("DELETE","size=5,style=min-width:30px");
  /* echo '<div style="width:5%" class="rptitem">#</div>
  <div style="width:40%" class="rptitem">STUDENT</div>
  <div style="width:10%" class="rptitem">RESULT</div>
  <div style="width:10%" class="rptitem">ISSUES</div>
  <div style="width:20%" class="rptitem">FIXES</div>
  <div style="width:10%" class="rptitem">NOTES</div>
  <div style="width:5%" class="rptitem">&nbsp;</div>
  <div style="clear:both"></div>'; */
_FlatTHead();

Box("id=monregcontdiv");
$allcond = [];
/* array("All","VERIFICATION","BASIC DETAILS","PAYMENT","CONTACT","PASSPORT","ACADEMIC","GUADIANCE/REFEREE","RESULT/QUESTIONAIRE","FILE UPLOAD","ATTESTATION","COMPLETE") */
//exit($_POST['filter']);
$RegLCtr = [0=>0,1=>1,2=>1,3=>2,4=>3,5=>4,6=>5,7=>6,8=>7,9=>7,10=>8,11=>9,12=>10,13=>11];
$filtercond = "";
if((int)$_POST['filter'] > 0){
  foreach($RegLCtr as $reglevel => $reglevelnum){
      if((int)$_POST['filter'] == $reglevelnum){
        $filtercond .= "p.RegLevel = $reglevel OR ";  
      }
  }
}
if(trim($filtercond) != ""){
    $allcond[] = "(".rtrim($filtercond," OR ").")";
}

$valcond = "";
if(trim($_POST['val']) != ""){
    $val = $_POST['val'];
    $valcond = "p.SurName LIKE '%$val%' OR p.FirstName LIKE '%$val%' OR p.OtherNames LIKE '%$val%' OR v.Email LIKE '%$val%' OR v.Phone LIKE '%$val%' OR DATE_FORMAT(VDate , '%M %d %Y - %h:%i:%p') LIKE '%$val%'";
  $valarr = explode(" ",$_POST['val']);
  foreach($valarr as $valstr){
      if(trim($valstr) == "")continue;
    $valcond .= "OR p.SurName LIKE '%$valstr%' OR p.FirstName LIKE '%$valstr%' OR p.OtherNames LIKE '%$valstr%' OR v.Email LIKE '%$valstr%' OR v.Phone LIKE '%$valstr%' OR DATE_FORMAT(VDate , '%M %d %Y - %h:%i:%p') LIKE '%$valstr%'";
  }
}

if(trim($valcond) != ""){
    $allcond[] = "(".rtrim($valcond," OR ").")";
}
$allcondq = "";
if(count($allcond) > 0){
    $allcondq = "WHERE ".implode(" AND ",$allcond)."";
}

//exit("SELECT v.ID as VID, DATE_FORMAT(v.VDate , '%M %d %Y - %h:%i:%p') as VDate, v.Pin,COALESCE(v.Email,v.Phone,'') as VRegNo,  COALESCE(p.SurName,'NIL') as SurName, COALESCE(p.FirstName,'NIL') as FirstName, COALESCE(p.OtherNames,'NIL') as OtherNames,COALESCE(p.RegLevel,0) as RegLevel,IF(p.RegNo='',p.JambNo,p.RegNo) as RegNo, p.id as SID FROM applicantver_tb v LEFT JOIN pstudentinfo_tb p ON (v.Email = p.JambNo OR v.Email = p.RegNo OR v.Phone = p.JambNo OR v.Phone = p.RegNo) $allcondq ORDER BY v.VDate DESC LIMIT ".$_POST['limit']);

//individual report
$allappl = $dbo->RunQuery("SELECT v.ID as VID, DATE_FORMAT(v.VDate , '%M %d %Y - %h:%i:%p') as VDate, v.Pin,COALESCE(v.Email,v.Phone,'') as VRegNo,  COALESCE(p.SurName,'NIL') as SurName, COALESCE(p.FirstName,'NIL') as FirstName, COALESCE(p.OtherNames,'NIL') as OtherNames,COALESCE(p.RegLevel,0) as RegLevel,IF(p.RegNo='',p.JambNo,p.RegNo) as RegNo, p.id as SID FROM applicantver_tb v LEFT JOIN pstudentinfo_tb p ON (v.Email = p.JambNo OR v.Email = p.RegNo OR v.Phone = p.JambNo OR v.Phone = p.RegNo) $allcondq ORDER BY v.VDate DESC LIMIT ".$_POST['limit']);
if(is_array($allappl) && $allappl[1] > 0){
    $num = 1;
    $RegLevelArr = array("VERIFICATION","VERIFICATION","BASIC DETAILS","PAYMENT","CONTACT","PASSPORT","ACADEMIC","GUADIANCE/REFEREE","RESULT/QUESTIONAIRE","FILE UPLOAD","ATTESTATION","COMPLETE");
    
    while($indvapp = $allappl[0]->fetch_assoc()){
        FlatTRecord("class=ep-animate-opacity,style=text-align:unset");
        FlatTData($num,"size=5,style=min-width:10px");
        FlatTData($indvapp['VRegNo']." - ".$indvapp['SurName']." ".$indvapp['FirstName']." ".$indvapp['OtherNames'],"size=40,style=min-width:100px");
    FlatTData($indvapp['Pin'],"size=10,style=min-width:50px");
    FlatTData($indvapp['VDate'],"size=20,style=min-width:80px");
    $RegLevel = (int)$indvapp['RegLevel'];
  
    
    $RegN = $RegLevelArr[$RegLCtr[$RegLevel]];
    FlatTData($RegN,"size=15,style=min-width:50px");
    $regbtn = _LogoButton('style=margin-left:10px;color:#fff,class=altColor2 indcregbtnm,id='.$indvapp['VID'].'_smsbtn,onclick=Entrance.MonitorReg.SMS('.$indvapp['VID'].');return false;,logo=envelope');
    FlatTData($regbtn,"size=5,style=font-weight:bold;min-width:30px,class=ok");
    $regbtnd = _LogoButton('style=margin-left:10px;color:#fff,class=altColor indcregbtnm,id='.$indvapp['VID'].'_delbtn,onclick=Entrance.MonitorReg.DeleteV('.$indvapp['VID'].');return false;,logo=trash');
    FlatTData($regbtnd,"size=5,style=font-weight:bold;min-width:30px,class=err");
        $num++;
        _FlatTRecord();
    }
}

_Box();
//$procgrde = ; //return all grade structure with the grade symbole
// Hidden("gradeStruc",GetGrade(-1));,"*Name"=>"NAME"
// echo '<iframe src="Pages/Scripts/Exams/fix.php" style="border:none; width:100%; height:500px; background-color:#FFF"></iframe>';
_FlatTable();
_Box();
?>