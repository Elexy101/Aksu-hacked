<?php
//sleep(4);
//exit($_POST['Filter']);
//require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".urldecode($_POST['SubDir']);
require_once("../../../../general/config.php");
require_once("../../../../general/getinfo.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");
//if(!isset($_POST['SesID']) || (int)$_POST['SesID'] < 1)exit("#Invalid Session Selected");
//get the school structuer
$sch = $dbo->SelectFirstRow("school_tb","");
$schStruc = json_decode($sch['SchStrucContr'],true);
$filtercond = "";
if((int)$_POST['Filter'] == 2){
    $filtercond = " AND app.admitted = 0";
}elseif ((int)$_POST['Filter'] == 3) {
    $filtercond = " AND app.admitted = 1";
}

if(isset($_POST['ProgID']) && (int)$_POST['ProgID'] > 0){
    $filtercond = " AND app.ProgID = ".$_POST['ProgID'];
}

$dislarr = [1=>20,50,100,200,500,1000];
$limit = $dislarr[(int)$_POST['DisplayLimit']];
$strcdis = [
    "FacID"=>["f.FacID","*"],
    "DeptID"=>["d.DeptID","*"],
    "ProgID"=>["p.ProgID","*"],
    "ClassID"=>["app.ClassID","*"],
];
//$acadstruc = "";
 $acadstruc = "f.FacName, d.DeptName, p.ProgName, ";
foreach($strcdis as $did=>$qf){
 if(isset($schStruc[$did]['Name']) && $schStruc[$did]['SilentMode'] != "true"){
   // $acadstruc .= $qf[0].',';  
 }else{
    $strcdis[$did][1] = '-';
 }
}
$headers = array("-applID"=>"APPLID",
"*appFullName"=>"FULL NAME",
     "-appDOB"=>"DATE OF BIRTH",
     "*appGender"=>"GENDER",
     "*appStudy"=>strtoupper($schStruc['StudyID']['Name']));
     $headers[$strcdis["FacID"][1]."appFacs"]=strtoupper($schStruc['FacID']['Name']);
     $headers[$strcdis["DeptID"][1]."appDept"]=strtoupper($schStruc['DeptID']['Name']);
     $headers[$strcdis["ProgID"][1]."appProgID"]=strtoupper($schStruc['ProgID']['Name']);
     
    //  
     $headers["*appStartSes"]="BATCH";
     $headers["*appLvl"]="LEVEL";
     $headers[$strcdis["ClassID"][1]."appClassID"]=strtoupper($schStruc['ClassID']['Name']);
     $headers["*appStateIds"]="STATE";
     $headers["-appLGA"]="LGA";
     $headers["*appPhone"]="PHONE";
     $headers["-appEmail"]="EMAIL";
     $headers["*appStatus"]=array("STATUS","YES|NO");

     $CurSes = CurrentSes();
     $CurSesId = $CurSes['SesID'];
//get all appliicant

//{"SubDir":"nacos%2F","SesID":"10","StudyID":"5","FacID":"1","DeptID":"22","ProgID":"23"}
$q="SELECT app.id, CONCAT(app.SurName,' ',app.FirstName,' ',app.OtherNames) as FullName, DATE_FORMAT(app.DOB,'%c/%m/%Y') as ApplDOB,IF(Gender='F','Female','Male') as ApplGender,sd.Name as StudyName, $acadstruc  ses.SesName,l.Name,COALESCE(sc.Name,'NA') as ClassName, st.StateName, lg.LGAName, app.Phone, app.Email, app.admitted,  '#wrench' as 'logo', 'Manage/View Applicant Details' as 'info',CONCAT('Entrance.Screening.ManageApplicant(\'',COALESCE(app.JambNo, app.RegNo),'\',',app.id,')') as 'Action' FROM fac_tb as f, dept_tb d,programme_tb p, study_tb sd, state_tb st, lga_tb lg, session_tb ses,schoollevel_tb l, pstudentinfo_tb as app LEFT JOIN studentclass_tb sc ON app.ClassID = sc.ID WHERE p.ProgID = app.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND f.StudyID = sd.ID AND l.Level = (($CurSesId - app.StartSes) + app.ModeOfEntry) AND l.StudyID = app.StudyID AND app.LGA = lg.LGAID AND lg.StateID = st.StateID AND app.StartSes = ses.SesID  $filtercond ORDER BY app.id DESC LIMIT $limit";
$allappl = $dbo->Query($q); //
//exit("#$q");
//if(is_array($allappl))exit("#Error: ".$allappl);
if($allappl[1] < 1)exit("#No Applicant Found");
//
     Box("class=fadeInRight");
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin:auto;margin-bottom:6px,id=sprstscreen,multiselect=false,cellfocus=,cellblur=,cellkeypress=,readonly=appEmail;appFullName;appDOB;appStateIds;appPhone;appLGA;appGender;appFacs;appDept;appProgID;appStudy;appStartSes,dynamiccolumn=false,dynamicrow=false,minrow=-1,dependables=CA:Grd~Tot;Exm:Grd~Tot,rowdelete=false,rowfilter=true,filtertitle=FILTER DISPLAYED RECORD,filterstyle=width:calc(100% - 12px);margin:auto;margin-top:6px;",$headers,$dbo->FetchAll($allappl[0]));
      _Box();

?>