<?php
$configdir = "../../../../../../".urldecode($_POST['SubDir']);
require_once("../../../../general/config.php");
require_once("../../../../general/TaquaLB/Elements/Elements.php");

//AllowUser("screening");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

if(!isset($_POST["MaxDataRow"]))exit("#Invalid Parameter");
//exit("*Maxmum Row = ".$_POST['MaxDataRow']);
$sch = $dbo->SelectFirstRow("school_tb","","1=1 LIMIT 1");
$query = "";
$maxrw = (int)$_POST["MaxDataRow"];
$allphone = [];
if($maxrw > 0){
    $cnt = 0;
    for($i=1;$i<=$maxrw;$i++){
        if(!isset($_POST[$i."_1"]))continue;
        $appid = (int)$_POST[$i."_1"];
        //get applicant phone number
        $appdet = $dbo->SelectFirstRow("pstudentinfo_tb","SurName,FirstName,Phone,admitted,ProgID,ClassID","id=$appid");
        if(!is_array($appdet))continue;
        if((int)$appdet['ClassID'] == 0){
         $ProgID = (int)$appdet['ProgID'];
          //get the first classid 
          $classdet = $dbo->SelectFirstRow("studentclass_tb","ID","ProgID=".$ProgID);
          if(is_array($classdet)){
            $ClassID = $classdet['ID'];
            //update student class
            $updst = $dbo->Update("pstudentinfo_tb",["ClassID"=>$ClassID],"id=$appid");
          }
        }
        //$progid = $_POST[$i."_8"];
        $admison = $_POST[$i."_16"];
        //$classid = (int)$_POST[$i."_10"];
        if((int)$appdet['admitted'] != (int)$admison && (int)$admison == 1){ //if admission status changed to admited
          $phhone = trim($appdet['Phone']);
          if($phhone != "" && is_array($sch)){
            $allphone[] =$phhone;
            
          }
        }
        $query .= "UPDATE pstudentinfo_tb SET admitted=$admison WHERE id=$appid ;";
    }
}

if(trim($query) != ""){
    $dump = $dbo->Connection->multi_query($query);
    if(!$dump){
      echo "#Server Error: ".$dbo->Connection->error;
    }else{
       echo "Applicants Status Updated Successfully";
       if(count($allphone) > 0){
          $sendmail = $dbo->SendSMS($sch['Abbr'],"CONGRATULATIONS!!!\nYou have been offered Admission into {$sch['Name']}.\nAccess Apply > Student Account, on our portal to get your Portal Credentials.",implode(",",$allphone),"234",$sch['OpUName'],$sch['OpUPassw'],$sch['OpSMSLive']=="FALSE"?false:true); 
       }
      
    }
   }else{
     echo "No Change Found";
   }

?>