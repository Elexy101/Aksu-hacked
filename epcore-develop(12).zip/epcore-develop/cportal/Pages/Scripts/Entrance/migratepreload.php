<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");

//get loaded details
/* $preloadstudy = (int)$_POST['preloadstudy'];
$preloadprog = (int)$_POST['preloadprog'];
$preloadstartses = (int)$_POST['preloadstartses'];
$preloadclass = (!isset($_POST['preloadclass']) || (int)$_POST['preloadclass'] < 1) ?0:(int)$_POST['preloadclass'];
$preloadmoe = (!isset($_POST['preloadmoe']) || (int)$_POST['preloadmoe'] < 1) ?1:(int)$_POST['preloadmoe']; */

//get migrate details
$scrpreloadstudy  = (int)$_POST['scrpreloadstudy'];
$scrpreloadprog = (int)$_POST['scrpreloadprog'];
$scrpreloadstartses = (int)$_POST['scrpreloadstartses'];
$scrpreloadclass = (!isset($_POST['scrpreloadclass']) || (int)$_POST['scrpreloadclass'] < 1) ?0:(int)$_POST['scrpreloadclass'];
$scrpreloadmoe = (!isset($_POST['scrpreloadmoe']) || (int)$_POST['scrpreloadmoe'] < 1) ?1:(int)$_POST['scrpreloadmoe'];

if($scrpreloadstudy == 0 || $scrpreloadprog == 0 || $scrpreloadstartses == 0){

    exit(json_encode(["Success"=>FALSE,"Message"=>"#INVALID MIGRATE DETAILS SPECIFIED - $scrpreloadstudy , $scrpreloadprog , $scrpreloadstartses"]));
}

$queryarr = [];
//check if single student migrate
if(isset($_POST['StudID']) && (int)$_POST['StudID'] > 0){
    $studdet = $dbo->SelectFirstRow("pstudentinfo_tb","ProgID,IF(RegNo='',JambNo,RegNo) as StudRegNo","id=".$_POST['StudID']);
        if(!is_array($studdet))exit(json_encode(["Success"=>FALSE,"Message"=>"#Invalid Applicant"])); 
        $ProgID = (int)$studdet['ProgID'];
        $StudRegNo = $studdet['StudRegNo'];

    $queryarr[] = "UPDATE pstudentinfo_tb SET StudyID=$scrpreloadstudy, ProgID=$scrpreloadprog, StartSes=$scrpreloadstartses, ClassID=$scrpreloadclass, ModeOfEntry=$scrpreloadmoe WHERE id=".$_POST['StudID'];

    
    $query = implode(";",$queryarr).";";
    //exit(json_encode(["Success"=>FALSE,"Message"=>$query])); 
    if(trim($query) != ""){
        $dump = $dbo->Connection->multi_query($query);
         if(!$dump){
            exit(json_encode(["Success"=>FALSE,"Message"=>"#Server Error: ".$dbo->Connection->error]));
         }else{
                 do {
                         /* store first result set */
                                                         if ($result = $dbo->Connection->store_result()) {
                                                                 /*while ($row = $result->fetch_row()) {
                                                                         printf("%s\n", $row[0]);
                                                                 }*/
                                                                 $result->free();
                                                         }
                                                         /* print divider */
                                                         if ($dbo->Connection->more_results()) {
                                                                 //printf("-----------------\n");
                                                         }
                                                 } while ($dbo->Connection->next_result());
                                                 exit(json_encode(["Success"=>TRUE,"Message"=>"*Applicant Details Updated"]));
                                         }
        
    }else{
        exit(json_encode(["Success"=>FALSE,"Message"=>"#No Update Found"])); 
    }
   /*  $rq = $dbo->RunQuery($queryarr);
    if(!is_array($rq)){
        exit(json_encode(["Success"=>FALSE,"Message"=>"#Server Error: ".$rq]));
    }else{
        exit(json_encode(["Success"=>TRUE,"Message"=>"*Student Migrated"]));
    } */
}else{
   
    exit(json_encode(["Success"=>FALSE,"Message"=>"No Student Selected"])); 

}

?>