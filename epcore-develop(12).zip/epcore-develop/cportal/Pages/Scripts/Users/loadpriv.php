<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
//
AllowUser("privilege");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
if(!isset($_REQUEST['UID'])){exit("#Invalid User");}
$UID = $dbo->Sqlsafe($_REQUEST['UID']);
$UDet = $dbo->SelectFirstRow("user_tb","Privs","UserID = $UID");
if(is_array($UDet)){
  $res = "_".$UDet['Privs'];
  exit($res);
}else{
    exit("#Invalid User");
}



?>