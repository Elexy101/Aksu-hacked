<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("privilege");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
if(!isset($_POST['UID']))exit("#Invalid User");
$UID = $dbo->SqlSafe($_POST['UID']);
$Privs = $dbo->SqlSafe($_POST['Priv']);
//$dbo->Begin();
$del = $dbo->Update("user_tb",array("Privs"=>$Privs),"UserID = $UID");
if(is_array($del)){
    if($del[1] > 0){
      exit("*User Privileges Updated Successfully");
    }else{
      exit("No Change Found");
    }
}
exit("#Server Error");
?>