<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("Users");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
if(!isset($_POST['UID']))exit("#Invalid User");
$UID = $dbo->SqlSafe($_POST['UID']);
//$dbo->Begin();
$del = $dbo->Delete("user_tb","UserID = $UID");
$delst = $dbo->Delete("staff_tb","UserID = $UID");
//$del = $dbo->RunQuery("DELETE FROM user_tb, staff_tb USING user_tb, staff_tb WHERE user_tb.UserID = staff_tb.UserID AND user_tb.UserID = $UID");
if(is_array($del)){
   // if($del[1] == 1){
       // $dbo->Commit();
       unlink("../../../Files/UserImages/".$UID.".jpg");
        exit("*User Deleted Successfully");

   // }else{
       // $dbo->Rollback();
       // exit("#Suspicious Operation: Operation Terminated: ".var_dump($del));
   // }
}
//$dbo->Rollback();
exit("#Server Error");
?>