<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("Users");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");

extract($_POST); //get all post data as variables
if(!isset($UID)){exit("#Invalid User");}
if(!isset($ULogName) || !isset($UName)){exit("#Invalid User Details");}
if((int)$UID == 0){ //a new user
   
$exist = $dbo->SelectFirstRow("user_tb","","UserLogName = '$ULogName' or UserName = '$UName'");
 //check if supplied user parameter already exist
    if(is_array($exist)){
      
            
           exit("#User Already Exist"); 
        
    }
}
//exit("terminate");
$temp = (int)$UID == 0?rand().time():$UID;
$upload = false;
if($_FILES['userpasspd_image_file']){ //get passport
    $fileTmpLoc = $_FILES["userpasspd_image_file"]["tmp_name"];
    if($fileTmpLoc){
        if(!move_uploaded_file($fileTmpLoc, $configdir."Files/UserImages/".$temp.".jpg")){ //upload file
            exit("#Operation Aborted: Passport Upload Failed");
        }else{
          $upload = true;
        }
    }
}
//$mysqli->insert_id
$fielArr = array("UserLogname"=>$ULogName,"UserName"=>$UName);
if((int)$UID == 0){ //new User
//form user data / defaults
   $fielArr['Pin'] = "1111";
   $passwarr = $dbo->Hash("default@password");
   //Send to mail
   
   $fielArr['UserPassw'] = $passwarr[0];
   $fielArr['enc'] = $passwarr[1];
   $fielArr['MaxEntry'] = 8;
   $fielArr['IdleTime'] = 60;
   $fielArr['PinStatus'] = 1;
   $fielArr['Privs'] = "Password:Pin";
   $fielArr['StaffID'] = 0;
   $fielArr['Hint'] = '';
   $fielArr['remail'] = '';
   $fielArr['rphone'] = '';
  $inst = $dbo -> Insert("user_tb",$fielArr); //insert ib db
  if($inst == "#"){
      
      $NID = $dbo->Connection->insert_id; //get new user id
      $insrtmsg = "";
      //check if is ataff
      if($UStaffSt == 1){
          //add staff
          $inststaff = $dbo -> Insert("staff_tb",array("UserID"=>$NID,"StaffName"=>$UName));//create user staff record
          $insrtmsg = $inststaff != "#"?"Staff Details Upload Failed":"";
      }
      if(rename($configdir."Files/UserImages/".$temp.".jpg",$configdir."Files/UserImages/".$NID.".jpg")){ //rename user passport to id
       $insrtmsg = $insrtmsg != ""?", but ".$insrtmsg:"";
        exit("*User Added Successfully".$insrtmsg);
      }else{
          $insrtmsg = $insrtmsg != ""?", and ".$insrtmsg:"";
          exit("New User Added, but Passport Upload Failed".$insrtmsg);
      }
  }else{
     exit("#Error Adding User - ".$inst); 
  }
}else{ //if existing user (Update)
    $upd = $dbo->Update("user_tb",$fielArr,"UserID = $UID"); //update user record
    if(is_array($upd)){
        //check if is staff
        $staffinfo = $dbo->SelectFirstRow("staff_tb","","UserID=$UID LIMIT 1"); //get staff record
       $msg = "";$msgend = "";
        if(is_array($staffinfo)){ //if user is a staff
           if($UStaffSt == 1){//check if user staff state is on
            //update staff info
            $staffupd = $dbo->Update("staff_tb",array("StaffName"=>$UName,"Email"=>$ULogName),"UserID = $UID");
            $msg = "/Staff";
           }else{
               //delete Staff 
            $staffupd = $dbo->RunQuery("DELETE FROM staff_tb WHERE UserID = $UID");
            $staffupd[1] = 1;
           // $msgend = "and "
           }
        }else{ //if user is not a staff
            if($UStaffSt == 1){//check if user staff state is on
            //insert staff details (create user staff record)
            $staffupd[0] = $dbo -> Insert("staff_tb",array("UserID"=>$UID,"StaffName"=>$UName,"Email"=>$ULogName));
            $staffupd[1] = 1; 
            $msg = "/Staff";
           }
        }
       
        if($upd[1] < 1 && $upload == false && $staffupd[1] < 1){ //if no changes found
           exit("No Changes Found"); 
        }
       // if()
       exit("*User{$msg} Details Updated Successfully_{$UID}_{$UStaffSt}");  
    }else{
        exit("#Error Updating User Details");
    }
}


?>