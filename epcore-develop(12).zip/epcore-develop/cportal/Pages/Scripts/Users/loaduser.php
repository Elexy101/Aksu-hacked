<?php
require_once("../../../../general/TaquaLB/Elements/Elements.php");
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../../general/config.php");
require("../../../../general/getinfo.php");
AllowUser("Users");
//require("../../../../epconfig/GenScript/PHP/getinfo.php");
if(!isset($_REQUEST['UID'])){exit("#Invalid User");}
$UID = $dbo->Sqlsafe($_REQUEST['UID']);
$UCdet = $dbo->RunQuery("SELECT u.*,s.UserID as SUID FROM user_tb u LEFT JOIN staff_tb s ON u.UserID = s.UserID WHERE u.UserID = $UID LIMIT 1");
if(!is_array($UCdet)){exit("#Internal Error");}
if($UCdet[1] < 1){exit("#Invalid User");}
$UDet = $UCdet[0]->fetch_array();
//$UDet = $dbo->SelectFirstRow("user_tb","","UserID = $UID");
if(is_array($UDet)){
  $res = $UID."~~@##~~".$UDet['UserLogName']."~~@##~~".$UDet['UserName']."~~@##~~".$UDet['SUID'];
  exit($res);
}else{
    exit("#Invalid User");
}



?>