<?php
require_once("../../../epconfig/TaquaLB/Elements/Elements.php");
require_once("../../../epconfig/TaquaLB/Ajax/CGI/PHP/phplb.php");
 $path = _CURURL_;
        $patharr = explode("/",$path);
        $basepath = "";$cportalpth = ""; $eportalpth = "";
        foreach($patharr as $k => $val){
           if(strtolower(trim($val)) != "cportal"){
               $basepath .= $val."/";
           }else{ //if cportal fould in path
              $cportalpth = $basepath . "cportal";
              $eportalpth = $basepath . "portal";
              break;
           }
        }
       // $pthflip = array_flip($patharr);

//_CURURL_
?>
<div id="grpcont" style="width:720px; margin:auto" >
<h1 style="font-size:1.4em;color:green;display:inline-block;"><i class="fa fa-cogs" aria-hidden="true"></i> Setup</h1>
<h1 style="font-size:1em;color:green;display:inline-block;text-align:right;float:right;font-weight:normal;margin-top:30px"><a href="" style="color:#666"><i class="fa fa-database" aria-hidden="true"></i> Database Setup</a></h1><div style="clear:both"></div>
 <div id="loginCont" style="opacity:1;float:left;cursor:pointer;margin-top:0px">
  <div id="loginContInner" >
       <div id="header">
          <div><i class="fa fa-toggle-on fa-2x" style="color:#666" aria-hidden="true"></i></div> <div id="userLoginName"> Control Portal</div>
          
        </div>
        <p class="descrip"> Administrative platform for managing the student module (eduporta) and perform all configurations including internal school settings.
        <ul style="list-style:none; font-size:0.9em">
        <?php
          foreach(array(
              "Student Management System","Entrance Management System","School Site Manager","Eduporta Configuration System","School Payments Management System","Internal Mailing System","User Management System","Course Management and Reporting System","Examination/Result Management System","School Configuration System","Account Management","User Manager","Application Update and Backup System","General Reporting"
          ) as $cont){
              ?>
               <li><i class="fa fa-angle-double-right" style="color:#666" aria-hidden="true"></i> <?php echo $cont  ?>
              <?php
          }
        ?>
          
        </ul>
        </p>
        <?php
        FlatButton("text=Explore Now,style=width:308px;margin:auto;margin-top:20px,onclick=_('atocportal').click(),id=tocportal,logo=paper-plane");
       
        ?>
        <a href="<?php echo $cportalpth?>" target="_blank" id="atocportal" style="display:none" > Control Portal </a>
  </div>
  
   </div>

    <div id="loginCont" style="opacity:1;float:right;cursor:pointer;margin-top:0px">
  <div id="loginContInner" >
       <div id="header">
          <div><i class="fa fa-desktop fa-2x" style="color:#666" aria-hidden="true"></i></div> <div id="userLoginName"> Eduporta&trade; </div>
        </div>
        <p class="descrip"> Student platform (eduporta), handles all student operations from entering point to graduation level, using latest web application technology for easy access and usage. 
         <ul style="list-style:none; font-size:0.9em">
         <?php
        foreach(array("Entrance Registration and Management System",
         "Admission Management System","School Payments System","Student Course Registration &amp; Management System","Student Result Management System","Student Account management System","Student Forum &amp; Live Chatting System","School News and Events","Games","School-Student Management System","Student Transcript System","General Reporting") as $ncont){
             ?>
               <li><i class="fa fa-angle-double-right" style="color:#666" aria-hidden="true"></i> <?php echo $ncont  ?>
              <?php
        }
        ?>
        </ul>
        </p>
        <?php
        FlatButton("text=Explore Now,style=width:308px;margin:auto;margin-top:20px,onclick=_('atoeportal').click(),id=toeduporta,logo=paper-plane");
        ?>
        <a href="<?php echo $eportalpth?>" target="_blank" id="atoeportal" style="display:none" > EduPorta&trade; </a>
  </div>
  
   </div>

</div>