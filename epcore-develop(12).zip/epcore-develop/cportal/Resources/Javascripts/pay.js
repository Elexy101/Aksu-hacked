// Payment Javascrtipt Codes
AJTimeOut = 1*60*1000;
var Pay = new function(){
	this.Printer = new Printer(); //the printer object
	
	this.Ajax = new Ajax(AJTimeOut);// ajax object
	this.Link = null;
	this.LinkHTML = "";
	//the bank payment function
	this.BankPay = function(obj,RegNo, PayId,Sem,pre,lvl,alink,loadlvl){
		//alert(alink);
		if(typeof alink != "undefined" && alink != null ){
			Pay.Link = alink;
			Pay.LinkHTML = alink.innerHTML;
			alink.innerHTML = "<img style=\"width:20px;height:20px\" src=\"Resource/Images/loading.gif\" alt=\"Printing\" />"
		}
		if(typeof loadlvl == "undefined" || loadlvl == null ){ //load level is the payment breakdown level (payment analysis) in case where student is a directentry and level is 200 but is supose to pay as a fresh student, hence loadpay = 1, student level = 2
			loadlvl = 0;
		}
		if(obj != null){
		 var lo=obj.StartLoading("Bank");
		}else{
			lo = true;
		}
		var data = "RegNo="+escape(RegNo)+"&ItemNo="+PayId+"&Sem="+Sem+"&pre="+pre+"&lvl="+lvl+"&loadlvl="+loadlvl;
		if(lo){
			Pay.Ajax.PostResponse(data,"Admin/Payment/Bank/requestpay.php",function(res,url,param){
				res = res.Trim();
				if(res == "#"){
					MessageBox.ShowText("Sorry, we encountered some errors while proccessing your Payment <br /> Try again Later.",'');
				}else{
					//alert(res);
					//Pay.Printer.Print("Admin/Payment/Bank/Slip.php?"+res,function(){Pay.LinkLoading();MessageBox.Close()});
					Pay.PrintPay(res,function(){Pay.LinkLoading();MessageBox.Close()});
				}
				
				
			},"text",function(res){MessageBox.ShowText("Server error: "+res,"")});
		
		}
		
	}
	
	this.PrintOrder = function(OrderNo,alink){
		//alert(OrderNo);
		
		Pay.StartLinkLoading(alink); //turn the print link to display loading
		var res = "ItemNo="+escape(OrderNo);
		//Pay.Printer.Print("Admin/Payment/Bank/Slip.php?"+res,function(){Pay.LinkLoading();MessageBox.Close()});
		//Pay.Printer.Preview("Payment Slip",TaquaLoader.b+"/GenScript/Slip/Payment/Slip.php?"+res,function(){Pay.LinkLoading();MessageBox.Close()});
		Pay.PrintPay(res,function(){Pay.LinkLoading();MessageBox.Close()});
	}
	
	this.PrintPay = function(res,endfunc,directprint,root){
		root = typeof root == _UND?"":root; 
		/*directprint = typeof directprint == _UND?false:directprint;
		endfunc = typeof endfunc == _UND?function(){}:endfunc;
		if(!directprint){
		Pay.Printer.Preview("Payment Slip","Admin/Slip.php?folder=Payment&"+res,endfunc);
		}else{
		Pay.Printer.Print("Admin/Slip.php?folder=Payment&"+res,endfunc);	
	}*/
	PDFPrinter.Print(root+"Admin/Slip.php","folder=Payment&"+res+"&paper=A4&orientation=P&MT=4&MB=30");
	if(typeof endfunc != _UND)endfunc(); 
	}
	
	this.LinkLoading = function(){
		if(Pay.Link != null){
					Pay.Link.innerHTML = Pay.LinkHTML;
					Pay.LinkHTML = "";
				}
	}
	
	this.StartLinkLoading = function(alink){
		if(typeof alink != "undefined" && alink != null ){
			Pay.Link = alink;
			Pay.LinkHTML = alink.innerHTML;
			alink.innerHTML = "<img style=\"width:20px;height:20px\" src=\"Resource/Images/loading.gif\" alt=\"Printing\" />"
		}
	}
	
	
	//function to load the payment details
	this.LoadPay = function(obj){
	   PayType = _('payType.i').value;
	   PayTypeName = _('payType').Text();
	   Lvl = _('lvl.i').value;
	   Sem = _('paypol.i').value;
	   //alert(PayType);
	   if(PayType.ToNumber() == 0){
		   MessageBox.ShowText("INVALID <b style=\"font-weight:bolder; color:#CC3300\">PAYMENT TYPE</b>","");
		   return;
	   }
	   if(Lvl.ToNumber() == 0){
		   MessageBox.ShowText("INVALID <b style=\"font-weight:bolder; color:#CC3300\">LEVEL</b>","");
		   return;
	   }
	   if(Sem.ToNumber() == 0){
		   MessageBox.ShowText("INVALID <b style=\"font-weight:bolder; color:#CC3300\">PAYMENT POLICY</b>","");
		   return;
	   }
	   _('payDetails').Animate({CSSRule:"opacity:0;margin-left:10px",Time:_NORMAL});
	   
	   Pay.LoadAnalysis(obj,PayType,Lvl,Sem,PayTypeName); //load the payment analysis and display it
	}
	
	//load the payment breakdown
	this.LoadAnalysis = function(obj,payID,Lvl,Paypol,itemName){
		var lo=obj.StartLoading("Loading...");
		var RegNo = Cookie.Get('LoginName');
		var data = "RegNo="+escape(RegNo)+"&ItemNo="+payID+"&Sem="+Paypol+"&Lvl="+Lvl+"&ItemName="+itemName;
		
		if(lo){
			/*Pay.Ajax.PostResponse(data,"Admin/Payment/payResponse.php",function(res,url,param){
				//alert(res);
				//return;
				res = res.Trim();
				if(res == "##"){
					MessageBox.ShowText("No Payment Breakdown found".toUpperCase(),'');
				}else if(res == "###"){
					MessageBox.ShowText("Invalid Payment Analysis".toUpperCase(),'');
				}else if(res == "####"){
					MessageBox.ShowText("Server Error: Cannot get Payment details".toUpperCase(),'');
				}else if(res == "#####"){
					MessageBox.ShowText("payment already made".toUpperCase(),'');
				}else if(res == "######"){
					MessageBox.ShowText(param['ItemName']+" payment closed".toUpperCase(),'');
				}else if(res == "#######"){
					MessageBox.ShowText("only full payment is allowed".toUpperCase(),'');
				}else if(res == "@@##"){
					MessageBox.ShowText("invalid payment level/semester".toUpperCase(),'');
				}else if(res == "@@###"){
					MessageBox.ShowText("previous payment not made <br /> advise to suspend study".toUpperCase(),'');
				}else if(res == "######a"){//
					MessageBox.ShowText("screening test failed".toUpperCase(),'');
				}else if(res == "######p"){//
					MessageBox.ShowText("invalid payment policy, select first payment".toUpperCase(),'');
				}else if(res == "######na"){//
					MessageBox.ShowText("invalid operation: you are not allowed to make payment.".toUpperCase(),'');
				}else{
					_('payDetails').innerHTML = res;
				      Admin.PerformAutoHeight();//recalculate all auto height objects
				     _('payDetails').Animate({CSSRule:"opacity:1;margin-left:0px",Time:_NORMAL});
					//alert(res);
					//Pay.Printer.Print("Admin/Payment/Bank/Slip.php?"+res,function(){MessageBox.Close()});
				}
				_('loadpaybtn').StopLoading();
			},"text",function(res){MessageBox.ShowText("SERVER ERROR: "+res.toUpperCase(),"");_('loadpaybtn').StopLoading();});*/
			Pay.Ajax.Post({
				Action:"Admin/Payment/payResponse.php",
				PostData:data,
				OnProgress:function(delta){
					delta = Math.floor(delta*100);
					if(delta < 100){
						MessageBox.Progress.HintTo(delta,null,"Loading",'Pay.Ajax.abort()');
					}else{
						MessageBox.Progress.HintTo(-1,"Loading ...","Loading",'Pay.Ajax.abort()'); 
					}
				},
				OnComplete:function(res,url,param){
                     //alert(res);
					//return;
					res = res.Trim();
					if(res == "##"){
						MessageBox.ShowText("No Payment Breakdown found".toUpperCase(),'',null,null,"OPERATION FAILED");
					}else if(res == "###"){
						MessageBox.ShowText("Invalid Payment Analysis".toUpperCase(),'',null,null,"OPERATION FAILED");
					}else if(res == "####"){
						MessageBox.ShowText("Cannot get Payment details".toUpperCase(),'',null,null,"Server Error");
					}else if(res == "#####"){
						MessageBox.ShowText("payment already made".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "######"){
						MessageBox.ShowText(param['ItemName']+" payment closed".toUpperCase(),'',null,null,"OPERATION FAILED");
					}else if(res == "#######"){
						MessageBox.ShowText("only full payment is allowed".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "@@##"){
						MessageBox.ShowText("invalid payment level/semester".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "@@###"){
						MessageBox.ShowText("previous payment not made <br /> advise to suspend study".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "######a"){//
						MessageBox.ShowText("screening test failed".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "######p"){//
						MessageBox.ShowText("invalid payment policy, select first payment".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else if(res == "######na"){//
						MessageBox.ShowText("invalid operation: you are not allowed to make payment.".toUpperCase(),'',null,null,"INVALID OPERATION");
					}else{
						
						_('payDetails').innerHTML = res;
						Admin.PerformAutoHeight();//recalculate all auto height objects
						_('payDetails').Animate({CSSRule:"opacity:1;margin-left:0px",Time:_NORMAL});
						//alert(res);
						//Pay.Printer.Print("Admin/Payment/Bank/Slip.php?"+res,function(){MessageBox.Close()});
					}
					MessageBox.CloseHint();
					_('loadpaybtn').StopLoading();
				},
				OnAbort:function(){
                 _('loadpaybtn').StopLoading();
				},
				OnError:function(){
					MessageBox.CloseHint();
					MessageBox.ShowText(res.toUpperCase(),"",null,null,"SERVER ERROR");_('loadpaybtn').StopLoading();
				}
			})
		}
	}
	
	 //function to load the paypolicy based on the level selected
 this.LoadPayPol = function(input){
	 Filter.Reset('paypol',[0,"PAYMENT POLICY"]);
	  var Lvl = input.value;
	 var PayID =  _('payType.i').value;
	  if(Lvl.ToNumber() == 0){
		  return;
	  }
	  
	  var RegNo = Cookie.Get('LoginName');
	  _('payDetails').Animate({CSSRule:"opacity:0;margin-left:10px",Time:_NORMAL});
	   _('paypolloading').Show();
	   RegNo = RegNo.Replace("'","\\'");
	   myAjax = new Ajax(AJTimeOut);
	   //alert(Main.connect);
	   //General.Ajax.PostResponse("query="+escape(query)+"&loadid="+loadid+"&loadingId="+loadingid,"Admin/query.php",function(res,url,param){
		  // alert("RegNo="+RegNo+"&Lvl="+Lvl+"&PayID="+PayID);
	   myAjax.PostResponse("RegNo="+RegNo+"&Lvl="+Lvl+"&PayID="+PayID,"Admin/Payment/loadpaypolicy.php",function(res){
//alert(res);
//'dd'
_('paypolloading').Hide();
if(res.Trim() == "") {MessageBox.Hint("CANNOT LOAD PAYMENT POLICY");return;}
if(res.Trim() == "#") {MessageBox.Hint("COMPLETE PAYMENT ALREADY MADE FOR THE SELECTED LEVEL");return;}
//*************************************** */
if(res.Trim() == "##") {MessageBox.Hint("PREVIOUS PAYMENT NOT MADE, ADVISE TO SUSPEND STUDY");return;}
/*************************************** */
var arres = res.ToDataArray(true);
var orderarr = arres.OrderArray;
var rarr = arres.NewArray;
if(orderarr.length > 0){
	for(var s=0 ; s<orderarr.length; s++){
		//alert(rarr[id]); 
		var id = orderarr[s];
		var val = rarr[id];
		id = id.Trim(); //trim all leading and trailing space from the id 
		Filter.Add('paypol',[id,val]);
	}
}

		 
	 },"text",function(q){MessageBox.Hint("SERVER ERROR: "+res.toUpperCase());_('paypolloading').Hide(); });
	 
 }
 
 //function to determin immidiate previous payment parameter for checking
 this.GetPrevPayParam = function(rlvl, rsem){
	 if(rlvl == 1 && (rsem == 1 || rsem == 3))return {err:"None"}//if freshers, i.e no prevous payment record
	 if(rlvl == 0 || rsem == 0)return {err:"Invalid"}//if freshers, i.e no prevous payment record
	 rsem = (rsem == 3)?1:rsem; //if current payment is full take like first payment so that it can check for prev lvel sem 1
	 var sem = rsem - 1; //calculate prevouse semester
	 sem = (sem == 0)?2:sem; // if no semester for prev, den set semester to 2, meaning second semester of the prev level
	 var lvl = rlvl - sem + 1; //calculate prevous level
	 return {err:"",level:lvl,semester:sem}
 }
 
  
 //function to handle card payment
 this.CardPay = function(obj,hash,opt,data,root){
	 //http://localhost/projects/rportals/Admin/remita/sample-receipt-page.php
	 //alert(data);
	// if(1==1){MessageBox.Hint("Online/Card Option Disabled"); return;}
	
	 data = typeof data == _UND?"":"&"+data;
	 //alert(typeof obj.id);
	 if(typeof obj.id != _UND){ 
	 var lo = obj.StartLoading();
	 }
	 root = typeof root == _UND?"":root;
	 //alert(root+"Admin/Payment/cardpayredirect.php?h="+escape(hash)+"&op="+escape(opt)+data);
	 var win = window.open(root+"Admin/Payment/cardpayredirect.php?h="+escape(hash)+"&op="+escape(opt)+data,"newwin","width=800,menubar=no,status=no,scrollbars=yes");
	// var win = window.open("http://localhost/projects/rportals/Admin/Payment/finish.php?orderID=862454774060716195854","newwin","width=800,menubar=no,status=no,scrollbars=yes");
	 win.focus();
	 Pay.LinkLoading();MessageBox.Close()
 }
 //function to check if payment is made
/* this.Check = function(RegNo,Lvl,Paypol,payID){
	 var data = "RegNo="+escape(RegNo)+"&ItemNo="+payID+"&Sem="+Paypol+"&Lvl="+Lvl;
	 Pay.Ajax.PostResponse(data,"Admin/Payment/checkPay.php",function(res,url,param){
				//alert(res);
				if(res == "##"){
					MessageBox.ShowText("No Payment Breakdown found".toUpperCase(),'');
				}
	 });
 }*/
this.LoadAjax = null; //the ajax object loading courses reg currently
  this.currID = "";//the current selected id
  //function to load registered courses
  this.LoadReg = function(obj,contid){
	  //display loading gif
	  _("loadin_"+obj.id).Appear();
	  
	  if(Pay.LoadAjax != null){
		/* Pay.LoadAjax.abort();
		 Pay.LoadAjax = null;
		 if(Pay.currID != ""){
			 var oldload = _("loadin_"+Pay.currID);
			 if(oldload != null){ 
			_("loadin_"+Pay.currID).Disappear(); 
			 }
		 }*/
		 return;
		 
	  }
	  Pay.currID = obj.id;
	  // courses = obj.getAttribute("courses");
	   det = obj.getAttribute("det");
	  // alert(courses);
	  /*if(courses == null || courses.Trim() == ""){
	    MessageBox.ShowText("No Course Found".toUpperCase(),""); 
		 _("coursesbox").Animate({CSSRule:"opacity:0;margin-left:10px",Time:500});
	  }else{*/
		 if( _("coursesbox").style.opacity == "0"){
			 Pay.CompleteLoadReg(det);
		 }else{
		 _("coursesbox").Animate({CSSRule:"opacity:0;margin-left:10px",Time:500,DoAt:1,EndAction:"Pay.CompleteLoadReg('"+det+"')"});
		 }
	  //}
	 
	  
  }
  
  this.CompleteLoadReg = function(det){
	  Pay.LoadAjax = new Ajax();
	  /*Pay.LoadAjax = _("coursesbox").HTML("Admin/Payment/payhistoryres.php?det="+escape(det)+"&id="+escape(Pay.currID),
	  function(obj){
		  Admin.PerformAutoHeight();
		  obj.Animate({CSSRule:"opacity:1;margin-left:0px",Time:500,DoAt:1,EndAction:"_('loadin_'+Pay.currID).Disappear();"});
		},
	  function(res){ //error handler
        MessageBox.ShowText("SERVER ERROR: "+res, "");
	    _('loadin_'+Pay.currID).Disappear();
	  })*/
	  Pay.LoadAjax.Post({
		  Action:"Admin/Payment/payhistoryres.php",
		  PostData:"det="+escape(det)+"&id="+escape(Pay.currID),
		  OnProgress:function(delta){
			  delta = Math.floor(delta*100);
				if(delta < 100){
					MessageBox.Progress.HintTo(delta,null,"Loading",'Pay.LoadAjax.abort()');
				}else{
					MessageBox.Progress.HintTo(-1,"Loading ...","Loading",'Pay.LoadAjax.abort()'); 
				}
		  },
		  OnComplete:function(res,url,param){
			  MessageBox.CloseHint();
			  _("coursesbox").innerHTML = res;
			  Admin.PerformAutoHeight();
		  _("coursesbox").Animate({CSSRule:"opacity:1;margin-left:0px",Time:500,DoAt:1,EndAction:"_('loadin_'+Pay.currID).Disappear();"});
			 Pay.LoadAjax = null;
		  },
		  OnAbort:function(){
			 _('loadin_'+Pay.currID).Disappear();
			 Pay.LoadAjax = null; 
		  },
		  OnError:function(res){
			  MessageBox.CloseHint();
			  _('loadin_'+Pay.currID).Disappear(); 
			  MessageBox.ShowText(res,"",null,null,"SERVER ERROR");
			  Pay.LoadAjax = null;
		  }
	  })
  }

// 10/10/2016 - TAG: function to handle rrr verification
this.VPayAjax = new Ajax();
  this.VerifyPay = function(){

	  var lo=_('verifyRefbtn').StartLoading("Verifying...");
     var thirdp = _('thirdp').value;
	 var refno = _('payid').value;
	 var data = "tp="+thirdp+"&rn="+refno;
	 
	 if(lo){
		  _('studDetails').SetStyle("opacity:0;margin-left:10px");
      /* Pay.Ajax.PostResponse(data,"Admin/Payment/vpayResponse.php",function(res,url,param){
		     //alert(res);
			 ressp = res.split("#");
                if(res.Trim() == "#"){
					MessageBox.ShowText("INVALID PAYMENT DETAILS","");
				}else if(ressp[0].Trim() == '5'){
					MessageBox.ShowText("INVALID TRANSACTION","");
				}else if(ressp[0].Trim()  == '0'){
                    MessageBox.ShowText("PAYMENT NOT MADE","");
				}else if(ressp[0].Trim()  == '6' || ressp[0].Trim()  == '2'){
                    MessageBox.ShowText("INVALID PARAMETERS OR BAD NETWORK","");
				}else if(ressp[0].Trim()  == '7'){
                    MessageBox.ShowText("WRONG REFERENCE NUMBER","");
				}else{
                   res = res.Trim();
				_('studDetails').innerHTML = res;
				//_('verifybtn').StopLoading();
				_('studDetails').Animate({CSSRule:"opacity:1;margin-left:0px",Time:_NORMAL});
				

				}
				_('verifyRefbtn').StopLoading();
				//return;
				
			},"text",function(res){MessageBox.ShowText("SERVER ERROR: "+res.toUpperCase(),"");_('verifyRefbtn').StopLoading();});*/
			Pay.VPayAjax.Post({
		  Action:"Admin/Payment/vpayResponse.php",
		  PostData:data,
		  OnProgress:function(delta){
			  delta = Math.floor(delta*100);
				if(delta < 100){
					MessageBox.Progress.HintTo(delta,null,"Verify",'Pay.VPayAjax.abort()');
				}else{
					MessageBox.Progress.HintTo(-1,"Verifying ...","Verify Payment",'Pay.VPayAjax.abort()'); 
				}
		  },
		  OnComplete:function(res,url,param){
			//alert(res); 
			  ressp = res.split("#");
                if(res.Trim() == "#"){
					MessageBox.ShowText("INVALID PAYMENT DETAILS","",null,null,"INVALID OPERATION");
				}else if(ressp[0].Trim() == '5'){
					MessageBox.ShowText("INVALID TRANSACTION","",null,null,"INVALID OPERATION");
				}else if(ressp[0].Trim()  == '0'){
                    MessageBox.ShowText("PAYMENT NOT MADE","",null,null,"OPERATION FAILED");
				}else if(ressp[0].Trim()  == '6' || ressp[0].Trim()  == '2'){
                    MessageBox.ShowText("INVALID PARAMETERS OR BAD NETWORK","",null,null,"OPERATION FAILED");
				}else if(ressp[0].Trim()  == '7'){
                    MessageBox.ShowText("WRONG REFERENCE NUMBER","",null,null,"INVALID OPERATION");
				}else{
                   res = res.Trim();
				_('studDetails').innerHTML = res;
				//_('verifybtn').StopLoading();
				_('studDetails').Animate({CSSRule:"opacity:1;margin-left:0px",Time:_NORMAL});
				}
				MessageBox.CloseHint();
				_('verifyRefbtn').StopLoading();
		  },
		  OnAbort:function(){
			_('verifyRefbtn').StopLoading();
		  },
		  OnError:function(res){
			  MessageBox.CloseHint();
			  _('verifyRefbtn').StopLoading();
			  MessageBox.ShowText(res,"",null,null,"SERVER ERROR");
			 
		  }
	  })
	 }
  }

 
}


//New Payment System
var NewPay = {
	
	InitPay:{
		Ajax:new Ajax(),
		Start:function(param,btn){
			//alert(OptionBox.Show());
		if(typeof param.RegNo != _UND && typeof param.Lvl != _UND && typeof param.Sem != _UND && typeof param.SemPart != _UND && typeof param.Amt != _UND && typeof param.PayID != _UND){
			var lo=typeof btn != _UND?btn.StartLoading("Initializing..."):true;
			if(lo){
				var analbx = _('paybtnbrkdwn');
				var brkdwn = analbx == null?"":escape(analbx.textContent);
				var paydata = "RegNo="+escape(param.RegNo)+"&Lvl="+escape(param.Lvl)+"&Sem="+escape(param.Sem)+"&SemPart="+escape(param.SemPart)+"&Amt="+escape(param.Amt)+"&PayID="+escape(param.PayID)+"&BrkDwn="+brkdwn;
				//paerform payment init operation and get the payment ref
				NewPay.InitPay.Ajax.Post({
					Action:configdata['Core']+"general/Payment/init.php",
					PostData:paydata+"&SubDir="+encodeURIComponent(configdata['SubDir']),
					OnProgress:function(delta){
						delta = Math.floor(delta*100);
						if(delta < 100){
							MessageBox.Progress.HintTo(delta,null,"Initialize Payment",'NewPay.InitPay.Ajax.abort()');
						}else{
							MessageBox.Progress.HintTo(-1,"Initializing ...","Initialize Payment",'Pay.InitPay.Ajax.abort()'); 
						}
					},
					OnComplete:function(res,url,param){
					    //alert(res);
						if(typeof btn != _UND)btn.StopLoading();
						MessageBox.CloseHint();
						//convert to object
						var resobj = JSON.parse(res);//console.log(resobj.Error);
						if(typeof resobj.Error != _UND){MessageBox.ShowText(resobj.Error,"",null,null,"PAYMENT");return}
						if(typeof resobj.Ref == _UND){MessageBox.ShowText("INTERNAL ERROR: No Payment Reference Found");return}
						var amt = resobj.Amt.ToNumber().toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})
						OptionBox.Show({
							Title:"Select Payment Options",
							HTML:'AMOUNT PAYABLE: <b>'+amt+"</b>",
							Logo:"money",
							Options:[
								{Title:"BANK",Logo:"university",
								Function:function(ref){
									PDFPrinter.Print("Admin/Slip.php","folder=Payment&ItemNo="+escape(ref)+"&paper=A4&orientation=P&MT=4&MB=30");
								},
								Parameter:resobj.Ref
							},
								{Title:"ONLINE",Logo:"laptop",
								Function:function(ref){
									var win = window.open("../epconfig/GenScript/Payment/post.php?Ref="+escape(ref),"newwin","width=800,menubar=no,status=no,scrollbars=yes");
								},
								Parameter:resobj.Ref}
							]
						});
						//MessageBox.ShowText("Good: "+ resobj.Ref,"",null,null,"Payment Options");
						
					},
					OnAbort:function(){
						MessageBox.Hint("PAYMENT ABORTED");
						if(typeof btn != _UND)btn.StopLoading();
					},
					OnError:function(res){
						MessageBox.Hint("SERVER ERROR: "+res);
						if(typeof btn != _UND)btn.StopLoading();
					}
				})
			}
		}else{
			MessageBox.Hint("INVALID PAYMENT DETAILS");
		}
		}
}
}