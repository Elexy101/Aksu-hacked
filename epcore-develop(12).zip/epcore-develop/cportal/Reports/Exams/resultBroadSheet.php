<?php //sleep(4); 
//LE 22-5-17 #6
ini_set("memory_limit","-1");
$baseurl = "../../../";
/* require_once($baseurl."epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
LoadFile("pdfprint",$baseurl); */
$subDir = urldecode($_REQUEST['SubDir']);
$configdir = "../../../../../".$subDir;
require_once("../../../general/config.php");
require("../../../general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
function FormCell($B4CO,$postfex=""){
 global $SemCourses;
 $carryOverHTML = "";
 $B4CO = trim($B4CO);
 if($B4CO == ""){return "";}
    $B4COArr = explode("::",trim($B4CO,":"));
            if(count($B4COArr) > 0){
                $B4COArr = array_unique($B4COArr);
                foreach($B4COArr as $indB4CO){
                    $courseDet = isset($SemCourses[$indB4CO])?$SemCourses[$indB4CO]:CourseDetails($indB4CO);
                   $carryOverHTML .= str_replace(" ","&nbsp;",$courseDet['CourseCode']).$postfex.", ";
                }
               $carryOverHTML = rtrim($carryOverHTML,", ");
            }
           // $carryOverHTML .= "";
            return $carryOverHTML;
}

//function to generate record 
function FormRow($indrst,$rwDescr){
  global $CoursesNow;
  global $Semspan;
  global $grdstr;
  global $schgrdstr;
  global $SemCourses;
  global $LevelID;
  global $firstRst;
  global $counter;
  global $classPassDetAll;
  global $classPassStr;
  global  $problimit;
  global $SemID;
  global $probflag;
  global $withdrawflag;
  global $OldCourses;
  global $yearofStudy;
 
  //global $LevelID;
  global $dbo;
  $recordhtml = "";
            $semcourseArr = array_fill_keys(array_keys($CoursesNow), "<th>  </th>");
            $carryOverHTML = "";
            $Name = strtoupper($indrst['SurName']).' '.ucwords(strtolower($indrst['FirstName'])).' '.ucwords(strtolower($indrst['OtherNames']));
            $RegNo = $indrst['RegNo'];
            $CarryOver = $indrst['Outst'];
            $CarryOverArr = explode("+",$CarryOver);
            $B4CO = isset($CarryOverArr[1])?$CarryOverArr[0]:"";
            $NowCO = isset($CarryOverArr[1])?$CarryOverArr[1]:$CarryOverArr[0];
            //form carryover html (b4)
            $carryOverHTMLB4 = FormCell($B4CO);
            //form carryover now
            $carryOverHTMLNow = FormCell($NowCO);

          $Rept = $indrst['Rept'];
          $RstInfo =  json_decode($indrst['RstInfo'],true);
            $ReptArr = explode("+",$Rept);
            $B4Rept = isset($ReptArr[1])?$ReptArr[0]:"";
            $NowRept = isset($ReptArr[1])?$ReptArr[1]:$ReptArr[0];
            //form repeat b4 
          $repeatHTMLB4 = FormCell($B4Rept,"F");
            //form repeat now 
         $repeatHTMLNow = FormCell($NowRept);
        //form b4 details 
         $recordhtml .= "<tr>
             <td style=\"vertical-align:top\">$counter</td>
             <td style=\"text-align:left;vertical-align:top\">$Name <br /> $RegNo <br /><b>$rwDescr</b></td>";
             if(!$firstRst){ //if not first rst
             $recordhtml .= "<td style=\"vertical-align:top\">$carryOverHTMLB4</td><td style=\"vertical-align:top\">$repeatHTMLB4</td>";
             }
        $CORepHTMLCH = ""; //hold the html CO repeat course rst CH
        $CORepHTMLCCode = ""; //hold the html CO repeat course rst Course Code
        $CORepHTMLRst = ""; //hold the html CO repeat course rst TotGrade
        $TCH = 0; $TGP = 0; $CCH = $indrst['CCH']; $CGP = $indrst['CGP'];
           $Rst = $indrst['Rst'];
           if(trim($Rst) == ""){ //if no result
             $recordhtml .= "<th colspan=\"$Semspan\" >NO RESULT </th>";
           }else{
             //loop through rst 
            $RstArr = explode("&",$Rst);
            if(count($RstArr) > 0){
              foreach($RstArr as $indStudRst){
                  $indrstdet = explode("=",$indStudRst);
                  if(count($indrstdet) == 2){
                      $RstCourseID = $indrstdet[0];
                      $RealRst = explode("|",$indrstdet[1]);
                      //check if old score structure
                      if(strpos($RealRst[0],",") === false){
                        $RealRst[0] = $RealRst[0].",".$RealRst[1];
                      }
                      // $tot = (int)$RealRst[0] + (int)$RealRst[1];
                      $tot = array_sum(explode(",",$RealRst[0]));
                      if(count($RealRst) > 2){
                        $pass = (int)$RealRst[5];
                        $grdval = $RealRst[3];
                        $grdlvl = (int)$RealRst[2];
                        $Ftot = $tot < 10?("0".$tot):$tot;
                      }else{
                        //get grade 
                      $grds = GetGrade($tot,$grdstr,$schgrdstr);
                      $Ftot = $tot < 10?("0".$tot):$tot;
                     /*  $totlen = strlen($Ftot);
                      if($totlen == 1)$Ftot = "0".$Ftot; */
						$pass = (int)$grds["PASS"];
                       $grdval = $grds["Grade"];
                       $grdlvl = (int)$grds["Level"];
                      }
                      
                      if(isset($RstInfo[$RstCourseID])){
                        $courseDet = $RstInfo[$RstCourseID];
                      }else{
                        $courseDet = isset($SemCourses[$RstCourseID])?$SemCourses[$RstCourseID]:CourseDetails($RstCourseID);
                      }
                       
                       //check if semester course
                       if(isset($semcourseArr[$RstCourseID])){
                           $semcourseArr[$RstCourseID] = "<td style=\"vertical-align:top\">".$Ftot . $grdval."</td>";
                       }else{ //if not sem course
                          //double check if result is a sem result but not loaded (old) 22-5-17 #1
                        /* if((int)$courseDet['Lvl'] == $LevelID && (int)$courseDet['Sem'] == $SemID){

                         }*/
                          $CORepHTMLCH .= $courseDet['CH']."<br />";
                          $CORepHTMLCCode .= $courseDet['CourseCode']."<br />";
                          $CORepHTMLRst .= $Ftot . $grdval."<br />";
                       }
                       //calculate TCH, TGP
                      // $TCH += (int)$courseDet['CH'];
                      // $TGP += (int)$courseDet['CH'] * $grdlvl;

                  }
              }

            }
              if($LevelID > 1){
                //22-5-17 #6 - removed || ($LevelID < 2 && count($OldCourses) > 0)
              $recordhtml .= "<td style=\"vertical-align:top\">$CORepHTMLCH</td>
              <td style=\"vertical-align:top\">$CORepHTMLCCode</td>
              <td style=\"vertical-align:top\">$CORepHTMLRst</td>
              ";
             }
             //$semcourseArr[$RstCourseID] = "<td>".$tot . $grdval."</td>";
             $recordhtml .= implode("",$semcourseArr);
           }
           //form records 
            
            
             $GPA = number_format($indrst['GPA'],2);
             $recordhtml .= "<td style=\"vertical-align:top\">{$indrst['TCH']}</td><td style=\"vertical-align:top\">{$indrst['TGP']}</td><td style=\"vertical-align:top\">$GPA</td>";
             $usecgpa = (float)$indrst['GPA'];
             if(!$firstRst){
             $B4CH = $indrst['BCH'];
             $B4GP = $indrst['BGP'];
             $CGPA = number_format($indrst['CGPA'],2);
             
             $recordhtml .= "<td style=\"vertical-align:top\">$B4CH</td><td style=\"vertical-align:top\">$B4GP</td><td style=\"vertical-align:top\">$CCH</td><td style=\"vertical-align:top\">$CGP</td><td style=\"vertical-align:top\">$CGPA</td>";
             $usecgpa = (float)$indrst['CGPA'];
            
             }
              $classPassdet = GetClassPass($usecgpa,$classPassStr,$classPassDetAll);
              $classOfPass = is_array($classPassdet)?$classPassdet['ClassName']:"";
             
             //remark
             if($usecgpa < $problimit && $SemID == 2){ //if on probation
               //get prev year result to check if probation (meaning stud will be advice to suspend study)
               if($LevelID > 1){
                 $PrevLlv = $LevelID - 1;
                 //get result for prev 
                 $prevyearRst = $dbo->SelectFirstRow("result_tb","","Lvl = $PrevLlv AND Sem = 2 AND RegNo = '$RegNo' ORDER BY GroupID DESC");
                 if(is_array($prevyearRst)){
                   //$PrevYearCCH = (int)$prevyearRst['CCH'];
                  // $PrevYearCGP = (int)$prevyearRst['CGP'];
                   //if($PrevYearCCH > 0){
                    // $PrevCGPA = $PrevYearCGP/$PrevYearCCH;
                     if((float)$prevyearRst['CGPA'] < $problimit){ //if prev year is probation, then stud is advice to Withdraw
                      $probflag=$withdrawflag;
                     }
                   //}
                 }
               }
               //New - when displaying probation also display repeat and carry overs
               if(trim($carryOverHTMLNow) != "" || trim($repeatHTMLNow) != ""){

               }
               $recordhtml .= "<td style=\"text-align:left;vertical-align:top\"><b style=\"text-transform:uppercase\"> $probflag </b><br />";
                  if(trim($carryOverHTMLNow) != ""){
                    $recordhtml .= "<b>CARRY OVER:</b> ".$carryOverHTMLNow."<br />";
                  }
                  if(trim($repeatHTMLNow) != ""){
                    $recordhtml .= "<b>REPEAT:</b> ".$repeatHTMLNow;
                  }
                  $recordhtml .= "</td>";
                 //$recordhtml .= "<td style=\"text-align:left;vertical-align:top;text-transform:uppercase\"> $probflag </td>";
               }else{
                if(trim($carryOverHTMLNow) == "" && trim($repeatHTMLNow) == ""){
                  //
                  if($LevelID >= (int)$yearofStudy){ //if final year student display class of pass
                    $recordhtml .= "<td style=\"text-align:left;vertical-align:top;text-transform:uppercase\"> $classOfPass </td>";
                  }else{
                  $recordhtml .= "<td style=\"text-align:left;vertical-align:top;text-transform:uppercase\"> PASSED </td>";
                  }
                }else{
                  
                  $recordhtml .= "<td style=\"text-align:left;vertical-align:top\">";
                  if(trim($carryOverHTMLNow) != ""){
                    $recordhtml .= "<b>CARRY OVER:</b> ".$carryOverHTMLNow."<br />";
                  }
                  if(trim($repeatHTMLNow) != ""){
                    $recordhtml .= "<b>REPEAT:</b> ".$repeatHTMLNow;
                  }
                  $recordhtml .= "</td>";
                  
                }
               }
              
             $recordhtml .= "</tr>";
            return $recordhtml;
}

$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");

//require_once("../../../epconfig/TaquaLB/Ajax/CGI/PHP/PDF/mpdf.php");
 extract($_GET);
//$pdf->Dump("<html>");
 
 
//$pdf->HTML();
/*echo "SELECT f.FacName, d.DeptName, p.ProgName, p.YearOfStudy,s.SesName,sm.Semester FROM fac_tb f, dept_tb d, programme_tb p, session_tb s, semester_tb sm WHERE f.FacID = d.FacID AND d.DeptID = p.DeptID AND s.SesID = $SesID AND sm.ID = $SemID AND p.ProgID = $ProgID LIMIT 1";
$pdf->Finish();
      exit();*/
 //get result information
 $rstinfo = $dbo->RunQuery("SELECT f.FacName, d.DeptName, p.ProgName, p.YearOfStudy,s.SesName,sm.Sem FROM fac_tb f, dept_tb d, programme_tb p, session_tb s, semester_tb sm WHERE f.FacID = d.FacID AND d.DeptID = p.DeptID AND s.SesID = $SesID AND ((sm.Num > 0 && sm.Num = $SemID) || sm.ID = $SemID) AND p.ProgID = $ProgID LIMIT 1");
 if(!is_array($rstinfo)){
      $pdf->Dump("Error Loading Result Info");
      $pdf->Finish();
      exit;
 }
 if($rstinfo[1] < 1){
      $pdf->Dump("No Result Info Found");
     // $pdf->_HTML();
      $pdf->Finish();
      exit;
 }
 
 $rstType = "";
 $tcond = "";
 $grporder = ", GroupID ASC";
 if($type == "1"){
   $rstType = "CORRECTION OF RESULTS";
   $tcond = "AND GroupID > 1";
   $grporder = ", GroupID DESC";
 }else if($type == "2"){ //if to load probation year
   
   $rstType = "PROBATION YEAR RESULTS";
   if($LevelID > 1){
     $tcond = "OR (r.Lvl = ".($LevelID - 1)." AND r.Sem = 2 AND r.SesID = ".($SesID - 1)." AND s.ProgID = $ProgID)";
     $grporder = ", r.Lvl ASC, GroupID DESC";
   }else{
     $tcond = "AND (1=2)";
     $grporder = "";
   }
   
   
 }else{
   $rstType = $type;
   $rstType = "";
 }

 if(trim($utitle) != "")$rstType = $utitle;
 
 $rst = $dbo->RunQuery("SELECT r.*, s.SurName ,s.FirstName,s.OtherNames FROM coursereg_tb c LEFT JOIN result_tb r ON (c.RegNo = r.RegNo AND c.Lvl = r.Lvl AND c.Sem = r.Sem AND c.SesID = r.SesID) INNER JOIN studentinfo_tb s ON (r.RegNo = s.RegNo OR r.RegNo = s.JambNo) WHERE (r.Lvl = $LevelID AND r.Sem = $SemID AND r.SesID = $SesID AND s.ProgID = $ProgID) $tcond ORDER BY r.RegNo ASC $grporder");

 //SELECT r.* FROM coursereg_tb c LEFT JOIN result_tb r ON (c.RegNo = r.RegNo AND c.Lvl = r.Lvl AND c.Sem = r.Sem AND c.SesID = r.SesID) INNER JOIN studentinfo_tb s ON (r.RegNo = s.RegNo OR r.RegNo = s.JambNo) WHERE r.Lvl = $LevelID AND r.Sem = $SemID AND r.SesID = $SesID AND s.ProgID = $ProgID ORDER BY r.RegNo ASC, GroupID DESC
 if(!is_array($rst)){
     $pdf->Dump("Error Loading Result");
     // $pdf->_HTML();
      $pdf->Finish();
      exit;
 }
 
 //hold the seen stud result 
 $Seen = array();
 //Get all Semester Courses 
 $SemCourses = GetCourses($ProgID,$LevelID,$SemID,$SesID);
 $CoursesNow = $SemCourses['Current'];
 $OldCourses = $SemCourses['Old'];
 //get grading details
$grdstr = $dbo -> SelectFirstRow("resultinfo_tb","","ID = (select GrdStrucID from school_tb limit 1)");
$classPassStr = $grdstr['ClassOfPass'];
$problimit = (float)$grdstr['ProbationLimit'];
 $probflag = $grdstr['ProbationFlag'];
$withdrawflag = $grdstr['WithdrawFlag'];
          $grdstr = is_array($grdstr)?$grdstr[1]:"";
          $schgrdstr = GetGradeDetAll();
 $rstinfo = $rstinfo[0]->fetch_array();
 $yearofStudy = $rstinfo['YearOfStudy'];
 //$classPassStr = GetClassPassStruct();
 $classPassDetAll = GetClassPassDetAll();
 
    $firstRst = ((int)$LevelID < 2 && $SemID < 2)?true:false; //if level 1 fisrt sem
    $firstSecondRst = ((int)$LevelID < 2 && $SemID == 2)?true:false; //if level 1 second
    $totalSemCourse = 8; //get the total number of semester courses
    $Semspan = count($CoursesNow); //set default semster courses header span
    //added '|| ($LevelID < 2 && count($OldCourses) > 0)' to the condition (if also old course exist) 22-5-17 #3 - removed -  || ($LevelID < 2 && count($OldCourses) > 0)
     if((int)$LevelID > 1){  //if not level 1 add the col span for Repeat/Carryover result 
         $Semspan += 3;
     }
     $headerspan = $Semspan + 6;
     if(!$firstRst){
       $headerspan += 7;
     }
   
  $fnl = $LevelID > (int)$rstinfo['YearOfStudy']?" AND FINAL":"";
  $topdet = '<div style="width:100%;margin-top:10px">

        <div style="width:33.3%;float:left;text-align:left">
          <b>FACULTY:</b> '.$rstinfo['FacName'].' <br/>
          <b>DEPARTMENT:</b> '.$rstinfo['DeptName'].' <br />
          <b>PROGRAMME:</b> '.$rstinfo['ProgName'].'
        </div>

        <div style="width:33.3%;float:left;text-align:center;font-weight:bold;text-decoration:underline">
          RESULTS REPORTING SHEET
          <div style="margin-top:10px">'.$rstType.'</div>
        </div>

        <div style="width:33.3%;float:right;text-align:right">
        <b>YEAR OF STUDY:</b> '.$LevelID."/".$rstinfo['YearOfStudy'].' <br/>
        <b>SESSION:</b> '.$rstinfo['SesName'].' <br />
        <b>SEMESTER:</b> '.$rstinfo['Sem'].$fnl.'
      </div>
   <div style="clear:both"></div>
  </div> ';
  $pdf->Header("MAIN CAMPUS/OBIO AKPA CAMPUS",array("LogoSize"=>"80px*80px","Style"=>"font-size:0.9em","WaterMark"=>"Abbr"),null,$topdet,array("Address"));
   if($rst[1] < 1){
     $pdf->Dump("<div style=\"margin-top:50px;text-align:center\">No Result Found</div>");
     // $pdf->_HTML();
      $pdf->Finish();
      exit();
 }
 
 $pdf->HTML(); //start to write htmls
  ?>
  <table style="width:100%;text-align:center;margin-top:5px">
    <thead>
      <!--<tr style="text-align:left"><td style="text-align:left" colspan = "<?php echo $headerspan ?>">
           
      </td></tr>-->
     <tr>
       <th rowspan="4"> S/N </th>
       <th rowspan="4"> NAME/REG. NO. </th>
      <?php  if(!$firstRst){ ?>
       <th rowspan="4" class="Rotate90">CARRY OVER COURSES </th> 
       <th rowspan="4" class="Rotate90"> REPEAT COURSES </th>
      <?php  } ?>
       <th colspan="<?php echo $Semspan ?>"> <?php echo $rstinfo['Sem'] ?> SEMESTER RESULTS </th>
       <th rowspan="4" class="Rotate90"> TOTAL CREDIT HOURS </th>
       <th rowspan="4" class="Rotate90"> TOTAL GRADE POINTS </th>
       <th rowspan="4" class="Rotate90"> GRADE POINT AVERAGE </th>
       <?php  if(!$firstRst){ ?>
       <th rowspan="4" class="Rotate90"> B/F TOTAL CREDIT HOURS </th>
       <th rowspan="4" class="Rotate90"> B/F TOTAL GRADE POINTS </th>
       <th rowspan="4" class="Rotate90"> CUM. CREDIT HOURS </th>
       <th rowspan="4" class="Rotate90"> CUM. GRADE POINTS </th>
       <th rowspan="4" class="Rotate90"> CUM. GRADE POINT AVERAGE </th>
       <?php  } ?>
       <th rowspan="4"> REMARKS </th>
     </tr>
     <tr>
        <?php  if($LevelID > 1 ){?>
       <th colspan="3"> Repeat/Carry Over <br /> Courses </th>
       <?php  }elseif($LevelID < 2 && count($OldCourses) > 0){ //if the first year result and old courses exist, create the old courses column 22-5-17 #2 - not displayed
        ?>
        <!-- <th colspan="3"> Old Courses </th> -->
        <?php 
       } 
       $nowCHs = "";
       $scoreGrd = "";
       $prech = $LevelID < 2?"CH ":"";
        foreach($CoursesNow as $CID => $det){
            $nowCHs .= "<th>$prech".$det['CH']."</th>";
            $scoreGrd .= "<th>Score/<br />Grade</th>";
       ?>
       <th><?php  echo $det['CourseCode'] ?></th>
       <!-- <th>EDU 212</th>
       <th>EDU 212</th>
       <th>EDU 212</th>
       <th>EDU 212</th>
       <th>EDU 212</th>
       <th>EDU 212</th>
       <th>EDU 212</th> -->
       <?php
        }
       ?>
    </tr>
    <tr>
    <?php  if($LevelID > 1 ){
    ////added '|| ($LevelID < 2 && count($OldCourses) > 0)' to the condition (if also old course exist) 22-5-17 #4 - removed - || ($LevelID < 2 && count($OldCourses) > 0)
    ?>
      <th rowspan="2"> CH </th>
      <th rowspan="2"> Course<br />Code </th>
      <th>CH</th>
     <?php  } 
      echo $nowCHs;
     ?> 
      <!-- <th> 2 </th>
      <th> 2 </th>
      <th> 3 </th>
      <th> 2 </th>
      <th> 3 </th>
      <th> 3 </th>
      <th> 2 </th>
      <th> 2 </th> -->

    </tr>
    <tr>
    <?php  if($LevelID > 1 ){
    ////added '|| ($LevelID < 2 && count($OldCourses) > 0)' to the condition (if also old course exist) 22-5-17 #5 - removed || ($LevelID < 2 && count($OldCourses) > 0)
    ?>
      <th>Score/<br />Grade</th>
      <?php  }
       echo $scoreGrd;
       ?> 
      <!--<th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>
      <th>Score/<br />Grade</th>-->
      
    </tr>
    </thead>
    <tbody>
       <?php
       $counter = 1;
       $prevprobseen = array();
       $prevrstseen = array();
       $currstseen = array();
        while($indrst = $rst[0]->fetch_array()){
            //$semcourseArr = $CoursesNow;
           //if probation result sheet
           if($type == "2"){
              //check if last year result
              if((int)$indrst['Lvl'] == $LevelID - 1 && (int)$indrst['Sem'] = 2){
                if(in_array($indrst['RegNo'],$prevrstseen)){ //if prev year result seen
                  continue;
                }
                $prevrstseen[] = $indrst['RegNo'];
                //get the CCH and CGP
                $probCCH = (int)$indrst['CCH'];
                $probCGP = (int)$indrst['CGP'];
                $probCGPA = $probCCH > 0?number_format($probCGP/$probCCH,2):0.00;
                //check if in probation
                if($probCGPA < $problimit){
                  $prevprobseen[] = $indrst['RegNo']; //add to prev prob list
                }
              }else if((int)$indrst['Lvl'] == $LevelID && $SemID == (int)$indrst['Sem']){ //if current result
                 if(in_array($indrst['RegNo'],$currstseen)){ //if current year result seen
                  continue;
                }
                $currstseen[] = $indrst['RegNo'];
                 //check if not in probation year
                 if(!in_array($indrst['RegNo'],$prevprobseen)){
                   continue;
                 }
                 echo FormRow($indrst,"");
                  $counter++;
              }


           }else{//if main resultsheet or correction
            $RegNo = $indrst['RegNo'];
            if(in_array($RegNo,$Seen)){
              continue;
            }
            $Seen[] = $RegNo;
            $Rwdescr = "";
            //check if display is correction
            if($type == "1"){
              $Rwdescr = "CORRECTED ENTRIES";
              $ImmdLvl = $indrst['Lvl'];
              $ImmdSem = $indrst['Sem'];
              $ImmdSes = $indrst['SesID'];
              $GroupIDnw = (int)$indrst['GroupID'];
              //$ImmdSes = $indrst['SesID'];
             //get the immediate approve result 
             $rstb4 = $dbo->RunQuery("SELECT r.*, CONCAT(s.SurName,' ',s.FirstName,' ',s.OtherNames) as SName FROM result_tb r LEFT JOIN studentinfo_tb s ON (r.RegNo = s.RegNo OR r.RegNo = s.JambNo) WHERE r.Lvl = $ImmdLvl AND r.Sem = $ImmdSem AND r.SesID = $ImmdSes AND s.ProgID = $ProgID AND r.RegNo = '$RegNo' AND r.GroupID < $GroupIDnw ORDER BY r.GroupID DESC LIMIT 1");
             //echo "aa";
             if(is_array($rstb4)){
               if($rstb4[1] > 0){
                $imdrst = $rstb4[0]->fetch_array();
                echo FormRow($imdrst,"PREVIOUSLY APPROVED");
                $counter++;
               }
             }else{
               //echo "<tr><td colspan=\"16\">$rstb4</td></tr>";
             }
            }
            //record generation 
            echo FormRow($indrst,$Rwdescr);
             $counter++;
           }
          
   }
        if($counter < 2){
          echo "NO Result Found";
        }
         ?>
    </tbody>
  </table>
<?php
// print_r($_GET);
$pdf->_HTML();

/* $signataries = ' <div style="width:100%;margin-top:10px">
    <div style="width:33.3%;float:left">
       <div style="width:80%;margin:auto">
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div>
       </div>
      <div style="margin-top:3px;text-align:center;font-weight:bold">HEAD OF DEPARTMENT</div>
    </div>

    <div style="width:33.3%;float:left">
       
       <div style="width:80%;margin:auto">
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div>
       </div>
      <div style="margin-top:3px;text-align:center;font-weight:bold">DEAN, FACULTY OF '.$rstinfo['FacName'].'</div>
      
       <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin:auto;margin-top:15px;width:80%">Date: </div>
      <div style="margin-top:3px;text-align:center;font-weight:bold">SENATE APPROVAL</div>
    </div>

    <div style="width:33.3%;float:left">
       
       <div style="width:80%;margin:auto">
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div>
       </div>
       <div style="margin-top:2px;text-align:center;font-weight:bold">CHAIRMAN, SERVC</div>
    </div>
  </div>'; */
  //get the signatory from database
  $sigarr = ["HEAD OF DEPARTMENT","DEAN","CHAIRMAN, SERVC"];
if(isset($ReportID)){
  //check if already signed
  //StudyID=5&ProgID=23&LevelID=1&SemID=1&SesID=8&ReportID=2
  $sigparam = $dbo->DataString(json_decode($sigparam,true));
  $sigs = $dbo->SelectFirstRow("reportsig_tb","","Param='".$sigparam."'");
if(!is_array($sigs))$sigs = $dbo->SelectFirstRow("report_tb","","ID=".$ReportID);
   if(is_array($sigs)){
    $sigarr = $sigs['Signatories'];
   }
}
//$pdf->Dump($sigarr);
//$pdf->Finish();
  $pdf->FooterNote("ERRS ( ".$rstinfo['ProgName']." | ".$rstinfo['SesName']." | ".$LevelID."/".$rstinfo['YearOfStudy']." | ".$rstinfo['Sem']." )",$pdf->Signataries($sigarr,"font-size:1.2em"),array("Developer"));
  //["HEAD OF DEPARTMENT"=>["Signature"=>"","Name"=>"","Date"=>""],"DEAN"=>["Signature"=>"","Name"=>"","Date"=>"","SENATE APPROVAL"=>["Date"=>""]],"CHAIRMAN, SERVC"=>["Signature"=>"","Name"=>"","Date"=>""]]
  //$LevelID."/".$rstinfo['YearOfStudy']
//$pdf->FooterNote("ERRS ( ".$rstinfo['ProgName']." | ".$rstinfo['SesName']." | ".$LevelID."/".$rstinfo['YearOfStudy']." | ".$rstinfo['Sem']." )",$signataries,array("Developer"));

$pdf->Finish();
//$pdf->WriteHTML();
?>