<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
/* require_once($baseurl."epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
LoadFile("pdfprint",$baseurl); */
$subDir = urldecode($_REQUEST['SubDir']);
$configdir = "../../../../../".$subDir;
require_once("../../../general/config.php");
require("../../../general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
//UID=8&limit=128&val=&filter=0
//Get the results infos 
$UID = $_REQUEST['UID'];
$limit = $_REQUEST['limit'];
$val = $dbo->SqlSafe($_REQUEST['val']);
         $deptCond = "(ra.ProgID > 0)";
         $staffDet = $dbo->SelectFirstRow("staff_tb","","UserID=$UID");
          if(isset($staffDet)){
            $Depts = trim($staffDet['DeptIDs']);
            if($Depts != ""){
              $deptCond = "(ra.ProgID = ".str_replace("~"," OR ra.ProgID = ",$Depts).")";
            }
          }
          //f.FacName,d.DeptName,p.ProgName
          if(trim($val) != ""){
              $deptCond .= " AND ((c.CourseCode LIKE '%$val%' OR c.Title LIKE '%$val%' OR l.Name LIKE '%$val%' OR se.Sem LIKE '%$val%' OR s.SesName LIKE '%$val%' OR st.Name LIKE '%$val%' OR f.FacName LIKE '%$val%' OR d.DeptName LIKE '%$val%' OR p.ProgName LIKE '%$val%' OR ra.ID LIKE '$val')";
              //if has space
          $valarr = explode(" ",$val);
          if(count($valarr) > 1){
            $deptCond .= " OR (";
            foreach($valarr as $indval){
              $deptCond .= " ( c.CourseCode LIKE '%$indval%' OR c.Title LIKE '%$indval%' OR l.Name LIKE '%$indval%' OR se.Sem LIKE '%$indval%' OR s.SesName LIKE '%$indval%' OR st.Name LIKE '%$indval%' OR f.FacName LIKE '%$indval%' OR d.DeptName LIKE '%$indval%' OR p.ProgName LIKE '%$indval%' OR ra.ID LIKE '$indval') AND";  
            }
            $deptCond = rtrim($deptCond,"AND");
            $deptCond .= " )";
          }
         //exit($deptCond);
          $deptCond .=")";
          }

          
         // $limit = round((0.0816 * (5000 - 100)) + 100);
          //print_r($_POST);
          $filterArr = array("ALL","APPROVED","UNAPPROVED");
          $filter = $_REQUEST['filter'];
         $filterCond = "";
	 if($filter == 1){
       //approved only 
	   $filterCond = "AND ra.Status='TRUE'";
	 }else if($filter == 2){
		$filterCond = "AND ra.Status='FALSE'"; 
	 }
         // $dump = array();
          //get the result info 
          $rstinfos = $dbo->Select("resultapprove_tb ra, fac_tb f, dept_tb d, programme_tb p, course_tb c, session_tb s, study_tb st, schoollevel_tb l,semester_tb se","ra.*,f.FacID,d.DeptID,s.SesName,st.Name as StudyName,f.FacName,d.DeptName,p.ProgName,l.Name as LvlName,se.Sem as Semester, CONCAT(c.Title,' (',c.CourseCode,')') as CourseName, ra.ID as RSID",$deptCond." AND f.FacID = d.FacID AND d.DeptID = p.DeptID AND p.ProgID = ra.ProgID AND ra.CourseID = c.CourseID AND ra.Ses = s.SesID AND st.ID = ra.StudyID AND st.SchoolType = (Select Type from school_tb limit 1) AND l.Level = ra.Lvl AND l.SchoolTypeID = st.SchoolType AND l.StudyID = st.ID AND ((se.Num > 0 && se.Num=ra.Sem) || se.ID = ra.Sem) $filterCond ORDER BY ra.ID DESC LIMIT $limit");
		 $UserName = @$staffDet['StaffName'];
$PrintDate = date("d/M/Y");
$PrintTime = date("h:i A");
$quryva = @$_REQUEST['val'];
$totalrst = 0;
$html = "NO RESULT FOUND";
//form table 

          if(is_array($rstinfos)){
              $totalrst = $rstinfos[1];
            if($rstinfos[1] > 0){
              $header=array("SN","SESSION","STUDY TYPE","FACULTY","DEPARTMENT","PROGRAMME","LEVEL","SEMESTER","COURSE","RSID","APPROVED");
                $html = "<table><thead><tr>";
                //form the header 
                foreach($header as $head){
                $html .= "<th>$head</th>";
                }
                $html .= "</tr></thead>";
                $appr = 0;
                $nappr = 0;
                $cnt = 1;
              while($rstinfo = $rstinfos[0]->fetch_array()){
                $rstinfo['Status'] = $rstinfo['Status'] == "TRUE"?1:0;
				$fieldarr = array("SesName","StudyName","FacName","DeptName","ProgName","LvlName","Semester","CourseName","RSID","Status");
				$html .= "<tr><td>$cnt</td>";
                foreach($fieldarr as $fname){
                    $cont = strtoupper($rstinfo[$fname]);
                    if($fname == "Status"){
                        if((int)$cont == 1){
                            $cont = "<strong>APPROVED</strong>";
                            $appr++;
                        }else{
                            $cont = "NOT APPROVED";
                            $nappr++;
                        }
                    }
                $html .= "<td>$cont</td>";
                }
                $html .= "</tr>";
                $cnt++;
				/*foreach($fieldarr as $fieldName){
					$searchval = strtolower($searchval);
					$strdis = strtolower($rstinfo[$fieldName]); 
					$rw[] = str_replace($searchval,'<strong class="altColor">'.$searchval.'</strong>',$strdis);
				}*/
				//$rw[] =  $status;
				/*$rw["logo"] =  "*print";
				$rw["info"] =  "View/Print";
				$rw["Action"] =  "Exams.Approval.View('rstudstudy=".$rstinfo['StudyID']."&rstudfac=".$rstinfo['FacID']."&rstuddept=".$rstinfo['DeptID']."&rstudprog=".$rstinfo['ProgID']."&rstudlvl=".$rstinfo['Lvl']."&semest=".$rstinfo['Sem']."&sestb=".$rstinfo['Ses']."&rcourse=".$rstinfo['CourseID']."')";
                //$dump[] = array($rstinfo['SesName'],$rstinfo['StudyName'],$rstinfo['FacName'],$rstinfo['DeptName'],$rstinfo['ProgName'],$rstinfo['LvlName'],$rstinfo['Semester'],$rstinfo['CourseName'],$rstinfo['RSID'],$status,"logo"=>"*eye","info"=>"View/Print","Action"=>"Exams.Approval.View('rstudstudy=".$rstinfo['StudyID']."&rstudfac=".$rstinfo['FacID']."&rstuddept=".$rstinfo['DeptID']."&rstudprog=".$rstinfo['ProgID']."&rstudlvl=".$rstinfo['Lvl']."&semest=".$rstinfo['Sem']."&sestb=".$rstinfo['Ses']."&rcourse=".$rstinfo['CourseID']."')");
				$dump[] = $rw;*/
              }
              $html .= "</table>";
            }
          }

//########################

//$UID = $_REQUEST['UID'];
//Get the User Details
//$UserDet = $dbo->SelectFirstRow("user_tb","","UserID=".$UID);
/*$UserName = @$staffDet['StaffName'];
$PrintDate = date("d/M/Y");
$PrintTime = date("h:i A");
$quryva = @$_REQUEST['val'];
$totalrst = (int)$_REQUEST['MaxDataRow'];
//form table 
$header=array("SN","SESSION","STUDY TYPE","FACULTY","DEPARTMENT","PROGRAMME","LEVEL","SEMESTER","COURSE","RSID","APPROVED");
$html = "<table><thead><tr>";
 //form the header 
 foreach($header as $head){
   $html .= "<th>$head</th>";
 }
 $html .= "</tr></thead>";
 $appr = 0;
 $nappr = 0;
for($s=1; $s<=$totalrst; $s++){
    $html .= "<tr><td>$s</td>";
    for($d=1;$d<=10;$d++){
        $cont = strtoupper($_REQUEST[$s."_".$d]);
        if($d == 10){
            if((int)$cont == 1){
                $cont = "<strong>APPROVED</strong>";
                $appr++;
            }else{
                $cont = "NOT APPROVED";
                $nappr++;
            }
        }
       $html .= "<td>$cont</td>";
    }
    $html .= "</tr>";
}
$html .= "</table>";*/
$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Banner("Result Approval Report",array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));
$pdf->FooterNote("Result Approval Report",$pdf->Signataries(array("HOD","DEAN")));
$pdf->Panel();
$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("DETAILS");
        $pdf->Info("Staff Name:",$UserName);
        $pdf->Info("Date:",$PrintDate);
        $pdf->Info("Time:",$PrintTime);
$pdf->_InfoBox();
$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("STATICTICS");
       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("Total Record:",$totalrst);
        $pdf->Info("Approved:",$appr);
        $pdf->Info("Unapproved:",$nappr);
$pdf->_InfoBox();
$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("CRITERIA");
       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("Search:",$val);
        $pdf->Info("Filter:",$filterArr[(int)$filter]);
        $pdf->Info("Max-Record:",$limit);
$pdf->_InfoBox();
$pdf->_Panel();
$pdf->Dump($html);
$pdf->HTML();
/*echo '
<div style="width:95%; margin:auto;margin-top:100px;">
<div style="width:200px;float:left;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">HOD</div>
<div style="width:200px;float:right;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">Staff/User</div>
</div>';*/

$pdf->_HTML();
$pdf->Finish();

?>