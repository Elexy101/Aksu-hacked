<?php
ini_set("memory_limit","-1");
if(!isset($baseurl)){
    $baseurl = "../../../";
$configdir = "../../../../../".urldecode($_REQUEST['SubDir']);
require_once($baseurl."general/config.php");
require($baseurl."general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
$pdf = new PDFPrinter();

$pdf->SetBasePath($configdir."Files/");
$pdf->FooterNote("OFFLINE PAYMENT",$pdf->Signataries(array("STAFF","BURSAR")));
$Waterm = "Abbr";
}


//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Banner("OFFLINE PAYMENT REQUEST",array("LogoSize"=>"80*80","WaterMark"=>$Waterm));

if(!isset($_REQUEST['OrderID']) && !isset($OrderID)){
    $html = "INVALID PARAMETER";
    $pdf->Dump($html);
    $pdf->Finish();
}

$OrderID = isset($_REQUEST['OrderID'])?$_REQUEST['OrderID']:$OrderID;

//get the order details
$OrderDet = $dbo->SelectFirstRow("order_tb od, item_tb it","od.*,it.ItemName","od.ID=".$OrderID." AND od.ItemID = it.ID");
if(!is_array($OrderDet)){
    $html = "INVALID OFFLINE PAYMENT REQUEST";
    $pdf->Dump($html);
    $pdf->Finish();
}

$PayeeName = "Unknown";
$payeePhone = "";
$LevelName = "";
$Policy = "";
//get the student/payee details
$payeedet = GetBasicInfo($OrderDet['RegNo'], "", "a");
if(!is_array($payeedet)){ //if not exist as student or candidate
  //check payee_tb
  $payeedet = $dbo->SelectFirstRow("payee_tb","","PayeeID='".$OrderDet['RegNo']."'");
  if(is_array($payeedet)){
    $PayeeName = $payeedet['Name'];
  }
}else{ ///if a student or candidate
    $PayeeName = $payeedet['Name'];
    $payeePhone = $payeedet['Phone'];
    $LevelName = LevelName($OrderDet['Lvl'], $payeedet['StudyID']);
    $semarr = [1=>"FIRST","SECOND","FULL"];
    $sempartarr = [1=>"PART","COMPLETE","FULL"];
    $Policy = (int)$OrderDet['Sem'] > 2?"FULL":$semarr[(int)$OrderDet['Sem']]."(".$sempartarr[(int)$OrderDet['SemPart']].")";
}




//request Date
$Requestdate = "";
if(!is_null($OrderDet['RequestDate'])){
 $rd = new DateTime($OrderDet['RequestDate']);
 $Requestdate = $rd->format("d/m/Y");
}


//get the initializing user details
$InitDet = $dbo->SelectFirstRow("user_tb","UserName,UserLogName","UserID=".$OrderDet['UserID']);
$UserName = is_array($InitDet)?$InitDet['UserName']:"";
$UserName = trim($UserName) == ""?$Requestdate:$Requestdate == ""?$UserName:$UserName."-".$Requestdate;
//$UserEmail = is_array($InitDet)?$InitDet['UserLogName']:"";

//approval details
$ApproveName = "NOT YET APPROVED";
if((int)$OrderDet['Paid'] == 1){
    //get the approve username
    $ApprvDet = $dbo->SelectFirstRow("payhistory_tb p, user_tb u","p.ApproveUserID,u.UserName,p.ApproveDate","p.TransID='{$OrderDet['TransNum']}' AND p.itemNum='{$OrderDet['ItemNo']}' AND p.PayID={$OrderDet['ItemID']} AND p.ApproveUserID = u.UserID");
    if(is_array($ApprvDet)){
        $ApproveName = $ApprvDet['UserName'];
        $Approvedate = "";
        if(!is_null($ApprvDet['ApproveDate'])){
         $ad = new DateTime($ApprvDet['ApproveDate']);
         $Approvedate = $ad->format("d/m/Y");
         $ApproveName = trim($ApproveName) == ""?$Approvedate:$Approvedate == ""?$ApproveName:$ApproveName."-".$Approvedate;
        }
    }
}

//form the reciept filename
$fn = $configdir."Files/Payment/Receipt/".str_replace("/","_",$OrderDet['RegNo'])."_".$OrderDet['ItemID']."_".$OrderDet['Lvl']."_".$OrderDet['Sem']."-".$OrderDet['SemPart'].".jpg";
if(file_exists($fn)){
    $html = '<div style="text-align:center"><img src="'.$fn.'" style="height:80%;margin-top:20px;" /></div>';
    
}else{
    $html = "OFFLINE PAYMENT REQUEST RECEIPT NOT FOUND";
    //$pdf->Dump($html);
    //$pdf->Finish();
}


$pdf->Panel();
$pdf->InfoBox(2,"margin-left:1.5%");
    $pdf->InfoTitle("PAYEE DETAILS");
        $pdf->Info("NAME:",$PayeeName);
        $pdf->Info("REG. NO.:",$OrderDet['RegNo']);
        $pdf->Info("PHONE",$payeePhone);
        $pdf->InfoTitle("REQUEST DETAILS");
       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("REQUEST:",$UserName);
        $pdf->Info("APPROVED:",$ApproveName);
        $dt = new DateTime($OrderDet['RegDate']);
        $pdf->Info("DATE:",$dt->format("d/m/Y"));
$pdf->_InfoBox();
$pdf->InfoBox(2,"margin-left:1.5%");
    $pdf->InfoTitle("PAYMENT DETAILS");
    
    // $arrRec = ($from != "" && $to != "")?date("j-M-Y",mktime(0,0,0,$fromarr[1],$fromarr[2],$fromarr[0]))." - ".date("j-M-Y",mktime(0,0,0,$toarr[1],$toarr
   // [2],$toarr[0])):"";

       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("TYPE:",$OrderDet['ItemName']);
        $pdf->Info("LEVEL/POLICY:",$LevelName."/".$Policy);
        $pdf->Info("AMOUNT:",number_format($OrderDet['Amt'],2));
        if(!is_null($OrderDet['ReceiptNum']) && trim($OrderDet['ReceiptNum']) != "")$pdf->Info("RECEIPT NUMBER:",$OrderDet['ReceiptNum']);
        if(!is_null($OrderDet['ReceiptBank']) && trim($OrderDet['ReceiptBank']) != "")$pdf->Info("RECEIPT BANK:",$OrderDet['ReceiptBank']);
        if(!is_null($OrderDet['ReceiptBranch']) && trim($OrderDet['ReceiptBranch']) != "")$pdf->Info("RECEIPT BRANCH:",$OrderDet['ReceiptBranch']);
        if(!is_null($OrderDet['ReceiptDate']) && trim($OrderDet['ReceiptDate']) != "")$pdf->Info("RECEIPT DATE:",MysqlDateDecode($OrderDet['ReceiptDate']));
$pdf->_InfoBox();
/* $pdf->InfoBox(1.33,"margin-left:1.5%");
    
$pdf->_InfoBox(); */
$pdf->_Panel();
$pdf->Dump($html);
$pdf->HTML();
/*echo '
<div style="width:95%; margin:auto;margin-top:100px;">
<div style="width:200px;float:left;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">HOD</div>
<div style="width:200px;float:right;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">Staff/User</div>
</div>';*/

$pdf->_HTML();
$pdf->Finish();


?>