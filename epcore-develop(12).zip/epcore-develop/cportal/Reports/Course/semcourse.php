<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
$configdir = "../../../../../".urldecode($_REQUEST['SubDir']);
require_once($baseurl."general/config.php");
require($baseurl."general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
//LoadFile("pdfprint",$baseurl);
//cstudy=2&coursefac=5&coursedept=48&courseprog=49&courselvl=1&coursesemest=1
$dataobj = json_decode($_REQUEST['cdet'],true);
//$cstudy = $dataobj['cstudy'];
$courseprog = $dataobj['courseprog'];$coursesemest = $dataobj['coursesemest'];$courselvl = $dataobj['courselvl'];
$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Banner("SEMESTER COURSES",array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));
//get course details
$coursdet = $dbo->SelectFirstRow("fac_tb f, dept_tb d, programme_tb p, schoollevel_tb l, study_tb s, semester_tb sm","f.FacName, s.Name as SName,p.ProgName, l.Name as LName, sm.Sem","d.FacID = f.FacID AND p.DeptID = d.DeptID AND l.Level = $courselvl AND l.StudyID = s.ID AND s.ID = f.StudyID AND p.ProgID = $courseprog AND f.StudyID = s.ID AND ((sm.Num > 0 && sm.Num=$coursesemest) || sm.ID = $coursesemest) LIMIT 1");
if(!is_array($coursdet)){
  $pdf->Dump("INVALID PARAMETER ".$_REQUEST['cdet']);
  $pdf->Finish();
  exit;
}

//get course settings
$allset = COURSE();

$semcourses = $dbo->Select("course_tb","","DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest");
//$semcourses = $dbo->Select("course_tb","","DeptID=$courseprog AND Lvl=$courselvl AND Sem=$coursesemest AND StudyID=$cstudy");
         if(!is_array($semcourses)){
            $pdf->Dump("INTERNAL ERROR","Loading Semester Courses Failed");
            $pdf->Finish();
            exit;
         }
         if($semcourses[1] > 0){
             $html = '<table>
             <thead>
              <tr><th>S/N</th><th>COURSE CODE</th><th>TITLE</th><th>CH</th><th>START</th><th>END</th><th>STATUS</th><th>ELECTIVE GROUP</th><th>GROUP</th><th>CID</th></tr>
             </thead>';
             $cnt = 1;
            //form all courses dump file
            while($indcourse = $semcourses[0]->fetch_array()){
                //condition for gettin session
                //$sescond = $indcourse['StartSesID'] == 0?"1=1 ORDER BY SesID LIMIT 1":"SesID=".$indcourse['StartSesID'];
                $cgroup = $dbo->SelectFirstRow("coursegroup_tb","Descr","ID=".$indcourse['GroupID']);
                $StartSes = $indcourse['StartSesID'] == 0?'MIN SESSION':'';
                $EndSes = $indcourse['EndSesID'] == 0?'MAX SESSION':'';
                if($indcourse['StartSesID'] > 0 || $indcourse['EndSesID'] > 0){
                    //get start session
                $sesArr = $dbo->Select("session_tb");
                if(is_array($sesArr) && $sesArr[1] > 0){
                    while($ses = $sesArr[0]->fetch_assoc()){
                       if($EndSes != '' && $StartSes != '')break;
                       if($indcourse['StartSesID'] == $ses['SesID']){
                        $StartSes = $ses['SesName'];
                       }
                       if($indcourse['EndSesID'] == $ses['SesID']){
                        $EndSes = $ses['SesName'];
                       }
                    }
                }
                }

                //elective group
                $electgrp = $indcourse['Elective'];
                $electgroup = array(1=>"ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE","TEN");
                $datastr = ["COMPULSARY","NONE OR ABOVE"];
                for($i=1;$i<=(int)$allset['MaxElectiveGrp'];$i++){
                    $datastr[$i+1] = $electgroup[$i]." ONLY";
                  }
                $elctivegrptxt = $datastr[$indcourse['Elective']];
                $status = (int)$indcourse['CourseStatus'] == 0?"ENABLED":"DISABLED";
                $html .= '<tr><td>'.$cnt.'</td><td>'.strtoupper($indcourse['CourseCode']).'</td><td>'.strtoupper($indcourse['Title']).'</td><td>'.$indcourse['CH'].'</td><td>'.$StartSes.'</td><td>'.$EndSes.'</td><td>'.$status.'</td><td>'.$elctivegrptxt.'</td><td>'.strtoupper($cgroup['Descr']).'</td><td>'.$indcourse['CourseID'].'</td></tr>';
                $cnt++;
            }
            $html .= '</table>';
        }else{
            $pdf->Dump("EMPTY SET","No Course Found");
            $pdf->Finish();
            exit;  
        }

$pdf->FooterNote("SEMESTER COURSES",$pdf->Signataries(array("HOD","DEAN")));
$pdf->Panel();
$pdf->InfoBox(2,"margin-left:1.5%");
    $pdf->InfoTitle("SCHOOL");
        $pdf->Info("STUDY:",$coursdet['SName']);
        $pdf->Info("FACULTY/SCHOOL:",$coursdet['FacName']);
        $pdf->Info("DEPARTMENT:",$coursdet['ProgName']);
$pdf->_InfoBox();
$pdf->InfoBox(2,"margin-left:1.5%");
    $pdf->InfoTitle("COURSE");
    
    // $arrRec = ($from != "" && $to != "")?date("j-M-Y",mktime(0,0,0,$fromarr[1],$fromarr[2],$fromarr[0]))." - ".date("j-M-Y",mktime(0,0,0,$toarr[1],$toarr
   // [2],$toarr[0])):"";

       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("LEVEL:",$coursdet['LName']);
        $pdf->Info("SEMESTER:",$coursdet['Sem']);
        $pdf->Info("RECORDS:",$semcourses[1]);
$pdf->_InfoBox();


$pdf->_Panel();
$pdf->Dump($html);
$pdf->Finish();
?>