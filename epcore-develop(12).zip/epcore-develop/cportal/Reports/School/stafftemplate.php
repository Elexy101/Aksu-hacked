<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
$configdir = "../../../../../".urldecode($_REQUEST['SubDir']);
require_once($baseurl."general/config.php");
require($baseurl."general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";

$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Header("STAFF DETAILS TEMPLATE",array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));
$pdf->FooterNote("STAFF DETAILS TEMPLATE");

$pdf->Panel();
$pdf->InfoBox(2.5);
  $pdf->InfoTitle("BAISIC INFO");
  $pdf->Info("FULL NAME:","");
  $pdf->Info("DATE OF BIRTH:","");
  $pdf->Info("STATE:","");
  $pdf->Info("LGA:","");
  $pdf->Info("NATIONALITY:","");
  $pdf->Info("EMAIL:","");
  $pdf->Info("PHONE NUMBER:","");
  $pdf->Info("EMERGENCY NUMBER:","");
  $pdf->Info("ADDRESS:","");
$pdf->_InfoBox();
//passport
$pdf->InfoBox(1.5);
$pdf->InfoTitle("PASSPORT");
$pdf->Dump("<div style=\"margin:auto;margin-top:0px;margin-bottom:5px;width:180px;height:180px\">");
 //$pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($schdet['logo'])),"width:100%;height:100%;text-align:center");
 $pdf->Dump("</div>");
$pdf->_InfoBox();

$pdf->_Panel();

$pdf->Panel();
$pdf->InfoBox(2.5);
$pdf->InfoTitle("SCHOOL DETAILS");
$pdf->Info("POSITION:","");
$pdf->Info("STAFF NUMBER:","");
$pdf->Info("UNIT/DEPARTMENT:","");
$pdf->Info("QUALIFICATION:","");
$pdf->Info("ALLOW RESULT UPLOAD:","");
$pdf->_InfoBox();

$pdf->InfoBox(1.5);
$pdf->InfoTitle("SIGNATURE");
$pdf->Dump("<div style=\"margin:auto;margin-top:0px;margin-bottom:5px;width:180px;height:180px\">");
 //$pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($schdet['logo'])),"width:100%;height:100%;text-align:center");
 $pdf->Dump("</div>");
$pdf->_InfoBox();


$pdf->_Panel();

$pdf->Panel();
$pdf->InfoBox(1.5);
$pdf->InfoTitle("STAFF DEPARTMENT(S)");
$pdf->Table("");
$pdf->TableHead(["Programme/Department"]);
for($s=0;$s<6;$s++){
    $pdf->TableRow(["&nbsp;"]);
}

$pdf->_Table();
$pdf->_InfoBox();
$pdf->InfoBox(2.5);
$pdf->InfoTitle("COURSES");
$pdf->Table("");
$pdf->TableHead(["Prog./Dept.","Level","Semester","Assign Course"]);
for($s=0;$s<12;$s++){
    $pdf->TableRow(["&nbsp;","&nbsp;","&nbsp;","&nbsp;"]);
}
$pdf->_Table();
$pdf->_InfoBox();
$pdf->_Panel();
$pdf->Finish();
?>