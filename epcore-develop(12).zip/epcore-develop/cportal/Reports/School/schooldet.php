<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
$configdir = "../../../../../".urldecode($_REQUEST['SubDir']);
require_once($baseurl."general/config.php");
require($baseurl."general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
//get the school details
$schdet = $dbo->SelectFirstRow("school_tb sc, schooltype_tb st","sc.Name, sc.ShortAddr, sc.LongAddr, sc.logo, sc.Phone, sc.Abbr, sc.Type, sc.description, sc.email, sc.LevelLoad, sc.ExtraYearPrefix, sc.MaxExtraYear, st.SchoolType","sc.Type = st.ID");
$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Header("SCHOOL DETAILS",array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));

$pdf->Panel();
$pdf->InfoBox(2.5);
  $pdf->InfoTitle("DETAILS");
  $pdf->Info("SCHOOL NAME:",strtoupper(@$schdet['Name']));
  $pdf->Info("ABBREVIATION:",strtoupper(@$schdet['Abbr']));
  $pdf->Info("SCHOOL TYPE:",strtoupper(@$schdet['SchoolType']));
  $pdf->Info("DESCRIPTION:",$schdet['description']);
  $pdf->Info("SHORT ADDRESS:",$schdet['ShortAddr']);
  $pdf->Info("LONG ADDRESS:",$schdet['LongAddr']);
  $pdf->Info("OFFICIAL EMAIL:",$schdet['email']);
  $pdf->Info("OFFICIAL PHONE:",$schdet['Phone']);
  $pdf->Info("AUTO LOAD LEVEL:",$schdet['LevelLoad'] == 'AUTO'?'ENABLED':'DISABLED');
  $pdf->Info("EXTRA YEAR PREFIX:",$schdet['ExtraYearPrefix']);
  $pdf->Info("MAXIMUM EXTRA YEAR:",$schdet['MaxExtraYear']);
$pdf->_InfoBox();
//passport
$pdf->InfoBox(1.5);
$pdf->InfoTitle("SCHOOL LOGO");
$pdf->Dump("<div style=\"margin:auto;margin-top:0px;margin-bottom:5px;width:180px;height:180px\">");
 $pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($schdet['logo'])),"width:100%;height:100%;text-align:center");
 $pdf->Dump("</div>");
$pdf->_InfoBox();

$pdf->_Panel();
$pdf->Finish();
?>