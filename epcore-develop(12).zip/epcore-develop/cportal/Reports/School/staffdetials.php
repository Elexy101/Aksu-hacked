<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
$configdir = "../../../../../".urldecode($_REQUEST['SubDir']);
require_once($baseurl."general/config.php");
require($baseurl."general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
//get the school details
function WriteDepts(){
  global $pdf;
  global $StaffDetInd;
  global $dbo;
  $pdf->InfoTitle("ASIGNED DEPARTMENT");
           $deptids = trim($StaffDetInd['DeptIDs']);
            if($deptids == ""){
              $pdf->Info("Department:","ALL");
            }else{
            
               $cond = str_replace("~"," OR p.ProgID=",$deptids);
              $rec = $dbo->Select("fac_tb f, dept_tb d, programme_tb p","f.FacName,d.DeptName,p.ProgName","f.FacID = d.FacID AND d.DeptID = p.DeptID AND (p.ProgID=".$cond.")");
              if(is_array($rec)){
                if($rec[1] > 0){
                    $pdf->Table("margin-top:5px;margin-bottom:5px");
                    $pdf->TableHead(array("Faculty","Department","Programme"));
                    while($recdet = $rec[0]->fetch_array()){
                      $pdf->TableRow(array($recdet[0],$recdet[1],$recdet[2]));
                    }
                    $pdf->_Table();
                }
              }
              
            }
}

function WriteCourses(){
  global $pdf;
  global $StaffDetInd;
  global $dbo;
  $pdf->InfoTitle("ASIGNED COURSES");
  $deptids = trim($StaffDetInd['Courses']);
            if($deptids == ""){
              $pdf->Info("Courses:","ALL");
            }else{
            
              $cond = str_replace("~"," OR c.CourseID=",$deptids);
              $rec = $dbo->Select("course_tb c, programme_tb p","CONCAT(c.Title,' (',c.CourseCode,')') as Course,p.ProgName","c.DeptID = p.ProgID AND (c.CourseID=".$cond.')');
              if(is_array($rec)){
                if($rec[1] > 0){
                    $pdf->Table("margin-top:5px;margin-bottom:5px");
                    $pdf->TableHead(array("Course","Programme"));
                    while($recdet = $rec[0]->fetch_array()){
                      $pdf->TableRow(array($recdet[0],$recdet[1]));
                    }
                    $pdf->_Table();
                }
              }else{
                $pdf->Dump($rec);
              }
              
            }
}
$SID = $_REQUEST['SID'];
$cond = (int)$SID > 0?"st.StaffID = $SID":"1=1";

//Get the User Details
$StaffDet = $dbo->RunQuery("SELECT st.*, s.StateName, l.LGAName, u.Privs FROM staff_tb st LEFT JOIN user_tb u ON u.UserID = st.UserID LEFT JOIN state_tb s ON st.StateID = s.StateID LEFT JOIN lga_tb l ON (l.StateID = s.StateID AND l.LGAID = st.LGAID) WHERE $cond ORDER BY st.StaffID");
$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Header("STAFF DETAILS",array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));
$pdf->FooterNote("STAFF DETAILS");
//$pdf->Dump($StaffDet);
if(is_array($StaffDet)){
  
    
    if($StaffDet[1] > 0){
        //"StaffID","StaffName","DOB","LGAID","StateID","EduQual","StaffType","Phone","Rank","Email","Nat","Addrs","Emergency","Passport","UserID","StaffUnit","StaffSchID","Courses","DeptIDs"
        $cnt = 1;
        while($StaffDetInd = $StaffDet[0]->fetch_array()){
         
          $pdf->Panel();
           $pdf->InfoBox(0.5,"margin-left:0.75%");
          // $pdf->Info("a",$StaffDetInd['StaffID']);
          $fileex = "";
          foreach (["jpg","jpeg","png","gif","bmp"] as $ext) {
             if(!file_exists($configdir."Files/UserImages/".$StaffDetInd['UserID'].".".$ext))continue;
             $fileex = $configdir."Files/UserImages/".$StaffDetInd['UserID'].".".$ext;break;
          }


          if($fileex == ""){
            $fileex = "../../../images/App/Images/userbig.jpg";
          }

           
            $pdf->Image($fileex,"width:100%;display:block");
            
           $pdf->_InfoBox();
           $pdf->InfoBox(1.75,"margin-left:0.75%");
            $pdf->InfoTitle("BASIC");
            $pdf->Info("Name:",$StaffDetInd['StaffName']);
            $dob = $StaffDetInd['DOB'];
            $da = new DateTime($dob);
            $dob = $da->format("d, M Y");
            $pdf->Info("DOB:",$dob);
            $pdf->Info("State:",$StaffDetInd['StateName']);
            $pdf->Info("LGA:",$StaffDetInd['LGAName']);
            $pdf->Info("Nationality:",$StaffDetInd['Nat']);
            $pdf->InfoTitle("CONTACT");
            $pdf->Info("Email:",$StaffDetInd['Email']);
            $pdf->Info("Phone:",$StaffDetInd['Phone']);
            $pdf->Info("Emergency:",$StaffDetInd['Emergency']);
            $pdf->Info("Address:",$StaffDetInd['Addrs']);
             $pdf->InfoTitle("SCHOOL");
        $pdf->Info("Position:",$StaffDetInd['Rank']);
        $pdf->Info("Staff ID:",$StaffDetInd['StaffSchID']);
        $pdf->Info("Unit:",$StaffDetInd['StaffUnit']);
        $pdf->Info("Qualification:",$StaffDetInd['EduQual']);/**/
        $priv = $StaffDetInd['Privs'];
        $alow = "NOT ALLOWED";
        if(trim($priv) != ""){
          $privarr = explode(":",$priv);
          if(in_array("RUpload",$privarr)){
            $alow = "ALLOWED";
          }
        }
        $pdf->Info("Result Upload:",$alow);/**/
        $courses = trim($StaffDetInd['Courses']);
       
        if($courses != "" && count(explode("~",$courses)) > 7){
          WriteDepts();
        }
           $pdf->_InfoBox();
         
         $pdf->InfoBox(1.75,"margin-left:0.75%");
            WriteCourses();
             $courses = trim($StaffDetInd['Courses']);
            if($courses == "" || count(explode("~",$courses)) <= 7){
              WriteDepts();
            }
           $pdf->_InfoBox();

      
          $pdf->_Panel();
           if($cnt % 2 == 0){
            $pdf->Dump('<div style="page-break-after: always"></div>');
          }
          $cnt++;
        }
    }
}

$pdf->Finish();
 /* $pdf->InfoBox(1.5);
        $pdf->InfoTitle("SCHOOL");
        $pdf->Info("Position:",$StaffDetInd['Rank']);
        $pdf->Info("Staff ID:",$StaffDetInd['StaffSchID']);
        $pdf->Info("Unit:",$StaffDetInd['StaffUnit']);
        $pdf->Info("Qualification:",$StaffDetInd['EduQual']);
        $pdf->_InfoBox();*/
?>