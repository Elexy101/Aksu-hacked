<?php
ini_set("memory_limit","-1");
$baseurl = "../../../";
$subDir = $_REQUEST['SubDir'];
$configdir = "../../../../../".$subDir;
require_once("../../../general/config.php");
require("../../../general/getinfo.php");
require_once "../../../general/TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../general/TaquaLB/Elements/Script/pdf.php";
function ToMySQLDate($date){
    $montharr = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
    $dtarr = explode("-",$date);
    if(count($dtarr) == 3){ //if valid
      $dtarr[1] = (int)array_search(strtolower($dtarr[1]),$montharr)+1;
      return $dtarr[2]."-".$dtarr[1]."-".$dtarr[0];
    }
    return "";
}
if(!isset($_REQUEST['data'])){
    $html = "INVALID PARAMETER";
}else{
    $dataobj = json_decode($_REQUEST['data'],true);
    extract($dataobj);
    //get user details
    $UserDet = $dbo->SelectFirstRow("user_tb","","UserID=".$UID);
    $PrintDate = date("d/M/Y");
   $PrintTime = date("h:i A");
   $totalrst = 0;
   $html = "NO RECORD FOUND";

   $sch = GetSchool();
   $schStruc = json_decode($sch['SchStrucContr'],true);
   //$preloadstudy = (int)$_POST['preloadstudy'];
//$preloadprog = (int)$_POST['preloadprog'];
//$preloadstartses = (int)$_POST['preloadstartses'];
$preloadclass = (int)$preloadclass;
$preloadmoe = (int)$preloadmoe < 1 ?1:(int)$preloadmoe;

//get all academic detaisl
$acdet = $dbo->SelectFirstRow("study_tb st, fac_tb f, dept_tb d, programme_tb p, session_tb se, modeofentry_tb me ","st.Name as StudyName, f.FacName,p.ProgName,se.SesName,me.Name as MOE","st.ID = $preloadstudy AND d.FacID = f.FacID AND p.DeptID = d.DeptID AND p.ProgID = $preloadprog AND se.SesID = $preloadstartses AND me.Level = $preloadmoe LIMIT 1");
$defdet = !is_array($acdet)?["StudyName"=>"--","FacName"=>"--","ProgName"=>"--","SesName"=>"--","MOE"=>"--"]:$acdet;
//get class group
$defdet['ClassName']= "--";
if($preloadclass > 0){
    $classdet = GetStudentClassByID($preloadclass);
    //if(is_array($classdet)){
        $defdet['ClassName'] = $classdet["Name"];
    //}
}

$query = "SELECT UCASE(s.RegNo) as `Reg. Number`, s.JambNo as `Entrance ID`, UCASE(s.SurName) as Surname, UCASE(s.FirstName) as FirstName , UCASE(s.OtherNames) as Othernames, IF(s.Gender='M','MALE','FEMALE') as Gender, UCASE(COALESCE(st.StateName,'')) as `State`, UCASE(COALESCE(lg.LGAName,'')) as LGA, s.Phone, COALESCE(s.Addrs,'') as `Address`, COALESCE(a.AccessCode,'') as AccessCode FROM studentinfo_tb s LEFT JOIN accesscode_tb a ON ((a.JambNo = s.RegNo OR a.JambNo = s.JambNo) AND a.JambNo != '') LEFT JOIN state_tb st ON (s.StateId = st.StateID) LEFT JOIN lga_tb lg ON (s.LGA = lg.LGAID) WHERE ProgID = ".$dbo->SqlSafe($preloadprog)." AND StartSes = ".$dbo->SqlSafe($preloadstartses)." AND ClassID = ".$dbo->SqlSafe($preloadclass)." AND ModeOfEntry = ".$dbo->SqlSafe($preloadmoe)." ORDER BY s.SurName, s.FirstName, s.OtherNames, s.OtherNames, s.RegNo, s.JambNo, s.id" ;
$html = $query;
$totstud = 0;
          $totamt = 0;
          $cnt =1;
if($query != ""){
    $qr =  $dbo->RunQuery($query);
    if(is_array($qr)){
        if($qr[1] > 0){
            $thead = "";
            $tbody = "<tbody>";
            $tfoot = "";
           $totfields = 0;
            while($rst = $qr[0]->fetch_assoc()){
             $tr = "<tr><td>$cnt</td>";
             if($totfields == 0){$totfields = count($rst);}
             
              foreach($rst as $fName=>$val){
                  $fnameinit = substr($fName,0,1);
                  
                  $fName = $fnameinit == "_"?ltrim($fName,'_'):$fName;
                  if($fnameinit == "_"){ //if from json string (Info)
                     $val = json_decode($val,true);
                     $val = $val[$fName];
                 }

                 
                
                 if($cnt == 1){
                     $thead .= "<th>".strtoupper($fName)."</th>"; 
                 }
                 
                 //$val = $fName == "AMOUNT"?number_format($val,2,".",","):$val;
                 //$val = str_replace(strtoupper($searchstr),'<strong>'.strtoupper($searchstr).'</strong>',strtoupper($val));
                 $tr .=  "<td style=\"\">".$val."</td>"; 
              }
              $tr .= "</tr>";
              $tbody .= $tr;
            $colspan = $totfields;
            //$totalpayshtml = $sumary?"<th style=\"text-align:left\">$totpay</th>":'';
            //$datefil = $from == ""?"":"($from to $to)";
            
           
           // $tbody .= "</tbody><tfoot><tr><th colspan=\"".$colspan."\" style=\"text-align:right\">Total</th>".$qr[1]."<th style=\"text-align:left\"></th><tr></tfoot>";
           
            $cnt++;
        }
        //$expsstrdis = trim($searchstr) == ""?"":"| <i>$searchstr</i>";
           $totstud = $qr[1];
           $header = isset($export)?"<tr><th colspan=\"".($totfields + 1)."\">CLASS LIST ({$defdet['StudyName']} - {$defdet['ProgName']} - {$defdet['ClassName']} - {$defdet['MOE']})</th></tr>":"";
           $thead = "<thead>".$header."<tr><th>S/N</th>".$thead."</tr></thead>";
           $tbody .= "</tbody>";
           $tfoot = "<tfoot><tr><th colspan=\"".$colspan."\" style=\"text-align:right\">Total</th><th style=\"text-align:left\">".$totstud."</th><tr></tfoot>";
           $html = "<table id=\"classlistgen\"> $thead $tbody $tfoot</table>";
       }
    }
}

}

if(isset($export)){
    exit($html);
}



$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->WaterMarkText("AKSU",0.1);
$pdf->Banner($displaytext,array("LogoSize"=>"80*80","WaterMark"=>"Abbr"));
$pdf->FooterNote($displaytext,$pdf->Signataries(array("STAFF","REGISTRAR")));
$pdf->Panel();

$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("ACADEMICS");
    //$schStruc['StudyID']['Name'],$schStruc['FacID']['Name'],$schStruc['ProgID']['Name']
    if($schStruc['StudyID']['SilentMode'] == false){
        $pdf->Info($schStruc['StudyID']['Name'].":", $defdet['StudyName']);
    }else{
        $pdf->Info("", "");
    }
    if($schStruc['FacID']['SilentMode'] == false){
        $pdf->Info($schStruc['FacID']['Name'].":", $defdet['FacName']);
    }else{
        $pdf->Info("", "");
    }
    if($schStruc['ProgID']['SilentMode'] == false){
        $pdf->Info($schStruc['ProgID']['Name'].":", $defdet['ProgName']);
    }else{
        $pdf->Info("", "");
    }
    //get the class level
    $lvldet = GetLevel($preloadstartses,$preloadprog,$preloadstudy);
    $pdf->Info("Level", $lvldet['LevelName']);
$pdf->_InfoBox();

$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("CLASS");
    $pdf->Info("BATCH:", $defdet['SesName']);
    if($schStruc['ClassID']['SilentMode'] == false){
        $pdf->Info($schStruc['ClassID']['Name'].":", $defdet['ClassName']." <strong>($totstud)</strong>");
    }else{
        $pdf->Info("TOTAL:", " <strong>$totstud</strong>");
    }
    $pdf->Info("M.O.E:", $defdet['MOE']);
$pdf->_InfoBox();

$pdf->InfoBox(1.33,"margin-left:1.5%");
    $pdf->InfoTitle("DETAILS");
       // $pdf->Info("Query String:",$quryva);
        $pdf->Info("REPORT BY:",$UserDet['UserName']);
        $pdf->Info("DATE:",date("d-M-Y"));
        $pdf->Info("Time:",date("h:i:s A"));
$pdf->_InfoBox();
$pdf->_Panel();
$pdf->Dump($html);
$pdf->HTML();
/*echo '
<div style="width:95%; margin:auto;margin-top:100px;">
<div style="width:200px;float:left;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">HOD</div>
<div style="width:200px;float:right;border-top:#000 solid thin;padding-top:5px;text-align:center;font-style:italic;font-size:1.1em">Staff/User</div>
</div>';*/

$pdf->_HTML();
$pdf->Finish();

?>