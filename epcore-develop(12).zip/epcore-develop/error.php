<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Error On Page</title>
    <link href="https://fonts.googleapis.com/css?family=Exo+2:300|Encode+Sans+Condensed" rel="stylesheet" type="text/css" media="all" />
    <link href="css/w3.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/gen.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/bbwa.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/FA5/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <!-- Error Display -->
  <div class="bbwa-errdis">
      <div class=" errmsg-cont">
         <div class="img-cont">
         <img src="images/bbwa/error-img.png" />
        </div>
        <div class="err-cont w3-row-padding">
          <div class="icon-div w3-col m3 w3-text-red w3-hide-small  w3-right-align">
            <i class="fas fa-exclamation-triangle"></i>
          </div>
          <div class="msg-div w3-col m9">
            <div class="err-code w3-xxxlarge">Error - <?php echo $_GET['Error_Code'];  ?></div>
            <div class="err-msg w3-xlarge"><?php echo $_GET['Error_Message'];  ?></div>
          </div>
        </div>
        <div class="err-footer w3-padding w3-light-grey w3-large w3-topbar w3-margin">
          Contact the School ICT team to notify them of this Error
        </div>
        <button class="w3-button w3-blue w3-round w3-right w3-margin" onclick="window.location.reload();">Retry</button>
        <div style="clear:both"></div>
        <div class="w3-center">&copy; eduporta&trade; v3 2019 </div>
      </div>
</div>
  <!-- Error Display -->
</body>
</html>