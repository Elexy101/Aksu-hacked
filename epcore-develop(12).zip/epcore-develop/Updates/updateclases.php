<?php
$configdir = "../../../academa/";
require_once("../general/config.php");

//get all the student
$allstud = $dbo->Select("studentinfo_tb","IF(RegNo='',JambNo:RegNo) as RegNo, id, ProgID");
//look up
$errorprog = $errorupd = $success =0;
$Progs = [];
if(is_array($allstud) && $allstud[1] > 0){
    while ($indstud = $allstud[0]->fetch_assoc()) {
        $RegNo = $indstud['RegNo'];
        $id = $indstud['id'];
        $ProgID = $indstud['ProgID'];
        if(!isset($Progs[$ProgID])){
            $classidarr = $dbo->SelectFirstRow("studentclass_tb","ID","ProgID=".$ProgID);
            if(is_array($classidarr)){
                $Progs[$ProgID] = $classidarr['ID'];
            }else{
                $errorprog++;
                continue;
            }
        }
        $upd = $dbo->Update("studentinfo_tb",["ClassID"=>$Progs[$ProgID]],"id=".$id);
        if(!is_array($upd)){
            $errorupd++;
                continue;
        }else{
            $success++;
        }

    }
}

echo "Success=>".$success;
echo "<br/>ClassNotFound=>".$errorprog;
echo "<br/>Failed=>".$errorupd;

?>