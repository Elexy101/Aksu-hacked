<?php
$configdir = "../../../academa/";
require_once("../general/config.php");
require_once("../general/getinfo.php");

//get all result
$updated = 0;
$ok = 0;
$invalid = 0;
$error = 0;
$corseupdated = 0;
$corseupdatedf = 0;
$rst = $dbo->Select("result_tb","","SesID=8 ORDER BY Lvl");
if(is_array($rst) && $rst[1] > 0){
  while($rstind = $rst[0]->fetch_assoc()){
    $RegNo = $rstind['RegNo'];
    //get the student details
     $studdet = $dbo->SelectFirstRow("studentinfo_tb","RegNo","RegNo='$RegNo' OR JambNo='$RegNo'");
    if(!is_array($studdet)){$invalid++;continue;}
    $studlvl = StudLevel($RegNo);
    if((int)$rstind['Lvl'] > (int)$studlvl){//invalid result
        //update the level
        $updlvl = $dbo->Update("result_tb",["Lvl"=>$studlvl],"ID=".$rstind['ID']);
        if(is_array($updlvl)){
            //update the course registrationas well
            $updlvlc = $dbo->Update("coursereg_tb",["RegNo"=>$RegNo."_invalid"],"RegNo='$RegNo' AND Lvl={$rstind['Lvl']} AND SesID=8 AND Sem={$rstind['Sem']}");
            if(is_array($updlvlc)){
                $corseupdated++;
            }else{
                $corseupdatedf++;
            }

            $updated++;
        }else{
            $error++;
        }
    }else{
        $ok++;
    }
  }
}

echo "
OK => $ok <br/> Updated => $updated <br/> Invalid => $invalid <br/> Errors => $error <br/> CourseRegUpdated => $corseupdated <br/> CourseRegFailed => $corseupdatedf
";

?>