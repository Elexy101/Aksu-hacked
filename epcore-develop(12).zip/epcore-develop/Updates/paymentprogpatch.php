<?php
$configdir = "../../../academa/";
require_once("../general/config.php");
$invalid = 0;
$updated = 0;
$notupdated = 0;
//1. Get all payment in the database
$allpay = $dbo->Select("payhistory_tb","","ProgID=0");
//2. Check if record found
if(is_array($allpay) && $allpay[1] > 1){
    //3. Go trough all the records
    while($payrec = $allpay[0]->fetch_array()){
        $progID = 0;
        //get the student progid as at the time of payment
        $paydet = $payrec['Info'];
        
        //4. Convert the paydetails to array for easy access
        $paydet = json_decode($paydet,true);
        //5. Check if covertion is succesfull
        if(!is_null($paydet)){
          $progID = (int)$paydet['ProgID'];
        }

        //check if not valid
        if($progID == 0){
            //try get it from the student details
            $studdet = $dbo->SelectFirstRow("studentinfo_tb","ProgID","RegNo='{$payrec['RegNo']}' OR JambNo='{$payrec['RegNo']}'");
            //if not stydent exist skip the sudent
            if(!is_array($studdet)){
                $invalid++;
                continue;
            }
            $progID = $studdet['ProgID'];
        }

        //update the Prog ID in payhistory
        $pupd = $dbo->Update("payhistory_tb",["ProgID"=>$progID], "ID=".$payrec['ID']);
        $pupdd = $dbo->Update("order_tb",["ProgID"=>$progID], "TransNum='".$payrec['TransID']."'");
        if(!is_array($pupd)){
            $notupdated++;
        }
        $updated++;

    }
}

echo "Success:".$updated."<br/>";
echo "Failed:".$notupdated."<br/>";
echo "Invalid:".$invalid."<br/>";

?>