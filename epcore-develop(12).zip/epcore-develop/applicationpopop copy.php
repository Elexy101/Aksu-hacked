<!-- Content Popop -->
   <!-- <div class="menu-popup close-popup" id="menu-popup"> -->
   <div class="menu-popup-cont w3-example  close-popup" id="menu-popup">
<!-- <div class="popupconner w3-display-topleft TopLeft lineE" id="TopLeftg"></div>
<div class="popupconner w3-display-topright TopRight lineE"></div>
<div class="popupconner w3-display-bottomleft BottomLeft lineE"></div>
<div class="popupconner w3-display-bottomright BottomRight lineE"></div> -->
  <div class="w3-display-topmiddle popupsizer Top lineE w3-hide-small" style=""></div>
  <div class="w3-display-bottommiddle popupsizer Bottom lineE w3-hide-small" style=""></div>
  <div class="w3-display-left popupsizer vertical Left lineE w3-hide-small" style=""></div>
  <div class="w3-display-right popupsizer vertical Right lineE w3-hide-small" style=""></div>
<!-- <button name="" class="close popup-close-btn appbgcolor tooltip" tooltip="Hide Window" onclick="Application.Close()"><span class="mbri-close"></span></button> -->
  {{R004:
  <!-- Popup Head -->
 <div class="head">
 
 <button name="" class=" menubtn" onclick="this.parentElement.nextElementSibling.classList.toggle('small-screen')"><i class="fas fa-bars "></i></button>
 <div class="mainlogo"><img src="{{R001:{{__Root__}}{{Logo}}:R001}}" /></div>
   <div class="menus-group">
     {{AppGroup:
   <button name="" onclick="Application.ActivateGroup(this,'{{ID}}')" class="animate-normal fadeIn popup-real-menu">{{Name}}</button>
    :AppGroup}}
    
    
   <!--<button name="" onclick="Application.Activate(this,'id3')" class="animate-normal fadeIn popup-real-menu">Staff</button> -->
   
</div>
<div class="menus-group3">
<button name="" onclick="this.parentElement.parentElement.parentElement.parentElement.classList.toggle('menu-popup-drop')" class="animate-normal fadeIn popup-real-menu popup-menu-display-btn arrowbtn w3-hide-large w3-hide-medium appbgcolor"><i class="fas fa-caret-down popup-menu-display-btn"></i></button>
</div>

<div class="menus-group2" style="">
<button name="" onclick="Application.Close(this.parentElement.parentElement.parentElement)" class="animate-normal fadeIn popup-real-menu appcolor w3-right"><span class="mbri-close"></span></button>
<button name="" onclick="Application.Maximize(this.parentElement.parentElement.parentElement)" class="animate-normal fadeIn popup-real-menu w3-hide-small w3-hide-medium w3-right"><span class="mbri-browse"></span></button>
<button name="" onclick="" class="animate-normal fadeIn popup-real-menu w3-hide-small w3-hide-medium w3-right w3-hide"><span class="mbri-arrow-down"></span></button>

</div>

   
 </div>
 <!-- Popup body -->
 <div class="body small-screen">
 {{AppGroup:
 <div class="body-cont bdcont{{ID}}" id="id{{ID}}">
   <div class="body-cont-title">{{Descr}}</div>
    <div class="w3-row struc-row">
      <!-- Back Button-->
    <div class="w3-col l4 struc-col back-btn ">
    <div class="ind-menu-bx" onclick="this.parentElement.parentElement.parentElement.classList.remove('preview-mode');this.parentElement.parentElement.parentElement.parentElement.classList.remove('preview-mode-parent')">
          <div class="ind-menu-bx-logo appcolor"><i class="mbri-features fa-fw"></i></div>
          <div class="ind-menu-bx-cont">
          <div class="ind-menu-bx-cont-title appcolor">Menu Grid</div>
          </div>
 </div>
 </div>
    {{Applications:
       <div class="w3-col l4 struc-col">
          <div class="ind-menu-bx appmenu{{AID}} tooltip" tooltip="{{AppName}}" onclick="Application.LoadPage(this,{{AID}},{{ID}})">
          <div class="ind-menu-bx-logo"><i class="{{AppLogo}} fa-fw"></i></div>
          <div class="ind-menu-bx-cont">
          <div class="ind-menu-bx-cont-title appcolor">{{AppName}}</div>
          <div class="ind-menu-bx-cont-det">{{AppDescr}}</div>
          </div>
          <div style="clear:both"></div>
          </div>
       </div>
    :Applications}}
     
    </div>
    <div class="menu-bx-cont fadeIn custom-scroll">
       <div class="menu-bx-ind-cont">
       <div class="loading-cont"><img src="images/logo.png" class="" /></div>
       </div>
    </div>

    
 <button name="" class="w3-button w3-card w3-hide-large heartBeat2 w3-hide-medium gen-back-menu-btn appbgcolor w3-circle" onclick="this.parentElement.classList.remove('preview-mode');this.parentElement.parentElement.classList.remove('preview-mode-parent')"><div class="w3-display-container"><i class="mbri-features w3-large fa-fw w3-display-middle"></i></div></button>
 </div>
 
 :AppGroup}}<!-- 
 <div class="body-cont" id="id2"> aa 2</div>
 <div class="body-cont" id="id3"> aa 3</div> -->
 
</div>

<!-- Popup Footer -->
<div class="footer">
<div class="footer-cont">
   <div class="bbwa-checkbox">
     <input type="checkbox" id="autoopenapply" onchange="Login.SetAutoOpenApply(this)" name="bbwa-checkbox" checked />
       <div class="bbwa-checkbox-logo"><i class="fas fa-check"></i></div><div class="bbwa-checkbox-text">Display on Startup</div>
   </div>
</div>
  <div class="footer-link">
  <a href="javascript:void(0)" onclick="Application.Close();Login.Close()">Home</a>
<a href="javascript:void(0)" onclick="Application.Close();Login.Open()">Login</a>
<a href="javascript:void(0)" onclick="Application.Close();" >Guest</a>
</div>
</div>
:R004}}
</div>