<?php

error_reporting(1);
//Eduporta api engine request Manager V1
//*********************************** */
session_start();
//make available the parameters
include "parameter.php";


//Verify User Parameters
if(!isset($_POST['RequestID']) || trim($_POST['RequestID']) == "" || !isset($_POST['Version']) || trim($_POST['Version']) == "" )Error(0);

//verify request engine version
//if(!file_exists(strtolower($_POST['Version']).".php"))Error(1);



//set the encrypt config url
$Config = json_decode(urldecode($_POST['Config']),true);

if(isset($Config['SubDir']))$configdir =  $_POST['Base']."../".$Config['SubDir'];


//exterblish database conection
require_once $_POST['Base']."epcore/general/config.php";

if(!isset($dbo))Error(2);

//load gen scripts
require_once $_POST['Base']."epcore/general/getinfo.php";

$RequestArr = explode(",",$_POST['RequestID']);
//include the version engine
//require_once strtolower($_POST['Version']).".php";
require_once "utility.php";

//get user parameter
$Param = (!isset($_POST['Param']) || trim($_POST['Param']) == "")?[]:json_decode($_POST['Param'],true);



//get the apply global data and merge with param
if(isset($_POST['ApplyID']) && (int)$_POST['ApplyID'] > 0){
  
  $applydet = $dbo->SelectFirstRow("new_apply_tb","GlobalData","ID=".$_POST['ApplyID']);
  if(is_array($applydet) && !is_null($applydet['GlobalData']) && trim($applydet['GlobalData']) != ""){
    
    //Error(0,$applydet['GlobalData']);
    $Param = array_merge($Param,json_decode($applydet['GlobalData'],true));
  }
}

/* $ServerRoot = isset($_SERVER['HTTP_HOST'])?$_SERVER['HTTP_HOST']:$_SERVER['SERVER_NAME'];
//$protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === true ? 'https://' : 'http://';
$protocol = !empty($_SERVER['HTTPS'])?'https://' : 'http://';
//get the current setup details
//$setupdet = $dbo->SelectFirstRow("setup_tb","","Inuse=1 LIMIT 1");
$Versionstr = "";
//if(is_array($setupdet)){
    $Versionstr = $Config['Version']."/".$Config['Core']; */
//}

//$__Root__ = $protocol.$ServerRoot."/".$Versionstr;
$__Root__ = $dbo->Config['Core2'];
$Param['__Root__'] = $__Root__;
$Param['__Core__'] = $dbo->Config['Core'];
$Param['__SubDir__'] = $dbo->Config['SubDir'];
$Param['__Domain__'] = $dbo->Config['SubDir2'];
//$Param['ttt'] = $_POST['Param'];

$AllRst = [];
$Scripts = [];

foreach($RequestArr as $RID){
 
  if(isset($Request[$RID][1])){
    
    $includescripti = trim(strtolower($Request[$RID][1]));
    
    // /* $inclarr = explode(",",$includescript);
    
    // foreach($inclarr as $k=>$includescripti){ */
      
      if($includescripti != "utility" && $includescripti != "" && !in_array($includescripti,$Scripts)){
        
      require_once($includescripti.".php");
      
     // Error(0," : ".$includescripti.".php");
      $Scripts[] = $includescripti;
      
    }
    
    // }
    
    
  }
  
  
  //get request name
if(!isset($Request[$RID]))Error(3,": 1");

//check if request function exist
if(!function_exists($Request[$RID][0]))Error(3,": 2");
$Param['dbo'] = $dbo;
//call the script
$rst = call_user_func($Request[$RID][0],$Param);
//exit(json_encode($dbo));
//update param
$Param = array_merge($Param,$rst);

$AllRst[$RID] = $rst;
}


$AllRst = count($AllRst) == 1?array_pop($AllRst):$AllRst;



if(is_array($AllRst)){
    $AllRst['__Root__'] = $__Root__;
    $AllRst['__Core__'] = $dbo->Config['Core'];
    $AllRst['__Logo__'] = $rst['__Root__'];
    $AllRst['__SubDir__'] = $dbo->Config['SubDir'];
$AllRst['__Domain__'] = $dbo->Config['SubDir2'];
//exit('ddd');
    //$_SESSION['LRegNo'] = "aaa";
    //$AllRst = array_merge($AllRst,$_SESSION);
  //exit(urlencode(json_encode($rst)));
  echo json_encode($AllRst);
}else{
   echo $AllRst;
}


//check if the 








?>