<?php
//"R067" => ["","media"]
function LoadNotification($param=[]){
    global $dbo;
    //$Param['PageClass'] = "ReloadOnPaid";
               /*     $Param["ErrorImage"] = "images/pages/notpaid.png";
                   Error(13,json_encode($param),$Param); */
                   $RegNo = $param['LoginName'];
                   $alln =$dbo->SelectAsArray("notification_tb","*, REPLACE(REPLACE(Message, '\r', ''), '\n', '') as MessageLine, REPLACE(REPLACE(Message, '\r', '<br/>'), '\n', '<br/>') as MessageHTML, IF(DATEDIFF(NOW(),MDateTime) > 1,CONCAT(DATEDIFF(NOW(),MDateTime),' days ago'),CONCAT(TIME_FORMAT(TIMEDIFF(NOW(),MDateTime),'%Ihr %imin'),' ago')) as DD, IF(Viewed=1,'viewed','') as VV","RegNo='".$dbo->SqlSafe($RegNo)."' ORDER BY MDateTime DESC LIMIT 50");

                   if(!is_array($alln))Error(66);
                   if(count($alln) < 1)Error(67);

                   return ["Notifies"=>$alln];

}

?>