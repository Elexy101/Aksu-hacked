<?php
//Get State Of Origin - R011
function GetStateOfOrigin($Param){
    global $dbo;
    //check if country id supplied
    $conty = (isset($Param['CountryID']) && (int)$Param['CountryID'] > 0)?$Param['CountryID']:1;
    $selected = (isset($Param['SelectID']) && (int)$Param['SelectID'] > 0)?$Param['SelectID']:0;
    //get all state of origin
    $states = $dbo->Select("state_tb","","CountryID=".$conty);
    if(!is_array($states))Error(4);
    $StateReturn = [];
    while($state = $states[0]->fetch_assoc()){
        $state['Selected'] = "";
        if((int)$state['StateID'] == (int)$selected){
            $state['Selected'] = "selected";
            array_unshift($StateReturn,$state);
        }else{
            $StateReturn[] = $state;
        }
    }

    return $StateReturn;
}

//Get Local government - R012
function GetLGAreas($Param){
    global $dbo;
    if(isset($Param['StateID']) && (int)$Param['StateID'] > 0){
      //select all
      $lgas = $dbo->Select("lga_tb","","StateID=".$Param['StateID']);
      if(!is_array($lgas))Error(4);
      return $dbo->FetchAll($lgas[0],MYSQLI_ASSOC);
    }else{
        return [];
    }

}
?>