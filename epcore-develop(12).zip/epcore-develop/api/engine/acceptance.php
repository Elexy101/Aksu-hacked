<?php



//#R022
function AcceptAdmission($Param){

  Underscored($Param);
  if(!isset($Param['RegNo']) || trim($Param['RegNo']) == "")Error(11);
  global $dbo;
  //get candidate from student info
  $cand = $dbo->SelectFirstRow("pstudentinfo_tb","","RegNo='".trim($dbo->SqlSafe($Param['RegNo']))."' OR JambNo='".trim($dbo->SqlSafe($Param['RegNo']))."'");
  if(!is_array($cand))Error(23,$Param['RegNo']); //candidate doesnot exist
  $upd = $dbo->Update("pstudentinfo_tb",["Accept"=>1,"AdminDate"=>date("Y-m-d")],"id=".$cand['id']);
  if(!is_array($upd))Error("CE","Error while updating Acceptance.");
 
  return ["RegNo"=>$Param['RegNo']];

}

//R053
//Check if Entrance module is enabled
function Acceptance($Param){
    
    global $dbo;
    
    
    //check if entrance id isset
  $EntrContrID = (isset($Param["FormID"]) && (int)$Param["FormID"] > 0)?$Param["FormID"]:1;
  $entrancedet = $dbo->SelectFirstRow("form_tb","","ID=".$EntrContrID,MYSQLI_ASSOC);
  if(!is_array($entrancedet))Error(57);
  if($entrancedet['Status'] == "CLOSED")Error(53,'<br/>'.$entrancedet['Title']);
  $entrancedet['VerDisStr'] = $entrancedet['Type'] != "FN"?"Entrance Number":"Phone Number or Email Address";
  return $entrancedet;
}


//R052
function LoadAcceptancePayment($Param){
  //Error(0,": ");
    global $dbo;
    
    
    if(!isset($Param['RegNo_Cand']) || trim($Param['RegNo_Cand']) == ""){
     // return ["PageNum"=>1,"__Alert__"=>"Sorry, we could not Identify you. Enter your Email Address and Try Again"];
     
      return RedirectTo(1,"Sorry, we could not Identify you. Try Again");
  }
    //get the payid for entrance payment
    //check if entrance id isset
   /*  $EntrContrID = (isset($Param["EntranceID"]) && (int)$Param["EntranceID"] > 0)?$Param["EntranceID"]:1;
    $entrancedet = $dbo->SelectFirstRow("putme","","ID=".$EntrContrID);
    if(!is_array($entrancedet))Error(52); */
    $entrancedet = Acceptance($Param);
    
    if($entrancedet['PayReg'] == "REG"){ //if payment disabled
      if(!isset($Param['NextPageNum']))$Param['NextPageNum'] = 4;//if the next page not sent set to 5
      //update the applicant RegLevel - not needed incase payment enable during the registration process
     // $upd = $dbo->Update("pstudentinfo_tb",["RegLevel"=>$Param['NextPageNum']],"id=".$appldet['id']);
      return RedirectTo($Param['NextPageNum']);
    }

    $PayID = $entrancedet['PayID'];
    //get the applicant details
    $appldet = $dbo->SelectFirstRow("pstudentinfo_tb","","RegNo='".$dbo->SqlSafe($Param['RegNo_Cand'])."' OR JambNo='".$dbo->SqlSafe($Param['RegNo_Cand'])."'",MYSQLI_ASSOC);
    //if not exist get it from studentinfo
    if(!is_array($appldet)){
      $appldet = $dbo->SelectFirstRow("studentinfo_tb","","RegNo='".$dbo->SqlSafe($Param['RegNo_Cand'])."' OR JambNo='".$dbo->SqlSafe($Param['RegNo_Cand'])."'",MYSQLI_ASSOC);
      //if not exist, meaning not even a student
      if(!is_array($appldet))return RedirectTo(1,"Candidate/Student Not Exist");
    }
    if(trim($appldet['OtherDet']) != "" && !is_null($appldet['OtherDet'])){
        $otherdetarr = json_decode($appldet['OtherDet'],true);
        if(is_array($otherdetarr)){
            unset($appldet['OtherDet']);
            $appldet = array_merge($appldet,$otherdetarr);
        }
    }
    //get payment ref
    $payorder = $dbo->SelectFirstRow("order_tb","","RegNo='".$dbo->SqlSafe($Param['RegNo_Cand'])."' AND ItemID = $PayID");
    if(is_array($payorder)){
      //check payment
    $paydet = HasPaidRef($payorder['TransNum']);
      //return ["Status"=>"Paid"];
      if($paydet[0] == 1){ //payment made
          //if(!isset($Param['NextPageNum']))$Param['NextPageNum'] = 4;//if the next page not sent set to 5
          
          if(isset($Param['ApplyID'])){
           
            //get the application details
            $appdet = $dbo->SelectFirstRow("new_apply_tb","Pages","ID=".$Param['ApplyID']);
            if(is_array($appdet)){
              
              $pages = $appdet['Pages'];
              $pagesarr = json_decode($pages,true);
              $lastpage = array_pop($pagesarr);
             
              if((int)$lastpage <= 3){
               // Error(52," - ".$lastpage);
                return RedirectTo(1,"Required Payment Verified Successfully");
              }
            }else{
              
            }
          }
          
          //update the applicant RegLevel
          //$upd = $dbo->Update("pstudentinfo_tb",["RegLevel"=>$Param['NextPageNum']],"id=".$appldet['id']);
          return RedirectTo(4,"Required Payment Verified Successfully gg");
      }
    }
  
    //get the payment item details
    //$payitem = $dbo->SelectFirstRow("item_tb","","ID=".$PayID);
    //if(!is_array($payitem))Error(14); //invalid payment type
  $HighSem = HighestSemester();
    //get the payment amount
    $Pamt = GetPaymentAmt(["LoginName"=>$Param['RegNo_Cand'],"SemesterID"=>($HighSem['Num']+1),"LevelID"=>1,"SemesterPartID"=>3,"PayID"=>$PayID,"StudentDetails"=>$appldet]);
    if(!is_array($Pamt))Error(12);
  
    //marge all details
    return array_merge($Pamt['StudentDetails'],$Pamt['PayDetails'],["Amount"=>$Pamt['Amount'],"FAmount"=>$Pamt['FAmount'],"RegNo_Cand"=>$Param['RegNo_Cand']]);
    //Error("CE",json_encode($Pamt));
    
  }
