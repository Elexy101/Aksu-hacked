<?php
//$dbo2 = $GLOBALS['_POST']['dbo'];

//Get all School Basic Details
//R001
function GetSchoolDetails($Param){
     
    
    //$dbo = $GLOBALS['_POST']['dbo'];
    global $dbo;
   // var_dump($dbo);
    // exit;
    //if(is_null($dbo) && isset($Param['dbo']))$dbo = $Param['dbo'];
    // $schooldety = $dbo->RunQuery("SELECT * FROM item_tb");
     
    //Get the school details
     $schooldet = $dbo->RunQuery("SELECT s.Name, p.colorScheme as ColorScheme, s.description as Description, s.ID as SID, s.AppThemeColor, p.wallpapers, s.FooterNote, s.email as Email, s.Phone, p.walldelay as WallDelay, s.Abbr as Abbreviation, SUBSTRING_INDEX(SUBSTRING_INDEX(p.colorScheme, ';', 1), ';', -1) as BaseColor, SUBSTRING_INDEX(SUBSTRING_INDEX(p.colorScheme, ';', 2), ';', -1) as ForeColor, CONCAT('Files/',s.logo) as Logo FROM school_tb s, portal_tb p");
     
     if(!is_array($schooldet))Error(4,": School Details");
     $schooldet = $schooldet[0]->fetch_assoc();
    
     //get the set wallpapers
     $setwp = trim($schooldet['wallpapers']);
     $forcolorarr = explode(",",$schooldet['ForeColor']);
     $LightColor = [];
     foreach($forcolorarr as $col){
 $col = (int)$col;
 $inc = 50;
 $col = ($col + $inc) > 255?255:($col + $inc);
 $LightColor[] = $col;
     }
     $schooldet["LightForeColor"] = implode(",",$LightColor);
     $schooldet["Wallpapers"] = [];
     //if no wall paper set
     if($setwp != ""){
         $setwpcond = "ID = ".str_replace("~"," OR ID = ",$setwp);
         //get all set wallpaper details
         //Get The School Wallpapers
         $schwp = $dbo->RunQuery("SELECT ID as WID, CONCAT('Files/UserImages/wallpapers/bgs/',wallpaper) as WallImage, wallheader as WallTitle, wallText as WallContent FROM wallpapers_tb WHERE $setwpcond");
         if(!is_array($schwp))Error(4," : Wallpapers");
         $schooldet["Wallpapers"] = $dbo->FetchAll($schwp[0],MYSQLI_ASSOC);
        // $schooldet["ss"] = "SELECT ID as WID, CONCAT('epconfig/UserImages/wallpapers/bgs/',wallpaper) as WallImage, wallheader as WallTitle, wallText as WallContent FROM wallpapers_tb WHERE $setwpcond";
     }
 
     
 
     return $schooldet;
   
 }

?>