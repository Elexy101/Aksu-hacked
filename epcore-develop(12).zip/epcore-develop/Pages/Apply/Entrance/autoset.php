<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto set</title>
</head>
<body>
    <script>
      var vc = '<?php echo @$_GET['VerCode']?>';
      current = localStorage.getItem("VerCode");
      if(current == vc)localStorage.setItem("VerCode","");
      localStorage.setItem("VerCode",vc);
     //alert(localStorage.getItem("VerCode"))
    </script>

</body>
</html>