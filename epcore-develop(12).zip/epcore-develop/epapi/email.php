<?php

//generate emil
function genPHPMEmail($mailT0="",$mailFrom="",$subject="",$msg=""){
    $mailto = "ab_keje@yahoo.com";
    $from_name = "AKSU";
    $from_mail = "taquatech@gmail.com";
    $subject = "Test";
    $message = "aaaa";
    $boundary = "XYZ-" . date('dmYis') . "-ZYX";
    $header = "--$boundary\r\n";
    $header .= "Content-Transfer-Encoding: 8bits\r\n";
    $header .= "Content-Type: text/html; charset=ISO-8859-1\r\n\r\n";
    $header .= "$message\r\n";
    $header .= "--$boundary\r\n";

    $header2 = "MIME-Version: 1.0\r\n";
    $header2 .= "From: ".$from_name." \r\n";
    $header2 .= "Return-Path: ".$from_mail." \r\n";
   // $header2 .= 'Cc: ubonge80@gmail.com' . "\r\n";
    $header2 .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
    $header2 .= "$boundary\r\n";
    $getRespons = mail($mailto,$subject,$header,$header2,"-r".$from_mail);
    if($getRespons){
        return "Mail Sent";
    }else{
        return "Not Sent";
    }
}

genPHPMEmail();
//mail with attachment
function sendMailAttachment($mailFrom,$subject,$bodyOfThTxt,$mailTo){
$filename = 'admissinprocedure.pdf';
$path = 'widget';//path to the file
$file = $filename;//$path . "/" . 
$mailto = "$mailTo";
$subject = "$subject";
$message = "$bodyOfThTxt";
$from_name = "AKWA IBOM STATE UNIVERSITY";
$content = file_get_contents($file);
$content = chunk_split(base64_encode($content));

// a random hash will be necessary to send mixed content
$separator = md5(time());

// carriage return type (RFC)
$eol = "\r\n";
// main header (multipart mandatory)
$headers = "Return-Path: $mailFrom" . $eol;
$headers .= "MIME-Version: 1.0" . $eol;
$headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol;
$headers .= "Content-Transfer-Encoding: 7bit" . $eol;
$headers .= "This is a MIME encoded message." . $eol;
$headers .= "From: ".$from_name." \r\n";
// message
$body = "--" . $separator . $eol;
$body .= "Content-Type: text/plain; charset=\"iso-8859-1\"" . $eol;
$body .= "Content-Transfer-Encoding: 8bit" . $eol;
$body .= $message . $eol;

// attachment
$body .= "--" . $separator . $eol;
$body .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"" . $eol;
$body .= "Content-Transfer-Encoding: base64" . $eol;
$body .= "Content-Disposition: attachment" . $eol;
$body .= $content . $eol;
$body .= "--" . $separator . "--";
 //SEND Mail
if (mail($mailto, $subject, $body, $headers)) {
    echo "mail send ... OK"; // or use booleans here
} else {
    echo "mail send ... ERROR!";
    print_r( error_get_last() );
}
}

?>