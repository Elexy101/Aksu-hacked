<?php
error_reporting(0);
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
if(isset($_GET['regno'])){
	$regno = $_GET['regno'];
	$studReg = STUDREG(); 
	$binfo = GetBasicInfo($regno,"sch","");
  /* print_r($binfo);
  exit; */
	//$ac = GetBasicInfo($regno,"ac",@$studReg['StudInfoPref']);
	
}
$sch = GetSchool();
$schStruc = json_decode($sch['SchStrucContr'],true);

$pdf->Banner("Student Admission Details",array("LogoSize"=>"80px*80px","WaterMark"=>"Abbr"));
  if(!is_array($binfo)){
	      if($binfo == "0"){
          $pdf->HTML();
	  ?>
                 <div class="errl">Candidate Not Found - <?=$regno?></div>
                <?php
               //exit;
            }else{
	  ?>
       
      <div class="errl">Internal Error</div>
      </div>
      </body>
      <?php
      $pdf->_HTML();
      $pdf->Finish();
            }
	 exit;
  }
//echo $binfo['OtherDet'];
if(trim($binfo['OtherDet']) != ""){
   $otherdet = json_decode($binfo['OtherDet'],true);
  $binfo = array_merge($binfo,$otherdet);
}
 
  $pdf->Panel();
    $pdf->InfoBox(2.5);
      $pdf->InfoTitle("BASIC DETAILS");
      $pdf->Info("SURNAME:",strtoupper(@$binfo['SurName']));
      $pdf->Info("FIRSTNAME:",strtoupper(@$binfo['FirstName']));
      $pdf->Info("OTHERNAMES:",strtoupper(@$binfo['OtherNames']));
      if(isset($binfo['FormerName']) && trim($binfo['FormerName']) != "")$pdf->Info("FORMER:",strtoupper(@$binfo['FormerName']));
     
      $db = new DateTime($binfo['DOB']); $dtb = $db->format("d, M Y");
      $pdf->Info("DATE OF BIRTH:",$dtb);
      //$pdf->Info("NATIONALITY:",strtoupper(@$binfo['Nationality']));
      $pdf->Info("STATE OF ORIGIN:",strtoupper(@$binfo['StateName']));
      $pdf->Info("LGA:",strtoupper(GetLGA(@$binfo['LGA'])));
      $pdf->Info("GENDER:",substr(strtoupper(@$binfo['Gender']),0,1) == "M"?"MALE":"FEMALE");
      $pdf->Info("MARITAL STATUS:",(trim(@$binfo['MaritalStatus']) == "M")?"MARRIED":"SINGLE");
    $pdf->_InfoBox();
    //passport
    $pdf->InfoBox(1.5);
    $pdf->InfoTitle("PASSPORT PHOTOGRAPH");
    $pdf->Dump("<div style=\"margin:auto;margin-top:0px;margin-bottom:5px;margin-top:5px;width:180px;height:180px\">");
     $pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($binfo['Passport'])),"width:100%;text-align:center");
     $pdf->Dump("</div>");
    $pdf->_InfoBox();

  $pdf->_Panel();

  $pdf->Panel();
  //acedemic
   $pdf->InfoBox(2);
      $pdf->InfoTitle("ACEDEMIC DETAILS");
      //  $pdf->Info("REGISTRATION NO.:",@$regno);
      /* $pdf->Info("FACULTY/SCHOOL:",@$binfo['FacName']);
      // $pdf->Info("DEPARTMENT:",strtoupper(@$binfo['DeptName']));
      $pdf->Info("DEPARTMENT:",@$binfo['ProgName']); */
      if($schStruc['StudyID']['SilentMode'] != "true")$pdf->Info(strtoupper($schStruc['StudyID']['Name']).":",$binfo['StudyName']);
      if($schStruc['FacID']['SilentMode'] != "true")$pdf->Info(strtoupper($schStruc['FacID']['Name']).":",@$binfo['FacName']);
      if($schStruc['DeptID']['SilentMode'] != "true")$pdf->Info(strtoupper($schStruc['DeptID']['Name']).":",@$binfo['DeptName']);
      // $pdf->Info("DEPARTMENT:",strtoupper(@$binfo['DeptName']));
      if($schStruc['ProgID']['SilentMode'] != "true")$pdf->Info(strtoupper($schStruc['ProgID']['Name']).":",@$binfo['ProgName']);
      $LevName = LevelName(LevelStartSes($binfo['StartSes']), $binfo["StudyID"]);
      $ClassDet = GetStudentClassByID($binfo['ClassID']);
      $ClassName = $ClassDet['Name'];
      $ClassT = isset($schStruc['ClassID']['Name'])?$schStruc['ClassID']['Name']:"CLASS";
      $pdf->Info("LEVEL/$ClassT:", $LevName." (".$ClassName.")"); 
    
      if(isset($binfo['Degree']) && (int)$binfo['Degree'] > 0){
        //get the degree
      $deg = $dbo->SelectFirstRow("school_degrees_tb","","ID=".(int)$binfo['Degree']);
      $binfo['Degree'] = is_array($deg)?$deg['Name']:'';
      $pdf->Info("DIPLOMA/DEGREE:",$binfo['Degree']);
      }
      $RegNo = (is_null($binfo['RegNo']) || trim($binfo['RegNo']) == "")?$binfo['JambNo']:$binfo['RegNo'];
      $pdf->Info("REG. NO.:",$RegNo);
      //get the accesscode
      $acccd = $dbo->SelectFirstRow("accesscode_tb","","JambNo='$RegNo'");
      if(is_array($acccd)){
        $pdf->Info("ACCESS CODE:",$acccd['AccessCode']);
      }
      
      
      if(isset($binfo['AreaofSpecial']) && trim($binfo['AreaofSpecial']) != "")$pdf->Info("AREA OF SPECIALIZATION:",@$binfo['AreaofSpecial']);
      if(isset($binfo['StudyModeFullTime']) && isset($binfo['StudyModePartTime']))$pdf->Info("STUDY MODE:",(int)@$binfo['StudyModeFullTime'] < 1?'PART TIME':'FULL TIME');
      if(isset($binfo['ResearchTopic']) && trim($binfo['ResearchTopic']) != "")$pdf->Info("RESEARCH TOPIC:",@$binfo['ResearchTopic']);
    //  
   $pdf->_InfoBox();
   //contact
  $pdf->InfoBox(2);
    $pdf->InfoTitle("CONTACT DETAILS");
    $pdf->Info("PHONE NUMBER:",@$binfo['Phone']);
    $pdf->Info("EMAIL:",@$binfo['Email']);
    $pdf->Info("HOME ADDRESS:",@$binfo['Addrs']);
    if(isset($binfo['OtherAddress']) && trim($binfo['OtherAddress']) != "")$pdf->Info("MAILING ADDRESS:",@$binfo['OtherAddress']);
    // $pdf->Info("NOK PHONE:",@$binfo['Nphone']);
  $pdf->_InfoBox();
  
  $pdf->_Panel();

  if(trim($binfo['OlevelRstDetails']) != ""){
    $pdf->Panel();
   $rst = BreakDownRst(@$binfo['OlevelRstDetails'],@$binfo['OlevelRst']);
   /*$pdf->HTML();
    print_r($rst);
    $pdf->_HTML();*/
          $sitrealdarr1 = $rst[0];
          $sit1arr = $rst[1];
          $sitrealdarr2 = $rst[2];
          $sit2arr = $rst[3];
          $size = count($sit2arr) > 0?2:4;
      $pdf->InfoBox($size);
       $pdf->InfoTitle("ENTRANCE RESULT");
       // $pdf->Info("EXAM. TYPE:",@$StudD['OlevelRst']);
       $exmb = (int)$sitrealdarr1[4] > 1?"EXTERNAL":"INTERNAL";
        $pdf->Info("EXAM. TYPE:",OlevelExam($sitrealdarr1[3]). " ($exmb)");
        $pdf->Info("EXAM. YEAR:",$sitrealdarr1[1]);
        $pdf->Info("SCHOOL:",$sitrealdarr1[0]);
        $pdf->Info("EXAM. NO.:",$sitrealdarr1[2]);
        //$pdf->InfoTitle(" ");
        if(count($sit1arr) > 0){
        $pdf->Table("margin-bottom:10px");
        $pdf->TableHead(array("SN","SUBJECT","GRADE"));
        for($f=0; $f<count($sit1arr); $f++){
         $rrst = $sit1arr[$f];
         $rrstarr = explode("=",$rrst);
         $cnt = $f+1;
         $subj = strtoupper(@$rrstarr[0]);
         $grd = @$rrstarr[1];
         //$grd = (trim($grd) == "D7" || trim($grd) == "E8" || trim($grd) == "F9")?"<span class=\"secondColor\">{$grd}</span>":$grd;
          $pdf->TableRow(array($cnt,$subj,$grd));
        }
        $pdf->_Table();
        }
        $pdf->_InfoBox();
        //$cnt =0;
        if(count($sit2arr) > 0){
        $pdf->InfoBox(2);
          $pdf->InfoTitle("OTHER RESULT");
          $exmb = (int)$sitrealdarr2[4] > 1?"EXTERNAL":"INTERNAL";
        $pdf->Info("EXAM. TYPE:",OlevelExam($sitrealdarr2[3]). " ($exmb)");
        $pdf->Info("EXAM. YEAR:",$sitrealdarr2[1]);
        $pdf->Info("SCHOOL:",$sitrealdarr2[0]);
        $pdf->Info("EXAM. NO.:",$sitrealdarr2[2]);
        $pdf->Table("margin-bottom:10px");
        $pdf->TableHead(array("SN","SUBJECT","GRADE"));
        for($f=0; $f<count($sit2arr); $f++){
         $rrst = $sit2arr[$f];
         $rrstarr = explode("=",$rrst);
         $cnt = $f+1;
         $subj = strtoupper(@$rrstarr[0]);
         $grd = @$rrstarr[1];
         //$grd = (trim($grd) == "D7" || trim($grd) == "E8" || trim($grd) == "F9")?"<span class=\"secondColor\">{$grd}</span>":$grd;
          $pdf->TableRow(array($cnt,$subj,$grd));
        }
        $pdf->_Table();
  
        $pdf->_InfoBox();
  
        }
      
    $pdf->_Panel();
      }

  
  if(isset($binfo['SchoolAttt'])){
    $binfo['SchoolAttt'] = is_array($binfo['SchoolAttt'])?$binfo['SchoolAttt']:[$binfo['SchoolAttt']];
    $binfo['SchooAttDate'] = is_array($binfo['SchooAttDate'])?$binfo['SchooAttDate']:[$binfo['SchooAttDate']];
    $binfo['SchoolAtttAward'] = is_array($binfo['SchoolAtttAward'])?$binfo['SchoolAtttAward']:[$binfo['SchoolAtttAward']];
    $pdf->Panel();
  $pdf->InfoBox(4);
  $pdf->InfoTitle("EDUCATIONAL QUALIFICATION");
  //$pdf->Info("a: Secondary Education","");
  $pdf->Table("margin-bottom:10px");
      $pdf->TableHead(array("Qualification","Date Awarded","Awarding Institution"));
      //get the secondary qualification
      foreach($binfo['SchoolAttt'] as $key=>$secdet){
        if(trim($binfo['SchoolAttt'][$key]) != "" || trim($binfo['SchooAttDate'][$key]) != "" || trim($binfo['SchoolAtttAward'][$key]) != "" ){
          $pdf->TableRow(array($binfo['SchoolAtttAward'][$key],$binfo['SchooAttDate'][$key],$binfo['SchoolAttt'][$key]));
        }
        
      }

      $pdf->_Table();
      /* $pdf->Info("b: Tertiary Education","");
      $pdf->Table("margin-bottom:10px");
          $pdf->TableHead(array("Qualification","Date Awarded","Awarding Institution"));
          //get the secondary qualification
          foreach($binfo['TerEdu'] as $secdet){
            if(trim($secdet['col1']) != "" || trim($secdet['col2']) != "" || trim($secdet['col3']) != ""){
              $pdf->TableRow(array($secdet['col1'],$secdet['col2'],$secdet['col3']));
            }
            
          }
    
          $pdf->_Table();
          $pdf->Info("c: University Education","");
          $pdf->Table("margin-bottom:10px");
              $pdf->TableHead(array("Qualification","Date Awarded","Awarding Institution"));
              //get the secondary qualification
              foreach($binfo['UniEdu'] as $secdet){
                if(trim($secdet['col1']) != "" || trim($secdet['col2']) != "" || trim($secdet['col3']) != ""){
                  $pdf->TableRow(array($secdet['col1'],$secdet['col2'],$secdet['col3']));
                }
                
              }
        
              $pdf->_Table(); */

  $pdf->_InfoBox(); 
  $pdf->_Panel();
  }
  
  //get the candidate referee
  $candref = $dbo->Select("referee_tb","","ApplID='".$dbo->SqlSafe($regno)."'");
  if(is_array($candref) && $candref[1] > 1){ //if freferee exist
    $pdf->Panel();
  $pdf->InfoBox(4);
  $pdf->InfoTitle("REFEREES");
  $pdf->Table("margin-bottom:10px");
  $pdf->TableHead(array("Name","Phone","E-mail Address"));
    while($ref = $candref[0]->fetch_assoc()){
      $pdf->TableRow(array($ref['Name'],$ref['Phone'],$ref['Email']));
    }
    $pdf->_Table();
    $pdf->_InfoBox(); 
  $pdf->_Panel();
  }

  
  

  //get the notes
  $entrID = isset($binfo['EntranceID']) && (int)$binfo['EntranceID'] > 0?$binfo['EntranceID']:1;
  //get the entarnce details
  $EntrDet = $dbo->SelectFirstRow("putme","","ID=".$entrID);
  $Uploads = is_array($EntrDet) && trim($EntrDet['Uploads']) != ""?json_decode($EntrDet['Uploads'],true):[];
  if(is_array($EntrDet) && trim($EntrDet['Notes']) != ""){
    $Notes = json_decode($EntrDet['Notes'],true);
    if(is_array($Notes) && count($Notes) > 0){
      $pdf->HTML();
      echo '<ul style="text-align:left;padding:15px">';
      foreach($Notes as $Note){
        echo '<li>'.$Note.'</li>';
      }
      echo '</ul>';
      $pdf->_HTML();
    }
  }
/* 
  $pdf->Dump('<div style="page-break-after: always;"></div>');

  //file upload
  if(isset($binfo['Uploads']) && count($binfo['Uploads']) > 0){
    $pdf->Panel();
      foreach($binfo['Uploads'] as $Dir=>$imgs){
        $pdf->InfoBox(4);
        $DirTit = isset($Uploads[$Dir])?$Uploads[$Dir][1]:$Dir;
        $pdf->InfoTitle(strtoupper($DirTit));
          foreach($imgs as $img){
            if(trim($img) == "")continue;
            $pdf->Dump("<div style=\"margin-bottom:5px;margin-top:5px;width:48%;float:left\">");
     $pdf->Image($pdf->BaseConfigPath."UserImages/$Dir/".$img,"width:100%;text-align:center");
     $pdf->Dump("</div>");
          }
        $pdf->_InfoBox(); 
      }
    $pdf->_Panel();
  } */
 
  
  $pdf->FooterNote("Registration Comfirmation Slip - ".@$regno);

  $pdf->Finish();
  //exit();
?>
  