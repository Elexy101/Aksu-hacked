<?php
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
$RegNo = @$_GET['RegNo'];
$RegID = isset($_GET["RegID"]) && (int)$_GET["RegID"] > 0?(int)$_GET["RegID"]:1; //the putme reg type that is calling the script, sent from the sub menu param in db (putme table ID field)
//$RegNo = '45678912AD';
//$PayID = @$_GET['ItemID'];
$pdet = PUTME($RegID);
$params = trim(@$pdet['Param']);
$paramarr = ($params != "")?json_decode($params,true):array("Cert"=>"Jamb");
$StuddbPre = @$pdet["StudInfoPref"];
$Notes = @$pdet["Notes"];
$NotObj = trim($Notes) != ""?json_decode($Notes):NULL;

/*if((int)$PayID == 3){
$StuddbPre = "p";	
}*/

$StudD = GetBasicInfo($RegNo,"",$StuddbPre,$RegID);

$ac = GetBasicInfo($RegNo,"ac",$StuddbPre,$RegID);
$accC = @$ac['AccessCode'];
$name = "";
if(is_array($StudD)){
	$name = @$StudD['Name'];
}
$gender = @$StudD['Gen'];
$fac = @$StudD['Fac'];
$dept = @$StudD['Dept'];
$prog = @$StudD['Prog'];
$passp = @$StudD['Passport'];
$passparr = explode("?",$passp);
$passp = $passparr[0];
$lga = GetLGA(@$StudD['lga']);
$state = GetState(@$StudD['StateId']);
$phone = @$StudD['Phone'];
$email = @$StudD['Email'];
$addr = @$StudD['Addr'];
$jamb = @$StudD['jamb'];
$othercert = @$StudD['OtherCert'];
$nSubjComb = explode("~",@$StudD['JmbComb']);
$sunjCombJmb = "";
if(count($nSubjComb) > 0){
  foreach($nSubjComb as $subjID){
    $subjName = GetSubj2($subjID);
     $sunjCombJmb .= $subjName[1]  . " | ";
    //$sunjCombJmb .= substr(strtoupper($subjName),0,3) . " | ";
  }
  $sunjCombJmb = rtrim($sunjCombJmb," | ");
}
//$subjComb = GetSubjCombID(@$StudD['PUTMECombID']);
//$seatNo = @$StudD['SeatNo'];
$venue = Venue(@$StudD['VenueID']);
//get the time_slot details
$Times = $dbo->SelectFirstRow("time_slot ts, panel_tb p","ts.*,p.*","ts.id=".@$StudD['VenueID']." AND p.PanelID = ts.PanelID");
//$campus= Venue2(@$StudD['VenueID']);
//$examDateTime = PUTMEDateTime($StudD['ProgID']);

/*$transNo = @$_GET['TransNo'];
$payType = @$_GET['ItemName'];
$payPol = (isset($_GET['Sem']) && (int)$_GET['Sem'] < 3)?"Part":"Full";*/
$regDate = @$_GET['RegDate'];
/*$brDwn = @$_GET['BD'];
$totPrice = @$_GET['Amt'];
<div class="IndItem">
    <div class="itemname">Full Name:</div><div class="itemvalue"><b><?php echo $name  ?></b></div>
  </div>
  <div class="IndItem">
  <div class="itemname">Reg. Number:</div><div class="itemvalue"><b><?php echo $RegNo  ?></b></div>
  </div>
  <div class="IndItem">
 <div class="itemname">Gender:</div><div class="itemvalue"><?php echo $gender  ?></div>
  </div>
  <div class="IndItem">
   <div class="itemname">Faculty/School:</div><div class="itemvalue"><?php echo $fac  ?></div>
  </div>
  <div class="IndItem">
  <div class="itemname">Department:</div><div class="itemvalue"><?php echo $dept  ?></div>
  </div>
  <div class="IndItem">
  <div class="itemname">Programme:</div><div class="itemvalue">
 <?php echo $prog  ?>                  </div>
  </div>
*/
$school = GetSchool();
$schoolType = SchoolType($school['Type']);
$pdf->Banner(@$pdet['Title'] ,array("LogoSize"=>"100px*100px","WaterMark"=>"Abbr"));

$pdf->Panel();
 $pdf->InfoBox(2,"text-transform:uppercase");
  $pdf->InfoTitle("BASIC DETAILS");
  $pdf->Info("FULL NAME:",$name);
  $pdf->Info("REG. NUMBER:",$RegNo);
  $pdf->Info("GENDER:",$gender);
  $pdf->Info("FACULTY/SCHOOL:",$fac);
  $pdf->Info("department:",$dept);
  $pdf->Info("programme:",$prog);
  if(trim($lga) != ""){
     $pdf->Info("LGA:",$lga);
   }
    if(trim($state) != ""){
     $pdf->Info("State of Origin:",$state);
    }
   $pdf->Info("Phone Number:",$phone);
   $pdf->Info("Email:",'<span style="text-transform:unset">'.$email.'</span>'); 
    $pdf->Info("Address:",$addr);
 $pdf->_InfoBox();
 //passport
    $pdf->InfoBox(2);
    $pdf->InfoTitle("PASSPORT PHOTOGRAPH");
    $pdf->Dump("<div style=\"margin:auto;margin-top:2px;margin-bottom:5px;width:180px;height:180px\">");
     $pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($passp)),"width:100%;height:100%;text-align:center");
     $pdf->Dump("</div>");
    $pdf->_InfoBox();
$pdf->_Panel();

$pdf->Panel();
  $pdf->InfoBox(2,"text-transform:uppercase");
   $pdf->InfoTitle("SCREENING DETAILS");
  //$pdf->Info("External Entrance Result:",$jamb);
  /*if($pdet['Subj_Comb'] == "YES"){
   $pdf->Info("Subject Combination:",$subjComb);
  } */
  if($pdet['ShowDate'] == "YES"){
  // $pdf->Info("Screening Date & Time:",$examDateTime);
  if(is_array($Times)){
      $dt = new DateTime($Times['Date']);
     $pdf->Info("Date & Time:",$Times['Day']. ", ".$dt->format("d-m-Y")." ".$Times['Time']);
    $pdf->Info("Panel:","<strong>".$Times['PanelName']."</strong> - ". $Times['Location']);
    }else{
      //$pdf->Info("Time:",$Times);
    }
  }
  if($pdet['ShowOtherDetails'] == 'TRUE'){
    
   
  // $pdf->Info("Venue:",$venue);
   //$pdf->Info("Seat Number:",$seatNo);
  }
  $pdf->Info("Access Code:",'<span style="text-transform:lowercase">'.$accC.'</span>');
$pdf->_InfoBox();
 $pdf->InfoBox(2,"text-transform:uppercase");
 if($paramarr['Cert'] == "Jamb"){
   $pdf->InfoTitle("UTME RESULT");
  $pdf->Info("Aggregate Score:",$jamb);
  if(trim($sunjCombJmb) != ""){
  $pdf->Info("Subject Combination:",$sunjCombJmb);
  }

}else{
  $pdf->InfoTitle("DIPLOMA RESULT DETAILS");
  $dipdet = explode("~",$othercert);
  if(count($dipdet) > 3){
    //hard code class of pass
    $cop = $dbo->SelectFirstRow("classofpass_tb","ClassName","ID=".$dipdet[2]);
    $pdf->Info("SCHOOL:",$dipdet[0]);
    $pdf->Info("GRAD. YEAR:",$dipdet[1]);
    $pdf->Info("CLASS OF PASS:",$cop[0]." ({$dipdet[3]})");
  }
}
$pdf->_InfoBox();
$pdf->_Panel();
/*$pdf->Panel();
  $pdf->InfoBox(4,"text-transform:uppercase");
   $pdf->InfoTitle("CONTACT DETAILS");
   
  $pdf->_InfoBox();
$pdf->_Panel();*/

//$sunjCombJmb
/*$pdf->Panel();
 
$pdf->_Panel();*/



$pdf->Panel();
//$pdf->InfoBox(4,"text-transform:uppercase");
  // $pdf->InfoTitle("EXTERNAL ENTRANCE RESULT");
  $rst = BreakDownRst(@$StudD['OlevelRstDetails'],@$StudD['OlevelRst']);
				$sitrealdarr1 = $rst[0];
				$sit1arr = $rst[1];
				$sitrealdarr2 = $rst[2];
				$sit2arr = $rst[3];
        $size = count($sit2arr) > 0?2:4;
    $pdf->InfoBox($size);
     $pdf->InfoTitle("OLEVEL RESULT");
     // $pdf->Info("EXAM. TYPE:",@$StudD['OlevelRst']);
     $exmb = (int)$sitrealdarr1[4] > 1?"EXTERNAL":"INTERNAL";
      $pdf->Info("EXAM. TYPE:",OlevelExam($sitrealdarr1[3]). " ($exmb)");
      $pdf->Info("EXAM. YEAR:",$sitrealdarr1[1]);
      $pdf->Info("SCHOOL:",$sitrealdarr1[0]);
      $pdf->Info("EXAM. NO.:",$sitrealdarr1[2]);
      //$pdf->InfoTitle(" ");
      if(count($sit1arr) > 0){
      $pdf->Table("margin-bottom:10px");
      $pdf->TableHead(array("SN","SUBJECT","GRADE"));
      for($f=0; $f<count($sit1arr); $f++){
			 $rrst = $sit1arr[$f];
			 $rrstarr = explode("=",$rrst);
		   $cnt = $f+1;
		   $subj = strtoupper(@$rrstarr[0]);
		   $grd = @$rrstarr[1];
		   //$grd = (trim($grd) == "D7" || trim($grd) == "E8" || trim($grd) == "F9")?"<span class=\"secondColor\">{$grd}</span>":$grd;
        $pdf->TableRow(array($cnt,$subj,$grd));
      }
      $pdf->_Table();
      }
      $pdf->_InfoBox();
      //$cnt =0;
      if(count($sit2arr) > 0){
      $pdf->InfoBox(2);
        $pdf->InfoTitle("OTHER OLEVEL RESULT");
        $exmb = (int)$sitrealdarr2[4] > 1?"EXTERNAL":"INTERNAL";
      $pdf->Info("EXAM. TYPE:",OlevelExam($sitrealdarr2[3]). " ($exmb)");
      $pdf->Info("EXAM. YEAR:",$sitrealdarr2[1]);
      $pdf->Info("SCHOOL:",$sitrealdarr2[0]);
      $pdf->Info("EXAM. NO.:",$sitrealdarr2[2]);
      $pdf->Table("margin-bottom:10px");
      $pdf->TableHead(array("SN","SUBJECT","GRADE"));
      for($f=0; $f<count($sit2arr); $f++){
			 $rrst = $sit2arr[$f];
			 $rrstarr = explode("=",$rrst);
		   $cnt = $f+1;
		   $subj = strtoupper(@$rrstarr[0]);
		   $grd = @$rrstarr[1];
		   //$grd = (trim($grd) == "D7" || trim($grd) == "E8" || trim($grd) == "F9")?"<span class=\"secondColor\">{$grd}</span>":$grd;
        $pdf->TableRow(array($cnt,$subj,$grd));
      }
      $pdf->_Table();

      
$pdf->_InfoBox();
      }
    
  $pdf->_Panel();
 // $pdf->Dump($NotObj);
if(!is_null($NotObj)){
  
$pdf->HTML();

  echo '<hr/><ol style="margin-top:10px;font-size:1.1em">';
  foreach($NotObj as $note){
    echo "<li>".$note."</li>";
  }
  echo "</ol>";
$pdf->_HTML();
}
$pdf->FooterNote(@$pdet['Title']);

$pdf->Finish();
?>
