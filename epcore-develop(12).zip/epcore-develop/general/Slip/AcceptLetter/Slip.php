<?php
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
$RegNo = @$_GET['RegNo'];
$RegID = isset($_GET["RegID"]) && (int)$_GET["RegID"] > 0?(int)$_GET["RegID"]:1; //the putme reg type that is calling the script, sent 


//$StudD = GetBasicInfo($RegNo,"all","",$RegID);
$query = "SELECT st.id, st.SurName, st.FirstName, st.OtherNames, st.RegNo, st.DOB, st.JambNo, st.Passport, st.Gender, st.Phone, st.Email, st.Addrs, st.NName, st.NAddrs, st.Nphone, st.StartSes, st.ModeOfEntry, st.RegDate, st.AdminDate, st.JambAgg, st.StudyID, fac.FacName, dpt.DeptName,se.SesName,se.Abbr as SesAbbr ,pr.ProgName, pr.YearOfStudy, pr.Degree, sd.*, st.OtherDet FROM studentinfo_tb st, fac_tb fac, dept_tb dpt, programme_tb pr,  session_tb se, study_tb sd WHERE (st.JambNo = '{$RegNo}' OR st.RegNo = '{$RegNo}') AND st.ProgID = pr.ProgID AND pr.DeptID = dpt.DeptID AND dpt.FacID = fac.FacID AND ((st.StartSes = se.SesID AND st.AdmSes = 0) OR st.AdmSes = se.SesID) AND st.StudyID = sd.ID ORDER BY st.RegID LIMIT 1";
$StudD = $dbo->RunQuery($query);
//$accC = @$ac['AccessCode'];
$name = "";

/*$gender = @$StudD['Gen'];
$fac = @$StudD['Fac'];
$dept = @$StudD['Dept'];
$prog = @$StudD['Prog'];
$passp = @$StudD['Passport'];
$passparr = explode("?",$passp);
$passp = $passparr[0];
$lga = GetLGA(@$StudD['lga']);
$state = GetState(@$StudD['StateId']);
$StudD['State'] = $state;
$StudD['LGA'] = $lga;
$phone = @$StudD['Phone'];
$email = @$StudD['Email'];
$addr = @$StudD['Addr'];
$jamb = @$StudD['jamb'];*/
$school = $dbo->SelectFirstRow("school_tb","Name as SchName,ShortAddr,LongAddr,logo,Abbr");
//$pdf->WaterMarkText($school['Abbr'],0.1);
$pdf->WaterMarkImage($pdf->BaseConfigPath.$school["logo"],0.07);

$acceptContent = "";
if(!is_array($StudD) || (int)@$StudD[1] < 1){
  $pdf->Banner("Offer of Admission" ,array("LogoSize"=>"100px*100px","WaterMark"=>"Abbr","Align"=>"Center","Style"=>"font-size:0.9em"));
  $acceptContent = "Cannot Load Student Information";
}else{
  $StudD = $StudD[0]->fetch_array();  
  $StudD = array_merge($StudD,$school);
  $StudD['AcceptLetterContents'] = NULl;
  //get the acceptance report content
  $rept = $dbo->SelectFirstRow("report_tb","Content","ID=".$StudD['AcceptLetterID']);
  //exit($rept['Content']);
if(is_array($rept))$StudD['AcceptLetterContents'] = $rept['Content'];
  $StudD['Now'] = date('F d, Y');
  $StudD['Session'] = $StudD['SesName'];
  if(trim($StudD['OtherDet']) != "")$StudD = array_merge($StudD,json_decode($StudD['OtherDet'],true));
  $StudD['StudyMode'] = (isset($StudD['StudyModeFullTime']) && (int)$StudD['StudyModeFullTime'] == 1)?"Full":"Part";
  //format the id
  $StudD['DBID'] = $StudD['id'];
  $PStudD = $dbo->SelectFirstRow("pstudentinfo_tb","","JambNo = '{$RegNo}' OR RegNo = '{$RegNo}' OR JambNo = '".$StudD['Email']."' OR RegNo = '".$StudD['Email']."'");
if(is_array($PStudD))$StudD['DBID'] = $PStudD['id'];
$lensid = strlen($StudD['DBID']."");
if($lensid < 4){
  $rem = 4 - $lensid;
  $StudD['DBID'] = str_repeat("0",$rem).$StudD['DBID'];
}

$StudD['DegreeName'] = "";
//get the school degree
if(isset($StudD['Degree']) && (int)$StudD['Degree'] > 0){
$DegreeDet = $dbo->SelectFirstRow("school_degrees_tb","","ID=".$StudD['Degree']);

if(is_array($DegreeDet)){
$StudD['DegreeName'] = $DegreeDet['Name'];
}

}

$StudD['BaseDir'] = $pdf->BaseConfigPath;
  //$StudyID = $StudD['StudyID'];
  
 // $formdet = $dbo->SelectFirstRow("study_tb","","ID = $StudyID");
  if(trim($StudD['AcceptLetterContents']) != "" && !is_null($StudD['AcceptLetterContents'])){
    $acceptContent = $StudD['AcceptLetterContents'];
    //furnish acceptance letter with data
    foreach($StudD as $key=>$val){
      if($key != "AcceptLetterContents")$acceptContent = str_replace('{{'.$key.'}}',$val,$acceptContent);
      
    }
  }else{
    $pdf->Banner("" ,array("LogoSize"=>"100px*100px","WaterMark"=>"Abbr","Align"=>"Center","Style"=>"font-size:0.9em"));
    $acceptContent = "Content Not Available, Contact the ICT Team";
  }
}



//$pdf->Banner("Offer of Admission" ,array("LogoSize"=>"100px*100px","WaterMark"=>"Abbr","Align"=>"Center","Style"=>"font-size:0.9em")); 
$pdf->HTML();
echo $acceptContent;
/*if(!is_array($StudD) || (int)@$StudD[1] < 1){
	echo "Cannot Load Student Information";
}else{
  $StudD = $StudD[0]->fetch_array();
  $StudD['Now'] = date('F d, Y');
$StudD['Session'] = $StudD['SesName'];
foreach($StudD as $key=>$val){
    $acceptContent = str_replace('{{'.$key.'}}',$val,$acceptContent);
  }
echo $acceptContent;
}*/
  
?>


<?php
$pdf->_HTML();

//$pdf->FooterNote(@$pdet['Title']);

//$pdf->WriteHTML();
$pdf->Finish();
?>
