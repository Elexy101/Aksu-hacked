<?php
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
 //simpaydate=29/01/2019&simbatch=8&simstudy=5&simfac=4&simdept=1&simprog=1&simlvl=1&simstate=3&simgender=M&simstatus=S&simmodeentry=1&simpaypol=1-2&PayID=2
 if(isset($_REQUEST['simbatch'])){
	$paydet = GetPaymentItem((int)$_REQUEST['PayID']);
	//get db details
	//fac details
	$facdet = $dbo->SelectFirstRow("fac_tb","","FacID=".$_REQUEST['simfac']);
	$progdet = $dbo->SelectFirstRow("programme_tb","","ProgID=".$_REQUEST['simprog']);
	$studydet = $dbo->SelectFirstRow("study_tb","","ID=".$_REQUEST['simstudy']);
	$statedet = $dbo->SelectFirstRow("state_tb","","StateID=".$_REQUEST['simstate']);
	$moedet = $dbo->SelectFirstRow("modeofentry_tb","","ID=".$_REQUEST['simmodeentry']);
	$gender = $_REQUEST['simgender'] == "M"?"MALE":"FEMALE";
	$mstatus = $_REQUEST['simstatus'] == "S"?"SINGLE":"MARIED";
	$StudD = ["Name"=>@$studydet['Name']." / ".@$facdet['FacName']. " / ".@$progdet['ProgName']. " / ".@$moedet['Name'],"ModeOfEntry"=>$_REQUEST['simmodeentry'],"StudyID"=>$_REQUEST['simstudy'],"StateId"=>$_REQUEST['simstate'],"Gender"=>$_REQUEST['simgender'],"MaritalStatus"=>$_REQUEST['simstatus'],"StartSes"=>$_REQUEST['simbatch'],"AdmSes"=>$_REQUEST['simbatch'],"ProgID"=>$_REQUEST['simprog'],"FacID"=>$_REQUEST['simfac'],"ClassID"=>$_REQUEST['simclass']];
$semarr = explode("-",$_REQUEST['simpaypol']);
$sem = (int)$semarr[0];
$sempart = isset($semarr[1])?(int)$semarr[1]:3;
$semdate = date("Y-m-d");
if(trim($_REQUEST['simpaydate']) != ""){
 $simdatearr = explode("/",$_REQUEST['simpaydate']);
 $semdate = $simdatearr[2]."-".$simdatearr[1]."-".$simdatearr[0];
}

	$order = ["Sem"=>$sem,"SemPart"=>$sempart,"TransNum"=>"00000000","ItemName"=>$paydet['ItemName'],"RegDate"=>$semdate,"Lvl"=>$_REQUEST['simlvl'],'Paid'=>0];
$PayID = $_REQUEST['PayID'];
$RegNo = @$statedet['StateName']. " / ".@$gender. " / ".@$mstatus;
$studpref = "";
$Channel = "ONLINE";
$PayVia = "CPORTAL";
 }else{
		$ItemNo = @$_REQUEST['ItemNo'];
	$RegID = isset($_REQUEST['RegID']) && trim($_REQUEST['RegID']) != ""?$_GET['RegID']:1;
	$BankPre = isset($_REQUEST["BankPre"]) ? $_REQUEST["BankPre"] : '';

	//get the student payment info by the itemno from order_tb
	$order = $dbo->Select4rmdbtbFirstRw("order_tb o LEFT JOIN payhistory_tb p ON o.TransNum = p.TransID ","o.*, COALESCE(p.Bank,o.Channel) as Bank","(o.ItemNo = '$ItemNo' or o.TransNum = '$ItemNo')");
	if(is_array($order)){
		/*ID 	ItemNo 	TransNum 	ItemName 	ItemDescr 	Amt 	Currency 	RegNo 	Sem 	Lvl 	ItemID 	Paid 	RegDate 	Ses*/
	$RegNo = @$order['RegNo'];
	$PayID = (int)@$order['ItemID'];
	$Channel = @$order['Channel'];
	$PayVia = $order['Bank'];
	//$StuddbPre = StudPreByPayID($PayID,$RegID);
	//$StuddbPre = (isset($_GET['pre']))?$_GET['pre']:"p";
	/*if((int)$PayID == 3){
	$StuddbPre = "p";	
	}*/
	//echo "$RegNo,'',$StuddbPre,$RegID";
	$StudD = GetBasicInfo($RegNo,"",$BankPre,$RegID);
	
	if(!is_array($StudD)){
		//$StudD = GetBasicInfo($RegNo,"","p",$RegID);
		$StudD = $dbo->SelectFirstRow("{$BankPre}studentinfo_tb","*, CONCAT(SurName,' ',FirstName,' ',OtherNames) as Name","RegNo='".$dbo->SqlSafe($RegNo)."' OR JambNo='".$dbo->SqlSafe($RegNo)."'",MYSQLI_ASSOC);
		$studpref = "p";
		
	$studpref = "";
		if(!is_array($StudD)){
	//try getting Details from payee_tb
	$StudD = $dbo->SelectFirstRow("payee_tb","","PayeeID='$RegNo' LIMIT 1");
	if(is_array($StudD)){
		$studpref = "g";
		$otherdet = $StudD['OtherDet'];
			if(trim($otherdet) != ""){
				$otherdet = json_decode($otherdet,true);
				$StudD = array_merge($StudD,$otherdet);
			}
	}

	}
	} 
 }
}
//print_r()


//ModeOfEntry
$name = "";
if(is_array($StudD)){
	$name = $StudD['Name'];
	//add other det to array
	if(trim($StudD['OtherDet']) != ""){
		$StudD = array_merge($StudD,json_decode($StudD['OtherDet'],true));
	}
}
$semPart = @$order['SemPart'] ;
$semPart = (int)$semPart < 1 || (int)$semPart > 3 ? 3:(int)$semPart;
$transNo = @$order['TransNum'];
$payType = @$order['ItemName'];
$payDescr = @$order['ItemDescr'];
if(!isset($order['PayScope']) || $order['PayScope'] != "w"){ //if not wallet payment
	$payPol = FormPayPolicy((int)$order['Sem'],$semPart);
}

$regDate = @$order['RegDate'];
$Lvl = @$order['Lvl'];
//$paydet = GetPaymentItem((int)$PayID);
$paydet = $dbo->RunQuery("SELECT it.*, tp.* FROM item_tb it, thirdparty_tb tp  WHERE it.PayGatewayID = tp.ID AND it.ID = {$PayID} LIMIT 1");
if(!is_array($paydet)){
	$pdf->Dump('Reading Payment Type Details Failed');
	$pdf->Finish();
	exit();
}
$paydet = $paydet[0]->fetch_assoc();
$loadlvl = PayLoadLevel((int)$Lvl,GetMOEID($StudD["ModeOfEntry"]));

$brDwn = PaymentBreakDown($paydet['PayBrkDn'],$loadlvl,(int)$order['Sem'],$StudD,$semPart,$regDate);
//exit($brDwn);
$totPrice = isset($_REQUEST['simbatch'])?$brDwn[0]:@$order['Amt'];
$paid = @$order['Paid'];
$pstatus = ($paid==1)?"PAID":"UNPAID";

$school = GetSchool();
$schoolType = SchoolType($school['Type']);
//$thirdPPayIDarr = array("ETRANZACT"=>"PAYEE ID","REMITA"=>"RRR");
//$thirdPPayID = isset($thirdPPayIDarr[$school["PayThirdParty"]])?$thirdPPayIDarr[$school["PayThirdParty"]]:"REFERENCE NO.";
$thirdPPayID = $paydet['RefIndicator'];
//$pdf->mpdf->showImageErrors = true;
//genearte pdf slip
$pdf->Banner($school['Name']." Payment Analysis",array("LogoSize"=>"100px*100px","WaterMark"=>$pstatus),$school);

$pdf->Panel();
 $pdf->InfoBox(4,"text-transform:uppercase");
 $pdf->InfoTitle("PAYMENT DETAILS");
 $pdf->Info("full name:",$name);
 $pdf->Info("Registration Number:",$RegNo);
 $pdf->Info("$thirdPPayID:",$transNo);
 $pdf->Info("Payment Type:",$payType);
 if(!isset($order['PayScope']) || $order['PayScope'] != "w"){ //if not wallet payment
 $pdf->Info("Payment Policy:",$payPol);
 }/* else{
	$pdf->Info("Description:",$payDescr);	 
 } */
 if((int)$StudD['StudyID'] > 0 && $studpref == ""){
	 if(isset($_REQUEST['simbatch'])){
		$LvlName = LevelName($Lvl,$StudD['StudyID']);
	 }else{
		$LvlName = LevelName($Lvl,$StudD['StudyID']);
		if(is_numeric($LvlName)){
			$spillStr = ExtraLevelString();
		$yearofSt = StudYearOfStudy($RegNo,$StuddbPre);
		if(((int)$Lvl - $yearofSt) > 0){
			$LvlName = $spillStr." ".((int)$Lvl - $yearofSt);
		}else{
			// $LvlName = LevelName($Lvl,$StudD['StudyID']);
			//$LvlName = "--";
		}
		}

		//get the student class
		$classdet = StudClass($RegNo);
         $ClassName = $classdet['Name']; 

	 }
	 
 $pdf->Info("Class:",$LvlName."(".$ClassName.")");

 }
 $dts = new DateTime($regDate);
$dts = $dts->format("d / m / Y");
 $pdf->Info("Date:",$dts);
 $pdf->Info("Channel:",$PayVia);
 $pdf->_InfoBox();
$pdf->_Panel();

//payment breakdown
$pdf->Table("");
$pdf->TableHead(array("S/N","ITEM DESCRIPTION","AMOUNT"));
$breakend = false;
$brDwn = isset($_REQUEST['simbatch'])?$brDwn:[$order['Amt'],number_format($order['Amt'], 2, '.', ','),$order['BrkDwn']];
if((float)$brDwn[0] == (float)$totPrice && (!isset($order['PayScope']) || $order['PayScope'] != "w")){
      if($brDwn[2]."" != ""){
		  $brArr = explode("***",$brDwn[2]);
		  $cnt = 0;
		  
		  if(count($brArr) > 0){
			  for($s =0; $s < count($brArr); $s++){
				  $it = $brArr[$s];
				  $itemAmt = explode("~",$it);
				  if(count($itemAmt) > 2){
					  $ItemName = $itemAmt[0];
					  $Amt = $itemAmt[1];
					  if(isset($itemAmt[4]) && (int)$itemAmt[4] == 1)continue;
					  $cnt++;
					 
	    $pdf->TableRow(array($cnt,strtoupper($ItemName),number_format($Amt, 2, '.', ',')));
				  }
			  }
			  
		  }
	  }
}else{
	$disItem = (isset($order['PayScope']) && $order['PayScope'] == "w")?$payDescr:$paydet['ItemName'];
	$pdf->TableRow(array(1,strtoupper($disItem),number_format($totPrice, 2, '.', ',')));
}
$pdf->Dump('<tr>
     <th colspan="2" style="font-weight: bolder; text-align:right">Total</td><th style="text-align:left">'.number_format($totPrice, 2, '.', ',').'</th>
   </tr>');
$pdf->_Table();

  
   
   $footerimg = trim($paydet["FooterImage"]);
   if($footerimg != "" && $Channel != "OFFLINE"){
	$html = '<p style="font-size:0.9em;padding-left:10px; margin-top:0px;">
	<strong>You can make payment in the Bank via '.$paydet["Name"].' Platform.</strong> <br />';
	$footerimg = str_replace("epconfig/","",$footerimg);
	$html .= '<img src="'.$pdf->BaseConfigPath.$footerimg.'" alt="'.$paydet["Name"].' FOOTER LOGO" style="max-width:98%" />';
   }
   /* if(strtolower($school["PayThirdParty"]) == "remita"){
     $html .= '<img src="'.$pdf->BaseConfigPath.'UserImages/App/Images/logo.png" alt="REMITA LOGO" width="300" />';
   }else{
	  $html .= '<span style="padding-bottom:30px"> Sterling Bank | UBA | FCMB | Zennith Bank | Enterprise Bank | Eco Bank | Diamond Bank | Union Bank | Unity Bank | WEMA | First Bank | GTB | Skye Bank | Keystone Bank | Access Bank</span><hr />'; 
   } */
   $html .= "</p><hr />";
$FooterNote = "Payment Analysis Slip";
$pdf->FooterNote($FooterNote,$html);
 if($Channel == "OFFLINE"){
	 $pdf->Dump('<div style="page-break-after: always;"></div>');
	
	 $baseurl = "../../";
	 $OrderID = $order['ID'];
	 $Waterm = $pstatus;
	 include $baseurl."cportal/Reports/Payment/offlinereceipt.php";
   }

$pdf->Finish();
?>