<?php
//echo "aaa";
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
 //exit("aaaa");

if(isset($_GET['regno'])){
	$regno = $_GET['regno'];
	//$lvl = (int)$_GET['lvl'];
	$sem = $_GET['Sem'];
	$binfo = GetBasicInfo($regno);
	//print_r($binfo);
	//$lvlarr = StudLevelSpill($regno);
	$lvl = $_GET['Lvl'];
	$yearofSt = StudYearOfStudy($regno,"");
		if(((int)$lvl - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
			$LvlName = strtoupper($spilstr)." ".((int)$lvl - $yearofSt);
		}else{
			$LvlName = LevelName($lvl,$binfo['StudyID']);
		}
		/*$filename = $qrtemp.'cr'.md5($_GET['regno'].'|'.$_GET['Sem'].'|'.$_GET['Lvl']).'.png';
		if(!file_exists($filename))
        QRcode::png(_CURURL_, $filename, $errorCorrectionLevel, $matrixPointSize, 2);*/
	/*$lvlc = $lvlarr[2];
	 $spill = "";
				 if($lvlarr[1] > 0){ //if spill over
					 $spill = "(SPILLOVER " . $lvlarr[1] .")";
					// $lvlcd = $lvlarr[0] + $lvlarr[1]; //get the calculated level
				 }*/

	//$ac = GetBasicInfo($regno,"ac");
}
$sch = $dbo->SelectFirstRow("school_tb");
//get the course reg details
$sqlregno = $dbo->SqlSave($regno);
	   $lvl = (int)$lvl;
	   $sem = (int)$sem;
	      $query = "SELECT c.*, s.SesName, sm.Sem FROM coursereg_tb c, session_tb s, semester_tb sm WHERE c.SesID = s.SesID AND c.RegNo = '{$sqlregno}' AND c.Lvl = {$lvl} AND c.Sem = {$sem} AND c.Sem = sm.Num LIMIT 1";
		$rst = $dbo->RunQuery($query);
		$sesName = "";
		$semName = "";
		$rstarr = NULL;
		if(is_array($rst)){
			if($rst[1] > 0){
              $rstarr = $rst[0]->fetch_array();
              $sesName = $rstarr['SesName'];
              $semName = $rstarr['Sem'];
			}
		}
		if(trim($sesName) == ""){
          $ses = CurrentSes(); $sesName = $ses[1];
		}

$pdf->Banner(strtoupper("Course Registration Form"),array("LogoSize"=>"80px*80px","WaterMark"=>"Abbr"));
$pdf->Panel();
  $pdf->InfoBox(2.5,"text-transform:uppercase");
    $pdf->InfoTitle("BASIC DETAILS");
	$pdf->Info("Reg. Number:",$regno);
	$pdf->Info("Name:",$binfo['Name']);
	$pdf->Info("Faculty:",$binfo['Fac']);
	$pdf->Info("Department:",$binfo['Dept']);
	$pdf->Info("Subject of Study:",$binfo['Prog']);
	$pdf->Info("Session:",$sesName);
	$pdf->Info("Level of Course:",$LvlName);
	$regCourse = array("First","Second","Third");
	if($semName == ""){
		$pdf->Info($sch['SemLabel'].":",$regCourse[((int)$sem - 1)]);
	}else{
		$pdf->Info($sch['SemLabel'].":",$semName);
	}
	
  $pdf->_InfoBox();
//passport
    $pdf->InfoBox(1.5);
    $pdf->InfoTitle("PASSPORT PHOTOGRAPH");
    $pdf->Dump("<div style=\"margin:auto;margin-top:2px;margin-bottom:5px;width:180px;height:180px\">");
	$passpp = str_replace("../epconfig","",trim($binfo['Passport']));
	$passpp = explode("?",$passpp);
	$passpp = $passpp[0];
	//if(strpos($passpp,'../epconfig'))
     $pdf->Image(rtrim($pdf->BaseConfigPath,"/")."/".ltrim($passpp,"/"),"width:100%;height:100%;text-align:center");
     $pdf->Dump("</div>");
    $pdf->_InfoBox();
$pdf->_Panel();
$pdf->HTML();
?>
<table cellpadding="3" border="1" cellspacing="0" style="border-collapse:collapse; font-size:0.9em; margin-top:10px" width="100%">
     <thead>
       <tr>
	   <th width="5%">S/N </th>
          <th width="15%">COURSE CODE </th>
          <th width="40%">COURSE TITLE </th>
          <th width="15%">CREDIT UNITS </th>
          <th width="25%">SIGNATURE </th>
       <tr>
       </thead>
       <?php
	   

			
	if(!is_null($rstarr)){
		//if($rst[1] >0){
			$rstt = $rstarr;
			$selectedC = $rstt['CoursesID'];
			$selectedC = ResolveRegCourses($selectedC);
			
			//$sarr = explode("~",$selectedC);
			//if(count($sarr) > 0 ){
			if(trim($selectedC) != ""){
				//sort($sarr);
				//print_r($sarr);
				//get all courses 
				$condc = "CourseID=".str_replace("~"," OR CourseID=",$selectedC);
				//for aksu sorted by level, akscoe by CourseCode
				$orderi = "Lvl"; //aksu
				//$orderi = "CourseCode";  //akscoe
				$coursesDis = $dbo->RunQuery("Select * from course_tb where $condc order by $orderi");
				$tot = 0;
				if($coursesDis[1] > 0){
				//for($f=0; $f< count($sarr); $f++){
					$cnt = 1;
				while($corsearr = $coursesDis[0]->fetch_array()){
					//$course = $sarr[$f];
					//$corsearr=CourseDetails($course);
					//$corsearr = explode("~~",$course);
					if(is_array($corsearr)){
					$tot += (int)$corsearr["CH"];
					?>
                    <tr>
					<td style="text-transform:uppercase"><?php echo $cnt ?></td>
                <td style="text-transform:uppercase"><?php echo $corsearr["CourseCode"] ?></td>
             <td style="text-transform:uppercase"><?php echo $corsearr["Title"] ?></td>
             <td style="text-align:center;"><?php echo $corsearr["CH"] ?></td>
             <td>&nbsp;</td>
             </tr>
           
                    <?php
					$cnt++;
					}
				}
				
				?>
                <tr  style="">
               
             <th colspan="3">&nbsp;</td>
             <th style=""><?php echo $tot ?></th>
             <th>&nbsp;</th>
             </tr>
                <?php
				}
			}
		//}
	}
	   
	   ?>
       
   
   </table>

<?php
$pdf->_HTML();
$pdf->FooterNote("Course Registration Form",$pdf->Signataries(array("STUDENT","ACADEMIC ADVISER","HOD","DEAN")));
$pdf->Finish();
?>
