<?php
$sch = $dbo->SelectFirstRow("school_tb");
$pdf->Banner(strtoupper("Course Registration Form"),array("LogoSize"=>"80px*80px","WaterMark"=>"Abbr"));
$Error = "";
/* $pdf->HTML();
echo $_GET['CourseRegID'];
$pdf->_HTML(); */
//check if CourseRegID is set
if(!isset($_GET['CourseRegID']) || (int)$_GET['CourseRegID'] == 0){
    $Error = "INVALID COURSE REGISTRATION";
}else{
    //Get the All Details
    $query = "SELECT cr.*, CONCAT(st.SurName,' ',st.FirstName,' ',st.OtherNames) as StudName,f.FacName,d.DeptName,p.ProgName,sm.Sem,ss.SesName,p.YearOfStudy,IF(st.RegNo = '',st.JambNo,st.RegNo) as StudRegNo,st.Passport,st.StudyID FROM coursereg_tb cr, studentinfo_tb st, fac_tb f, dept_tb d, programme_tb p, semester_tb sm, session_tb ss WHERE cr.ID = {$_GET['CourseRegID']} AND (cr.RegNo = st.RegNo OR cr.RegNo = st.JambNo) AND st.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND cr.Sem = sm.Num AND cr.SesID = ss.SesID LIMIT 1";
    // $query = "SELECT cr.*, CONCAT(st.SurName,' ',st.FirstName,' ',st.OtherNames) as StudName,f.FacName,d.DeptName,p.ProgName,IF(l.Descr = '',l.Name,l.Descr) as LevelName,sm.Sem,ss.SesName,p.YearOfStudy,IF(st.RegNo = '',st.JambNo,st.RegNo) as StudRegNo,st.Passport FROM coursereg_tb cr, studentinfo_tb st, fac_tb f, dept_tb d, programme_tb p, schoollevel_tb l, semester_tb sm, session_tb ss WHERE cr.ID = {$_GET['CourseRegID']} AND (cr.RegNo = st.RegNo OR cr.RegNo = st.JambNo) AND st.ProgID = p.ProgID AND p.DeptID = d.DeptID AND d.FacID = f.FacID AND cr.Sem = sm.Num AND cr.lvl = l.Level AND l.StudyID = st.StudyID AND cr.SesID = ss.SesID LIMIT 1";
    $rst = $dbo->RunQuery($query);
    if(!is_array($rst) || $rst[1] < 1){
        $Error = "Reading Details Failed";
    }else{
        $rst = $rst[0]->fetch_assoc();
        //get the level
        $LvlName = GetLevelNameI($rst['Lvl'],$rst['StudyID'],$rst['StudRegNo']);

$pdf->Panel();
  $pdf->InfoBox(2.5,"text-transform:uppercase");
    $pdf->InfoTitle("BASIC DETAILS");
	$pdf->Info("Reg. Number:",$rst['StudRegNo']);
	$pdf->Info("Name:",$rst['StudName']);
	$pdf->Info("Faculty:",$rst['FacName']);
	$pdf->Info("Department:",$rst['DeptName']);
	$pdf->Info("Subject of Study:",$rst['ProgName']);
    $pdf->Info("Session:",$rst['SesName']);
	/* $yearofSt = (int)$rst['YearOfStudy'];
		if(((int)$rst['Lvl'] - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
			$LvlName = strtoupper($spilstr)." ".((int)$rst['Lvl'] - $yearofSt);
		}else{
			$LvlName = $rst['LevelName'];
		} */
	$pdf->Info("Level of Course:",$LvlName['LevelName']);
		$pdf->Info($sch['SemLabel'].":",$rst['Sem']);
  $pdf->_InfoBox();
//passport
    $pdf->InfoBox(1.5);
    $pdf->InfoTitle("PASSPORT PHOTOGRAPH");
    $pdf->Dump("<div style=\"margin:auto;margin-top:2px;margin-bottom:5px;width:180px;height:180px\">");
	$passpp = str_replace("../epconfig","",trim($rst['Passport']));
	$passpp = explode("?",$passpp);
	$passpp = $passpp[0];
	if(file_exists(rtrim($pdf->BaseConfigPath,"/")."/".ltrim($passpp,"/"))){
     $pdf->Image(rtrim($pdf->BaseConfigPath,"/")."/".ltrim($passpp,"/"),"width:100%;height:100%;text-align:center");
     
    }else{
        $pdf->Image("../images/App/Images/userbig.jpg","width:100%;height:100%;text-align:center");
       
	}
     $pdf->Dump("</div>");
     
    $pdf->_InfoBox();
$pdf->_Panel();
$pdf->HTML();
?>
<table cellpadding="3" border="1" cellspacing="0" style="border-collapse:collapse; font-size:0.9em; margin-top:10px" width="100%">
     <thead>
       <tr>
	   <th width="5%">S/N </th>
          <th width="15%">COURSE CODE </th>
          <th width="40%">COURSE TITLE </th>
          <th width="15%">CREDIT UNITS </th>
          <th width="25%">SIGNATURE </th>
       <tr>
       </thead>
       <?php
	   

			$selectedC = $rst['CoursesID'];
            $selectedCDet = $rst['CouresRegData'];
            if(trim($selectedCDet) == ""){
                //Registered from old portal
                $selectedC = ResolveRegCourses($selectedC);
			
			//$sarr = explode("~",$selectedC);
			//if(count($sarr) > 0 ){
			if(trim($selectedC) != ""){
				//sort($sarr);
				//print_r($sarr);
				//get all courses 
				$condc = "CourseID=".str_replace("~"," OR CourseID=",$selectedC);
				//for aksu sorted by level, akscoe by CourseCode
				$orderi = "Lvl"; //aksu
				//$orderi = "CourseCode";  //akscoe
				$coursesDis = $dbo->RunQuery("Select * from course_tb where $condc order by $orderi");
				$tot = 0;
				if($coursesDis[1] > 0){
				//for($f=0; $f< count($sarr); $f++){
					$cnt = 1;
				while($corsearr = $coursesDis[0]->fetch_array()){
					//$course = $sarr[$f];
					//$corsearr=CourseDetails($course);
					//$corsearr = explode("~~",$course);
					if(is_array($corsearr)){
					$tot += (int)$corsearr["CH"];
					?>
                    <tr>
					<td style="text-transform:uppercase"><?php echo $cnt ?></td>
                <td style="text-transform:uppercase"><?php echo $corsearr["CourseCode"] ?></td>
             <td style="text-transform:uppercase"><?php echo $corsearr["Title"] ?></td>
             <td style="text-align:center;"><?php echo $corsearr["CH"] ?></td>
             <td>&nbsp;</td>
             </tr>
           
                    <?php
					$cnt++;
					}
				}
				
				?>
                <tr  style="">
               
             <th colspan="3">&nbsp;</td>
             <th style=""><?php echo $tot ?></th>
             <th>&nbsp;</th>
             </tr>
                <?php
				}
			}
            }else{
                //Registered from new portal
                $Coursdet = json_decode($selectedCDet,true);
                $tot = 0;
                $cnt =1;
                if(count($Coursdet) > 0){
                    foreach($Coursdet as $CourseID => $IndCourseDet){
                        $tot += (int)$IndCourseDet["CH"];
                       // $cnt++;
					?>
                    <tr>
					<td style="text-transform:uppercase"><?php echo $cnt ?></td>
                <td style="text-transform:uppercase"><?php echo $IndCourseDet["CourseCode"] ?></td>
             <td style="text-transform:uppercase"><?php echo $IndCourseDet["Title"] ?></td>
             <td style="text-align:center;"><?php echo $IndCourseDet["CH"] ?></td>
             <td>&nbsp;</td>
             </tr>
           
                    <?php
					$cnt++;
                    }
                    ?>
                <tr  style="">
               
             <th colspan="3">&nbsp;</td>
             <th style=""><?php echo $tot ?></th>
             <th>&nbsp;</th>
             </tr>
                <?php
                }
            }//Registered from new portal - Ends
			
		//}
	
	   
	   ?>
       
   
   </table>

<?php
$pdf->_HTML();
    }


    /*  */
}

if(trim($Error) != ""){
    $pdf->HTML();
echo $Error;
    $pdf->_HTML();
}
$pdf->FooterNote("Course Registration Form",$pdf->Signataries(array("STUDENT","ACADEMIC ADVISER","HOD","DEAN"),"",true));
$pdf->Finish();




?>