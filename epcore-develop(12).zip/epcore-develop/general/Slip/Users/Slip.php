<?php
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
 
 require_once("TaquaLB/Elements/Elements.php");
 $uid = "";
if(isset($_GET['UID'])){
	$uid = $_GET['UID'];
	
}
//exit('jjj');
$pdf->Banner("CONTROL PORTAL USERS",array("LogoSize"=>"100px*100px","WaterMark"=>"Abbr"));
$pdf->FooterNote("CONTROL PORTAL USERS");
if($uid == ""){
	  $pdf->Dump("<h1>Invalid User</h1>");
  }else{
		$cond = "";
	if((int)$uid > 0){
		$cond = "UserID = $uid";
	}
	$userdet = $dbo->Select("user_tb","",$cond);
	if(is_array($userdet)){
		if($userdet[1] > 0){
			while($user = $userdet[0]->fetch_array()){ 
              $pdf->Panel();
              $pdf->InfoBox(1.5);
				$pdf->InfoTitle("PASSPORT PHOTOGRAPH");
				list($width, $height, $type, $attr) = getimagesize($pdf->BasePath."UserImages/{$user['UserID']}.jpg");
	        list($w,$h,$o) = AutoFit(150,150,$width,$height,3);
				$pdf->Dump("<div style=\"margin:auto;margin-top:2px;margin-bottom:5px;width:{$w}px;height:{$h}px\">");
				$pdf->Image(rtrim($pdf->BasePath,"/")."/UserImages/{$user['UserID']}.jpg","width:100%;height:100%;text-align:center");
				$pdf->Dump("</div>");
			$pdf->_InfoBox();

			$pdf->InfoBox(2.5);
              $pdf->InfoTitle("USER DETAILS");
			  $pdf->Info("USER NAME:",strtoupper($user['UserName']));
			  $pdf->Info("PUID:",$user['UserID']);
			  $pdf->Info("EMAIL/LOGIN:",$user['UserLogName']);
			  $pdf->InfoTitle("PRIVILEGES");
			  $priv = $user['Privs'];
  
        $privarr = explode(":",$priv);
		if(count($privarr) > 0){ //if user priv exist
			$menus = $dbo->Select("menu_tb");
			if(is_array($menus)){
				if($menus[1] > 0){
					while($menu = $menus[0]->fetch_array()){
					 $list = "";
                      $menuName = $menu['DName'];
					  $menutabs = $menu['Tabs'];
					  $mentTabsArr = $dbo->DataArray($menutabs);
					  foreach($mentTabsArr as $tabid => $tabName){
						  if(in_array($tabid,$privarr)){
                            $list .= $tabName." | ";
						  }
					  }
					  $list = str_replace("|","<strong>|</strong>",rtrim($list," | "));
					  if($list != ""){
						 $pdf->Info(strtoupper($menuName.":"),$list);
					  }
					}
				}
			}
		}
              $pdf->_InfoBox();
			  $pdf->_Panel();

			}

		}
	} 
  }
$pdf->Finish();
?>
