<?php
error_reporting(0);
/* include("../../../TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../PHP/getinfo.php");//hold basic functions to perform some common database operations or request*/
 //the caller or script that include it should also include the config and getinfo
 $sch = $dbo->SelectFirstRow("school_tb");
if(isset($_GET['Regno'])){
	$regno = $_GET['Regno'];
	//$lvl = (int)$_GET['lvl'];
	$sem = $_GET['Sem'];
	$binfo = GetBasicInfo($regno);
	//$lvlarr = StudLevelSpill($regno);
	$lvl = $_GET['Lvl'];
	$yearofSt = StudYearOfStudy($regno,"");
		if(((int)$lvl - $yearofSt) > 0){
			$spilstr = ExtraLevelString();
			$LvlName = strtoupper($spilstr)." ".((int)$lvl - $yearofSt);
		}else{
			$LvlName = LevelName($lvl,$binfo['StudyID']);
		}
	/*$lvlc = $lvlarr[2];
	 $spill = "";
				 if($lvlarr[1] > 0){ //if spill over
					 $spill = "(SPILLOVER " . $lvlarr[1] .")";
					// $lvlcd = $lvlarr[0] + $lvlarr[1]; //get the calculated level
				 }*/

	//$ac = GetBasicInfo($regno,"ac");
}else{

}
$GPA = "";
$CGPA = "";
$rsthtml = "";
$SesName = "";
$sqlRegNo = $dbo->SqlSave($regno);
   $lvl = (int)$lvl;
   $sem = (int)$sem;
	 $rsult = $dbo->RunQuery("select * from result_tb where RegNo='{$sqlRegNo}' and Lvl = {$lvl} and Sem = {$sem} ORDER BY GroupID DESC LIMIT 1");
	 if(is_array($rsult)){
		 if($rsult[1] > 0){
			 $SemCourses = GetCourses($binfo['ProgID'],$lvl, $sem);
			 //get grading details
		$grdstr = $dbo -> SelectFirstRow("resultinfo_tb","","ID = (select GrdStrucID from school_tb limit 1)");
		$classPassStr = $grdstr['ClassOfPass'];
		//$classPassDetAll = GetClassPassDetAll();
          $grdstr = is_array($grdstr)?$grdstr[1]:"";
          $schgrdstr = GetGradeDetAll();
		  $rstarr = $rsult[0]->fetch_array();
		  $results = $rstarr['Rst'];
			$SesName = SessionName($rstarr['SesID']);
			$SemName = SemesterName($rstarr['Sem']);
		  $CCH = $rstarr['CCH'];
		  $CGP = $rstarr['CGP'];
		  if(trim($results) != ""){
			  //break into individual result
			  $indrst = explode("&",$results);
			  if(count($indrst) == 0){
				  $rsthtml = "RST003: Looks like you have no Result Yet or Result not yet Available."; 
				 // $pdf->Finish();
                 //exit();
			  }
//$pdf->HTML();

 $rsthtml = '<table>
     <thead>
       <tr style="text-wrap: normal; overflow:hidden;">
          <th width="">S/N</th>
          <th width="">CODE</th>
          <th width="">TITLE</th>
          <th width="">CA</th>
          <th width="">EXAM</th>
          <th width="">TOTAL</th>
          <th width="">GRADE</th>
       <tr>
       </thead>';

//$pdf->_HTML();
$tch = 0;
			 $tgp = 0;
			 $cnt = 1;
			  for($a =0; $a < count($indrst); $a++){
				  $result = $indrst[$a];
				  if(trim($result) != ""){
					  //break to form result details
					  $resultdet = explode("=",$result);
					  if(count($resultdet) == 2){
						  $courseID = $resultdet[0];
						  $rawscr = $resultdet[1];
						  $rawscrarr = explode("|",$rawscr);
						  $CA = (float)$rawscrarr[0];
						  $Exm = (float)$rawscrarr[1];
						  $courseDet = isset($SemCourses[$courseID])?$SemCourses[$courseID]:CourseDetails($courseID);
						  if(is_array($courseDet)){
							  $Cd = trim($courseDet['CourseCode']);
							  $tit = strtoupper($courseDet['Title']);
							  $CH = $courseDet['CH'];
							  
							$tot = $CA + $Exm;
								//get grade 
							$grds = GetGrade($tot,$grdstr,$schgrdstr);
								$pass = (int)$grds["PASS"];
							$grdval = $grds["Grade"];
							$tch += (int)$CH;
							$tgp += (int)$CH * (int)$grds["Level"];
							$rsthtml .= "<tr><td>".$cnt."</td><td>".str_replace(" ","&nbsp;",$Cd)."</td><td>".str_replace(" ","&nbsp;",$tit)."</td><td>".$CA."</td><td>".$Exm."</td><td>".$tot."</td><td>".$grdval."</td></tr>";
							$cnt++;
							//$arrval2[] = array(array("title={$tit}"),array(str_replace(" ","&nbsp;",$Cd),str_replace(" ","&nbsp;",$tit),"[{$CA}]","[{$Exm}]",$tot,$grdval)); 
						  }
					  }
					  /*if(count($resultdet) == 3){
						 $courseID = $resultdet[0];
						 $CA = (float)$resultdet[1];
						 $Exm = (float)$resultdet[2];
						  $courseDet = CourseDetails($courseID); //get the course Details
						  if(is_array($courseDet)){
							  $Cd = trim($courseDet['CourseCode']);
							  $tit = strtoupper($courseDet['Title']);
							  $CH = $courseDet['CH'];
							  $tot = $CA + $Exm;
							  $grd = GetGrade($tot);
							 // $grdd = $grd. "-" .GetPoint($grd);
							$arrval2[] = array(array("title={$tit}"),array(str_replace(" ","&nbsp;",$Cd),str_replace(" ","&nbsp;",$tit),"[{$CA}]","[{$Exm}]",$tot,$grd));  
						  }
					  }*/
				  }
			  }
$rsthtml .="</table>";
$GPA = $tch > 0?number_format($tgp/$tch,2):"0.00";
$usecgpa = $GPA;
	 if($lvl == 1 && $sem == 1){
		 $CGPA = "";
	 }else{
	$CGPA = $CCH > 0?number_format($CGP/$CCH,2):"0.00";
	$usecgpa = $CGPA;
	 }
	 $classPassdet = GetClassPass($usecgpa,$classPassStr);
    $classOfPass = is_array($classPassdet)?$classPassdet['ClassName']:"";
		  }else{
			  $rsthtml = "RST004: Looks like you have no Result Yet or Result not yet Available.";
		  }
		 }else{
			 $rsthtml = "RST002: Looks like you have no Result Yet or Result not yet Available.";
		 }
	 }else{
		 $rsthtml = "RST001: We Encounter an Internal Problem, Loading your Result. Kindly Report this Error Message to the ICT Team";
	 }

	 //generate pdf
	 $pdf->Banner(strtoupper("Result Sheet"),array("LogoSize"=>"80px*80px","WaterMark"=>"Abbr"));
$pdf->Panel();
  $pdf->InfoBox(2.5,"text-transform:uppercase");
    $pdf->InfoTitle("BASIC DETAILS");
	$pdf->Info("Reg. Number:",$regno);
	$pdf->Info("Name:",$binfo['Name']);
	$pdf->Info("Faculty/School:",$binfo['Fac']);
	$pdf->Info("Department:",$binfo['Dept']);
	$pdf->Info("Programme:",$binfo['Prog']);
	$pdf->Info("Session:",$SesName);
	$pdf->Info("Level of Result:",$LvlName);
	$regCourse = array("First","Second","Third"); 
	if($SemName == ""){
		$pdf->Info($sch['SemLabel'].":",$regCourse[((int)$sem - 1)]);
	}else{
		$pdf->Info($sch['SemLabel'].":",$SemName);
	}
	
	
  $pdf->_InfoBox();
//passport
    $pdf->InfoBox(1.5);
    $pdf->InfoTitle("PASSPORT PHOTOGRAPH");
    $pdf->Dump("<div style=\"margin:auto;margin-top:2px;margin-bottom:5px;width:180px;height:180px\">");
     $pdf->Image($pdf->BaseConfigPath.str_replace("../epconfig","",trim($binfo['Passport'])),"width:100%;height:100%;text-align:center");
     $pdf->Dump("</div>");
    $pdf->_InfoBox();
$pdf->_Panel();
$pdf->Panel();
 $pdf->InfoBox(4,"text-transform:uppercase");
  $pdf->InfoTitle("RESULT DETAILS");
	$pdf->Info("Grade Point Average:",$GPA);
	if($CGPA != ""){
     $pdf->Info("Cum. Grade Point Average:",$CGPA);
	}
	$pdf->Info("Class of Pass:",$classOfPass);
 $pdf->_InfoBox();
$pdf->_Panel();
$pdf->Dump($rsthtml);
$pdf->FooterNote("Result Sheet - ".$regno,$pdf->Signataries(array("STUDENT","ACADEMIC ADVISER","HOD")));
$pdf->Finish();
?>
