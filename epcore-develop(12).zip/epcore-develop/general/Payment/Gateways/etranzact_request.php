<?php
include("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request
//PAYEE_ID=XXXX&PAYMENT_TYPE=XXXXGetPayInfo
if(isset($_REQUEST['PAYEE_ID']) ){
$payeeID = $_REQUEST['PAYEE_ID'];
$payType = @$_REQUEST['PAYMENT_TYPE'];


echo GetPayInfo($payeeID,$payType);

}


?>