<?php
include("../../../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php"); //the configuration object (connection parameters)
include("../../../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request

$ip = $_SERVER['HTTP_CLIENT_IP']?$_SERVER['HTTP_CLIENT_IP']:($_SERVER['HTTP_X_FORWARDE‌​D_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR']);
$local = "127.0.0.1";
$demo = "197.255.244.10";$live = "197.255.244.5";
$ip = trim($ip);
if($ip == $local){
    if(!isset($_REQUEST['RECEIPT_NO']) || !isset($_REQUEST['TRANS_AMOUNT']) || !isset($_REQUEST['TRANS_DATE']) || !isset($_REQUEST['BANK_NAME']) || !isset($_REQUEST['BRANCH_NAME']) || empty($_REQUEST['RECEIPT_NO']) || empty($_REQUEST['TRANS_AMOUNT'])){
        exit("Transaction Status = false 3");
        //exit;
    }
  $payeeID = $dbo->SqlSafe($_REQUEST['CUSTOMER_ID']);
  $amt = (float)$_REQUEST['TRANS_AMOUNT'];
  $trans_Date = $_REQUEST['TRANS_DATE'];
  $bank = $_REQUEST['BANK_NAME'];
  $bankBranch = $_REQUEST['BRANCH_NAME'];
 $datearr = explode(" ",$trans_Date);
 $dateonly = $datearr[0];
 $dateonlyarr = explode("/",$dateonly);
 $dateonlyarr = array_reverse($dateonlyarr);
 $datemysql = implode("-",$dateonlyarr);
 $payhist = $dbo->Select4rmdbtbFirstRw("payhistory_tb","","TransID = '$payeeID' limit 1");
 if(is_array($payhist)){
exit("Transaction Status = false 1");
 }
 //get the order details using the payyeeID
 $orderdet = $dbo->Select4rmdbtbFirstRw("order_tb","","TransNum = '$payeeID' limit 1");
								if(!is_array($orderdet)){//order not found
                                   exit("Transaction Status = false -1");
								}else{
                                    $amtord = (float)$orderdet['Amt'];
                                    if($amt != $amtord){
                                      exit("Transaction Status = false 4");
                                    }
                                   $dbo->Bigin();
								   $inst = $dbo->Insert2DbTb(array(
									                      "RegNo"=>$orderdet['RegNo'],
														  'Lvl'=>$orderdet['Lvl'],
														  'Sem'=>$orderdet['Sem'],
														  'Ses'=>$orderdet['Ses'],
														  'Amt'=>$orderdet['Amt'],
														  'TransID'=>$orderdet['TransNum'],
														  'PayID'=>$orderdet['ItemID'],
														  'itemNum'=>$orderdet['ItemNo'],
														  'PayDate'=>$datemysql,
                                                          'Bank'=>$bank,
													'BnkBranch'=>$bankBranch,
													'Info'=>StudPatchDet($orderdet['RegNo'],$orderdet['ItemID'],$orderdet['Lvl']),
													'TransAmt'=>$orderdet['Amt']
														  ),"payhistory_tb");
								 //Updatedbtb($tb,$fieldsValeus,$cond = ""){
								 $updt = $dbo->Updatedbtb("order_tb",array('Paid'=>1),"TransNum = '$payeeID'");
								 if($inst == "#" && is_array($updt)){
									 $dbo->Commit();
                                     exit("Transaction Status = true");
								 }else{

									 $dbo->Rollback();
									 exit('Transaction Status = false -1');
								 }
								}
}else{
    echo "Transaction Status = false -1"; //wrong ip 
}

//confirm if order found

//echo $ip;
?>