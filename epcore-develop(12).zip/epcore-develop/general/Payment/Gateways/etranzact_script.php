<?php

function EGetData($data,$PayID){
    global $dbo;
    $dataarr = $dbo->DataArray($data,"`",$keyItem = "~");
    if(isset($dataarr[''.$PayID]))return $dataarr[''.$PayID];
    if(isset($dataarr['-1']))return $dataarr['-1'];
    return "";
}

function EInit($param){
    global $dbo;
    $transnums = generateTransInfoOnly();
    return ["Ref"=>$transnums[1]];
}


function EPayNow($param){
    
        //Generate your own unique transId per transaction.
$time = time();
$transId = $param["Ref"];
//10000000000001etz1554379169webhttp://localhost:81/projects/Webconnect/response.phpRXeQfW7pf4PmIi9w
//10000000000001etz1554379169webhttp://localhost:81/projects/Webconnect/response.phpRXeQfW7pf4PmIi9w
//if ($transId==null) $transId="Peter123456787898fff7tt";

$terminalId = EGetData($param["TERMINALID"],$param["PayID"]);
//return ["Markup"=>$terminalId];
//if ($terminalId == null) $terminalId = "0000000001";
//$success = $HTTP_POST_VARS["SUCCESS"];
$amount = $param["Amt"];
$responseurl = explode("?",$param["FinishUrl"   ]);
$responseurl = $responseurl[0];
//if ($amount == null) $amount = 1000;
//session_register("TOTAL");
//echo "Amount Charged: ".$amount;
/* {"Name":"WALTER VICTORIA IDORENYIN","ProgID":"39","ProgName":"Economics","DeptID":"31","DeptName":"Economics","FacID":"5","FacName":"Social Sciences","StartSes":"7","ModeOfEntry":"1","StudyID":"5","RegID":"1","ClassName":"Regular","LevelName":"400","PayName":"AKSU SCHOOL FEE"} */
$info = json_decode($param['Info'],true);
$descr = $info['PayName'].' | '. $info['FacName'].' | '.$info['ProgName'].' | '.$info['LevelName'];
//if ($descr == null) $descr = "Payment";
$secret_key=EGetData($param["SECRETKEY"],$param["PayID"]);
$str=$amount.$terminalId.$transId.$responseurl.$secret_key;
$checksum=md5($str);
$cheksum=md5($str);
$posturl = EGetData($param["POSTURL"],$param["PayID"]);
$logo = !isset($param['LOGO'])?EGetData($param["LOGOURL"],$param["PayID"]):$param['LOGO'];

		$form =  "<form method='POST' action='".$posturl."'>
            <input type='hidden' name='TERMINAL_ID' value='".$terminalId."'>
            <input type='hidden' name = 'TRANSACTION_ID' value='".$transId."'>
            <input type='hidden' name = 'AMOUNT' value='".$amount."'>
            <input type='hidden' name = 'DESCRIPTION' value='".$descr."'>
            <input type='hidden' name = 'EMAIL' value='".$param["Email"]."'>
            <input type='hidden' name = 'CURRENCY_CODE' value='NGN'>
            <input type='hidden' name = 'RESPONSE_URL' value='".$responseurl."'>
            <input type='hidden' name = 'CHECKSUM' value='".$cheksum."'> 
            <input type='hidden' name = 'FULL_NAME' value=\"".$param["Name"]."\"> 
            <input type='hidden' name = 'LOGO_URL' value='".$logo."'>
            <input type='hidden' name = 'PHONENO' value='".$param["Phone"]."'>
            
            </form>
            <script language='javascript'>
            var form = document.forms[0];
            form.submit()</script>";
            $formdata = array(
                'TERMINAL_ID' => $terminalId,
                'TRANSACTION_ID' => $transId,
                'AMOUNT' => $amount,
                'DESCRIPTION' => $descr,
                'EMAIL' => $param["Email"],
                'CURRENCY_CODE' => 'NGN',
                'RESPONSE_URL' => $responseurl,
                'CHECKSUM' => $cheksum,
                'FULL_NAME' => $param["Name"],
                'LOGO_URL' => $logo,
                'PHONENO' => $param["Phone"]
            );
	return ["Markup"=>$form,"Data"=>$formdata,"Url"=>$posturl,"CheckSum"=>$str];
}


//requery Bank or Card Payment
function EQueryPay($params){
    //return ["Markup"=>json_encode($params)];
    global $dbo;
	//global $phpf;
	//$REMITAPARAM = $dbo->DataArray($param,"&","=","");
        //	extract($REMITAPARAM);
        $transId = $params["Ref"];
        $responseurl = explode("?",$params["FinishUrl"]);             
       $responseurl = $responseurl[0];
    //return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['RRR'],"Amt"=>$params['Amt'],"Message"=>json_encode($params)];
    if(isset($params['QChannel']) && (int)$params['QChannel'] == 1){ //if card verification
        //QUERYURL
        $terminalId = EGetData($params["TERMINALID"],$params["PayID"]);


$qurl = EGetData($params["QUERYURL"],$params["PayID"]);
//$logo = !isset($param['LOGO'])?EGetData($param["LOGOURL"],$param["PayID"]):$param['LOGO'];
        $form = '<form method="POST" action="'.$qurl.'" > 
            <input type=hidden name="TERMINAL_ID" value="'.$terminalId.'"> 
            <input type=hidden name="TRANSACTION_ID" value="'.$transId.'"> 
            <input type=hidden name="RESPONSE_URL" value="'.$responseurl.'"> 
            </form>
            <script language="javascript">
            var form = document.forms[0];
            form.submit()</script>';
            $formdata = array(
                'TERMINAL_ID' => $terminalId,
                'TRANSACTION_ID' => $transId,
                'RESPONSE_URL' => $responseurl
            );
	return ["Markup"=>$form,"Data"=>$formdata,"Url"=>$qurl];
    }elseif(isset($params['QChannel']) && (int)$params['QChannel'] == 2){ //bank
        $qurl = EGetData($params["QUERYURLBANK"],$params["PayID"]);
        $terminalId = EGetData($params["TERMINALIDBANK"],$params["PayID"]);
//$logo = !isset($param['LOGO'])?EGetData($param["LOGOURL"],$param["PayID"]):$param['LOGO'];
        $form = '<form method = "POST" action="'.$qurl.'" > 
            <input type=hidden name = "TERMINAL_ID" value="'.$terminalId.'">
            <input type=hidden name = "PAYEE_ID" value="'.$transId.'">
            </label> 
            <input type=hidden name= "RESPONSE_URL" value="'.$responseurl.'"> 
            </form>
            <script language="javascript">
            var form = document.forms[0];
            form.submit()</script>';
            $formdata = array(
                'TERMINAL_ID' => $terminalId,
                'TRANSACTION_ID' => $transId,
                'RESPONSE_URL' => $responseurl
            );
	return ["Markup"=>$form,"Data"=>$formdata,"Url"=>$qurl];
    }else{
      if(isset($params['TERMINALIDBANK'])){
		$TERMINALID = EGetData($params['TERMINALIDBANK'],$params['PayID']);
			   //$concatString = $params['Ref'] . $params['APIKEY'] . $params['MERCHANTID']; //RRR+api_key+merchantId
				//$hash = hash('sha512', $concatString);
                
               // return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>$params['Ref']];
               $url 	= EGetData($params['QUERYURL'],$params['PayID']);
               $data = "TERMINAL_ID=".$TERMINALID."&PAYEE_ID=".$params['Ref']."&RESPONSE_URL=";


               //$url = "https://demo.etranzact.com/webconnect/v3/query.jsp";
               //$data = "TRANSACTION_ID=".$params['Ref'];

                /* <form method = ‘POST’ action= ‘http://demo.etranzact.com/WebConnectPlus/query.jsp’ > 
<input type=hidden name = ‘TERMINAL_ID’ value=’0000000001’> 
<input type=hidden name = ‘TRANSACTION_ID’ value=’1234325435435345345435454’> 
<input type=hidden name= ‘RESPONSE_URL’ value=’http://www.mywebsite.com/processQuery.jsp’> 
</form> */
				//return [$params['Ref']];
		   //$TERMINALID = '0440000045';
		   //$url = 'https://www.etranzact.net/WebConnectPlus/queryReference.jsp';
			//  Initiate curl
            $ch = curl_init();
            curl_setopt($ch,CURLOPT_POST, 3);
            curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
			// Disable SSL verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
			// Will return the response, if false it print the response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// Set the url
			curl_setopt($ch, CURLOPT_URL,$url);
			// Execute
			$rst = curl_exec($ch);
//return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>$rst];			
$rst = rtrim($rst,"</html>");
$rst = trim($rst);
curl_close($ch);

$etr = urldecode($rst);

$data = UrlToArray($etr); //$etr = implode("~",$data);
$data['BANK'] = 1;
if((isset($data['SUCCESS']) && $data['SUCCESS'] == -1) || count($data) == 0){
    //check if it is a bank payment or card payment
    if(isset($data['BANK']) && $data['BANK'] == 1 ){
        return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>"Payment Not Made"];
    }else if(count($data) == 0){
        return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>"Invalid Parameter or Bad Network"];
     //  return "6#{$msg}"; //Invalid Parameter or Bad Network 
    }else{
        return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>"Transaction Failed"];
       
    }
    
}else{
  if(isset($data['TRANS_AMOUNT']) || isset($data['AMOUNT'])){
      $amtPaid = isset($data['TRANS_AMOUNT'])?(float)$data['TRANS_AMOUNT']:(float)$data['AMOUNT'];
      $amtOrder = (float)$params['Amt'];
      if($amtPaid < $amtOrder){
        return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>"Invalid Amount Paid"];
      }else{
        return ["Status"=>1,"DateTime"=>$data["TRANS_DATE"],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>"Paid","Bank"=>$data["BANK_NAME"],"Branch"=>$data["BRANCH_NAME"]];
      }
    }else{
        return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>$params['Ref']." - ($etr) "]; 
    }

}

			}  
    }
	
		
}


//Card Payment Finish script
function EFinishPay($param){
       //check if from requery
if(isset($param['TRANSACTION_URL']) && trim($param['TRANSACTION_URL']) != ""){
    $newdata = [];
    parse_str($param['TRANSACTION_URL'],$newdata);
    $param = array_merge($param,$newdata);
    $param['AMOUNT'] = $param['TRANS_AMOUNT'];
    $param['DESCRIPTION'] = $param['TRANS_DESCR'];
    $param['TERMINAL_ID'] = "";
    $param['FINAL_CHECKSUM'] = "dddd";
    $param['RESPONSE_CODE'] = "hshsj";
    $param['STATUS_REASON'] = "";
    $param['MESSAGE'] = "hhh";
 }
//Calcualte Finalchecksum from response returned.
if(isset($param['CUSTOMER_ID']) && $param['RECEIPT_NO'] && trim($param['CUSTOMER_ID']) != "" && trim($param['RECEIPT_NO']) != "" && $param['CUSTOMER_ID'] == $param['TransNum']){ //if it bank requery
/* RECEIPT_NO=0332110262645687&PAYMENT_CODE=033145175201635258734297&MERCHANT_CODE=7006025451&TRANS_AMOUNT=42700.0&TRANS_DATE=2021/10/26 15:32:24&TRANS_DESCR=AKSU%20MISCELLANEOUS%20PAYMENTS-3525403055-Peter%20Justice%20Emmanuel&CUSTOMER_ID=3525403055&BANK_CODE=033&BRANCH_CODE=538&SERVICE_ID=3525403055&CUSTOMER_NAME=Peter%20Justice%20Emmanuel&CUSTOMER_ADDRESS=Engineering-Marine%20Engineering&TELLER_ID=NKOIMAWFM00678&USERNAME=%20&PASSWORD=%20&BANK_NAME=United%20Bank%20for%20Africa&BRANCH_NAME=0538-%20UDO%20UDOMA%20AVENUE,%20UYO&CHANNEL_NAME=Bank&PAYMENT_METHOD_NAME=Cash&PAYMENT_CURRENCY=566&TRANS_TYPE=MISCAKSU&TRANS_FEE=0.0&TYPE_NAME=&LEAD_BANK_CODE=700&LEAD_BANK_NAME=United%20Bank%20for%20Africa&COL1=2020/2021&COL2=AKSU MISCELLANEOUS PAYMENTS&COL3=Engineering&COL4=Marine Engineering&COL5=Marine Engineering/Naval Architecture&COL6=100&COL7=null&COL8=FIRST&COL9=AK19/ENG/MAE/047&COL10=justicepeter962@gmail.com&COL11=08025784759&COL12=&COL13=&COL14=&COL15=&COL16=&COL17=&COL18=&COL19=&COL20=  */
return [1,$param['TransNum'],"Bank Payment Successful",0,["Amt"=>$param['TRANS_AMOUNT'],"Bank"=>$param['BANK_NAME'],"Branch"=>$param['BRANCH_NAME'],"DateTime"=>date("Y-m-d")]];
}else{
$secret_key=EGetData($param["SECRETKEY"],$param["PayID"]);
//$secret_key = "DEMO_KEY";
$amount = $param['AMOUNT'];
$desc = $param['DESCRIPTION'];
$email = $param['EMAIL'];
$status_code = $param['SUCCESS'];
$terminal_id = $param['TERMINAL_ID'];
$transid = $param['TRANSACTION_ID']; //Note, status_code and response_code are the same.
$final_checksum = $param['FINAL_CHECKSUM'];
$response_code = $param['RESPONSE_CODE'];
$msg = $param['STATUS_REASON'];
$msg2 = $param['MESSAGE'];
/* Array ( [TRANSACTION_URL] => SUCCESS=0&TRANSACTION_ID=3562103974&MERCHANT_CODE=700602X3I0&TRANS_AMOUNT=15000.00&TRANS_DATE=2021-02-19 12:40:51.0&TRANS_DESCR=NUCO WALLET FEE&CARD4 =N/A&CHANNEL=Online [SUCCESS] => SUCCESS=0&TRANSACTION_ID=3562103974&MERCHANT_CODE=700602X3I0&TRANS_AMOUNT=15000.00&TRANS_DATE=2021-02-19 12:40:51.0&TRANS_DESCR=NUCO WALLET FEE&CARD4 =N/A&CHANNEL=Online )  */

//Note, STATUS_REASON and MESSAGE are the same.
//$msg3 = $param['msg'];
//$rmsg = isset($param['STATUS_REASON'])?$param['STATUS_REASON']:isset($param['MESSAGE'])?$param['MESSAGE']:isset($param['msg'])?$param['msg']:"Unknown Error";
$etzRef = $param['TRANS_NUM'];
// amount + terminal_id + transaction_id + response_url + secret_key //RESPONSE_URL
// $myFinalcheck = md5($param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$param['RESPONSE_URL'].$secret_key);
//0 + amount + terminal_id + transaction_id + response_url + secret_key
// $myFinalcheck = md5($param['SUCCESS'].$param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$secret_key);
$myFinalcheck = md5($param['SUCCESS'].$param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$param['RESPONSE_URL'].$secret_key);
$param['MYCheckSum'] = $myFinalcheck;
// $param['MYCheckSumStr'] = $param['SUCCESS'].$param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$secret_key;
// $param['MYCheckSumStr'] = $param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$param['RESPONSE_URL'].$secret_key;
$param['MYCheckSumStr'] = $param['SUCCESS'].$param['AMOUNT'].$param['TERMINAL_ID'].$param['TRANSACTION_ID'].$param['RESPONSE_URL'].$secret_key;
//return $param;


//$err = "";
 if(!isset($param['FINAL_CHECKSUM']) || (strtolower($param['FINAL_CHECKSUM']) != strtolower($myFinalcheck))){
        $msg .= "WRONG CHECKSUM (".$param['FINAL_CHECKSUM'].")";
        $status_code = -2;
} 
if($status_code == '0'){
    $qurl = EGetData($param["QUERYURL"],$param["PayID"]);
    //requery
    $data = array(
        'TERMINAL_ID' => $param['TERMINAL_ID'],
        'TRANSACTION_ID' => $param['TRANSACTION_ID'],
        'RESPONSE_URL' => '',
        "Query"=>$qurl
    );
   //return ICurlPost($qurl,$data);
    return [1,$param['TransNum'],$msg,$status_code,["Amt"=>$amount,"Bank"=>$param['CARD_TYPE'],"Branch"=>$param['CARD_NO'],"DateTime"=>date("Y-m-d")]];
}else{
    //@@@try requery incase it is network issue

    return [0,$param['TransNum'],$msg,$status_code,["Amt"=>$amount,"Bank"=>"UNKNOWN","Branch"=>"UNKNOWN","DateTime"=>date("Y-m-d")]];
} 
}

}

function ICurlPost($url,$data){
    $datastr = http_build_query($data);
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_POST, count($data));
    curl_setopt($ch,CURLOPT_POSTFIELDS, $datastr);
    // Disable SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    // Will return the response, if false it print the response
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // Set the url
    curl_setopt($ch, CURLOPT_URL,$url);
    // Execute
    $rst = curl_exec($ch);
//return ["Status"=>0,"DateTime"=>$params['RegDate'],"Ref"=>$params['Ref'],"Amt"=>$params['Amt'],"Message"=>$rst];			
$rst = rtrim($rst,"</html>");
$rst = trim($rst);
curl_close($ch);

return $rst;
}

?>