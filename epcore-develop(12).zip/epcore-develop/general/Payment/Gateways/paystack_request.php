<?php
//require("../../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require_once("../epconfig/TaquaLB/Ajax/CGI/PHP/config.php");
require_once("../epconfig/TaquaLB/Elements/Elements.php");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Eduporta::Setup</title>
<link href="https://fonts.googleapis.com/css?family=Encode+Sans+Condensed" rel="stylesheet">
<script src="../epconfig/TaquaLB/Loader/Loader.js" loadtype="Premium" onComplete=""></script>
<link href="../cportal/Resources/Css/main.css" rel="stylesheet" type="text/css" media="all" />
<link href="../epconfig/GenScript/CSS/logos/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="../epconfig/GenScript/CSS/gen.min.css" rel="stylesheet" type="text/css" media="all" />
<style>
.progressbx{
  width:330px;
  height:10px; margin:auto; margin-top:20px; overflow:hidden;border-radius:5px;border:solid thin #eee;
}

.progressbx .bar{
  width:10px;
  height:6px; margin:2px;border-radius:4px; animation:loadingpub 2s ease-in-out infinite;
}

.worktxt{
text-align:center;margin-top:10px;
}
@keyframes loadingpub {
	0% {
	  margin-left: -10px;
	  width:10px;
  }

  20% {
    width:10px;
  }
  
  50% {
    width:100px;
  }
  80% {
    width:10px;
  }
	100% {
    margin-left: 340px;
    width:10px;
	}
  }

</style>
</head>
<body id="Default">
 <div id="contgen">
   <div id="loginCont" style="opacity:1;margin-top:60px">
          <?php 

//$UID = $_POST['UID'];
   ?>

     <div id="loginContInner" >
        <div id="header" style="margin-top:0px;padding-top:0px">
          <div><i class="fa fa-cogs fa-2x altColor2" style="color:#666" aria-hidden="true"></i></div> <div id="userLoginName"> Setup: Publish</div>
        </div>
        
         <?php
     Box("id=mainpublishbx,class=ep-animate-left");    
     Form("id=lngfrmsetup,name=lngfrmsetup,action=javascript:Setup.Verify(),method=post");
     TextBoxGroup("width:310px;margin:auto");
     TextBoxGroupItem();
       echo "Server:";
       TextBoxGroupItemMore();
       echo "<i>".DbFunctions::$hostName.";</i> "."<i>".DbFunctions::$userName.";</i> "."<i>".DbFunctions::$dbName."</i>";
      _TextBoxGroupItem();
     /*  TextBoxGroupItem();
      echo "User";
      TextBoxGroupItemMore();
      echo "<i>".DbFunctions::$userName."</i>";
     _TextBoxGroupItem();
     TextBoxGroupItem();
       echo "Database";
       TextBoxGroupItemMore();
       echo "<i>".DbFunctions::$dbName."</i>";
      _TextBoxGroupItem(); */
  //get the version file
$versions = file_get_contents("version.json");
if($versions !== FALSE){
  $versions = json_decode($versions,true);
$lastpublish = array_pop($versions);
      TextBoxGroupItem();
      echo "Last Publish";
      TextBoxGroupItemMore();
$vstr = str_replace(".","_",$lastpublish['Number']."");
      echo '<a download href="versions/V'.$vstr.'/setup_V'.$vstr.'.epx"><i>V'.$lastpublish['Number']." - ".$lastpublish['Date']." ".$lastpublish['Time']."; Build:".((int)$lastpublish['Build'] == 1?"Update":"Fresh").((int)@$lastpublish['Minified'] == 1?" - Minified Only":"")."</i></a>";
     _TextBoxGroupItem();

}

     _TextBoxGroup();



     
      TextBoxGroup("margin:auto;margin-top:20px");
      TextBox("title=Version Number,style=width:300px,id=versnam,logo=copy");
      Note();
        echo "If version already exist, Publish will overwrite it";
      _Note();
      echo '<input type="hidden" value="1" id="publishignores" />';
      Switcher("id=publishminonly,state=1,text=Minified Only,style=width:300px,info=Publish minified file only,ontext=yes,offtext=no,align=right");
      _TextBoxGroup();
 Box("id=ignores_spsht_bx,style=max-height:110px;overflow:auto;margin:auto;margin-top:10px;width:310px,class=ep-animate-opacity");
      $dump = [
        ["root://cportal/Files/Payment/Receipt",1],
        ["root://cportal/Files/UserImages",1],
        ["root://cportal/fixer",0],
        ["root://epconfig/TaquaLB/Ajax/CGI/PHP/Excel",1],
        ["root://epconfig/TaquaLB/Ajax/CGI/PHP/PDF",1],
        ["root://epconfig/UserImages/Advert",1],
        ["root://epconfig/UserImages/App",1],
        ["root://epconfig/UserImages/JambResult",1],
        ["root://epconfig/UserImages/Origin",1],
        ["root://epconfig/UserImages/PUTME",1],
        ["root://epconfig/UserImages/Student",1],
        ["root://epconfig/UserImages/Waec",1],
        
        ["root://epconfig/conf.txt",1]
      ];
      //["root://epconfig/UserImages/School",1],["root://epconfig/UserImages/wallpapers",1],
      $headerrr = array(
        "*PublIgnore"=>"IGNORE DIR/FILE",
        "*PublPopulate"=>array("USE OLD","YES|NO")
       );
      SpreadSheet("rowselect=false,style=width:calc(100% - 12px);margin-top:6px;margin-bottom:6px,id=ignores_spsht,multiselect=false,cellfocus=,cellblur=,cellkeypress=,dynamiccolumn=false,dynamicrow=true,minrow=1,case=none",$headerrr,$dump);
      _Box();

      
      FlatButton("text=Publish,style=width:308px;margin:auto;margin-top:20px,id=tocportal,logo=cog,onclick=Publish.Start()");

      _Box();
      Box("id=loadingpubbx,class=ep-animate-right,style=display:none");
Box("id=publishworkcont,class=ep-animate-opacity");
        echo '<div class="progressbx selBgColor"><div class="bar altBgColor2"></div></div>';
         echo '<div class="worktxt" id="publishtext">Publishing... </div>';
         _Box();

         Box("id=publishinfocont,class=ep-animate-opacity");
         Note("id=errnoted,style=margin-top:20px;display:none");_Note();
         Note("id=oknoted,style=margin-top:20px;display:none;text-align:center,class=success-fade");_Note();//
         TextBoxGroup("margin:auto;margin-top:20px");
         TextBoxGroupItem();
         FlatButton("text=Back,style=width:120px;margin:auto,id=pbackbtn,logo=chevron-left,onclick=Publish.ShowHomeScreen()");
         TextBoxGroupItemMore();
         FlatButton("text=Retry,style=width:120px;margin:auto,id=retrybtn,logo=undo,onclick=Publish.Start()");
         _TextBoxGroupItem();
         _TextBoxGroup();
         _Box();
      _Box();
		 /*Radio("group=aaa,id=r3");
		 Radio("group=aaa,id=r4");
		 Radio("group=aaa,id=r5");*/
		 /*if(isset($UID) && (int)$UID != 0){
			 $dbo->Updatedbtb("user_tb",array("Online"=>0),"UserID = $UID");
		 }*/
	  ?>
       <input type="hidden" id="setup_tabs" value="setup=Setup"  />  
     </div>
  </div>
</div>
 
   <!-- <div id="genloading"><i class="fa fa-circle-o-notch fa-spin"></i></div> -->
   
<?php
//}else{
//	echo "Page Error";
//}

?>

<script>
  var Publish = {
    ShowWorkingScreen:function(){
      Publish.HomeScreen.Hide();
      Publish.WorkingScreen.Show();
    },
    ShowHomeScreen:function(){
      Publish.WorkingScreen.Hide();
      Publish.HomeScreen.Show();
    },
Working:function(txt){
  Publish.Text.textContent = txt;
  Publish.InfoCont.Hide();
  Publish.WorkingCont.Show();
 Publish.ShowWorkingScreen();
},
Done:function(){
  Publish.WorkingCont.Hide();
  Publish.InfoCont.Show();
 Publish.ShowWorkingScreen();
},
Message:function(mes,ok){
  if(typeof ok != _UND && ok == true){
    Publish.Error.Hide();
    Publish.Ok.Show();
    Publish.Ok.innerHTML = mes;
  }else{
    Publish.Ok.Hide();
    Publish.Error.Show();
    Publish.Error.innerHTML = mes;
  }
 
 Publish.Done();
},
    Text:null,
    Ajax:null,
    WorkingScreen:null,
    HomeScreen:null,
    Version:null,
    Error:null,
    Ok:null,
    Start:function(){
Publish.Version = _('versnam')
      var version = Publish.Version.TextContent();
       if(version.Trim() == ""){MessageBox.Show('Invalid Version Number Entered');return;}
        
        Publish.Text = _('publishtext');
        //Publish.Text.textContent = "Initializing...";
        Publish.WorkingScreen =  _('loadingpubbx');
        Publish.HomeScreen =  _('mainpublishbx');
        Publish.WorkingCont = _('publishworkcont');
        Publish.InfoCont = _('publishinfocont');
        Publish.Error = _('errnoted');
        Publish.Ok = _('oknoted');
        Publish.Init();
    },
    Init:function(){
      var version = Publish.Version.TextContent();
       if(version.Trim() == ""){MessageBox.Show('Invalid Version Number Entered');return;}
       var upd = _('publishignores').GetStatus();
       var min = _('publishminonly').GetStatus();
       
      // alert(data); return;
      Publish.Working("Intializing...");
        Publish.Ajax = new Ajax();
        Publish.DBAjax = new Ajax();
        Publish.FileAjax = new Ajax();
        Publish.Ajax.Post({
          Action:"scripts/init.php",
          PostData:"v="+escape(version)+"&upd="+upd+"&min="+min,
          OnComplete:function(res,url,param){
            if(res != "#"){ //if error occur
              Publish.Message(res);
            }else{ //initialization successfull
              Publish.Database(param['v']);
            }
          },
          OnAbort:function(res){
            Publish.Message(Aborted);
          },
          OnError:function(res){
            Publish.Message(res);
          }
        })
    },
    Database:function(version){
      Publish.Working("Packaging Database...");
      Publish.DBAjax.Post({
          Action:"scripts/db.php",
          PostData:"v="+escape(version),
          OnComplete:function(res,url,param){
            if(res != "#"){ //if error occur
              Publish.Message(res);
            }else{ //initialization successfull
             // Publish.Message(res);
              Publish.Files(param['v']);
            }
          },
          OnAbort:function(res){
            Publish.Message(Aborted);
          },
          OnError:function(res){
            Publish.Message(res);
          }
        })
    },
    Files:function(version){
      var upd = _('publishignores').GetStatus();
       var ignores = _('ignores_spsht').GetDataString();
       var min = _('publishminonly').GetStatus();
      var data = "v="+escape(version)+"&updst="+upd+"&ignores="+escape(ignores)+"&min="+min;
      Publish.Working("Packaging Files...");
      Publish.FileAjax.Post({
          Action:"scripts/files.php",
          PostData:data,
          OnComplete:function(res,url,param){
            if(res != "#"){ //if error occur
              Publish.Message(res);
            }else{ //initialization successfull
              Publish.Finish(param['v'],param['updst'],param['min']);
            }
          },
          OnAbort:function(res){
            Publish.Message(Aborted);
          },
          OnError:function(res){
            Publish.Message(res);
          }
        })
    },
    Finish:function(version,upd,min){
      var data = "v="+escape(version)+"&upd="+upd+"&min="+min;
      Publish.Working("Finishing ...");
      Publish.Ajax.Post({
          Action:"scripts/finish.php",
          PostData:data,
          OnComplete:function(res,url,param){
            if(res != "#"){ //if error occur
              Publish.Message(res);
            }else{ //initialization successfull
              var vstr = param['v'].Replace(".","_");
              Publish.Message('<div><i class="fa fa-thumbs-up altColor2 " style="font-size:2.5em"></i></div><strong>V'+param['v']+' PUBLISHED SUCCESSFULLY</strong><br /><a download href="versions/V'+vstr+'/setup_V'+vstr+'.epx" >Eduporta Setup V'+param['v']+'</a>',true);
            }
          },
          OnAbort:function(res){
            Publish.Message(Aborted);
          },
          OnError:function(res){
            Publish.Message(res);
          }
        })
    },
    ToggleIgnores:function(obj){
      st = obj.GetStatus();
      if(st == 1){
        //_('ignores_spsht_bx').Show();
      }else{
        //_('ignores_spsht_bx').Hide();
      }
    }

  }
</script>
</body>
</html>
