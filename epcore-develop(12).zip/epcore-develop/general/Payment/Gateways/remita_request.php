<?php
require_once("../TaquaLB/Ajax/CGI/PHP/config.php");
//require_once("../TaquaLB/Elements/Elements.php");
require_once("../GenScript/PHP/getinfo.php");
 //get the ref number
 if(!isset($_REQUEST['Ref']))exit('{"Error":"Invalid Parameter"}');
 $Ref = $_REQUEST['Ref'];
//get the payment details
$pdet = $dbo->SelectFirstRow("order_tb","","TransNum='$Ref'");
if(!is_array($pdet))exit('{"Error":"Invalid Payment Reference"}');
$rst = [];
$rst["RegNo"] = $pdet['RegNo'];
$rst["OrderNo"] = $pdet['ItemNo'];
$rst["Ref"] = $pdet['TransNum'];
$rst["Date"] = $pdet['RegDate'];
$rst["PayName"] = $pdet['ItemName'];
$rst["Amt"] = $pdet['Amt'];
$rst["Level"] = $pdet['Lvl'];
$rst["Sem"] = $pdet['Sem'];
$rst["SemPart"] = $pdet['SemPart'];
$rst["Paid"] = $pdet['Paid'] == 1?"Payment Already Made":"Payment Not Made";
echo json_encode($rst);
?>