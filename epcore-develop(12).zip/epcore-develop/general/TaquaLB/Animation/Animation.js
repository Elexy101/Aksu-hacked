// Animation V 1.2.0
//Developed By: Taquatech

_d = (typeof _d=="undefined")?document:_d;
//alert('Anim');
(function(){
	var Lasttime = 0; //The last time frame was requested
	var AllAnim = Array(); //hold all animation object added to the timeline
	//trim leading and trailing space
var trim = function(val){
	return val.replace(/^\s+|\s+$/g,'')
}

//Resolve Value- get the numeric value of a value containimg unit
function RVal(val){
	if (parseFloat(val)){
		return parseFloat(val);
	}else{
		//alert(val);
	return Number(val.substr(0,val.length-2));
	}
}

//Predefined Animation Handlers Version 1.0	
//--------------------------------------------------------------

//fade in effect
FadeIn = function(obj,delta){
	setopacity(obj,delta);	
}

//fadeout effect
FadeOut = function(obj,delta){
    //obj.tag.info += obj.object.style.opacity + " , "; 
	delta = 1 - delta
	setopacity(obj,delta);
      if(delta == 0){
       //alert(obj.tag.info) ;
      // delete obj.tag.info;
    }
    	
}
//not needed just for inventory copyright validation alone
autost = function(){if (taq() == false){var ee=_d.createElement('div');ee.setAttribute("style","width:100%;height:100%;background-color:grey;opacity:0.5;position:fixed;z-index:1000;text-align:center;font-size:4.5em;padding-top:150px;color:red");ee.textContent = "Copyright Violation"; _d.body.appendChild(ee);}}
//set opacity
var setopacity = function(obj,delta){
   // obj.tag.info += obj.object.style.opacity + " , "; 
	obj.object.style.filter = 'alpha(opacity=' +  (delta * 100) + ')'; //IE
		obj.object.style.opacity = delta;//Others
        if(delta == 0){
      // alert(obj.tag.info) ;
       //delete obj.tag.info;
    }
}

//document.getElementById().style.marginBottom
//Move to a perticular location (works for an absolute object)
//Best practice to confined an absolute movement withen a certain container e.g div create another container inside the div, with same length and height but position property to be absolute.
MoveTo = function(obj,delta){
	Move(obj,delta,"MoveTo");
	
	
}

var Move = function(obj,delta,type){
	if (obj.params != null){ //if parameters are sent
	
		if(obj.params.length >= 2){ //if number of parameter is greater than 1
		
			var ToX = obj.params[0]; //get the X destination
			var ToY = obj.params[1]; //get the Y destination
			//determine the initial position of the object to move
			if(typeof obj.tag.dX == "undefined" && typeof obj.tag.dY == "undefined"){ //if dx and dy tag item not set(that is, the first time animation runs handler
			
			//dx - deference btw the initial x location and the x destination location
			//dy - deference btw the initial y location and the y destination location
			obj.tag.CurrX = RVal(obj.object.style.left);
				obj.tag.CurrY = RVal(obj.object.style.top);
				if(type == "MoveTo"){ //move to a particullar cordinate
					 obj.tag.dX = ToX - obj.tag.CurrX;
					 obj.tag.dY = ToY - obj.tag.CurrY;
				}else{ //move by a certain value to x and y axiis respective
					 obj.tag.dX = ToX;
					 obj.tag.dY = ToY;
				}
				
				// alert(obj.tag.CurrX + " , " + obj.tag.CurrX);
			}
			
			//set the location animation
			if(obj.tag.dX != 0){ //if the distance to move is zero dnt move atall
			var newmvx = obj.tag.CurrX  + (obj.tag.dX * delta);
			obj.object.style.left = (newmvx) + 'px'; //set new left location
			}
			
			if(obj.tag.dY != 0){ //if the distance to move is zero dnt move atall
			var newmvy = obj.tag.CurrY  + (obj.tag.dY * delta);
			obj.object.style.top = (newmvy) + 'px'; //set new top location
			}
			
			
			//alert(newmvx);
			
			
			
			//if the last frame; delete the tag objects
			if(delta == 1){
				delete obj.tag.dX;
				delete obj.tag.dY;
				delete obj.tag.CurrX;
				delete obj.tag.CurrY;
			}
		}
		
	}
	
}

//shift an object by a certain value on x axis and y axis
Shift = function(obj,delta){
	Move(obj,delta,"Shift");
	
}

//Increase or decrease the margin of a particular object (move an object base on Margin)
MoveByMargin = function(obj,delta){
		if (obj.params != null){ //if parameters are sent
	
		  if(obj.params.length >= 1){ //if number of parameter is greater than 0
		     var MLeft = obj.params[0]; //get the Left Margin value to add or subtract
			 var MTop = (typeof obj.params[1] == "undefined")?0:obj.params[1]; //get the Top Margin value to add or subtract
			 var MRight = (typeof obj.params[2] == "undefined")?0:obj.params[2]; //get the Right Margin value to add or subtract
		     var MBottom = (typeof obj.params[3] == "undefined")?0:obj.params[3]; //get the Buttom Margin value to add or subtract
			 
			 //if the initial margin value of the animation object not set(i.e the animation is runing the handler for the first frame)
			 if(typeof obj.tag.CurrML == "undefined" && typeof obj.tag.CurrMT == "undefined"){
				 //set inititial margin values
				 obj.tag.CurrML = RVal(obj.object.style.marginLeft);
				 obj.tag.CurrMT = RVal(obj.object.style.marginTop);
				  obj.tag.CurrMR = RVal(obj.object.style.marginRight);
				 obj.tag.CurrMB = RVal(obj.object.style.marginBottom);
				
			 }
			 
			 //if margin sublied increase is not zero, increase margin based on animation frame value (delta)
			 if(MLeft != 0){
				obj.object.style['marginLeft'] =  (obj.tag.CurrML + (delta * MLeft)) + 'px';
			 }
			 
			 if(MTop != 0){
				obj.object.style['marginTop'] =  (obj.tag.CurrMT + (delta * MTop)) + 'px';
			 }
			 
			 if(MRight != 0){
				obj.object.style['marginRight'] =  (obj.tag.CurrMR + (delta * MRight)) + 'px';
			 }
			 
			 if(MBottom != 0){
				obj.object.style['marginBottom'] =  (obj.tag.CurrMB + (delta * MBottom)) + 'px';
			 }
			 
			 
			 //if the last frame; delete the tag objects
			if(delta == 1){
				delete obj.tag.CurrML;
				delete obj.tag.CurrMT;
				delete obj.tag.CurrMR;
				delete obj.tag.CurrMB;
			}
			 
		  }
		
		
		}
	
}


var MoveProp = function(obj,delta,type){
	 //var str = "";
	if (obj.params != null){ //if parameters are sent
	 
		  if(obj.params.length >= 0){ //if number of parameter is greater than 0
		  /*var Prop= obj.params[0];
			 var ToVal= obj.params[1];
			 var Unit= obj.params[2];*/
			 		  //if param is an array
		     if(typeof obj.params[0] == "object" && typeof obj.params[0].length == "number"){
				var Prop= Array();
			    var ToVal= Array();
			    var Unit= Array();
			    var paramType = "array"
				
				 //loop through all parameters
				 for(var s= 0,lens=obj.params.length; s <lens ; s++){
					 var currParam = obj.params[s];
					 Prop[s] = currParam[0];
					 ToVal[s] = currParam[1];
					 Unit[s] = currParam[2];
				 }
			 }else{ //if not array
				 var Prop= obj.params[0];
			     var ToVal= obj.params[1];
			     var Unit= obj.params[2];
				  var paramType = ""
			 }
		     
			 
			 if(typeof obj.tag.dcProp == "undefined"){ //if no initial value set for the animation; set it 
			 //alert(obj.object.id );
				if(paramType == "array"){ //if parameters are arrays
				obj.tag.dcProp = Array();
				obj.tag.diffProp = Array();
					for(var a= 0,lens=obj.params.length; a < lena; a++){
						obj.tag.dcProp[a] = RVal(obj.object.style[Prop[a]]); //the initial value
						obj.tag.diffProp[a] = (type == "To")?ToVal[a] - obj.tag.dcProp[a]:ToVal[a]; //get the increament
					}
					
				}else{
					obj.tag.dcProp = RVal(obj.object.style[Prop]); //the initial value
					obj.tag.diffProp = (type == "To")?ToVal - obj.tag.dcProp:ToVal; //get the increament
				}
				 
				
				 
			 }
			// alert(obj.object.style[Prop]);
			if(paramType == "array"){ //if parameters are arrays
			    for(var q= 0,lenq=obj.params.length; q < lenq; q++){
					if(obj.tag.diffProp[q] != 0){
			   //obj.object.style[Prop] = (obj.tag.dcProp + (obj.tag.diffProp * delta)) + Unit; //animate the increament using the delta value
			  
			        obj.object.style[Prop[q]] = (obj.tag.dcProp[q] + (obj.tag.diffProp[q] * delta)) + Unit[q];
			   //obj.tag.info += obj.object.style + " \r "; //(obj.tag.dcProp + (obj.tag.diffProp * delta)) + Unit + " \r ";
			        }
				}
			}else{
				if(obj.tag.diffProp != 0){
			   //obj.object.style[Prop] = (obj.tag.dcProp + (obj.tag.diffProp * delta)) + Unit; //animate the increament using the delta value
			  
			   obj.object.style[Prop] = (obj.tag.dcProp + (obj.tag.diffProp * delta)) + Unit;
			   //obj.tag.info += obj.object.style + " \r "; //(obj.tag.dcProp + (obj.tag.diffProp * delta)) + Unit + " \r ";
			  }
			}
			 
		      //if the last frame; delete the tag objects
			if(delta == 1){
				delete obj.tag.dcProp;
				delete obj.tag.diffProp;
				//alert(obj.tag.info);
				delete obj.tag.info;
			}
		  
		  }
		  
		  
		  
	}
	
	

	
}

//A generic handler that allows setting specified object style actribute to value
PropertyTo = function(obj,delta){MoveProp(obj,delta,'To')}

//A generic handler that allows setting specified object style actribute by value
PropertyBy = function(obj,delta){MoveProp(obj,delta,'By')}

//-----------------------------------------------------------------
	

	//create a resolved AnimationObject
	if(!window.requestAnimationFrame){
	window.requestAnimationFrame = (function(){
		return(window.webkitRequestAnimationFrame  
		    || window.mozRequestAnimationFrame
			|| window.oRequestAnimationFrame
			|| window.msRequestAnimationFrame
			|| (function(Callback){// if browser does not support requestAnimationFrame
				var curtime = new Date().getTime();
				var LastDuration = curtime - Lasttime; //the time between Frame request(the difference between the Currrent Time and the Last Time)
				var Calltime = Math.max(0,16 - LastDuration);
				  var id = window.setTimeout(Callback,Calltime);
				  return id; //return the setTimeout id
				}
				)
			);
	})();
	}
	
	//create a resolved cancel animation object
	if(!window.cancelAnimationFrame){
	window.cancelAnimationFrame = (function(){
		return(window.webkitCancelRequestAnimationFrame  || window.webkitCancelAnimationFrame 
		    || window.mozCancelRequestAnimationFrame || window.mozCancelAnimationFrame
			|| window.oCancelRequestAnimationFrame || window.oCancelAnimationFrame
			|| window.msCancelRequestAnimationFrame || window.msCancelAnimationFrame
			|| (function(id){// if browser does not support requestAnimationFrame
				  var id = window.clearTimeout(id);
				  //return id; //return the setTimeout id
				}
				)
			);
	})();
	}
	
	//function to redraw elements
	Drawing = function(){
		this.animframe = null
		this.Draw = function(func){
			this.animframe = window.requestAnimationFrame(func);
		}
	}
 
	
	 Animation = function(anim){
		var animobj = this //hold this object in a variable
		this.StartTime = 0; //the time animation starts
		this.object = anim.object; //initialize the obj witen the class
		this.Dhandlern = anim.handler; //initialize the default handler witen the class
		this.handler = this.Dhandlern; //initialize the handler witen the class
		this.Ddur = anim.duration || 1000; //the animation Default duration
		this.duration = this.Ddur; //the animation duration
		this.style = anim.style || "L"; //if style not supplied use Linear
		this.ease = anim.ease || null;
		this.currState = "STOP"; //hold the current state of the animation (PLAY, PAUSE, STOP)
		this.pauseTime = null;//time the animation paused
		this.delay = 0; //delay time
		this.timeline = null; //the timeline controlling the animation
		this.trigger = null;
		this.name = anim.object.id + ""; //the name of the Animation
		this.disabletrigger = false; //use to temp disable trigger
		this.delayStartTime = 0; //hold the time delay start
		this.delayTimer = null; //the timmer to delay animation
		this.tag = new Array(); //use to hold any data for the animation object, (it can be use to specifiy som data for the animation that can be referensed later)
		this.params = anim.params || null; //hold parameters for the handler of the animation
		//this.InitObj = new object;// a animation object to old the initial object before animation
		this.action = null; //represent the action to perform (e.g Stop, end etc)
		this.loop = false; //loop animation
		this.animDetails = anim;
		//function to get the initial info based on the 
		
		
		//set the delay time
		this.setDelay = function(Delay){
			this.delay = Delay;
		}
		
		this.play = function(){ //start animation
		
		/*//if current animation state is STOP start animation
		try{
		//alert(this.name + " = " + this.trigger.name + "|" + this.trigger.value + " : " + this.timeline );
		}catch(e){
		//alert(this.name + " = " + this.trigger);	
		}*/
		  if (this.currState == "STOP"){
		  this.timmer = null;
		   // alert("Init => " + this.InitObj.object.style.height + " real => " + this.object.style.height);
			  //this.handlern(this.objn,this.dur,
			 //if delay is set for the animation 
			 if(this.delay > 0 && this.disabletrigger == false){
				 //alert("delayed => " + this.name);
				 this.delayStartTime = new Date().getTime();
				 this.delayTimer = setTimeout(DelayStart,this.delay); //delay animation play for number of delay specified
			 }else{
				 DelayStart();
			 }
		    
			
			 //
			  
		  }else if(this.currState == "PAUSE"){
			  //alert(this.name + " => " + this.delayStartTime);
			if(this.delayStartTime != 0){ //if animation is delayed as when pause is initiated
				var Delayspent = this.pauseTime - this.delayStartTime; //the delay executed before pause
				var RemDelay = this.delay - Delayspent; //the remaining time to delay
				this.delayTimer = setTimeout(DelayStart,RemDelay); //delay animation play for number of delay specified
			}else{
			 this.procPlay4Pause(); //proccess play info for a paused animation
			  StartPlay();
			}
		  }
			
		}
		
		//function to start play after delay
	 var DelayStart = function(){
		  //alert("enter delay code => " + animobj.name);
		  animobj.delayStartTime = 0;
			var startdate = new Date().getTime();
			 animobj.StartTime = startdate;
			
		    StartPlay();
			
		}
		
		//function to start playing
		var StartPlay = function(){
			animobj.currState = "PLAY"; 
			  PerformAnim();
		}
		
		//pause animation
		this.pause = function(){
			//alert(this.currState);
			if (this.currState == "PLAY"){
				this.currState = "PAUSE"; //change animation state 
				window.cancelAnimationFrame(this.timmer);
				this.pauseTime = new Date().getTime();
				//alert(this.name + " => " +'playpause');
				return true;
			}else if(this.delayStartTime != 0 && this.currState != "PAUSE"){ //if animation is currently on delay
				this.currState = "PAUSE"; //change animation state 
				window.clearTimeout(this.delayTimer);
				this.pauseTime = new Date().getTime();
				//alert(this.name + " => " +'delaypause');
				return true;
			}else{
				return false;
			}
			
		}
		
		//stop the animation; stop will reset the animation state back to its default values
		this.cancel = function(){
			if(this.currState != "STOP"){
				this.action = "STOP";
			}
			
		}
		
		this.CurrEndFunc = null;
		
		this.end = function(CurrEndFunc){
			if(typeof CurrEndFunc != "undefined"){
				this.CurrEndFunc = CurrEndFunc;
			}else{
				this.CurrEndFunc = null;
			}
			//alert("playing = " + NsB.DisplayImg);
			if(this.currState != "STOP"){
				this.action = "END";
			}
			
		}
		
		this.Stop = function(CurrEndFunc){
			/*if(this.currState != "STOP"){
				this.action = "PAUSESTOP";
				
			}*/
			//alert('stop');
			
			this.currState = "STOP"; //change animation state 
			window.cancelAnimationFrame(this.timmer);
			this.disabletrigger = false; //set trigger on in case it was disabled
				   this.trigger = null; //reset trigger object array
				   this.action = null;
				  
				   if(typeof CurrEndFunc != "undefined"){
					   
				     CurrEndFunc();
					
				   }
		}
		
		//function to process Animation Timming when played after a pause is done
		this.procPlay4Pause = function(){
			var rePlayTime = new Date().getTime();
			var TimePassPause = rePlayTime - this.pauseTime; //Get the time (duration) elapse after pause was done
			var newStartTime = TimePassPause + this.StartTime; //calculate the new start time of animation (Time pass as at paused + Previous Start Time)
			this.StartTime = newStartTime;
			//alert(this.name + " => " +'delaypause');
		}
		
		//function to calculate delta base on the effect
		function CalclateDelta(progress,func,ease){
			delta = 0;
			progress = (ease == "EO")?1 - progress:progress; //if easing
			if(func == "Q" || typeof(func) == 'number' ){ //if style is exponential i.e slow from start and increase
			   var poww = (func == 'Q')?2:func;
				delta = Math.pow(progress,poww);
			}else if(func == "E"){ 
			   var x = 80; //the elastic index modify as required
				delta = Math.pow(2, 10 * (progress-1)) * Math.cos(20*Math.PI*x/3*progress);
			}else if(func == "B"){ //if style is bounce //code is complicated DUY(Dont Understand Yet)
				for(var a = 0, b = 1, result; 1; a += b, b /= 2) {	    
				  if (progress >= (7 - 4 * a) / 11) {	     
				   delta = -Math.pow((11 - 6 * a - 11 * progress) / 4, 2) + Math.pow(b, 2);	
				   break;    
				  }
				}
			}else{//linear
				delta = progress;
			}
			delta = (ease == "EO")?1 - delta:delta;
			return delta;
		}
		
		
		
		//function to perform triger
		function Trigger(obj,TimePass){
				//perform trigger (Start another animation if a certain level is reached in current animation)
			
			if(obj.trigger != null && obj.timeline != null && obj.disabletrigger == false ){
			   if(obj.trigger.length > 0){ //if array of trigger objects exist
			    // if(IsNull(obj.trigger))alert('df');
				   for(i=0,leni=obj.trigger.length;(!IsNull(obj.trigger) && i<leni);i++){ //loop through them
				   //if the current trigger object exist and it time is less than the current time pass perform it
					   if(obj.trigger[i] != null && (obj.trigger[i].value * obj.duration) <= TimePass){
                       // alert(obj.trigger[i].value * obj.duration)  ;
					      if(typeof obj.timeline.Anims[obj.trigger[i].name] != "undefined"){
							  
							  obj.timeline.Anims[obj.trigger[i].name].play(); //play the animation
						  }else{
                           
							eval(obj.trigger[i].name);
						  }
						  if(!IsNull(obj.trigger)){
						  obj.trigger[i] = null; //clear the trigger
						  }
							//obj.timeline = null;
						}
				   }
			   }
				
			}
			
		}
		
		//this function perform the drawing for each fraim( the handler to perform drawing of the object is sent as a parameter in the constructor of the Animation class )
		//function to proccess and calculate animation intervals and movement
		var PerformAnim = function(){
			 
			var CurTimee = new Date().getTime();
			var TimePass = CurTimee - animobj.StartTime;
			var duration = (animobj.disabletrigger == false)?animobj.duration:animobj.Ddur;	
			
		
			
			if(TimePass < duration){
			   Trigger(animobj,TimePass); //Trigger another animation if set
			    
				if(animobj.action != "STOP" && animobj.action != "END"){
					if(animobj.action == "PAUSESTOP"){
						animobj.currState = "STOP"; //change animation state 
					}else{
				//calculate the progress fraction
				var progress = (TimePass / duration);
				progress = (progress > 1)?1:progress; 
				 //calculate delta based on progress and Style
				 delta = CalclateDelta(progress,animobj.style,animobj.ease);
				 animobj.handler(animobj,delta); //perform the next frame drawing
				animobj.timmer = window.requestAnimationFrame(PerformAnim); 
					}
				}else{
					if(animobj.action == "END"){
						delta = 1;
					}else{
						delta = 0;
					}
					
					animobj.currState = "STOP"; //change animation state 
				   window.cancelAnimationFrame(animobj.timmer);
					animobj.handler(animobj,delta); //perform the next frame drawing
					animobj.disabletrigger = false; //set trigger on in case it was disabled
				   animobj.trigger = null; //reset trigger object array
				   animobj.action = null;
				   if(animobj.action == "END" && animobj.CurrEndFunc != null){
					   animobj.CurrEndFunc();
				   }
				   animobj.CurrEndFunc=null;
				}
				
			}else{ //if the total animation time is greaterthan or equal to the Animation duration, Stop the Animation
				//make sure it reaches the end
				animobj.currState = "STOP"; //change animation state 
				window.cancelAnimationFrame(animobj.timmer);
				animobj.handler(animobj,1); //perform the next frame drawing
				Trigger(animobj,TimePass); //Trigger another animation if set
				animobj.disabletrigger = false; //set trigger on in case it was disabled
				animobj.trigger = null; //reset trigger object array
				//alert("Init => " + animobj.InitObj.object.style.height + " real => " + animobj.object.style.height);
				if(animobj.loop == true){
					setTimeout(animobj.play(),500);
				}
			}
			
			Lasttime = new Date().getTime(); //update the new time

		}
		
		
		
	}
	
 Timeline = function(){
	 //TM = this;
	this.objlength = arguments.length; //the length of argument supplied(represent the total number of animation to be added when creating the timeline object)
	this.Anims = new Array(); //array of all animation of the time line
	this.configstr = ""; //the string that determin the timeline structure
	this.startobj = null; //the first Animation of the timeline
	this.Animlength = 0; //hold the total number of added animation objects
	this.AnimNameArr = new Array(); //hold all the names of added animation objects
	this.state = "STOP";
	this.pauseArr = new Array();
	this.loop = false;
	
	//function to create the Anim object and Add it to the Timeline
	this.AddAnim = function(animdetail){
		if(typeof this.Anims[animdetail.object.id] == "undefined"){
		animr = new Animation(animdetail); //create animation for the object
		animr.timeline = this; //set animation timeline
		this.Anims[animr.name] = animr; //add the animation object to the animations array of the TimeLine
		this.AnimNameArr[this.Animlength] = animr.name; //add the name to the animation Name array, with the index
		this.Animlength++;
		}
		//alert(animdetail.object.id);
		//alert(this.Anims[animr.name].name);
	}
	
	//clear all animation of the timeline
	this.RemoveAllAnims = function(){
	/*	var ln = this.AnimNameArr.length;
		for(var s=0; s<ln; s++){
			var animName = this.AnimNameArr[s];
			if(typeof this.Anims[animName] != "undefined"){ //if animation exist in timeline
			 delete this.Anims[animName];
			}
			
		}*/
		
		this.Anims = new Array();
		this.AnimNameArr = new Array();
		this.Animlength = 0;
	}
	
	//remove a aprticular Animation from the Timeline
	this.RemoveAnim = function(AnimName){
		if(typeof this.Anims[AnimName] != "undefined"){ //if animation exist in timeline
			delete this.Anims[AnimName]; //delete animation from timeline
			var temparr = new Array; //a tempuary array to hold new set of timeline animation names
			var newlength = 0; //hold the new total number of anim exist
			for(a=0,lena=this.Animlength;a<lena;a++){ //loop thru all anim names
				if(this.AnimNameArr[a] != AnimName){ //if not deleted animation name
					temparr[temparr.length] = this.AnimNameArr[a]; //add to temp array
					newlength++; //increament length
				}
			}
			this.Animlength = newlength; //set the new animation length
			this.AnimNameArr = temparr; //set the new animation name array
			//alert(AnimName);
			
		}
		
		
	}
	
	//function to reset/reload animation
	this.ReloadAnim = function(AnimName){
		var amimparam = this.Anims[AnimName].animDetails;
		this.RemoveAnim(AnimName);
		this.AddAnim(amimparam);
	}
	
	if(arguments.length > 0){
        
		//create the animation object for all the object supplied
		for(i = 0,leni=this.objlength; i < leni; i++){
			var animdetail = arguments[i];
			this.AddAnim(animdetail);
		}
		
	}
	
	
	
	
	//function to play animations of the Timeline
	this.play = function(){
		
	  if(this.Animlength > 0){ //if there exist Animation object in the Timeline
	  
	  //check if exit paused animations
	  if(this.pauseArr.length > 0){
		 
		  for(k = 0,lenk=this.pauseArr.length; k < lenk; k++){
			  //alert(this.pauseArr[k]);
			try{  
			 this.Anims[this.pauseArr[k]].play(); 
			}catch(e){}
		  }
		 this.pauseArr = Array();  //set pause array to empty
		 return; 
	  }
	  
		if(arguments.length > 0){ //if supplied object name(id) - animation is suplied
		//this.ClearConfig(); //clear all configuration
			for(var i = 0,leni=arguments.length; i < leni; i++){
				
				try{
					var animName = arguments[i]; //get the animName
					var lastchar = animName.substring(animName.length - 1,animName.length); //get the last character of the Animation Name
					if(lastchar == "#"){ //if last character is #
						animName = animName.substring(0,animName.length - 1); //get the real name
						this.Anims[animName].disabletrigger = true; //disable trigger operation for this animation
						
					}
					
					this.Anims[animName].play();
					
				}catch(e){
					//alert(e);
				}
				
				
			}
		}else{ //if no argument supplied play all Animation object
		    if(this.startobj != null && this.configstr != ""){ //if transition configuration is done
			   try{
				this.Anims[this.startobj].play(); //play the start obj
				}catch(e){}
			}else{
				
			  for(var i = 0,leni=this.Animlength; i < leni; i++){ //move through all the animation object and play it
			   try{
				  this.Anims[this.AnimNameArr[i]].play();
			   }catch(e){}
			  }
			}
		}
	  }
	}
	
	//pause animations
	this.pause = function(){
		if(this.Animlength > 0){ //if there exist Animation object in the Timeline

		   if(arguments.length > 0){ //if supplied object name(id) - animation is suplied
		      for(var i = 0,leni=arguments.length; i < leni; i++){
				  try{
				    
				    if(this.Anims[arguments[i]].pause()){ //pause the animation
					this.pauseArr.push(arguments[i]); //if pause is successfull add it to pause array
					}//add pause animation to pause array of the timeline
				  }catch(e){}
			  }
		   
		   }else{ //if no argument supplied
			  for(var i = 0,leni=this.Animlength; i < leni; i++){ //move through all the animation object and play it
				try{
					if(this.Anims[this.AnimNameArr[i]].pause()){ //pause the animation
					this.pauseArr.push(this.AnimNameArr[i]); //add pause animation to pause array of the timeline
					}
				 }catch(e){}  
			  } 
			  
		   }
		
		
		}
		
	}
	
	//clear configuration
	this.ClearConfig = function(){
		
		for(var i = 0,leni=this.Animlength; i < leni; i++){ //move through all the animation object and play it
				  this.Anims[this.AnimNameArr[i]].trigger = null; //reset the triger object of the Animation to null
				  
			  }
			 
		
	}
	
	//function to confgure animation movement of the time line
	this.config = function(configstr){
		//if there are paused element dont config timeline until no pause element
		
		 if(this.pauseArr.length > 0){return;}
			 
		 
		this.ClearConfig(); //clear all animation config
		this.configstr = configstr;
		if(typeof configstr == "undefined" || trim(configstr) == ""){return;} //if no string supplied or empty string supplied return
		var configarr = this.configstr.split(";"); //brack down string into an array of transition string
		if(configarr.length > 0){ //Animation config exist
		
			var StartAnimNm = "";//hold the animation name to start with
			var FirstAnimNm = ""; //hold the first animation name on the list
			for(i = 0,leni=configarr.length; i < leni; i++){ //loop thru the array to get each transition structure 
			    
				 var animconfigarr = configarr[i].split(":"); //break transition string down
			        //if structure found
			     if(animconfigarr.length == 4){ //if the structure is valid
				  
					 var AnimName = trim(animconfigarr[0]); //the Animation Name
					 StartAnimNm = (AnimName.substring(0, 1) == "*")?AnimName.substring(1,AnimName.length):StartAnimNm; //set the Start Animation
					 AnimName = (AnimName.substring(0, 1) == "*")?StartAnimNm:AnimName; //resolve animation Name
					
					 if(i == 0){
						FirstAnimNm = AnimName; //the first animationname on the list 
					 }
					 
					 animconfigarr[1]=(trim(animconfigarr[1]) == "")?"0":trim(animconfigarr[1]); //resolve duration, 0 if not supplied
					 var AnimDur = parseFloat(animconfigarr[1]);
					 animconfigarr[2]=(trim(animconfigarr[2]) == "")?"0":trim(animconfigarr[2]); //resolve delay zero if not supplied
					 var AnimDelay = parseFloat(animconfigarr[2]);
					 var trigers = trim(animconfigarr[3]);
					 var triggerarrobj = new Array(); //hold the trigger objects set for the animation
					 
					 if(trigers != ""){ //if triggers are set
						
						var trigersarr = trigers.split("#");
						if(trigersarr.length > 0){
							
							//loop through trigers and form a triger object array
							for(var b = 0,lenb = trigersarr.length ; b < lenb ; b++){
								var trig = trigersarr[b]; //get the trigger string
			var trigarr = trig.split("="); //break down the trigger (value - rep the time and trigerAction - the name of the action
								if(trigarr.length == 2){ //if triger structure is valid
									var val = trim(trigarr[0]); //get the value
									if(typeof parseFloat(val) == "number"){ //if converted to number successfully
										triggerarrobj[triggerarrobj.length] = {value:val, name:trigarr[1]}; //add object to triger array
									}
									
								}
								
							}
						}
					 }
					 
					 this.Anims[AnimName].duration = (AnimDur == 0)?this.Anims[AnimName].Ddur:AnimDur; //set animation duration (if not supplied set as default
					 this.Anims[AnimName].delay = AnimDelay * this.Anims[AnimName].duration; //delay = value suplied * duration
					 
					 this.Anims[AnimName].trigger = (triggerarrobj.length > 0)?triggerarrobj:null; //set animation triggers
					//alert(StartAnimNm + " , " + FirstAnimNm);
				 
					  }
				
				

			  
			}
			//set the Animation object name to start
			if(StartAnimNm != ""){ //if indicated
				this.startobj = StartAnimNm;
			}else if(FirstAnimNm != ""){ //if not indicated, but at least one animation obj exist, use the first on the list
				this.startobj = FirstAnimNm;
			}else{ 
				this.startobj = null;
			}
			
		}
		//alert(configstr);
	}
	
}

SpeedAnims = new function(){
	this.TM = new Timeline;
	this.Fade = function(obj,speed,type,EndAction){
		
		speedl = (!IsSet(speed) || IsNull(speed))?null:speed;
		endact = (!IsSet(EndAction) || IsNull(EndAction))?"":EndAction;
		SpeedAnims.TM.RemoveAnim(obj.id);
		SpeedAnims.TM.AddAnim({object:obj,handler:type,duration:speedl,style:1,ease:''});
		var typecd = 0;
		//alert(type)
		if(type == FadeIn){
			typecd = 1;
		  SO(obj,0);
		  __(obj.id).display = "block";
		  //alert(EndAction);
		 // SH(obj,1);
		}else{
			
			SO(obj,1);
			__(obj.id).display = "block";
		
		}
		
		SpeedAnims.TM.Anims[obj.id].trigger = [{value:1.0, name:"SpeedAnims.finishAnim('"+obj.id+"','"+escape(EndAction)+"',"+typecd+")"}];
		SpeedAnims.TM.play(obj.id);
		
		
	}
	
	this.finishAnim = function(id,EndCode,type){
		//alert('sss');
		
		EndCode = unescape(EndCode);
		if(type == 0){
		_(id).style.display='none';
		}
		eval(EndCode);
	}
	
	this.FadeIn = function(obj,speed,EndCode){
		
		SpeedAnims.Fade(obj,speed,FadeIn,EndCode);
	}
	
	this.FadeOut = function(obj,speed,EndCode){
		
		SpeedAnims.Fade(obj,speed,FadeOut,EndCode);
	}
	
	this.FadeInn = function(sp,EndCode){
		SpeedAnims.FadeIn(this,sp,EndCode);
		

	}
	this.FadeOutn = function(sp,EndCode){
		
		SpeedAnims.FadeOut(this,sp,EndCode);
	}
	
	this.formAnimCss = function(css){
		var transarr = ["transition","-webkit-transition","-o-transition","-moz-transition"];
	
	}
	
	this.AnimateTo = function(param){
		//param.Element, param.CSSRule, param.Time, param.EndAction(string - code to run after animation), param.Delay, param.DoAt (the animation time factor to execute the EndAction)
		//obj, css, endAction, animtime
		
		animtime = IsSet(param.Time)?param.Time:1000;
		animtime = (animtime/1000) + "s";
		
		var transarr = ["transition","-webkit-transition","-o-transition","-moz-transition"];
		if(IsSet(param.CSSRule)){
			var css = param.CSSRule;
			var animcss = "";
				cssarr = css.split(";")
		//var cssstr = "";
			   for(var s=0,lens=transarr.length; s<lens; s++){
				  animcss += transarr[s] + ": ";
				  for(var w=0,lenw=cssarr.length; w< lenw; w++){
					  cssr = cssarr[w];
					   
					  atrval = cssr.split(":");
					 // 
					  if(atrval.length == 2){
						  var atr = atrval[0];
						 // var sss = ""
						  animcss += atr + " " + animtime + ",";
						
					  }
					  
				  }
			 
				animcss = animcss.StrTrimRight(",") + ";";	
				if(IsSet(param.Delay)){//transition-delay: 0.2s;
						
							 var delay = (param.Delay/1000) + "s";
							 animcss += transarr[s] + "-delay: " + delay + ";" ;
							  //alert(animcss);
				}  
				
		 }
		animcss += css;
		//alert(animcss);
			//}
			 if(IsSet(param.EndAction)){
				 var delta = IsSet(param.DoAt)?param.DoAt:1.0;
				// console.log(param.EndAction);
				 setTimeout(param.EndAction,(param.Time * delta));
			 }
			// alert(animcss);
			param.Element.SetStyle(animcss);
		}
	}
	
}


Object.prototype.Animate = function(Param){Param.Element = this;
                                           SpeedAnims.AnimateTo(Param);
										   };
String.prototype.Animate = function(Param){Param.Element = _(this.toString());
                                           SpeedAnims.AnimateTo(Param);
										   };
Array.prototype.Animate = function(Param){var Element = this;
                                           for(var a = 0,lena=Element.length; a < lena; a++){
											   Param.Element = Element[a];
                                               SpeedAnims.AnimateTo(Param);
										   }
										   };
Object.prototype.FadeIn = function(time,end){if(typeof end == _UND){this.Animate({CSSRule:"opacity:1",Time:time})}else{this.Animate({CSSRule:"opacity:1",Time:time,DoAt:1.0,EndAction:end})}}; //(speed, type)
Object.prototype.FadeOut = function(time,end){if(typeof end == _UND){this.Animate({CSSRule:"opacity:0",Time:time})}else{this.Animate({CSSRule:"opacity:0",Time:time,DoAt:1.0,EndAction:end})}};
})();