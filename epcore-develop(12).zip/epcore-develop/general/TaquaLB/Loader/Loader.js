// Taquatech Javascript library loader
//Object.prototype.LoadType;
DOM = {
	ReadyList:new Array(), //list of all event to run whwn page loads
	Ready:function(func,param){
		//alert(func);
		param = typeof param == "undefined"?null:param;
	  DOM.ReadyList.push([func,param]);
	},
	Run:function(){
		//alert("Running: "+DOM.ReadyList.length)
	  if(DOM.ReadyList.length > 0){
		  var ii = 0;
		 for(const lenll=DOM.ReadyList.length;ii<lenll;ii++){
			 var it = DOM.ReadyList[ii];
		   var func = it[0];
		   var prm = it[1];
		   //run the function
		   func(prm);
		 }
	  } 
	  return true; 
	}

  }
rarr = new Array();rarr['Premium']='Basic,#Printer,Animation,Ajax,#Elements,#DateTimePicker';rarr['Enterprise']='Basic,Printer,Animation,Ajax';rarr['Standard']='Basic,Printer,Animation';rarr['BasicPlus']='Basic,Printer';rarr['Basic']='Basic';rarr['Elements']='Basic,Animation,Ajax,#Elements';rarr['Ajax']='Basic,Ajax';
newarr = new Array();
pointer = -1;
_d = (typeof _d=="undefined")?document:_d;TaquaLoader={lb:"TaquaLB",finish:false,b:"",min:""};
var _setsrc= function(src){ //create the html script tag, set the src and insert it
  var srcarr = src.split(".");
  if(srcarr.length < 2)return; 
	  var ext = srcarr[srcarr.length - 1];
	  ext = ext.replace(/\s+$/g,'').toLowerCase();
 var fsc,s = ext=="css"?"link":"script";
		var sc = _d.createElement(s);
		
		if(ext=="css"){
			sc.href = src;
			sc.type = "text/css";
			sc.media = "all";
			sc.rel = "stylesheet";
		}else{
			sc.src = src;
			//alert(src);
		}
			fsc = _d.getElementsByTagName("script")[0];
			//  alert(newarr.length);
			if(ext!="css"){
			sc.onload = LoadNext;
			}else{
			   LoadNext(); 
			}
			
		  //alert(src);
			fsc.parentNode.insertBefore(sc,fsc);	
  
}
function LoadNext(){
 
 pointer = pointer + 1;
 //alert(pointer)
 if(pointer < newarr.length  ){
 //alert(pointer + " = " + newarr[pointer] + "; len = " + newarr.length);	
 _setsrc(newarr[pointer]);
 }else{
	 TaquaLoader.finish = true;
 }
}
String.prototype.ScriptLoad = function(){ //load the appropriate script based on the string 
 /*var loadtypes = this.toString();
 loadtypes = loadtypes.split(";");
 if(loadtypes.length > 1){
	 loadtypes.ScriptLoad();
	 return;
 }*/
 
		  if(typeof rarr[this.toString()] != 'undefined'){ //if taqualb
 
			var locs = rarr[this.toString()].split(",");
				
				for(var w=0,lenw=locs.length;w<lenw;w++){
					//_setsrc(lb+"/"+locs[w]+"/"+locs[w]+".js")
					var file = locs[w];
					filestart = file.substr(0,1);
					if(filestart == "#"){ //if css exist
						file = file.substr(1);
						//newarr.push(lb+"/"+file+"/"+file+".js");
						newarr.push(TaquaLoader.lb+"/"+file+"/"+file+TaquaLoader.min+".css");
					}
					newarr.push(TaquaLoader.lb+"/"+file+"/"+file+TaquaLoader.min+".js");
					};
				  
			}else{ //if user specified
			
				var str = this.toString();
				if(str.indexOf(":",0) >= 0){//if common directary
				
				   var strarr = str.split(":");if(strarr.length != 2)return;
				   var pths = strarr[1].split(",");
				   for(var w=0,lenw=pths.length;w<lenw;w++){
					   //_setsrc(strarr[0]+"/"+pths[w])
					   newarr.push(strarr[0]+"/"+pths[w]);
						 
					   };
				}else{//if full path supplied
				//_setsrc(this.toString());
				
				newarr.push(this.toString());
				}
			}
		   // st = new String('ss');
			
};

Array.prototype.ScriptLoad = function(){
	 if(this.length > 0){ //for array loop through all values specified
	   for(var s = 0,lens=this.length; s < lens; s++){
		   
		   this[s].ScriptLoad();
	   }
	   
	   LoadNext();
	 }
 };
 //function to automatically loads start loading
var Start = function(){
 //alert("enter start");
 var obj = document.getElementsByTagName("script"); //get the script element
 
 if(obj.length > 0){
	 for(var a=0,lena=obj.length; a<lena; a++){//loop through all script element found
	 //get an array of atrribute(key) and value, sending in the script outer HTML
	 
		 /*var attval = function(str){
			 //document.getElementById().getAttribute("");
		   var innercont = str.substr(str.indexOf("<")+1, str.indexOf(">")-1); //get inner tagname and attribut=value list (string)
		   var atrval = innercont.split(" "); //get the individual pair
			var newarr = new Array();
		   for(var s=0; s<atrval.length; s++){
			   
			var atrvarr = atrval[s].split("="); //get tha value and the attribute
			  if(atrvarr.length == 2){
				var val = atrvarr[1].substr(atrvarr[1].replace(/^\s+|\s+$/g,'').indexOf('"')+1,atrvarr[1].length - 2);//remove "" from the value
				//alert("atr=>"+atrvarr[0].replace(/^\s+|\s+$/g,'').toLowerCase()+" ; val=>"+val);
				newarr[atrvarr[0].replace(/^\s+|\s+$/g,'').toLowerCase()] = val; //insert value in the array using the attribute as key
			   }
		   }
		   return newarr; //return the array after loop
		 }(obj[a]['outerHTML']);*/
		 var loadtypes =  obj[a].getAttribute("loadtype");
		 
		 var srcs =  obj[a].getAttribute("src");
		 Loader.FinishFunc = obj[a].getAttribute("onComplete");
		 //alert(Loader.FinishFunc);
		 //if script tag is a valid TAQUALB library loader script tag
		 // if(typeof attval['loadtype'] != 'undefined' && typeof attval['src'] != 'undefined'){
			 
			if((typeof loadtypes != 'undefined' && typeof srcs != 'undefined') && (loadtypes != null &&  srcs != null)){
			   // alert(loadtypes);
			 // var loadtypes = attval['loadtype'] ;
			  var basesrc = srcs.split("/");
			  var loaderfn = basesrc[basesrc.length - 1];
			  //get if the Compress version is to be loadaed or not (default is valse)
		 //load types : True = minify | false = beutified
		 //only minify library js. and css;
		 var mini = obj[a].getAttribute("compress");
		 mini = mini == null || (mini.replace(/^\s+/, '').replace(/\s+$/, '').toLowerCase() != 'true') ?'false':mini.replace(/^\s+/, '').replace(/\s+$/, '').toLowerCase();
		 TaquaLoader.min = mini == 'true' || loaderfn.split(".")[1] == 'min'?".min":"";
			 // if() TaquaLoader.min = '.min';
				   var basepath = "";
					for(var s=0,lens=basesrc.length - 2; s < lens; s++){
						basepath += basesrc[s]+"/";
					}
					TaquaLoader.lb = basepath.substr(0,basepath.length - 1);
					TaquaLoader.b = TaquaLoader.lb.replace("/TaquaLB","");
				   // rlb = 
			   loadtypes = loadtypes.split(";");
			  // if(loadtypes.length > 1){
				   loadtypes.ScriptLoad();
				  // var basesrc = attval['src'].split("/");
				 
				   // alert(basepath);
				  // return;
			   //}else{
				   
			  // }
			 // attval['loadtype'].ScriptLoad();//load the scripts
			  return;
		  }
		 
	 }
 }	
return;}


var tid = null;

//loader object to hold the set finishfunction
Loader = new function(){
this.Finish = null;
this.FinishFunc = null;
this.DynamicScriptLoad = function(paths, finishf){
 newarr = new Array();
pointer = -1;
TaquaLoader.finish=false;
Loader.Finish = (typeof finishf == "undefined")?null:finishf;
paths.ScriptLoad(); 
tid = setInterval("dchecker()" , 100 ); 

}
}
function dchecker() {
 if ( document.readyState !== 'complete' || TaquaLoader.finish == false ) return;
 clearInterval( tid ); 
 if(Loader.FinishFunc != null){
	 //alert(Loader.FinishFunc);
	 eval(Loader.FinishFunc);
 }else{
	 //initial function to run when scripts complete loading
 //setTimeout("Main.Load()",0);
 }
  //function to load when page loads
 //alert(window.locationbar.)
 //Start();
}
function completed() {
 document.removeEventListener( "DOMContentLoaded", completed );
 window.removeEventListener( "load", completed );
 //alert('completed');
 if(TaquaLoader.finish == false){ //check if all dynamic loading script are loaded
	 setTimeout(completed,10); // delay and try again
	 return;
 }
 DOM.Run(); //run all add scripts
 if(Loader.FinishFunc != null){ //if loader Finish func set load it
	 //alert(Loader.FinishFunc);
	 eval(Loader.FinishFunc);
 }
}
//the auto run function to start the loading after a successful body load.
(function(){
  
  Start(); //start script loading
  //tid = setInterval("dchecker()" , 100 ); 


// Catch cases where $(document).ready() is called
// after the browser event has already occurred.
// Support: IE <=9 - 10 only
// Older IE sometimes signals "interactive" too soon
if ( document.readyState === "complete" ||
 ( document.readyState !== "loading" && !document.documentElement.doScroll ) ) {

 // Handle it asynchronously to allow scripts the opportunity to delay ready
 window.setTimeout( DOM.Run );
 
 if(Loader.FinishFunc != null){
	 //alert(Loader.FinishFunc);
	 eval(Loader.FinishFunc);
 }
} else {

 // Use the handy event callback
 document.addEventListener( "DOMContentLoaded", completed );

 // A fallback to window.onload, that will always work
 window.addEventListener( "load", completed );
}	 
}());