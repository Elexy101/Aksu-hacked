<?php
if(!isset($_POST['SubDir'])){
	exit("Setup Dir Not Found");
}

require_once("../Elements.php"); 
$configdir = "../../../../../../".$_POST['SubDir'];
require_once("../../../config.php");
//$regno = $dbo->SqlSafe($_POST['regNo']);
/*Textbox dropdown loader*/
$rtnstr = "";
if(isset($_POST['def']) && trim($_POST['def']) != ""){ //if default drop down option set
  //get the key and value;
  $exp = explode(":",$_POST['def']);
  if(count($exp) > 0){ //if key exist
	 $defkey = $exp[0];
	 $defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[1]);
  }else{
	  $defkey = 0;
	$defval = str_replace(array("@~!~@","#@!@"),array(":",'"'),$exp[0]); 
  }
}
if(isset($_POST['tbid']) && isset($_POST['key']) && isset($_POST['value']) && isset($_POST['cond'])  && isset($_POST['table'])){
	
	
	$rst = $dbo->Select4rmdbtb($_POST['table'],$_POST['key'].",".$_POST['value'],$_POST['cond']);
	$id = $_POST['tbid'];
	
	if(is_array($rst)){
		//if($_POST['table'] == "course_tb"){var_dump($rst);exit();}
		if($rst[1] > 0){
			
			$rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=false,id={$id}tb");
			if(isset($defval)){
				$rtnstr .= __TRecord(array($defval),"id={$defkey}");
			}
			while($rec = $rst[0]->fetch_array()){
				$txt = $rec[$_POST['value']];
				$idtxt = $rec[$_POST['key']];
				if(!is_array($txt)){
				 $rtnstr .= __TRecord(array($txt),"id={$idtxt}");
				}else{
				   $rtnstr .= __TRecord($txt,"id={$idtxt}"); 
				}
			}
			$rtnstr .= ___Table();
			
		}else{
			$rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=false,id={$id}tb");
			if(isset($defval)){
				$rtnstr .= __TRecord(array($defval),"id={$defkey}");
			}
             //$rtnstr .= __TRecord(array(""),"id=0");
			$rtnstr .= ___Table();
		}
	}
}
echo $rtnstr;


?>