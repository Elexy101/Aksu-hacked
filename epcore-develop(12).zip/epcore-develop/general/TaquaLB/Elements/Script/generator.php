<?php


$subDir = urldecode($_REQUEST['SubDir']);
$configdir = "../../../../../../".$subDir;
require_once("../../../config.php");
require("../../../getinfo.php");
require_once "../../../TaquaLB/Elements/Elements.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "../../../TaquaLB/Elements/Script/pdf.php";

$baseurl = "../../../../";
//exit($baseurl);
//LoadFile("pdfprint",$baseurl);
include "processor.php";

//exit(GetCharPos(">",'<div class="djdj" name="fhfh<>" fschool="hdhd\">djdj" last="jfj<hdhd>" >')."");

define("E001","Invalid Markup Specified");
define("E002","Markup File Not Found");
define("E003","Markup File is Empty");
define("E004","Markup Header Not Found");
define("E005","Invalid Markup Header");
define("E006","No Markup Engine Found");
define("E006","No Valid Method Found in Markup Engine");

function Message($msg){
    
    global $pdf;
    
    if(isset($pdf) && isset($pdf->Dump)){
        
      $pdf->Dump($msg);
      
    $pdf->Finish();
    //exit($msg);
    exit;   
    }else{
        exit($msg);
    }
    
}

function UrlPrep($url){
    global $dbo;
    global $configdir;
    //check if contain root://
        $root = "root://";
        $url = trim($url);
        
        if(substr($url,0,strlen($root)) == $root){ //if root indicator specified
          //check if exist in subdir
          if(file_exists($configdir.substr($url,strlen($root))))return $configdir.substr($url,strlen($root));
          if(file_exists("../../../../".substr($url,strlen($root))))return "../../../../".substr($url,strlen($root));
          Message(E002. " ".$configdir.substr($url,strlen($root)));
        }
        return $url;
}


   //1. Get the report markup
   if(!isset($_REQUEST['Markup'])){Message(E001);}

   $MarkUp = UrlPrep($_REQUEST['Markup']);
   
   if(!file_exists($MarkUp)){Message(E002. " ".$MarkUp);}
   
   //2. Read the markup file
    $MarkUpStr = file_get_contents($MarkUp);
    $MarkUpStr = trim($MarkUpStr);
    if($MarkUpStr == ""){Message(E003);}
    
    //6. - jump Get all proccessing Section in Markup
    //Get Default Sections
    //a.Paper details - fixed settings
    $papers = GetGroupByName($MarkUpStr,"ep-paper");
    if(count($papers) > 0){
        foreach($papers as $pap){
            if(isset($pap['Attribute']['Paper']) && trim($pap['Attribute']['Paper']) != "")$_REQUEST['paper']=$pap['Attribute']['Paper'];
            if(isset($pap['Attribute']['FontSize']) && trim($pap['Attribute']['FontSize']) != "")$_REQUEST['fontsize']=$pap['Attribute']['FontSize'];
            if(isset($pap['Attribute']['ML']) && trim($pap['Attribute']['ML']) != "")$_REQUEST['ML']=$pap['Attribute']['ML'];
            if(isset($pap['Attribute']['MT']) && trim($pap['Attribute']['MT']) != "")$_REQUEST['MT']=$pap['Attribute']['MT'];
            if(isset($pap['Attribute']['MR']) && trim($pap['Attribute']['MR']) != "")$_REQUEST['MR']=$pap['Attribute']['MR'];
            if(isset($pap['Attribute']['MB']) && trim($pap['Attribute']['MB']) != "")$_REQUEST['MB']=$pap['Attribute']['MB'];
            if(isset($pap['Attribute']['Orientation']) && trim($pap['Attribute']['Orientation']) != "")$_REQUEST['orientation']=$pap['Attribute']['Orientation'];
            $MarkUpStr = str_replace($pap['OpenTag'].$pap['RawMarkup'].$pap['CloseTag'],'',$MarkUpStr);
        }
    }

    $pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");
//$pdf->mpdf->progressBar = 1;
//var_dump($pdf->mpdf);
  //3. Get the header part
  if(substr($MarkUpStr,0,2) != "<%"){Message(E004);}
  
  $clpos = strpos($MarkUpStr,"%>",2); //check the clossing tag
  
  if($clpos === false){Message(E005);}
  $cbdata = substr($MarkUpStr,2,$clpos - 2);//get the header content
 
   //4. Get the individual header properties (engines and methods)
    $inddata = explode(" ",trim($cbdata));
    if(count($inddata) < 1){Message(E005);}
    
    //look for the markup engines and engine methods
    $engines = 0; $methods = [];
    foreach($inddata as $hdata){
        $hdata = trim($hdata);
        if($hdata == "")continue;
        if(substr($hdata,0,1) == "@"){ //if engine found
            $hdata = substr($hdata,1);
            $hdataarr = pathinfo($hdata);
           if(!file_exists($baseurl.$hdata) || $hdataarr['extension'] != "php")continue;
           
           require $baseurl.$hdata;
           $engines++;
        }else{
            $methods[] = $hdata;
        }
    }
    if($engines < 1 || count($methods) < 1){Message(E006);}
    
    //5. Call all the engine functions to get data from engine
    $globalData = ["Data"=>$_REQUEST]; $methcnt = 0;
    foreach($methods as $indmethod){
        //check if exist
        if(function_exists($indmethod)){
            $methcnt++;
            $methodData = call_user_func($indmethod,$globalData);
            if(is_array($methodData)){
                $globalData = array_merge($globalData,$methodData);
            }else{
                $globalData['Data'][] = $methodData;
            }
        }
    }
    
    //exit(json_encode($globalData));
    
    if($methcnt < 1){Message(E007);}
     //remover the script header part
     $MarkUpStr = str_replace("<%".$cbdata."%>","",$MarkUpStr);

    //b. Headers 
    //$headers = GetGroupByName($MarkUpStr,"ep-header");
    
    $hseen = false; $htitle = ""; $hlogosize = "80px*80px"; $hstyle = "font-size:0.9em"; $hmkup = ""; $hwatermk = "Abbr"; $haddr = array("Address"); $ftitle = "";$fhide = array(); $fseen = false;
    /* foreach($headers as $headerobj){
        if(isset($headerobj['Attribute']['Title']) && trim($headerobj['Attribute']['Title']) != "")$htitle=$headerobj['Attribute']['Title'];
        if(isset($headerobj['Attribute']['LogoSize']) && trim($headerobj['Attribute']['LogoSize']) != "")$hlogosize=$headerobj['Attribute']['LogoSize'];
        if(isset($headerobj['Attribute']['Style']) && trim($headerobj['Attribute']['Style']) != "")$hstyle=$headerobj['Attribute']['Style'];
        if(isset($headerobj['Attribute']['WaterMark']) && trim($headerobj['Attribute']['WaterMark']) != "")$hwatermk=$headerobj['Attribute']['WaterMark'];

        if(isset($headerobj['Attribute']['SubTitle']) && trim($headerobj['Attribute']['SubTitle']) != "")$haddr=explode(",",$headerobj['Attribute']['SubTitle']);
        if(isset($headerobj['Attribute']['Data'])){
            //proccess the data
            //$headerobj['Markup']
        }
        $hmkup .= $headerobj['Markup'];//must be populated first
        $MarkUpStr = str_replace($headerobj['OpenTag'].$headerobj['RawMarkup'].$headerobj['CloseTag'],'',$MarkUpStr);
        $seen = true;
    } */
   
    
    //get the sections
    $Sections = GetGroupByName($MarkUpStr,"ep-section");
   // $secdata = [];
     if(count($Sections) > 0){
         //loop trough all section to determine which section to work with using the data supplied
         foreach($Sections as $indsections){
             $sectionName = $indsections['Name'];
                  //Message(json_encode($globalData));
            
                
                //$MarkUpStr = str_replace($indsections['OpenTag'].$indsections['RawMarkup'].$indsections['CloseTag'],$SectionMarkUpStr,$MarkUpStr);
                if($sectionName == "Header"){ //if header section
                    if(isset($indsections['Attribute']['Title']) && trim($indsections['Attribute']['Title']) != "")$htitle=$indsections['Attribute']['Title'];
                    if(isset($indsections['Attribute']['LogoSize']) && trim($indsections['Attribute']['LogoSize']) != "")$hlogosize=$indsections['Attribute']['LogoSize'];
                    if(isset($indsections['Attribute']['Style']) && trim($indsections['Attribute']['Style']) != "")$hstyle=$indsections['Attribute']['Style'];
                    if(isset($indsections['Attribute']['WaterMark']) && trim($indsections['Attribute']['WaterMark']) != "")$hwatermk=$indsections['Attribute']['WaterMark'];
            
                    if(isset($indsections['Attribute']['Hide']) && trim($indsections['Attribute']['Hide']) != "")$haddr=explode(",",$indsections['Attribute']['Hide']);
                    if(isset($indsections['Attribute']['Data'])){
                        //proccess the data
                        //$headerobj['Markup']
                    }
                    $hmkup = isset($globalData[$sectionName])?Populate($globalData[$sectionName],$indsections['Markup']):$indsections['Markup'];//must be populated first
                    $hseen = true;
                    $SectionMarkUpStr = '';
                   // $MarkUpStr = str_replace($indsections['OpenTag'].$indsections['RawMarkup'].$indsections['CloseTag'],'',$MarkUpStr);
                }elseif($sectionName == "Footer"){ //if footer section
                    
                    if(isset($indsections['Attribute']['Title']) && trim($indsections['Attribute']['Title']) != "")$ftitle=$indsections['Attribute']['Title'];
                    if(isset($indsections['Attribute']['Hide']) && trim($indsections['Attribute']['Hide']) != "")$fhide=explode(",",$indsections['Attribute']['Hide']);
                    $sig = "";
                    if(isset($indsections['Attribute']['Signature']) && trim($indsections['Attribute']['Signature']) != "")$sig=explode(",",$indsections['Attribute']['Signature']);
                    $sig = is_array($sig)?$pdf->Signataries($sig):"";
                    $fmkup = isset($globalData[$sectionName])?Populate($globalData[$sectionName],$sig.$indsections['Markup']):$sig.$indsections['Markup'];//must be populated first
                    $fseen = true;
                }else{
                    $SectionMarkUpStr = isset($globalData[$sectionName])?Populate($globalData[$sectionName],$indsections['Markup']):"";
                    
                }
                
                $MarkUpStr = str_replace($indsections['OpenTag'].$indsections['RawMarkup'].$indsections['CloseTag'],$SectionMarkUpStr,$MarkUpStr); 
              //  $secdata = array_merge($secdata,$globalData[$sectionName]);    
            /* }else{
                //delete the section
                $MarkUpStr = str_replace($indsections['OpenTag'].$indsections['RawMarkup'].$indsections['CloseTag'],'',$MarkUpStr);
            } */
             
            
         }
     }
    //process markup
    
   // $secdata = count($secdata) == 0?$globalData:$secdata;
    $MarkUpStr = Populate($globalData,$MarkUpStr);
    
    //work on the header data
    if($hseen){
        //Message(json_encode($globalData['ResultInfo']));
        //all user data is available in Header Section
        //$hmkup = Populate($globalData,$hmkup);
        $headermk = $pdf->FormHeader($htitle,array("LogoSize"=>$hlogosize,"Style"=>$hstyle,"WaterMark"=>$hwatermk),null,$hmkup,$haddr);
        $pdf->SetHeader(Populate($globalData,$headermk));
        //remove it from the markup
        //Message("Seen");
    }

if($fseen){
    $footermk = $pdf->FormFooterNote($ftitle,$fmkup,$fhide);
    $pdf->SetFooterNote(Populate($globalData,$footermk));
}
    
    if(trim($MarkUpStr) != ""){
        $pdf->Dump($MarkUpStr);
    }
    
   // $mkstr = GetGroupByName($MarkUpStr);
    
    $pdf->Finish();
?>