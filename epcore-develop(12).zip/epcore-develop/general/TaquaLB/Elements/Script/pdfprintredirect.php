<?php
include("../../Ajax/CGI/PHP/config.php");
LoadFile("pdfprintredirect","../../../../");
 $url = $_GET['url'];
     unset($_GET['url']);
     $datastr = $dbo->DataString($_GET);
?>
<html>
<head>
 <title>Generating PDF Preview</title>
 <link href="../../../GenScript/CSS/logos/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css" >
   .redmaindiv{
	width: 100%;
	height: 100%;
	display: flex;
	text-align: center;
	font-family: "Segoe UI", "Segoe UI Black", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Semilight";
	font-size: 2.0em;
	color: #FFF;
	font-weight: lighter;
}.redmaindiv div{
  align-self: center; margin: auto; text-align: center
}
</style>
<script type="javascript">
function Redirect(){
    alert('ss')
  ;
}

</script>
</head>
<body onload = "document.location = '<?php echo $url.'?'.$datastr ?>'">
   <div class="redmaindiv">
       <div>
   <?php
    
     //echo $datastr;
      Icon("cog fa-spin");
   ?>
   &nbsp;Generating Preview ...
   </div>
   </div>
</body>

</html>
