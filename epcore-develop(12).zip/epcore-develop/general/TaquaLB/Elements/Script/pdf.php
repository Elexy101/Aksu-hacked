<?php


$outPut .= '<option value="'.$idoutp.'">'.$row[1].'</option>';

//echo 
//define('_MPDF_PATH','../../Ajax/CGI/PHP/PDF/mpdf60/')
//require_once __DIR__ . '/vendor/autoload.php';
//$ss = new mPDF();
//print_r($ss);
//pdf Print class 
//LE - 22-5-17 #4
//**************************************************
class PDFPrinter{
public $html = "";
public $mpdf = null;
public $logo = "";
public $download = "";
public $filename = "document.pdf";
public $schoolArr = null; //added to globally hold the school detatils 22-5-17 #2
public $BasePath = "";//LE 29/6/17 #5 - trying to handle apsolute path issue in some servers, holds the base path(the relative url to the server root) of the script calling the PDF LIB e.g ../../../
public $BaseConfigPath = _CONFIGDIR_;

//public $ss = "aaaa";
//([ string $mode [, mixed $format [, float $default_font_size [, string $default_font [, float $margin_left , float $margin_right , float $margin_top , float $margin_bottom , float $margin_header , float $margin_footer [, string $orientation ]]]]]])
//constructor

function PDFPrinter($mode="",$format="A4",$default_font_size = "11",$default_font="",$margin_left=4,$margin_right=4,$margin_top=4,$margin_bottom=16,$margin_header=3,$margin_footer=3,$orientation="P"){
 // echo ; //"paper="+paper+"&orientation="+orienta+"&fontsize="+fontsize+"&ML="+ML+"&MT="+MT+"&MR="+MR+"&MB="+MB;
 $format = isset($_REQUEST['paper'])?$_REQUEST['paper']:$format;
 $default_font_size = isset($_REQUEST['fontsize'])?$_REQUEST['fontsize']:$default_font_size;
 $margin_left = isset($_REQUEST['ML'])?$_REQUEST['ML']:$margin_left;
 $margin_right = isset($_REQUEST['MR'])?$_REQUEST['MR']:$margin_right;
 $margin_top = isset($_REQUEST['MT'])?$_REQUEST['MT']:$margin_top;
 $margin_bottom = isset($_REQUEST['MB'])?$_REQUEST['MB']:$margin_bottom;
 $orientation = isset($_REQUEST['orientation'])?$_REQUEST['orientation']:$orientation;
 $format .= "-".$orientation;
  
  $this->html .= $this->pageStyle;
  $this->download = isset($_REQUEST['dl']) && (int)$_REQUEST['dl'] == 1?"D":"I";
  if(isset($_REQUEST['fn'])){$this->filename = $_REQUEST['fn'];}
 // define('_MPDF_URI',_CONFIGDIR_."TaquaLB/Ajax/CGI/PHP/PDF/mpdf60/includes/");
 //$this->$BaseConfigPath = constant("_CONFIGDIR_");
  $this->mpdf = new mPDF($mode,$format,$default_font_size,$default_font,$margin_left,$margin_right,$margin_top,$margin_bottom,$margin_header,$margin_footer,$orientation);
  //echo "aaa";
//exit($this->mpdf);
 // $this->Page();
}

//function to set the BasePath and the baseconfigpath
function SetBasePath($path){
	$this->BasePath = $path;
	$this->BaseConfigPath = $path;
}

function HTML(){
  ob_start();
}

function _HTML(){
  $this->html .= ob_get_contents();
  ob_end_clean();
}

//Start Page Initialization
function Page(){
   
   //echo $this->html;
}

//set up the school Slip Header

  function Banner($title,$setting = array('LogoSize'=>"150px*150px","Style"=>"","Align"=>"Center"),$school=null,$morehtml = '',$hideArray=array()){
	
    //echo "aaa";
     //echo $title;
      $this->html .= $this->PrintHeader($title,$setting,$school,$morehtml,$hideArray);
     //echo $this->html;
  }

	function Header($title,$setting = array('LogoSize'=>"150px*150px","Style"=>""),$school=null,$morehtml = '',$hideArray=array()){
	$this->mpdf->SetHTMLHeader($this->PrintHeader($title,$setting,$school,$morehtml,$hideArray));
}

function FormHeader($title,$setting = array('LogoSize'=>"150px*150px","Style"=>""),$school=null,$morehtml = '',$hideArray=array()){
  return $this->PrintHeader($title,$setting,$school,$morehtml,$hideArray);
}

function SetHeader($headerhtml){
	$this->mpdf->SetHTMLHeader($headerhtml);
}

  function Finish(){
    //print_r($this);
    if(!is_null($this->mpdf)){
			
			$this->mpdf->WriteHTML($this->html);
			
		 /*$htmllen = strlen($this->html);
		 $len = 100000;
		 $start = 0;
		 if($htmllen > $len){
			 while($start < $htmllen){
				 $chnk = substr($this->html,$start,$len);
				 $this->mpdf->WriteHTML($chnk);
				 $start += $len;
			 }
			 
		 }else{
			 //$this->mpdf->WriteHTML($this->html);
		 }*/
   
	 //echo $this->html;
	 //exit($this->mpdf);
	 $this->mpdf->Output($this->filename,$this->download);
	 
   //echo "aaa";
    }
   // echo $this->html;
  }

	function WriteHTML(){
      echo "<html>".$this->html."</html>";
	}
  //function to display info on slip
function Panel($Style=""){
	$this->html .= '<div style="'.$Style.'" class="InfoDiv">';
}
function _Panel(){
	$this->html .= '<div style="clear:both"></div></div>';
}

function Info($title,$value,$titlesize="30%",$valuesize="60%"){
	$str = "<div class=\"IndItem\" >";
	$str .= "<div class=\"itemname\" style=\"width:$titlesize\" >$title</div>";
	$str .= "<div class=\"itemvalue\" style=\"width:$valuesize\" >$value</div>";
	$str .= '<div style="clear:both"></div></div>';
  $this->html .= $str;
}

function InfoTitle($title){
	$str = "<div class=\"IndItemHeader\" >";
	$str .= $title;
	$str .= "</div>";
  $this->html .= $str;
}

function InfoBox($size = 4,$Style=""){
	//$dif = $size > 1?"15px":"20px";
	$f = ($size == 4)?"x":"";
	$size = floor($size * 24);
	
 // $Style .= $size = 4 && $Style==""?"margin-left:1%":"";
	$this->html .= '<div class="bx'.$f.'" style="width:'.$size.'%;'.$Style.'">';
}
function _InfoBox(){
	$this->html .= '</div>';
	
}

//function to get print header 
function PrintHeader($title,$setting,$school=null,$morehtml='',$hideArray=array()){
$school = is_null($school)?GetSchool():$school; //function from general getinfo script
$this->schoolArr = $school; //set the global school variable 22-5-17 #3
//print_r($school);

$logo = $this->BaseConfigPath.$school["logo"]; //_CONFIGDIR_ - constant decleared in 
$this->logo = $logo;
$imgdimr = !isset($setting['LogoSize'])?"150px*150px":$setting['LogoSize'];
$Style = !isset($setting['Style'])?"":$setting['Style'];
$Align = !isset($setting['Align'])?"Center":$setting['Align']; 
$imgdim = "width:".str_replace("*",";height:",$imgdimr).";";

$abbr = $school["Abbr"];
$nm = $school["Name"];
$shtabbr = $school["LongAddr"];
if(isset($setting['WaterMark'])){
	if($setting['WaterMark'] == "logo"){
		$this->WaterMarkImage($logo,0.1);
	}else{
		if(isset($school[$setting['WaterMark']])){
			$this->WaterMarkText($school[$setting['WaterMark']],0.1);
		}else{
			$this->WaterMarkText($setting['WaterMark'],0.1);
		}
	}
}

$imgstyle="";
$txtstyle ="";
if($Align == "Left"){
	$ww = explode("*",$imgdimr);
	$imgstyle = "float:left;text-align:left;margin-left:0px;";
	$txtstyle = "float:right;width:calc(100% - ".$ww[0]." - 20px);text-align:left;margin-left:20px";
}
$header = '
<div id="TitleDiv" style="'.$Style.'">
   <div id="InnerDiv">';
  
     if(!in_array("Logo",$hideArray)){ //if to hide the logo
    $header .= '<div id="logocont" style="'.$imgstyle.$imgdim.'" ><img src="'.$logo.'" name="SchoolImg" alt="'.$abbr.'"  /></div>';
		 }

      $header .= '<div id="TitleBox" style="'.$txtstyle.'">';
			if(!in_array("Name",$hideArray)){ //if to hide the school Name
        $header .= '<div id="SchoolName">'.$nm.'</div>';
			}

			if(!in_array("Address",$hideArray)){ //if to hide the Address
        $header .= '<div id="SchoolAddress">'.$shtabbr.'</div>';
			}

			if(!in_array("Title",$hideArray)){ //if to hide the title
        $header .= '<div id="payTitle">'.$title.'</div>';
			}
      $header .= '</div><div style="clear:both"></div>
   </div>
</div>'.$morehtml;

/*$ff = '<div style="width:95%; margin:auto">
  <div style="float:left;width:60%" >&copy; '.$abbr.' '.date('Y').' - '.$title.'
  <br /> Powered By Taquatech
  </div>
  <div style="float:right;width:28%; font-size:1.5em;text-align:right" >{PAGENO}/{nbpg}</div>
  </div>';
  $this->mpdf->SetHTMLFooter($ff);*/
return $header;
}

function Dump($html){
   $this->html .= $html;
}

function Image($src = "",$Style = ""){
  if($src != ""){
    $this->html .= '<img src="'.$src.'" style="'.$Style.'" alt="Image" />';
  }
}

function Table($style){
  $this->html .= '<table style="'.$style.'">';
}

function _Table(){
  $this->html .= '</table>';
}

function TableHead($tabledata = array()){
  $this->html .= '<thead><tr>';
  foreach($tabledata as $data){
    $this->html .= '<th>'.$data.'</th>';
  }
  $this->html .= '</tr></thead>';
}

function TableFoot($tabledata = array()){
  $this->html .= '<tfoot><tr>';
  foreach($tabledata as $data){
    $this->html .= '<td>'.$data.'</td>';
  }
  $this->html .= '</tr></tfoot>';
}

function TableRow($tabledata = array(),$AtrVal=""){
  $this->html .= '<tr '.$AtrVal.'>';
  foreach($tabledata as $data){
    $this->html .= '<td>'.$data.'</td>';
  }
  $this->html .= '</tr>';
}

function WaterMarkImage($src="",$op=1,$size="F",$pos="F"){
   if(isset($src) && $src != ""){   $this->mpdf->SetWatermarkImage($src,$op,$size,$pos);
    $this->mpdf->showWatermarkImage = true;
   }
  }

function WaterMarkText($txt = "",$op=1){
  if(isset($txt) && $txt != ""){   $this->mpdf->SetWatermarkText($txt,$op);
   $this->mpdf->showWatermarkText = true;
  // $this->mpdf->SetWatermarkText()
   }
}

function FooterNote($title,$html="",$hideArray=array()){
	$ff = $this->FormFooterNote($title,$html,$hideArray);
  $this->mpdf->SetHTMLFooter($ff);
}

function FormFooterNote($title,$html="",$hideArray=array()){
	$ff = $html;
	$abbr = is_null($this->schoolArr)?"":$this->schoolArr['Abbr']; //get the scholl abbrivation 22-5-17 #4
	$compname = is_null($this->schoolArr) || !isset($this->schoolArr['BrandCompany'])?"TAQUATECH":strtoupper($this->schoolArr['BrandCompany']); //get the scholl abbrivation 22-5-17 #4
  $ff .= '<div style="width:95%; margin:auto">
  <div style="float:left;width:60%" >';
	if(!in_array("Copyright",$hideArray)){ //to hide the copyright info
	$ff .='&copy; '.$abbr.' '.date('Y');
	}
	if(!in_array("Title",$hideArray)){ //to hide the title info
	$ff .= ' - '.$title;
	}
	if(!in_array("Developer",$hideArray)){ //to hide the developer name
	$ff .= '<br /> Powered By '.$compname.' &amp; '.$abbr.' ICT';
	}
  $ff .= '</div>';
	if(!in_array("Numbering",$hideArray)){ //to hide the page numberin
  $ff .= '<div style="float:right;width:28%; font-size:1.5em;text-align:right" >{PAGENO}/{nbpg}</div>';
	}
	$ff .='</div>'; //added ".$abbr.' ICT" 22-5-17 #1
	return $ff;
}

function SetFooterNote($ff){
	$this->mpdf->SetHTMLFooter($ff);
}

function WriteSignataryHeader($cont,$title = ""){
	$html = "";
	if(!is_array($cont)){
		$cont = trim($cont) == ""?$title:$cont;
		$html .= '<div style="margin-top:3px;text-align:center;font-weight:bold"> '.$cont.'</div>';	
	  }else{
		  foreach($cont as $scont){
			  if(is_array($scont)){
				  $html .= $this->WriteSignataryHeader($scont,$title);
			  }else{
				$scont = trim($scont) == ""?$title:$scont;
				$html .= '<div style="margin-top:3px;text-align:center;font-weight:bold"> '.$scont.'</div>';	  
			  }
		  }
	  }
	  return $html;
}

function FormSignataryItem($title,$valuearr,$continue=false,$showTitle=false){
	$ids = ["1"=>"Signature:","2"=>"Name:","3"=>"Date:"];
	$subfound = false;
if($continue){
	$html = '';
}else{
$html = '<div style="width:90%;margin:auto;max-width:300px">';
}
	
					foreach($valuearr as $tit=>$cont){
						//$html .= $tit;
						if($tit == "#"){ //if to insert title
							$html .= $this->WriteSignataryHeader($cont,$title);
							//$html .= "hhhhhh";
							continue;
						}
            if(is_array($cont)){
								//close the current, and form another
								/* $html .= '</div>
							<div style="margin-top:3px;text-align:center;font-weight:bold"> '.$title.'</div>'; */
							$html .= '</div>';
							$html .= $this->FormSignataryItem($tit,$cont,true);
							$subfound = true;
						}else{
							$style = '';
							//$html .= $this->BasePath.$cont;
							if((int)$tit == 1 && trim($cont) != "")$cont = '<img src="'.$this->BasePath.$cont.'" alt="" style="height:40px" />';
							//if((int)$tit == 1 && trim($cont) == "")$style = 'height:10px';
						
							 $tit = isset($ids[$tit])?$ids[$tit]:$tit;
							 
						 $html .= '<div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px;">'.$tit.'&nbsp;&nbsp;&nbsp;&nbsp;'.$cont.'</div>';
							// $html .= '<div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px;">'.$cont.'</div>';
						}
						
					}
          /* <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
					<div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div> */
					if(!$subfound){
						if(!$continue){
$html .= '</div>';
						}
if($showTitle)$html .= '<div style="margin-top:3px;text-align:center;font-weight:bold"> '.$title.'</div>';
					}
					return $html;
					
}


function Signataries($sgnatry,$style="",$showTitle = false){
if(is_string($sgnatry)){
	$sgnatry = json_decode($sgnatry,true);
	if(is_null($sgnatry))return '<hr />';
}
  $numofsig = count($sgnatry);

	$html = '<div style="width:100%;margin-top:10px;'.$style.'">';
  if($numofsig > 0){
			$wi = number_format(100/$numofsig,1);
    foreach($sgnatry as $key=>$signnm){
			$valuearr = ["1"=>"","2"=>"","3"=>""];
			$title = "";
			if(is_array($signnm)){
				$valuearr = $signnm;
				$title = $key;
			}else{
				$title = $signnm;
			}
			$html .= '<div style="width:'.$wi.'%;float:left;font-size:0.8em">';
      /* <div style="width:90%;margin:auto;max-width:300px">';
					foreach($valuearr as $tit=>$cont){
						$html .= '<div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">'.$tit.': '.$cont.'</div>';
					}
           <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div> 
					$html .= '</div>
			<div style="margin-top:3px;text-align:center;font-weight:bold"> '.$title.'</div>*/
			$html .= $this->FormSignataryItem($title,$valuearr,false,$showTitle);
			$html .= '</div>';
		}
	}
	$html .= '</div><hr />';
	return $html;
	/*
' <div style="width:100%;margin-top:10px">
    <div style="width:33.3%;float:left">
       <div style="width:80%;margin:auto;max-width:500px">
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Signature: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Name: </div>
          
          <div style=" font-style:italic; border-bottom:#000 dotted 1px;margin-top:4px">Date: </div>
       </div>
      <div style="margin-top:3px;text-align:center;font-weight:bold">HEAD OF DEPARTMENT</div>
    </div>

	*/
}




public $pageStyle = '
<style type="text/css"  >
.topic{
	/*background:#999999;*/
	text-align:center;
	font-size:1.2em;
	font-weight:600;
	border-bottom:#CCCCCC solid 2px;
	text-transform:uppercase;	
}
.Rotate90{
	text-rotate: 90;
	text-align:left;
	vertical-align:bottom;
		
}

.title, .value{
	font-weight:600;
	width:50%;
}
.value{
	font-weight:normal;
}
table{
	width:95%; margin:auto; border-collapse:collapse; margin-top:15px;align:center; font-weight:500;
}

tr,td,th{
	border:#D5D5D5 thin solid;
	
	padding:5px;
	
}
th{text-transform:uppercase; text-align:center;background-color:rgba(0,0,0,.06);
	}
.err{
   background-color:rgba(0,0,0,.06);
	}

.inv{
   color:#555;
	}

td.title{
	padding-left:20px;
	vertical-align:top;
	text-align:start;
	
}
#passp{
	width:200px;
	height:200px;
	display:block;
	margin-left:auto;
	margin-right:auto;
	margin-bottom:15px;
	margin-top:8px;
	border:#CCCCCC solid thin;	
}

.linebottom{
	border-bottom:#CCCCCC solid 2px;
}

.secondColor{
	color:;
}

body{
	font-family:calibri,Arial,"Segoe UI Light","Segoe UI" ;
	font-weight:lighter;
	margin:0px;
	padding:0px;
	margin-bottom:0px;
	
	background-color:;
	font-size:0.8em;
}

#TitleDiv{
	width:100%;
	height:auto;
	margin-top:0px;
}

#TitleDiv #InnerDiv{
	min-width:100px;
	width:auto;
	margin:auto;
	height:auto;
	background-color:;	
	
}
#TitleDiv #InnerDiv #logocont{
    width:150px;
	height:150px;
  margin:auto;
  text-align:center;
  }
#TitleDiv #InnerDiv  #logocont img{
	width:100%;
	height:100%;
	background-color:;
	
}

#TitleDiv #InnerDiv #TitleBox{
	display:block;
	background-color:;
	text-align:center;
}

#TitleDiv #InnerDiv #TitleBox #SchoolName{
	font-size:2.5em;
	text-transform:uppercase;
	font-weight:bold;
}

#TitleDiv #InnerDiv #TitleBox #SchoolAddress{
	font-size:1.2em;
	
	
}

#TitleDiv #InnerDiv #TitleBox #payTitle{
	font-size:1.3em;
	text-transform:uppercase;
	font-weight:normal;
}

.InfoDiv, #AnalDiv{
	width:calc(95% - 20px);
	margin:auto;
	border:#D5D5D5 thin solid;
	background:rgba(0,0,0,.06);
	margin-top:10px;
	height:auto;
	border-radius:0px;
	font-size:1em;
	padding:10px;
	font-weight:normal;
	overflow:hidden;
}

.InfoDiv .detailSide{
	width:60%;
	float:left;
}

.InfoDiv #passp{
	width:170px;
	height:170px;
	float:right;
	
	background-color:;
	margin:7px;
}

.InfoDiv #passp img{
	width:inherit;
	height:inherit;
}

#AnalDiv{
	background:none;
}

.InfoDiv .IndItem, .IndItemHeader{
	width:100%;
	height:auto;
	padding-top:2px;
	padding-bottom:2px;
	border-bottom:#D5D5D5 thin solid;
	box-sizing:border-box;
}
.IndItemHeader{
  border-bottom:#AAA 2px solid;
  background-color:rgba(255,255,255,.01);
  text-align:center;
 
  font-weight:bold;
}

.InfoDiv .IndItem .itemname{
	width:30%;
	text-indent:0px;
	display: block;
	padding-left:5px;
  float:left;
}

.InfoDiv .IndItem .itemvalue{
	width:60%;
	margin-left:2px;
	display: block;
  float:left;
	font-style:italic;
}

#AnalDiv{
	border-collapse:collapse;
	/*border:inherit;*/
	
}

#AnalDiv th{
	text-align:center
}

#AnalDiv td{
	text-indent:10px
}

#AnalDiv strong{
	font-weight:bolder;
}

.errl{margin-top:30px; text-align:center; font-size:2.5em;	
}
body{
font-family: \'Segoe UI\',\'Segoe UI Light\', \'Segoe UI Semilight\', \'Segoe UI Semibold\',  \'Eras Light ITC\', Calibri;
margin:0px;
padding:0px;
	}
.bx{
    display:block;border:#D5D5D5 thin solid;
	background-color:rgba(255,255,255,1);margin-left:0.9%; vertical-align:top;float:left; box-sizing:border-box;
	}
	.bxx{
		display:block;border:#D5D5D5 thin solid;
	background-color:rgba(255,255,255,1);margin-left:2%;vertical-align:top;float:left; box-sizing:border-box;
		}
</style>';


}
//Function to form school slip header version 1 



?>