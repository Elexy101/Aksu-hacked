<?php

	//include("../Ajax/CGI/PHP/config.php");
//}
//basic internal functions
//LE 22-5-17 #1
//array to hold all files
$Files = array();
//function to form data array
function ELemDataArray($str,$elemstr = "&",$keyItem = "="){
	$str = trim($str);
	$rst = array();
	if($str != ""){
		$strarr = explode($elemstr,$str);
		for($a=0; $a<count($strarr) ; $a++){
			$strv = $strarr[$a];
			$stratrvallarr = explode($keyItem,$strv);
			if(count($stratrvallarr) == 2){
				$rst[trim($stratrvallarr[0])] = $stratrvallarr[1];
				
			}
			
		}
		
	}
	return $rst;
	
}
if(!function_exists("GetValue")){
//function to help get the value of the supplied named attribute from the atributevalue string
function GetValue($attrname, $attrVal){
	$val = ""; //hold atrr value
	if(trim($attrVal) != ""){
		$attrVal = str_replace("\=","@#@",$attrVal);
		$attrVal = str_replace("\,","#@#",$attrVal);
		$atrr = explode(",",$attrVal);//break individual atrrval pair
		foreach($atrr as $atval){//loop through
		    $atvalarr = explode("=",$atval); //break get atrr and its value
			if(strtolower(trim($atvalarr[0])) == strtolower($attrname)){ //confirm if atrr
				$val = trim($atvalarr[1]); //set value
				$val = str_replace("@#@","=",$val);
		        $val = str_replace("#@#",",",$val);
				break;
			}
		}
	}
	
	return $val; // return gotten value
}
}

if(!function_exists("PopValue")){
//functon to popvalue
function PopValue($attrname, &$attrVal){
	$val = GetValue($attrname, $attrVal);
	$attrVal = RemoveAtrr($attrname, $attrVal);
	return $val;
}
}

if(!function_exists("Obtain")){
//function to extract attribut
function Obtain($attrname, $attrVal){
	$val = GetValue($attrname, $attrVal);
	$attrVal = RemoveAtrr($attrname,$attrVal);
	return array($val,$attrVal);
}
}

if(!function_exists("RunFunction")){
//function to make supplied javascript function name runable
function RunFunction($func,$param = ""){
	if(trim($func) == "") return "";
	$func = trim($func);
	$lasttwoChar = substr($func,count($func) - 2);
	if($lasttwoChar == "()"){
		return substr($func,0,count($func) - 1).$param.")";
	}else{
	   $lastChar = strpos($func,"(");
	   if($lastChar === FALSE){ //if no parameter sent
			return $func."(".$param.")";
	   }else if(trim($param) == ""){
			return $func;
		}else{
            return substr($func,0,$lastChar+1).$param.")";
		}
	   }
		
	}
}


if(!function_exists("RemoveAtrr")){
//function to remove attribute
function RemoveAtrr($atrbName,$attrVal){
	$newatrrval = "";
	$attrVal = str_replace("\,","@#%",$attrVal); //convert escaped comma , to @#%
	$attrVal = str_replace("\=","@#*",$attrVal); //convert escaped equals , to @#*
	if(trim($attrVal) != ""){
		$atrr = explode(",",$attrVal);//break individual atrrval pair
		foreach($atrr as $atval){//loop through
		  $atvalarr = explode("=",$atval); //break get atrr and its value
		  if(count($atvalarr) == 2){
			$realatrr = strtolower(trim($atvalarr[0]));
			if($realatrr != trim($atrbName)){
			  $newatrrval .= ",".$realatrr."=". $atvalarr[1]; 
			}
		  }
		}
		$newatrrval = ltrim($newatrrval,",");
	}
	$newatrrval = str_replace("@#%","\,",$newatrrval);//convert @#% to comma ,@#*
	$newatrrval = str_replace("@#*","\=",$newatrrval);
	return $newatrrval;
}
}

if(!function_exists("ProcessAtrrVal")){
//function to process attribute value string
function ProcessAtrrVal($attrvals){
	
	global $logo;
	//servername
	$str = "";
	$attrvals = trim($attrvals);
	$atrrSeen = array();
	if($attrvals != ""){
		$attrvals = str_replace("\,","@#%",$attrvals); //convert escaped comma , to @#%
		$attrvals = str_replace("\=","@#*",$attrvals); //convert escaped equals , to @#*
		$atrValArr = explode(",",$attrvals);
		
		if(count($atrValArr) > 0){
			for($s=0; $s <count($atrValArr); $s++){
				$atrrVal = trim($atrValArr[$s]);
				if($atrrVal != ""){
					$rAttValArr = explode("=",$atrrVal);
					if(count($rAttValArr) == 2){
						$atrr = trim(strtolower($rAttValArr[0]));
						$val = trim($rAttValArr[1]);
						$val = str_replace("@#%",",",$val);//convert @#% to comma ,@#*
						$val = str_replace("@#*","=",$val);
						if($atrr != "type"){
							//make placeholder to be title
							//atribute auto height is found
							/*if($atrr == "autoheightdiff"){
								$atrValArr[] = "class=A_H"; //add to attrval array
								//$atrValArr[] = "style=max-height:".$val;
							}*/
							
							if($atrr=="logo"){
								/* $atrr="style";
							  //if(isset($logo[strtolower($val)])){
								 // $val = $logo[strtolower($val)];
							 // }
							 $valbrk = strpos($val,"/");
							 if($valbrk === false){
								 $val = "TaquaLB/Elements/Images/".$val;
							 }
							  $val = "background-image: url(".$val.")"; */
							}
							
						if(in_array($atrr,$atrrSeen)){
							if($atrr == "class"){
								$str = str_replace("class=\"","class=\"".$val." ",$str);
							}elseif($atrr == "style"){
								$str = str_replace("style=\"","style=\"".$val.";",$str);
							}
						}else{
						  /*if($disable == true && strtolower(trim($atrr)) == "onclick"){}else{*/
						  $str .= "{$atrr}=\"{$val}\" ";
						  if($atrr == "placeholder"){ //if placehoder create for title
						       if(!in_array("title",$atrrSeen)){
								$str .= "title=\"{$val}\" ";
								$atrrSeen[] = "title";
							   }
							}
						  $atrrSeen[] = $atrr;
						  }
						//}
						}
					}
				}
			}
		}
	}
return $str;	
}
}
$currfrm = "Default";

if(!function_exists("Form")){
function Form($atrrValStr=""){
	global $currfrm;
	$name = GetValue("groupname",$atrrValStr);
	   if(trim($name) == ""){
		   $atrrValStr = RemoveAtrr("groupname",$atrrValStr);
		   $name = "Default";
	   }
	 $currfrm = $name;
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	//echo $atrrValStr;
$str = <<<sss
<form $atrrValStr >
sss;
echo $str;	   
}
}

if(!function_exists("_Form")){
function _Form(){
	global $currfrm;
	$currfrm = "Default";
$str = <<<sss
</form>
sss;
echo $str;
}
}

//the elements object
function _SmallButton($atrrValStr="",$type="logobtn"){
	global $currfrm;
	$id = GetValue("id",$atrrValStr);
	 if($id == ""){
		 //generate an id for it
		 $id = $type.".".rand();
		 $atrrValStr = "id=".$id.",".$atrrValStr;
	 }
	 $logo = GetValue("logo",$atrrValStr);
	 if(trim($logo) == ""){
		 $txt = GetValue("text",$atrrValStr);
		 if(trim($txt) != ""){
            $rlogo = "<span>".$txt."</span>"; 
		 }else{
			$rlogo = _Icon("thumbs-o-up fa-fw"); 
		 }
	 }else{
       $rlogo = _Icon($logo." fa-fw");
	 }
	$atrrValStr = ProcessAtrrVal("class=$type themecolor greyBorder $currfrm,".$atrrValStr);
	//echo $atrrValStr;
	
$str = <<<sss
<div $atrrValStr >$rlogo</div>
<input type="hidden" id="frm_{$id}" value="{$currfrm}" name="frm_{$id}" />
sss;
return $str;
}

function SmallButton($atrrValStr="",$type="logobtn"){
	echo _SmallButton($atrrValStr,$type);
}

//the elements object big btn
function BigButton($atrrValStr=""){
	SmallButton($atrrValStr,$type="bglogobtn");
}

//the elements object radio or checkbox object
function Radio($atrrValStr="", $type = "radio"){
	global $currfrm;
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "id".time().mt_rand();
		   $atrrValStr = "id=".$id.",".$atrrValStr;
	   }
	   $name = GetValue("group",$atrrValStr);
	   if(trim($name) == ""){
		   $name = $type."Default";
	   }
	   $atrrValStr = RemoveAtrr("group",$atrrValStr);
	   $check = GetValue("check",$atrrValStr);
	   $disable = GetValue("disable",$atrrValStr);
	   $disablecls = trim($disable) == "" || trim($disable) == "false"?"enable":"disable";
	   $uncheck = GetValue("uncheck",$atrrValStr);
	   $checked = GetValue("checked",$atrrValStr);
	   $check = (trim($check) == "")?"null":$check;
	   $uncheck = (trim($uncheck) == "")?"null":$uncheck;
	   $checked = (trim($checked) == "" || $checked == strtolower("false"))?"false":strtolower(trim($checked));
	   $clss=($checked == "true")?"check":"normal";
	    $text = GetValue("text",$atrrValStr);
		$displayext = Obtain("display",$atrrValStr);
		$atrrValStr = $displayext[1];
		$display = $displayext[0];
		$logo = PopValue("logo",$atrrValStr);
		if($logo != ""){
			$logo = _Icon($logo);
		}
		$style = PopValue("style",$atrrValStr);
		$caption = "";
		if(trim($text) != ""){
			$atrrValStr = RemoveAtrr("text",$atrrValStr);
			$caption = _Text("text=$text");
		}
	   $onclick = "onClick=\"$type.Click(_('$id'),$check,$uncheck)\"";
		$atrrValStr = ProcessAtrrVal("class={$type}bx greyBorder  $clss $currfrm,".$atrrValStr);
		$js = "";

		if($checked == "true"){
			$js = "<script type=\"text/javascript\">{$type}.RadioArray['{$type}_{$name}'] = '$id';</script>";
		}
	//echo $atrrValStr;
$str = <<<sss
<div style="{$style}" class="{$type}cont $display $disablecls" id="cont{$type}_{$id}" $onclick><div $atrrValStr ><div id="{$type}Inner_{$id}"></div><input type="hidden" id="{$type}_{$id}" value="$checked" name="$name" /><input type="hidden" id="{$type}_frm_{$id}" value="{$currfrm}" name="{$name}_frm" /></div>
sss;
echo $str." ".$logo." ".$caption."</div>";
}

//check box
function Check($attrval = ""){
	Radio($attrval,"check");
}

//text element
function _Text($atrrValStr=""){
	global $currfrm;
	 $text = GetValue("text",$atrrValStr);
	 $atrrValStr = RemoveAtrr("text",$atrrValStr);
	$atrrValStr = ProcessAtrrVal("class=texta $currfrm,".$atrrValStr);
	//echo $atrrValStr;
$str = <<<sss
<div $atrrValStr >$text</div>
sss;
return $str;
}
if(!function_exists("Text")){
function Text($atrrValStr=""){
	echo _Text($atrrValStr);
}
}



//table element
$selectable = ""; //variable to hold the current rowselect type
$selfunc = "";
$unselfunc = "";
$rwcnter = 0;
$Tid = "";
$selections = array();
$lastsel = "";
$multiselg = "";
$altrw = "true";
//$filter = "";
function __Table($atrrValStr=""){
	global $selectable;
	global $selfunc;
	global $unselfunc;
	global $rwcnter;
	global $Tid;
	global $selections;
	global $lastsel;
	global $multiselg;
	global $altrw;
	//global $filter;
	$filter = PopValue("filter",$atrrValStr);
	$filter = trim($filter) == ""?"false":$filter;
	$altrw = PopValue("rowalt",$atrrValStr);
	$rtnstr = "";
	$onselect = PopValue("onselect",$atrrValStr);
	$sel = "";
	if(trim($onselect) != ""){ //if onselect function is set, allow table selection
		//$atrrValStr = RemoveAtrr("onselect",$atrrValStr);
		$rwsel = PopValue("rowselect",$atrrValStr);
		$sel = "rw";
		if(trim($rwsel) == "true"){ //if selection is to be row base
			//$atrrValStr = RemoveAtrr("rowselect",$atrrValStr);
			$sel = "rwb";
		}
		
	}
	
	$onunselect = PopValue("onunselect",$atrrValStr);
		/*if(trim($onunselect) != ""){ 
		   $atrrValStr = RemoveAtrr("onunselect",$atrrValStr);
		}*/
	//check for multi selection
	$multisel = PopValue("multiselect",$atrrValStr);
	
	//if(trim($multisel) != ""){
		//$atrrValStr = RemoveAtrr("multiselect",$atrrValStr);
		
	/*}else if(trim($multisel) == "true"){
		
	}*/
	$multisel = (trim($multisel) == "true")?"true":"false";
	$multiselg = $multisel;
	$id = GetValue("id",$atrrValStr);
	 if($id == ""){
		 //generate an id for it
		 $id = "tb.".rand();
		 $atrrValStr = "id=".$id.",".$atrrValStr;
	 }
	 $isfilter = PopValue("rowfilter",$atrrValStr);
	 $rtn = "";
if($isfilter == "true"){
$filterinfo = PopValue("filtertitle",$atrrValStr);
	 if($filterinfo == ""){
		$filterinfo = "Filter List";
	 }
	 $filterstyle = PopValue("filterstyle",$atrrValStr);

	 $filterstyle = $filterstyle  == ""?"width:95%;margin:auto;margin-top:5px;margin-bottom:5px":$filterstyle.";margin-bottom:5px";
	$rtn = __TextBoxGroup($filterstyle).__TextBox("title=$filterinfo,style=width:calc(100% - 6px),id={$id}_filtertb,textchange=TextBox.Filter(this),logo=filter,required=false").___TextBoxGroup();
	$styles = PopValue("style",$atrrValStr);
	
		$atrrValStr = "style=margin-top:0px;border-top-color:transparent;width:95%;$styles,".$atrrValStr;
	
}
	 
	$selectable = $sel; //set type of selection scope, row based or cell based
	$Tid = $id;
	//$multiselinp = "<input type=\"hidden\" id=\"multi_{$Tid}\" value=\"$multisel\" />";
	$selfunc = trim($onselect);
	$unselfunc = trim($onunselect);
	$atrrValStr = "class=tbl {$sel}  $currfrm,border=1,bordercolor=#dddddd,".$atrrValStr;
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	//$multiselinp
$str = <<<sss

<table {$atrrValStr} >
sss;
return $rtn.$str;
}

if(!function_exists("Table")){
function Table($atrrValStr=""){
	echo __Table($atrrValStr);
	
}
}

//Editor 
function _Editor($attrValStr=""){
	$id = PopValue("id",$attrValStr);
	if($id == ""){
		//generate an id for it
		$id = "editor".rand();
		$atrrValStr = "id=".$id.",".$atrrValStr;
	}
	$ph = PopValue("placeholder",$attrValStr);
	$verfunc = trim(PopValue("verifyfunction",$attrValStr));
	if($verfunc == "")$verfunc = "function(){return 1}";
	//use the flat table design
	$edbx = __FlatTable("style=height:auto");
	$edbx .= '<div style="width:100%;overflow:auto">';
		$edbx .= __FlatTHead('style=min-width:820px');
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddGrid(this\,'.$verfunc.');return false;,title=Insert Grid,class=greenGradient card-1,style=border-radius:3px 0px 0px 3px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 5px,logo=th-large'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddText(this\,'.$verfunc.');return false;,title=Insert Text,class=greenGradient card-1,style=border-radius:0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 0px,logo=font'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddText(this\,'.$verfunc.'\,true);return false;,title=Insert Title,class=greenGradient card-1,style=border-radius:0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 0px,logo=text-width'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddImage(this\,'.$verfunc.');return false;,title=Insert Image,class=greenGradient card-1,style=border-radius:0px ;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 0px,logo=image'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddAudio(this\,'.$verfunc.');return false;,title=Insert Audio,class=greenGradient card-1,style=border-radius:0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 0px,logo=music'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddVideo(this\,'.$verfunc.');return false;,title=Insert Video,class=greenGradient card-1,style=border-radius:0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 0px 0px 0px,logo=video-camera'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AddPlaceHolder(this\,'.$verfunc.');return false;,title=Insert Placeholder,class=greenGradient card-1,style=border-radius:0px 3px 3px 0px;color:#fff;border:transparent solid thin;padding:5px 8px;margin:0px 5px 0px 0px,logo=square-o'));
		$edbx .= __FlatTDataSep('style=padding:3px 0px;background-color:#dedede;margin:4px 5px 0px 5px');
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.Bold();return false;,title=Bold,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=bold'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.Italic();return false;,title=Italic,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=italic'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.Underline();return false;,title=Underline,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=underline'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.StrikeThrough();return false;,title=Strikethrough,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=strikethrough'));

		$edbx .= __FlatTDataSep('style=padding:3px 0px;background-color:#dedede;margin:4px 5px 0px 5px');
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AlignLeft();return false;,title=Align Left,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;;background-color:transparent;margin:4px 5px 0px 5px,logo=align-left'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AlignCenter();return false;,title=Align Center,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=align-center'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AlignRight();return false;,title=Align Right,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=align-right'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.AlignFull();return false;,title=Align Justify,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=align-justify'));
		$edbx .= __FlatTDataSep('style=padding:3px 0px;background-color:#dedede;margin:4px 5px 0px 5px');
		$edbx .= __FlatTData(_LogoButton('onclick=this.parentElement.nextElementSibling.click();return false;,title=Font Color,class=altColors,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=font')).'<input type="color" name=""  style="display:none;vertical-align:middle;width:20px" id="'.$id.'textcolorinp" onchange="Editor.FontColor(this.value)" />';
		//$edbx .= ;
		$edbx .= __FlatTData(_LogoButton('onclick=this.parentElement.nextElementSibling.click();return false;,title=Back Color,class=altColors,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=paint-brush')).'<input type="color" name=""  style="display:none;vertical-align:middle;width:20px" id="'.$id.'backcolorinp" onchange="Editor.BackColor(this.value)" />';
		$edbx .= __FlatTDataSep('style=padding:3px 0px;background-color:#dedede;background-color:transparent;margin:4px 5px 0px 5px');
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.UnOrderedList();return false;,title=Bullet,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=list-ul'));
		$edbx .= __FlatTData(_LogoButton('onclick=Editor.OrderedList();return false;,title=Numbering,class=altColor2s,style=color:#FFF;border-radius:2px;border:solid 1px transparent;background-color:transparent;margin:4px 5px 0px 5px,logo=list-ol'));
		$edbx .= __FlatTDataSep('style=padding:3px 0px;background-color:#dedede;margin:4px 5px 0px 5px');
		$edbx .= '<select class="editor-dropdown" onchange="Editor.FontSize(this)"><option>Default</option><option>1pt</option><option>2pt</option><option>4pt</option><option>3pt</option><option>4pt</option><option>5pt</option><option>6pt</option><option>7pt</option></select>';
		/* $edbx .= __TextBoxGroup('').__TextBoxGroupItem().__TextBox("title=Font Size,style=width:80px;height:18px;font-size:1.2em,onchange=Editor.FontSize,id={$id}fs,logo=text-width,required=false,selected=-1",array("1pt","2pt","3pt","4pt","5pt","6pt","7pt")).__TextBoxGroupItemMore().__TextBox("title=Font Style,style=width:100px;height:18px;font-size:1.2em,id={$id}fst,logo=pencil,required=false,selected=-1",array("Default","Calibri","Tahoma","Times New Roman","Arial","Verdana","Cambria","Candara","Segoe UI","Corbel")).___TextBoxGroupItem().___TextBoxGroup(); */
		
		$edbx .= ___FlatTHead();
		$edbx .= '</div>';
		$edbx .= '<div style="width:100%;max-height:400px;min-height:150px;overflow:auto;position:relative" class="editor-body" data-placeholder="'.$ph.'" id="'.$id.'_editor-body"></div>';
	$edbx .= ___FlatTable();
	return $edbx;
}

if(!function_exists("Editor")){
	function Editor($atrrValStr=""){
		echo _Editor($atrrValStr);
		
	}
	}

//flat table uses divs to form the table
function __FlatTable($attrValStr=""){
	$id = PopValue("id",$attrValStr);
	if($id == ""){
		//generate an id for it
		$id = "tb.".rand();
		$atrrValStr = "id=".$id.",".$atrrValStr;
	}
	//"class=rptbx greyShadow, style=border:#CCC solid thin"
	$isfilter = PopValue("rowfilter",$attrValStr);
	$rtn = "";
if($isfilter == "true"){
$filterinfo = PopValue("filtertitle",$attrValStr);
	if($filterinfo == ""){
	   $filterinfo = "Filter List";
	}
	$filterstyle = PopValue("filterstyle",$attrValStr);

	$filterstyle = $filterstyle  == ""?"width:95%;margin:auto;margin-top:5px":$filterstyle;
   $rtn = __TextBoxGroup($filterstyle).__TextBox("title=$filterinfo,style=width:calc(100% - 6px),id={$id}_filtertb,textchange=TextBox.Filter(this),logo=filter,required=false").___TextBoxGroup();
   $styles = PopValue("style",$attrValStr);
   
	   $attrValStr = "style=margin-top:0px;border-top-color:transparent;width:95%;$styles,".$attrValStr;
   
}
	$cls = PopValue("class",$attrValStr);
	$style = PopValue("style",$attrValStr);
	$attrValStr = "class=rptbx $cls,style=$style".$attrValStr;
	$attrValStr = ProcessAtrrVal($attrValStr);
	$str = <<<sss

<div {$attrValStr} >
sss;
return $rtn.$str;
}

if(!function_exists("FlatTable")){
	function FlatTable($atrrValStr=""){
		echo __FlatTable($atrrValStr);
		
	}
	}

//close the table
function ___FlatTable(){
	return '</div>';
}
function _FlatTable(){
	echo ___FlatTable();
}

function __FlatTHead($atrrValStr=""){
	$style = PopValue("style",$atrrValStr);
		$cls = PopValue("class",$atrrValStr);
  return '<div class="rpthead '.$cls.'" style="'.$style.'">';
}

function ___FlatTHead(){
	return '<div style="clear:both"></div></div>';
  }

  function FlatTHead($atrrValStr=""){
	echo __FlatTHead($atrrValStr);
  }
  
  function _FlatTHead(){
	  echo ___FlatTHead();
	}

	function __FlatTData($data = "",$atrrValStr=""){
		$size = PopValue("size",$atrrValStr);
		$style = PopValue("style",$atrrValStr);
		$cls = PopValue("class",$atrrValStr);
		$atrrValStr = ProcessAtrrVal($atrrValStr);
       return '<div style="width:'.$size.'%;'.$style.'" class="rptitem '.$cls.'" '.$atrrValStr.'>'.$data.'</div>';
	}

	function FlatTData($data = "",$atrrValStr=""){
		echo __FlatTData($data,$atrrValStr);
	}

	function __FlatTDataSep($atrrValStr=""){
		$style = PopValue("style",$atrrValStr);
		$cls = PopValue("class",$atrrValStr);
		return '<div style="width:1px;background-color:#222;'.$style.'" class="rptitem '.$cls.'">&nbsp;</div>';
	}

	function FlatTDataSep($atrrValStr=""){
        echo __FlatTDataSep($atrrValStr);
	}


	function __FlatTRecord($atrrValStr=""){
		$cls = PopValue("class",$atrrValStr);
		$atrrValStr = ProcessAtrrVal($atrrValStr);
      return '<div class="rptrow '.$cls.'" '.$atrrValStr.' >';
	}
	function ___FlatTRecord(){
		return '<div style="clear:both"></div></div>';
	  }
	  function FlatTRecord($atrrValStr=""){
		echo __FlatTRecord($atrrValStr);
	  }
	  function _FlatTRecord(){
		  echo  ___FlatTRecord();
		}
	function __FlatTDataSub($atrrValStr=""){
		$style = PopValue("style",$atrrValStr);
		$cls = PopValue("class",$atrrValStr);
		$atrrValStr = ProcessAtrrVal($atrrValStr);
       return '<div style="clear:both"></div><div class="subbx '.$cls.'" style="display:none;'.$style.'" '.$atrrValStr.'>';
	}

	function FlatTDataSub($atrrValStr=""){
		echo __FlatTDataSub($atrrValStr);
	}

	function ___FlatTDataSub(){
return '<div style="clear:both"></div></div>';
	}

	function _FlatTDataSub(){
echo ___FlatTDataSub();
	}

	function __FlatTBody($atrrValStr=""){
		$style = PopValue("style",$atrrValStr);
		$cls = PopValue("class",$atrrValStr);
		$id = PopValue("id",$atrrValStr);
		$ph = PopValue("placeholder",$atrrValStr);
		return '<div style="'.$style.'" class="'.$cls.'"  id="'.$id.'" data-placeholder="'.$ph.'">';
	}

	function ___FlatTBody(){
		return '</div>';
	}

	function FlatTBody($atrrValStr=""){
		echo __FlatTBody($atrrValStr);
	}

	function _FlatTBody(){
		echo ___FlatTBody();
	}
/* function __TableFilter($atrrValStr=""){
	//$atrrValStr = "filter=true,".$atrrValStr;
	$id = GetValue("id",$atrrValStr);
	 if($id == ""){
		 //generate an id for it
		 $id = "tb.".rand();
		 $atrrValStr = "id=".$id.",".$atrrValStr;
	 }
	 $filterinfo = GetValue("filterinfo",$atrrValStr);
	 if($filterinfo == ""){
		$filterinfo = "Filter List";
	 }
	$rtn = __TextBox("title=$filterinfo,style=width:270px,id={$id}_filtertb,textchange=TextBox.Filter(this),logo=filter,info=");
	//$rtn = "";
	$rtn .= __Table($atrrValStr);
	return $rtn;
}

function TableFilter($atrrValStr=""){
	echo __TableFilter($atrrValStr);
}

function ___TableFilter(){
	return ___Table();
}

function _TableFilter(){
	echo ___Table();
} */

function __TRecord($dataArray,$atrrValStr="",$cellatrrval = ""){
	global $selectable ;
	global $selfunc;
	global $unselfunc;
	global $rwcnter;
	global $Tid;
	global $selections;
	global $lastsel;
	global $multiselg;
	global $altrw;
	//global $filter;  
	$rtnstr = "";
	$rwcnter += 1;
	$rwuid = PopValue("rowid",$atrrValStr);
	if($rwuid != ""){
      $id=$rwuid;
	}else{
//generate an id for it
		 $id = $Tid."_rw_".$rwcnter;
	}
		 
		 
	   $cspan = GetValue("cspan",$atrrValStr);
	   $rspan = GetValue("rspan",$atrrValStr);
	   $head = GetValue("head",$atrrValStr);
	    $cheader = GetValue("cellheader",$atrrValStr);
	  // $rspan = GetValue("rspan",$atrrValStr);
	   if(trim($head) != ""){
	    $atrrValStr = RemoveAtrr("head",$atrrValStr);
	   }
	   $cspanlookup = array();
	   if(trim($cspan) != ""){
	      $atrrValStr = RemoveAtrr("cspan",$atrrValStr);
		  $cspanarr = explode(";",$cspan);
		  if(count($cspanarr) > 0){
			  foreach($cspanarr as $cspandata){
				  $cspandataArr = explode(":",$cspandata);
				  if(count($cspandataArr) == 2){
					 $cspanlookup[trim($cspandataArr[0])] = $cspandataArr[1]; 
				  }
			  }
		  }
	   }
	   $rspanlookup = array();
	   if(trim($rspan) != ""){
	      $atrrValStr = RemoveAtrr("rspan",$atrrValStr);
		  $rspanarr = explode(";",$rspan);
		  if(count($rspanarr) > 0){
			  foreach($rspanarr as $rspandata){
				  $rspandataArr = explode(":",$rspandata);
				  if(count($rspandataArr) == 2){
					 $rspanlookup[trim($rspandataArr[0])] = $rspandataArr[1]; 
				  }
			  }
		  }
	   }
	   $cheaders = array();
	 if($cheader != ""){
		 $atrrValStr = RemoveAtrr("cellheader",$atrrValStr);
		 $cheaders = explode(":",$cheader);
		  if(count($cheaders) >0){
			 // $cheaders = array_flip($cheaders); //make the cells numbers to be keys 
		  }

	 }
	 //$rwcls = "";
	 $inprw = "";
	if(trim($head) == "true"){
		$atrrValStr = "class=head,".$atrrValStr;	
	}else{//form hidden input to hold user specified id and value
		 $uid = GetValue("id",$atrrValStr);
		 if($uid != ""){
			  $atrrValStr = RemoveAtrr("id",$atrrValStr); //user defined id removed
		 }else{
			$uid = $id; 
		 }
		
		$rwcls = "class_".$Tid; //a classname for all the rows, incase if operation is needed to be performed on all rows
		$atrrValStr = "class={$rwcls},".$atrrValStr;
	}
	$atrrValStr = "id=".$id.",".$atrrValStr;
	$onclick = GetValue("onselect",$atrrValStr);
	//handle pre selection
	$selected = GetValue("selected",$atrrValStr);
	if($selected != ""){
		 $atrrValStr = RemoveAtrr("selected",$atrrValStr); //user defined id removed
		 
		 $selectedarr = explode(":",$selected);
		
		 
	}
	
	//user id (force id)
	$userid = GetValue("userid",$atrrValStr);
	if($userid != ""){
		$atrrValStr = RemoveAtrr("userid",$atrrValStr); 
	}
	
	if($rwcnter % 2 > 0 && $altrw != "false"){
		$atrrValStr .= ",class=alt";
	}
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	$cellselect = "";
	$rowselect = "";
	$selfuncset = trim($selfunc) == ""?"":"\,".$selfunc;
	$selfuncset = ResolveFunc($selfuncset);
	if(trim($unselfunc) != ""){ //if unselect function esist
	 $selfuncset .= trim($selfuncset) == ""?"":"\,".trim($unselfunc);
	}
	
	
	
	//determine the table onselect/rowselect
	if(trim($selectable) == "rw" && trim($head) == ""){
		/*if(trim($onclick) == ""){
			$cellselect = "onclick=Table.Select(this)";
		}else{*/
			$cellselect = "onclick=Table.Select(this\,false{$selfuncset})";
			$cellselect = ProcessAtrrVal($cellselect);
		//}
		
	}else if(trim($selectable) == "rwb" && trim($head) == ""){
		
		/*if(trim($onclick) == ""){
		$rowselect = "onclick=Table.Select(this);{$selfunc}";
		}else{*/
			$rowselect = "onclick=Table.Select(this\,false{$selfuncset})";
			$rowselect = ProcessAtrrVal($rowselect);
		//}
		$inprw = "<input type=\"hidden\" id=\"inp_{$id}\" value=\"$uid\" /><input type=\"hidden\" id=\"inpsel_{$id}\" value=\"\" />";
	}
	$totcoll = count($dataArray);
	if($cellatrrval != ""){
			$cellatrrval =  ProcessAtrrVal($cellatrrval);
		 }
$str = <<<sss
<tr $atrrValStr $rowselect >
$inprw <input type="hidden" id="totcol_{$id}" value="$totcoll" />
sss;
 if(count($dataArray) > 0){
	 $cntcl = 1;
	 $temselection = []; //for row based selection, select all columns before adding to real $election array
	 foreach ($dataArray as $key => $data){
		 $cspanStr = "";
		 $rspanStr = "";
		 if($userid == "true"){ //if user id is true, use the user supplied key as the column num
			 $cid = $id."_".$key;
		   }else{
		    $cid = $id."_".$cntcl;
		   }
		 if(count($cspanlookup) > 0){
			 if(isset($cspanlookup["d".$cntcl])){
				$cspanStr = "colspan=\"".$cspanlookup["d".$cntcl]."\""; 
			 }
		 }
		 if(count($rspanlookup) > 0){
			 if(isset($rspanlookup["d".$cntcl])){
				$rspanStr = "rowspan=\"".$rspanlookup["d".$cntcl]."\""; 
			 }
		 }
		 $iscellHeader = in_array($cntcl."",$cheaders);
		 $td = (trim($head) == "true" || $iscellHeader)?"th":"td";
		  $inpcl = "";
		 //set id input for selection porpose if selection scope is cell level
		 if(trim($head) == "" || !$iscellHeader){
		  
		 if(isset($uid)){ //if uid is not set meaning current row is an header
		   if($userid == "true"){
			   $cuid = $uid."_".$key;
		   }else{
		     $cuid = $uid."_".$cntcl;
		   }
		    $inpcl = "<input type=\"hidden\" id=\"inp_{$cid}\" value=\"$cuid\" /><input type=\"hidden\" id=\"{$Tid}_{$cuid}\" value=\"{$cid}\" />";
		   }
		 }
		 
		 $selclss = "";
		 $selstate = "";
		 if(in_array($cntcl."",$selectedarr) || $selected == "-1"){
			 
			 if(($multiselg == "false" && count($selections) == 0) || ($multiselg == "true")){
			   if(trim($selectable) == "rwb"){//if rw based
			      if(!in_array($id,$selections)){
					//$selections[] =  $id;
					$temselection[] = $id;
					$lastsel = $id;
				  }
				  
			   }else{
				   if(!in_array($cid,$selections)){
				    $selections[] =  $cid;
					$lastsel = $cid;
				  }
				  // $selclss = "class=\" sel\"";
			   }
			    $selclss = 'sel';
				$selstate = "sel";
			 }
		 }
		 $inpcl .= "<input type=\"hidden\" id=\"inpsel_{$cid}\" value=\"{$selstate}\" />";
		 /*if($userid != ""){
			 $cid = $userid;
		 }*/
		 // $selclss = 'class=" sel"';
		 $stys = "";
		 if(is_array($data)){
            $stys = $data[1];
			$data = $data[0];
		 }
//$selllll = $td == "th"?"sortEvent(this)":"";
		$str .= "<{$td} class=\"{$selclss}\" style=\"{$stys}\" {$cspanStr} {$rspanStr} {$cellselect} id=\"{$cid}\" {$cellatrrval} >".InsertID($data,$cid,"???")."</{$td}>{$inpcl}";
		$cntcl++; 
	 }
	 //for row based
     $selections = array_merge($selections,$temselection);
 }
$str .= "</tr>";
return $str;

}

//function to insert id in string data
function InsertID($str,$id,$placeholder){
	return str_replace($placeholder,$id,$str);
}

function TRecord($dataArray,$atrrValStr="",$cellatrrval = ""){
	echo __TRecord($dataArray,$atrrValStr,$cellatrrval);
}

function __THeader($dataArray,$atrrValStr="",$cellatrrval = ""){
   return __TRecord($dataArray,"head=true,".$atrrValStr,$cellatrrval);
}

function THeader($dataArray,$atrrValStr="",$cellatrrval = ""){
   TRecord($dataArray,"head=true,".$atrrValStr,$cellatrrval);
}
function ___Table($ids = ""){
	global $selectable ;
	global $selfunc;
	global $unselfunc;
	global $rwcnter;
	global $Tid;
	global $currfrm;
	global $selections;
	global $lastsel;
	global $multiselg;
	$sel = count($selections) > 0?implode("~",$selections):"";
	$selections = array();
	$id = (isset($ids) && trim($ids) != "")?$ids:$Tid;
	global $altrw;
	$altrw = "true";
	
	$Tid="";
	//<input type=\"hidden\" id=\"lastsel_{$id}\" value=\"$lastsel\" /><input type=\"hidden\" id=\"totrw_{$id}\" value=\"$rwcnter\" />
	$rst = "<input type=\"hidden\" id=\"data_{$id}\" value=\"\"
	          data-multiselect=\"$multiselg\" 
			  data-lastselect=\"$lastsel\"
			  
		    />
	        <input type=\"hidden\" id=\"sel_{$id}\" value=\"$sel\" />
			<input type=\"hidden\" id=\"frm_{$id}\" value=\"$currfrm\" />
			
			<input type=\"hidden\" id=\"rowselect_{$id}\" value=\"$selectable\" />
			<input type=\"hidden\" id=\"selfunc_{$id}\" value=\"$selfunc\" />
			<input type=\"hidden\" id=\"unselfunc{$id}\" value=\"$unselfunc\" />
			<input type=\"hidden\" id=\"totrw_{$id}\" value=\"$rwcnter\" />
			</table>";
			
	$selectable = "";
	$selfunc = "";
	$unselfunc = "";
	$lastsel = "";
	$multiselg = "";
	$rwcnter = 0;
	return $rst;
	
}

function _Table(){
	echo ___Table();
}

function Switcher($atrrValStr=""){
    echo _Switcher($atrrValStr);
}

//the switch object
function _Switcher($atrrValStr=""){
	global $currfrm;
	$state = GetValue("state",$atrrValStr);
	   if(trim($state) != ""){
	    $atrrValStr = RemoveAtrr("state",$atrrValStr);
	   }
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "sw".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   $onchange = GetValue("onchange",$atrrValStr);
	   if(trim($onchange) != ""){
		   $atrrValStr =RemoveAtrr("onchange",$atrrValStr);
		   $onchanges = explode(";",$onchange);
		   if(count($onchanges) > 1){
			   foreach($onchanges as &$inoncahnge){
			$inoncahnge = rtrim($inoncahnge,"()");
		   }
		   $onchange = "[".implode(",",$onchanges)."]";
		   }
		   
	   }else{
		   $onchange = "Switcher.onChange";
	   }
	    $text = GetValue("text",$atrrValStr);
		if(trim($text) != ""){
		   $atrrValStr =RemoveAtrr("text",$atrrValStr);
	   }
	   $info = GetValue("info",$atrrValStr);
		if(trim($info) != ""){
		   $atrrValStr =RemoveAtrr("info",$atrrValStr);
	   }
	   $style = GetValue("style",$atrrValStr);
		if(trim($style) != ""){
		   $atrrValStr =RemoveAtrr("style",$atrrValStr);
	   }
	   //get the text to display when on
	   $ontxt = GetValue("ontext",$atrrValStr);
		if(trim($ontxt) != ""){
		   $atrrValStr =RemoveAtrr("ontext",$atrrValStr);
	   }else{$ontxt = "on";}

	   //get text to display when off
	   $offtxt = GetValue("offtext",$atrrValStr);
		if(trim($offtxt) != ""){
		   $atrrValStr =RemoveAtrr("offtext",$atrrValStr);
		 }else{$offtxt = "off";}
		 
		 $deftxt = trim(PopValue("defaulttext",$atrrValStr));
		 //$showind = $showind == "" || $showind == "false"?false:true;

	   //alignment of the switch and text
	   $align = GetValue("align",$atrrValStr);
		if(trim($align) != ""){
		   $atrrValStr =RemoveAtrr("align",$atrrValStr);
	   }else{$align = "left";}

	   $class = PopValue("disabled",$atrrValStr);
		 $class = trim($class) == "true"?"disabled":"";
		 $tstat = trim($state);
	   //$state = ($tstat == "on" || $tstat == "1")?"on":(1 == 2?"def":"normal");
	   $state = ($tstat == "on" || $tstat == "1")?"on":($deftxt != "" && ($tstat == "-1" || $tstat == "default")?"def":"normal");
		 $stateinp = ($state == "on")?1:($state == "def"?-1:0);
		 
		 $showind = trim(PopValue("showstate",$atrrValStr));
		 $showind = $showind == "" || $showind == "false"?false:true;

		 $txt='';
		 $swtype = $deftxt == ""?"":"threeway";
	  // $txt = ($state == "on")?$ontxt:$offtxt;
	   $atrrValStr = "class=switchbox $swtype {$state} $currfrm $class,".$atrrValStr;
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	$loadingbj = _Icon("cog fa-spin");
	$shind = '';
	$mtop = 5;
	if($showind){
		$mtop = 0;
		$distxt = $state == "on"?$ontxt:($state == "def"?$deftxt:$offtxt);
		$shind = '<div id="'.$id.'_distext" class="distext" style="text-align:center;font-size:0.7em;color:rgba(0,0,0,0.7);font-style:italic;margin-top:-3px">'.$distxt.'</div>';
	}
	//$act = trim($text) == ""?"":"";
$str = <<<sss
<div  style="float:left; margin-top:{$mtop}px; width:57px" >
<div $atrrValStr data-ontext="$ontxt" data-offtext="$offtxt" data-deftext="$deftxt" data-value="$stateinp" >
	<div class="cover">$loadingbj</div>
       <div id="{$id}_mover" class="move"></div>
	   <input type="hidden" id="st_{$id}" value="$stateinp" />
	   <input type="hidden" id="frm_{$id}" value="$currfrm" />
			 </div>
			 $shind
</div>	   
sss;
$rtn = "<div style=\"$style\" onclick=\"Switcher.Select(_('$id'),{$onchange})\" >";if($align == "left"){$rtn .= $str;}
if(trim($text) !=""){
	$rtn .= __Box("style=float:left;margin-left:5px;width:calc(100% - 70px)");
$text = str_replace(array('=',','),array('\=','\,'),$text);
 $rtn .= _Text("text=$text,style=display:block;font-weight:bold;margin-top:0px;font-size:0.75em;text-transform:uppercase,class=altColor2");
 $rtn .= _Text("text=$info,style=font-size:0.7em;vertical-align:top;color:rgba(0\,0\,0\,0.7);font-style:italic;padding-right:3px");
 $rtn .= ___Box();
}

 if($align != "left"){$rtn .= $str;}
 $rtn .= " <div class=\"clearer\"></div> </div>";
 global $TextBoxGroupOn;global $TextBoxGroupItemOn;
 if($TextBoxGroupOn){
	return $TextBoxGroupItemOn?$rtn:'<tr class=""  ><td>'.$rtn.'</td></tr>'; 
}
 return $rtn;
}

//the switch object
function _ColorPicker($atrrValStr=""){
	global $currfrm;
	$value = GetValue("value",$atrrValStr);
	   if(trim($value) != ""){
	    $atrrValStr = RemoveAtrr("value",$atrrValStr);
	   }
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "cp".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   $onchange = GetValue("onchange",$atrrValStr);
	   if(trim($onchange) != ""){
		   $atrrValStr =RemoveAtrr("onchange",$atrrValStr);
		   $onchange = rtrim($onchange,"()");
	   }else{
		   $onchange = "ColorPicker.onChange";
	   }
	    $text = GetValue("text",$atrrValStr);
		if(trim($text) != ""){
		   $atrrValStr =RemoveAtrr("text",$atrrValStr);
	   }
	   $info = GetValue("info",$atrrValStr);
		if(trim($info) != ""){
		   $atrrValStr =RemoveAtrr("info",$atrrValStr);
	   }
	   $style = GetValue("style",$atrrValStr);
		if(trim($style) != ""){
		   $atrrValStr =RemoveAtrr("style",$atrrValStr);
	   }
	   

	   //alignment of the switch and text
	   $align = GetValue("align",$atrrValStr);
		if(trim($align) != ""){
		   $atrrValStr =RemoveAtrr("align",$atrrValStr);
	   }else{$align = "left";}

	 
	   $txt='';
	  // $txt = ($state == "on")?$ontxt:$offtxt;
	   $atrrValStr = "class=switchbox $currfrm,".$atrrValStr;
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	$loadingbj = _Icon("cog fa-spin");
$str = <<<sss
<input class="switchbox" style="float:left; margin-top:3px; border-radius:0px; font-size:0.8em; height:20px; cursor:text; " type="text"  onblur="_({$id}).value = this.value" value="$value" id="{$id}_hex" />
	<input $atrrValStr style="float:left; margin-top:3px; border-radius:40px" type="color" onchange="_({$id}_hex).value = this.value" value="$value" id="$id" />
       
sss;
$rtn = "<div style=\"$style\">";if($align == "left"){$rtn .= $str;}
$rtn .= __Box("style=float:left;margin-left:5px;width:calc(100% - 130px)");
$text = str_replace(array('=',','),array('\=','\,'),$text);
 $rtn .= _Text("text=$text,style=display:block;font-weight:bold;color:#777;margin-top:0px;font-size:0.7em;text-transform:uppercase");
 $rtn .= _Text("text=$info,style=font-size:0.7em;vertical-align:top;color:rgba(0\,0\,0\,0.7);font-style:italic");
 $rtn .= ___Box();
 if($align != "left"){$rtn .= $str;}
 $rtn .= " <div class=\"clearer\"></div> </div>";
 global $TextBoxGroupOn;global $TextBoxGroupItemOn;
 if($TextBoxGroupOn){
	return $TextBoxGroupItemOn?$rtn:'<tr class=""  ><td>'.$rtn.'</td></tr>'; 
}
 return $rtn;
}

function ColorPicker($atrrValStr=""){
	echo _ColorPicker($atrrValStr);
}

function HexToRGB($hexcolor){
  //remove the leading #
  $hexcolor = ltrim(trim($hexcolor),"#");
  //get the total character
  $len = strlen($hexcolor);
  if($len < 3){
	$hexcolor .= str_repeat("0",3-$len);
	$len = 3;
  }
  if($len > 3 && $len < 6){
	$hexcolor .= str_repeat("0",6-$len);
	$len = 6;
  }

  if($len > 6){
    $hexcolor = substr($hexcolor,0,6);
  }
  $rst = [];
  if(ctype_xdigit($hexcolor)){
	 if($len == 3){ //if short form
		//$nwhx = '';
        for($ch = 0; $ch < 3; $ch++){
			$char = substr($hexcolor,$ch,1);
			$rst[] = hexdec($char.$char);
		}
	 }else{
		for($ch = 0; $ch < 6; $ch = $ch + 2){
			$char = substr($hexcolor,$ch,2);
			$rst[] = hexdec($char);
		}
	 }
  return $rst;
  }else{
	  return [0,0,0];
  }
  
}

function RGBToHex($rgb = [0,0,0]){
	if(!is_array($rgb))return '#000000';
  if(count($rgb) < 3){
	 if(count($rgb) == 0)return '#000000';
	 if(count($rgb) == 1)$rgb = array_merge($rgb,[0,0]);
	 if(count($rgb) == 2)$rgb[] = 0;
  }
  $rtnstr = '';
  for($s=0;$s<3;$s++){
	$ss = dechex($rgb[$s]);
     if(strlen($ss) == 1){
		$ss = "0".$ss;
	 }
	 $rtnstr .= $ss;
  }
  return "#".$rtnstr;
}

//range object
function Ranges($atrrValStr = ""){
	global $currfrm;
	$id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "rg".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	 $value = GetValue("value",$atrrValStr);
	   if(trim($value) == ""){
		   $value = "0.5";
		  // $atrrValStr = "val={$id},".$atrrValStr;
	   }else{
		   $atrrValStr =RemoveAtrr("value",$atrrValStr);
	   }
	   $descr = GetValue("text",$atrrValStr);

	   $max = GetValue("max",$atrrValStr);
	   if(trim($max) == ""){
		   $max = 100;
	   }else{
	   $max = (int)$max;
	   $atrrValStr =RemoveAtrr("max",$atrrValStr);
	   }

	   $min = GetValue("min",$atrrValStr);
	   if(trim($min) == ""){
		   $min = 0;
	   }else{
	   $min = (int)$min;
	   $atrrValStr =RemoveAtrr("min",$atrrValStr);
	   }

	   $valnum = (float)$value;
	   //calculate display value
	   $range = $max - $min;
	   $curdisval = round($valnum * $range);
	   $curdisval += $min;
	   $lowhighcl = "";
	   if($valnum < 0.5){
        $lowhighcl = "low";
	   }else if($valnum > 0.5){
		$lowhighcl = "high";
	   }
	   //calculate default value
	   $defval = round((float)$value * 194);
	    $onmove = GetValue("onmove",$atrrValStr);
	   if(trim($onmove) != ""){
		   $atrrValStr =RemoveAtrr("onmove",$atrrValStr);
		   $onmove = rtrim($onmove,"()");
	   }else{
		   $onmove = "";
	   }
	   $atrrValStr = ProcessAtrrVal($atrrValStr);
$str = '
<div class="ranges '.$currfrm.' '.$lowhighcl.'" '.$atrrValStr.' data-max='.$max.' data-min='.$min.' >
      <div class="rangeMove" id="'.$id.'_move" style="margin-left:'.$defval.'px"> </div>
      <div class="rangeGauge" > </div>
	  <div class="rangeDis" id="'.$id.'_dis"> '.$curdisval.' </div>
	  <div style="clear:both"></div>
	  </div><input type="hidden" id="'.$id.'_val" value="'.$value.'" /><input type="hidden" id="'.$id.'_frm" value="'.$currfrm.'" /><input type="hidden" id="'.$id.'_mvfunc" value="'.$onmove.'" />';
	  $rtn = $str._Text("text=$descr,style=display:block;padding-left:10px;margin-top:5px;font-size:0.8em;width:200px;color:rgba(0\,0\,0\,0.7);font-style:italic");
	  global $TextBoxGroupOn; global $TextBoxGroupItemOn;
	  if($TextBoxGroupOn){
		echo $TextBoxGroupItemOn?$rtn:'<tr class=""  ><td>'.$rtn.'</td></tr>'; 
	}else{
echo $rtn;
	}

}

/*Tabs*/
$tabindex = 0;
$curtabid = ""; //hold the id of the currently selected tab
$curentsel = -1;
$tabTextarr = [];
$tabbodygrpbxcnt = 0;
function Tab($atrrValStr=""){
	global $tabindex;
	global $curtabid;
	global $curentsel;
	global $Files;
	global $tabTextarr;
	 $tabindex = 0;
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = isset($_POST['PGID'])?$_POST['PGID']."tab":"tab".rand();
		   //$id = "tab".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   $curtabid = $id;
	   $tabs = $_POST['TABS'];
		//$tabs = str_replace("=","\=",str_replace(",","\,",$tabs));
		
	   if(trim($tabs) != ""){
		   $atrrValStr =RemoveAtrr("tabs",$atrrValStr);
		   //$onchange = rtrim($onchange,"()");
	   }else{
		   $tabs = "Page";
	   }
	   
	   //get all tabs
	   $tabarr = explode("&",$tabs);
	   $totTab = count($tabarr);
	   $tabperc = 100;
	   if($totTab > 0){
	    $tabperc = 100/$totTab;
	   }
	   $select = $_POST['TABIND'];
		$group = $_POST['GRPNAME'];
	  // $select = GetValue("select",$atrrValStr);
		if(trim($select) != ""){
		   $atrrValStr =RemoveAtrr("select",$atrrValStr);
	   }else{
		 $select = -1;  
	   }
	   
	   $curentsel = (int)$select;
	   $selectedid = $curentsel > -1?$id.'_tb_'.$curentsel:"";
	   
	   //get the group name
	   //$group = GetValue("group",$atrrValStr);
		if(trim($group) != ""){
		   $atrrValStr =RemoveAtrr("group",$atrrValStr);
	   }else{
		 $group = "";  
	   }
	   
	$atrrValStr = ProcessAtrrVal($atrrValStr);
$str = <<<sssa
<div class="tabbox" id="$id" >
	<input type="hidden" id="{$id}_sel" value="{$selectedid}" />
	<input type="text" class="grpptabdis" id="{$group}_grptabmenus" value="" style="position:absolute;top:-200px" />
      <table cellspacing="0" class="tabl" id="grptabmenus_{$group}">
       <tr>
sssa;
for($d=0;$d<$totTab;$d++){
	$tabval = $tabarr[$d];
	$indtabarr = explode("=",$tabval);
	$tabatr = $indtabarr[0];
	$tabText = $indtabarr[1];
	$tabTextarr[$d] = $tabText;
	$selcls = (int)$select == $d?"class=\" active\"":"";
	$img = $tabatr;
	$mainid = $id.'_tb_'.$d;
	if(isset($img)){
		//$img .= "h";
		if(file_exists("../../Files/MenuImages/".strtolower($img).".png")){
			$img = '<img style="display:" src="'.$_POST['CORE']."cportal/Files/MenuImages/".strtolower($img).".png".'" /><div style="">'.$tabText.'</div>';
		}
	}
	//width:'.$tabperc.'%
	$str .= '<td id="'.$mainid.'" onClick="Tabs.Select(this)" '.$selcls.' title="'.$tabText.'"  style="" >'.$img.'</td><input type="hidden" id="'.$mainid.'_tabName" value="'.$tabatr.'" /><input type="hidden" id="'.$mainid.'_groupName" value="'.$group.'" /><input type="hidden" id="'.$mainid.'_tabDisName" value="'.$tabText.'" /><input type="hidden" id="tabindex_'.$tabatr.'" value="'.$d.'" />';
}
          /*<td id="{$id}_tb_1" onClick="Tabs.Select(this)">Bio Data</td>
          <td id="{$id}_tb_2" onClick="Tabs.Select(this)">Main Frame</td>
          <td id="{$id}_tb_3" onClick="Tabs.Select(this)">Student</td>*/
$str .= <<<sss
       </tr>
       </table>
       <div class="tabbody" onclick="">
sss;
echo $str;
}

function TabBody($atrrValStr = ""){
global $tabindex;
global $curtabid;
global $curentsel;
global $tabTextarr;
global $grpName;
global $tabbodygrpbxcnt;
$tabbodygrpbxcnt = 0;
$tabBodyName = PopValue("name",$atrrValStr);
if(trim($tabBodyName) == ""){
	$tabBodyName = $curtabid.$tabindex;
}
$tabText = $tabTextarr[$tabindex];
$selclsi = $curentsel == $tabindex?" show":"";
Box("class=progressBox,id={$curtabid}_{$tabindex}_progressbox");
	 echo "<div class=\"bar\" id=\"{$curtabid}_{$tabindex}_progressbar\"><div class=\"shadow-anim\"> </div></div>";
	 echo '<div class="progressBox-2">
	 <div class="pr-container" id="'.$curtabid.'_'.$tabindex.'_progress-2-bx"></div>
	 <div class="ep-center"><button class="progressBox-2-btn" onclick="Tabs.RunAbort(\''.$curtabid2.'\','.$tabindex.')" title="Cancel"><i class="fa fa-fw fa-times"></i></button><button class="progressBox-2-btn" onclick="Lock.Show()"  title="Lock Screen"><i class="fa fa-fw fa-key"></i></button><button class="progressBox-2-btn" onclick="Page.MinimizeAll();Page.HideTaskBar();"  title="Home"><i class="fa fa-fw fa-home"></i></button>
	 <button class="progressBox-2-btn" onclick="Login.Logout()"  title="Logout"><i class="fa fa-fw fa-power-off"></i></button></div>
	 </div>';

	/*  echo '<div class="progressBox-2">
	 <div class="pr-container" id="'.$curtabid.'_'.$tabindex.'_progress-2-bx"></div>
	 <div class="ep-center"><button class="progressBox-2-btn" onclick="Tabs.RunAbort(\''.$curtabid2.'\','.$tabindex.')" title="Cancel"><i class="fa fa-fw fa-times"></i></button><button class="progressBox-2-btn" onclick="Lock.Show()"  title="Lock Screen"><i class="fa fa-fw fa-key"></i></button><button class="progressBox-2-btn" onclick="Page.MinimizeAll();Page.HideTaskBar();"  title="Home"><i class="fa fa-fw fa-home"></i></button>
	 <button class="progressBox-2-btn" onclick="Login.Logout()"  title="Logout"><i class="fa fa-fw fa-power-off"></i></button></div>
	 </div>'; */
_Box();
$str = <<<sss
<div class="tabcont {$selclsi} animated fastest" id="{$curtabid}_tb_{$tabindex}_body">
sss;
$curtabid2 = substr($curtabid,0,strlen($curtabid)-3); //remove the 
echo $str."<div>";
 
/* echo '<div class="inner">
<div class="tabTitle">'.$grpName.' <i class="fa fa-angle-double-right"></i> '.$tabText.'</div>
'; */
echo '</div><div class="inner">
';
Hidden("{$curtabid}_tb_{$tabindex}_name",$tabBodyName);
}


$sidebarstart = false;
$sidebarlogo = 'mbri-search';
function _TabBody(){
	global $sidebarstart;
	global $tabindex;
	$str = '<div class="clearer"></div>'.($sidebarstart?'</div><div class="clearer"></div>':'').'
	</div>
</div>';
$sidebarstart = false;
$tabindex++;
echo $str;
}


function SideBar($atrrValStr = ""){
	global $sidebarstart;
	global $sidebarlogo;
	global $tabindex;
global $curtabid;
	$logo = PopValue("logo",$atrrValStr);
	$sidebarlogo = (trim($logo) != "")?$logo:"mbri-search";
	echo '<div class="sidebarbx card-3 minimize" id="'.$curtabid.'_'.$tabindex.'_sidebar" >
	<button type="button" onclick="this.parentElement.classList.add(\'minimize\')" class="menubtn-main-min"><i class="fa fa-chevron-left"></i></button>';
	$sidebarstart = true;
}
function _SideBar(){
	global $sidebarlogo;
	echo '<button type="button" onclick="this.parentElement.classList.remove(\'minimize\')" class="menubtn-main"><i class="'.$sidebarlogo.'"></i></button></div>';
	$sidebarlogo = "mbri-search";
	echo '<div class="sidebarbody">';
}

function _Tab(){
	global $tabindex;
global $curtabid;
global $curentsel;
	echo "</div>
    </div>";
	$tabindex = 0;
	$curtabid = "";
	$curentsel = -1;
}
if(!function_exists("EmailBox")){
function EmailBox($atrrValStr = "",$dropdown = NULL){
	$atrrValStr = "validate=email,".$atrrValStr;
	TextBox($atrrValStr,$dropdown);
}
}

function PhoneBox($atrrValStr = "",$dropdown = NULL){
	$atrrValStr = "validate=phone,".$atrrValStr;
	TextBox($atrrValStr,$dropdown);
}

/*TextBox Element*/
function __TextBox($atrrValStr = "",$dropdown = NULL){
	global $currfrm;
	$rtnstr = "";
 $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "txtbx".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   
	   $placeholder = GetValue("title",$atrrValStr);
	   if(trim($placeholder) != ""){
		   // $atrrValStr =RemoveAtrr("title",$atrrValStr);
	   }else{
		 $placeholder = "";  
	   }
	   
	   $type = GetValue("type",$atrrValStr);
	   if(trim($type) != ""){
		    $atrrValStr =RemoveAtrr("type",$atrrValStr);
	   }else{
		 $type = "text";  
	   }
	   
	   
	   $onchange = GetValue("onchange",$atrrValStr);
	   if(trim($onchange) != ""){
		    $atrrValStr =RemoveAtrr("onchange",$atrrValStr);
	   }
	   //$onchange = RunFunction($onchange);
	   
	   $textchange = GetValue("textchange",$atrrValStr);
	   if(trim($textchange) != ""){
		    $atrrValStr =RemoveAtrr("textchange",$atrrValStr);
	   }
	    $textt = PopValue("text",$atrrValStr);
		$onfocus = PopValue("onfocus",$atrrValStr);
		$onblur = PopValue("onblur",$atrrValStr);
	   $required = GetValue("required",$atrrValStr);
	   if(trim($required) != ""){
		    $atrrValStr =RemoveAtrr("required",$atrrValStr);
	   }
	   if(trim($required) == "true"){
		   $required = trim($textt) == ""?"~~!!@@":"reqs";
	   }else{
		$required = "";
	   }
	   
	   
	   $textchange = RunFunction($textchange);
	   
	   $logo = GetValue("logo",$atrrValStr);
	   if(trim($logo) != ""){
		    $atrrValStr =RemoveAtrr("logo",$atrrValStr);
			//$atrrValStr .= ",style=background-image:url(TaquaLB/Elements/Images/textbox/".$logo.".png)";
			/*$sty = GetValue("style",$atrrValStr);
			if($sty != ""){
				$sty = rtrim($sty,";").";background-image:";
			}*/
	   }else{
		  $logo = "font"; 
	   }
	   

	  
	   
	    $validate = GetValue("validate",$atrrValStr);
	   if(trim($validate) != ""){
		    $atrrValStr =RemoveAtrr("validate",$atrrValStr);
	   }
	   
	   //chain selection
	   $chain = GetValue("chain",$atrrValStr);
	   if(trim($chain) != ""){
		    $atrrValStr =RemoveAtrr("chain",$atrrValStr);
	   }

	   $readol = GetValue("readonly",$atrrValStr);
	   if(trim($readol) != ""){
		    $atrrValStr =RemoveAtrr("readonly",$atrrValStr);
	   }

	   $disable = GetValue("disabled",$atrrValStr);
	   if(trim($disable) != ""){
		    $atrrValStr =RemoveAtrr("disabled",$atrrValStr);
	   }
	   
	   //style
	   $st = GetValue("style",$atrrValStr);
	   $valueW = 0;
	   if(trim($st) != ""){
		    $brkd = explode(";",$st);
			foreach($brkd as $rule){
				$rulearr = explode(":",$rule);
				$ruleatr = strtolower(trim($rulearr[0]));
				if($ruleatr == "width"){
					$valueW = (int)$rulearr[1];
	                break;
				}
			}
	   }

	   $info = GetValue("info",$atrrValStr);
	   if(trim($info) != ""){$atrrValStr =RemoveAtrr("info",$atrrValStr);}
	   $selected = PopValue("selected",$atrrValStr);
//get the default  dropdown option
	   $defaultDrodown = PopValue("default",$atrrValStr);
	   //get the class for the input element
	   $inputclass = PopValue("input-class",$atrrValStr);
	   $calendarcl = "";
	   $iattrs="";
	if(strtolower($type) == "calendar"){
		$type = "text";
		$inputclass .= " Calendar";
		$selcalss = PopValue("calendar-selected",$atrrValStr);
		$selcalss = trim($selcalss) == ""?"selected":$selcalss;
		$prange =  PopValue("calendar-range",$atrrValStr);
		$prange = trim($prange) == ""?"false":$prange;
         $iattrs = 'data-selected-class="'.$selcalss.'" data-range="'.$prange.'"';
	}

	//get the hidden status
	$silent = PopValue("silent",$atrrValStr);
	$silent = trim($silent) == ""?"false":$silent;
	if($silent == "true" || $silent == "1"){

		$atrrValStr = "style=display:none,".$atrrValStr;
	}
	$dropup = PopValue("dropup",$atrrValStr);
	$dropup = strtolower($dropup) == "true"?"distop":"";
	  // $str = $textt;
		$atrrValStr = ProcessAtrrVal("class=textBx $required $currfrm,".$atrrValStr);

		if(is_array($dropdown)){ //if dropdown 
			//array_unshift($dropdown,)
			if(trim($defaultDrodown) != "" && isset($dropdown[$defaultDrodown])){ //if default(prepend) dropdown element set
				$defaultDrodown = $defaultDrodown.":".str_replace(array(":",'"'),array("@~!~@","#@!@"),$dropdown[$defaultDrodown]);
			}else{
				$defaultDrodown = "";
			}
			$totdrp = count($dropdown);
		}else{
			$totdrp = -1;
		}
	
		$logos = "";
		if($totdrp > 0){
			//$logos = '<i class="fa fa-arrow-double-down" aria-hidden="true" style="margin-left:10px"><i>';
		}

		$readonly = $totdrp > -1 || trim($readol) == "true" ?"readonly=readonly":"";
		$disable = trim($disable) == "true" ?"disabled=disabled":"";
		$bind = "";
		if($type == "password"){
		  $bind = "oncopy=\"return false\" onpaste=\"return false\"";   
	   }//{$logos}
$str = '<div '.$atrrValStr.' data-chain="'.$chain.'" data-validate="'.$validate.'" data-form="'.$currfrm.'" data-onchange="'.$onchange.'" data-default="'.$defaultDrodown.'" data-value="#***#" data-silent="'.$silent.'" >	<i class="fa fa-'.$logo.'" aria-hidden="true" id="'.$id.'_icon" ></i>';
if($totdrp > -1){
	$loadingstyle = '';

	if($valueW > 0){
		$valueW -= 20;
		$loadingstyle = 'style="margin-left:'.$valueW.'px"';
	}
	$str .= '<i class="fa fa-chevron-down drpdwn" onclick="_(\''.$id.'_inp\').focus()" aria-hidden="true" '.$loadingstyle.' id="'.$id.'_drpdwn"></i><i class="fa fa-cog fa-spin loading" aria-hidden="true" '.$loadingstyle.' id="'.$id.'_loading"></i>';
}else{
	$str = str_replace("#***#","",$str);
}
$textt = $selected == ""?str_replace('"','&quot;',$textt):"#@@@#";

//$selected = trim($selected) == ""?"":$selected; //if no selected set to - to avoid taking "" as 0
if($type == "multiline"){
$str .= <<<sss
<textarea  id="{$id}_inp" onblur="TextBox.Validate(_('{$id}'));_('{$id}_icon').classList.remove('altColor2');{$onblur}" value="{$textt}" onkeyup="{$textchange}" placeholder="{$placeholder}" title="{$placeholder}" $readonly $disable $bind onfocus="_('{$id}_icon').classList.add('altColor2');{$onfocus}" class="$inputclass" $iattrs >{$textt}</textarea>
sss;
}else{
	
$str .= <<<sss
<input  type="{$type}" id="{$id}_inp" onblur="TextBox.Validate(_('{$id}'));_('{$id}_icon').classList.remove('altColor2');{$onblur}" value="{$textt}" onkeyup="{$textchange}"  class="$inputclass" $iattrs placeholder="{$placeholder}" title="{$placeholder}" $readonly $disable $bind onfocus="_('{$id}_icon').classList.add('altColor2');{$onfocus}" />
sss;
}
$rtnstr .= $str;
$rtnstr .= "<div id=\"{$id}_drpd\" class=\"greyShadow tbdrpdwn {$dropup}\" style=\"font-size:1.1em\" >";

	if($totdrp > -1){
	  $rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=false,multiselect=,id={$id}tb");
	  $seensel = false;
	  $cnkk = true;
	  foreach($dropdown as $key => $val){
		  $txt = $val;	
		  $idtxt = $key;
		  if((trim($selected) != "" && $key == $selected) || ($cnkk && (int)$selected == -1)){
			  $rtnstr = str_replace(array("#***#","#@@@#"),array($key,$val),$rtnstr);
              $seensel = true;
			  $cnkk = false;
		  }
		  if(!is_array($txt)){
		   $rtnstr .= __TRecord(array($txt),"id={$idtxt}");
		  }else{
			 $rtnstr .= __TRecord($txt,"id={$idtxt}"); 
		  }
	  }
	  //if no selected
	  $rtnstr = str_replace(array("#***#","#@@@#"),"",$rtnstr);
	  $rtnstr = $seensel?str_replace("~~!!@@","reqs",$rtnstr):str_replace("~~!!@@","req",$rtnstr);
	  /*		  
				TRecord(array("Orange"));
				TRecord(array("Bread"));
				TRecord(array("Rice"));*/
	  $rtnstr .= ___Table();
	}else{ //for normal textbox
		
		$rtnstr = trim($textt) != ""?str_replace("~~!!@@","reqs",$rtnstr):str_replace("~~!!@@","req",$rtnstr);
	}/*else if($totdrp > 0){
		$rtnstr .= __Table("onselect=TextBox.Select,onunselect=TextBox.UnSelect,rowselect=true,multiselect=,id={$id}tb");
	    $rtnstr .= ___Table();
	}*/
	$info = EscapeString($info);
		  $rtnstr .= "</div>"."</div>";
		  if(trim($info) != ""){
            $rtnstr .= _Text("text=$info,style=display:block;padding-left:10px;font-size:0.8em;width:100%;color:rgba(0\,0\,0\,.7);visibility:visible;position:relative;font-style:italic");
		  }
		  //<input  type=\"hidden\" id=\"{$id}_inpVal\" value=\"\" />";//<input  type=\"hidden\" id=\"{$id}_onch\" value=\"{$onchange}\" />";//<input type=\"hidden\" id=\"frm_{$id}\" value=\"{$currfrm}\" name=\"frm_{$id}\" />";//.'<input type="hidden" id="'.$id.'_validate" value="'.$validate.'" />';//.'<input type="hidden" id="'.$id.'_chain" value="'.$chain.'" />';
		  global $TextBoxGroupOn; global $TextBoxGroupItemOn;
		  $silentclss = ($silent == "true" || $silent == '1')?'style="display:none"':'';
		  if($TextBoxGroupOn){

			  return $TextBoxGroupItemOn?$rtnstr:'<tr class="" '.$silentclss.' ><td>'.$rtnstr.'</td></tr>'; 
		  }
	return $rtnstr; 
}
if(!function_exists("TextBox")){
function TextBox($atrrValStr = "",$dropdown = NULL){
	echo __TextBox($atrrValStr,$dropdown);
}
}

//global indicator for textbox inside a textbox group
$TextBoxGroupOn = false;
$TextBoxGroupItemOn = false;
$td = 'td';
function __TextBoxGroup($style="width:95%;font-size:0.8em;margin:auto",$cls=""){
	global $TextBoxGroupOn;
	$TextBoxGroupOn = true;
	return '<table class="tbl2 rwb card-1 '.$cls.'" style="'.$style.';border-color:transparent" bordercolor="" border="">';
}

function TextBoxGroup($style="width:95%;font-size:0.8em;margin:auto",$cls=""){
	echo __TextBoxGroup($style,$cls);
}

function ___TextBoxGroup(){
	global $TextBoxGroupOn;
	$TextBoxGroupOn = false;
	return '</table>';
}

function _TextBoxGroup(){
	echo ___TextBoxGroup();
}

function __TextBoxGroupItem($attrval= ""){
	global $TextBoxGroupOn;
	global $TextBoxGroupItemOn;global $td;
	$tdval = PopValue("type",$attrval);
	$attrval = ProcessAtrrVal($attrval);
	if($TextBoxGroupOn){
		$td = trim($tdval) == "head"?'th':'td';
		$TextBoxGroupItemOn = true;
		return '<tr style=""><'.$td.' '.$attrval.'>';
		
	}

}//.$rtnstr.'</td></tr>'

function __TextBoxGroupItemMore($attrval= ""){
	global $TextBoxGroupOn;global $TextBoxGroupItemOn;global $td;
	//return (string)$TextBoxGroupItemOn;
	if($TextBoxGroupOn == true && $TextBoxGroupItemOn == true){
		$attrval = ProcessAtrrVal($attrval);
		return "</$td><$td $attrval>"; 
	}

}

function ___TextBoxGroupItem(){
	global $TextBoxGroupOn;
	global $TextBoxGroupItemOn;global $td;
	if($TextBoxGroupOn){
		$TextBoxGroupItemOn = false;
		$rtn = '</'.$td.'></tr>'; 
		$td = 'td'; //retuen to default
	}
}

function TextBoxGroupItem($attrval= ""){
  echo __TextBoxGroupItem($attrval);
}
function _TextBoxGroupItem(){
	echo ___TextBoxGroupItem();
  }

  function TextBoxGroupItemMore($attrval= ""){
	  echo __TextBoxGroupItemMore($attrval);
  }
$grpName = "";
$jscript = "";
function StartJavaScript($scri=""){
	global $jscript;
	$jscript .= $scri;
}

function Page($atrrValStr = ""){
	global $grpName;global $dbo;
	$ids = PopValue("pgid",$atrrValStr);
	$ids = $ids!=""?$ids:isset($_REQUEST['PGID'])?$_REQUEST['PGID']:"";
	$urls = PopValue("pgurl",$atrrValStr);
	$urls = $urls!=""?$urls:isset($_REQUEST['PGURL'])?$_REQUEST['PGURL']:$_REQUEST['PHP_SELF'];//GRPNAME
	$grpName = PopValue("grpname",$atrrValStr);
	$grpName = $grpName!=""?$grpName:isset($_REQUEST['GRPNAME'])?$_REQUEST['GRPNAME']:"Page";
	$tabname = PopValue("tabname",$atrrValStr);
	$tabname = $tabname!=""?$tabname:isset($_REQUEST['TABNAME'])?$_REQUEST['TABNAME']:$grpName;
	$tabdisname = PopValue("tabdisname",$atrrValStr);//TABDISNAME;
	$tabdisname = $tabdisname!=""?$tabdisname:isset($_REQUEST['TABDISNAME'])?$_REQUEST['TABDISNAME']:$tabname;
	$tabind = PopValue("tabind",$atrrValStr);
	$tabind = $tabind!=""?$tabind:$_REQUEST['TABIND'];
	$logo = PopValue("logo",$atrrValStr);
	$logo = $logo!=""?$logo:$_REQUEST['LOGO'];
$openE = isset($_REQUEST['EXPLORER']) && (int)$_REQUEST['EXPLORER'] > 0?"OpenExplorer":"";
   // $userdet = $_REQUEST['USER'];

	$atrrValStr = "class=pgmain,id=$ids,url=$urls,".$atrrValStr;
	 $id = GetValue("id",$atrrValStr);
	if(trim($id) == ""){
		   $id = "pg".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   $url = GetValue("url",$atrrValStr);
	   $grpNameSmall = strtolower($grpName);
	   $funcarr = array("Save"=>"","Print"=>"","Clear"=>"","Copy"=>"","Paste"=>"","Delete"=>"","Export"=>"","Import"=>"");
	   foreach($funcarr as $nme => $fun){
		   $rnme = strtolower($nme);
		   $val = GetValue($rnme,$atrrValStr);
		   if($val != ""){
			   $funcarr[$rnme] = RunFunction($val,"'{$id}','{$nme}'");
		   }else{
			   $funcarr[$rnme] = RunFunction("Tabs.Toolbox.Perform","'{$id}','{$nme}'");
		   } 
	   }
	   extract($funcarr);

//get all menus
/* $menustr = '';
$menus = $dbo->Select4rmdbtb("menu_tb","","1=1 ORDER BY GrpOrder");
if(is_array($menus)){
	if($menus[1] > 0){
   // $rst = 
		while($gmenu = $menus[0]->fetch_array()){
			$gnamea = $gmenu["GName"];
			$dnamea = $gmenu["DName"];
			$Tabs = $gmenu["Tabs"];
			$cl = $grpNamea == $gnamea?"":"closesub";
			$menustr .= '<li class="'.$cl.'">
			<a class="hoverable" onclick="this.parentElement.classList.toggle(\'closesub\')"><span class="imgcont"><i class="fa fa-caret-right" aria-hidden="true"></i></span><span>'.$dnamea.'</span></a><ul>';
			if(trim($Tabs) != ""){
				$tabsarr = explode("&",$Tabs);
				if(count($tabsarr) > 0){
					for($r = 0; $r <count($tabsarr); $r++){
						$tabinda = $tabsarr[$r];
						$tabindarr = explode("=",$tabinda);
						if(count($tabindarr) == 2){
							$tabnamea = $tabindarr[0];
							$tabDisnamea = $tabindarr[1];
$menustr .= '<li><a class="hoverable exsubitems" href="javascript:void(0)" onclick="Page.OpenByTabName(\''.$tabnamea.'\',true);Fender.SelectSub(this)"><span class="imgcont"><img src="Files/MenuImages/'.strtolower($tabnamea).'.png" /></span><span>'.$tabDisnamea.'</span></a></li>';

						}
					}
				}
			}
			$menustr .= '</ul></li>';
		}

	}
} */
	//$atrrValStr = ProcessAtrrVal($atrrValStr);
	//$menus = array("Save","Copy","Print","Clear","Delete","Export");
$str = <<<sss
<div class="toolboxL toolbox">
<div style ="font-size:1.9em" class="head showExplorer" onclick="this.parentElement.classList.toggle('toolboxOpen')">
<div class="headinner showExplorer">
<i class="fa fa-$logo showExplorer" aria-hidden="true"></i><span class="showExplorer">$grpName</span>
</div>
<div class="opener showExplorer" ><i class="fa fa-chevron-left showExplorer" aria-hidden="true"></i></div>
</div>
<div title="Save" onclick="this.parentElement.classList.remove('toolboxOpen');$save"><i class="fa fa-save" aria-hidden="true"></i><span>Save</span></div>
<div class="sepr"></div>
<div title="Print"  onclick="this.parentElement.classList.remove('toolboxOpen');$print"><i class="mbri-print" aria-hidden="true"></i><span>Print</span></div>
<div class="sepr"></div>
<div title="Clear"  onclick="this.parentElement.classList.remove('toolboxOpen');$clear"><i class="mbri-new-file" aria-hidden="true"></i><span>Clear</span></div>
<div title="Delete"  onclick="this.parentElement.classList.remove('toolboxOpen');$delete"><i class="mbri-trash" aria-hidden="true"></i><span>Delete</span></div>
<div class="sepr"></div>
<div title="Copy" onclick="this.parentElement.classList.remove('toolboxOpen');$copy"><i class="mbri-pages" aria-hidden="true"></i><span>Copy</span></div>
<div title="Paste" onclick="this.parentElement.classList.remove('toolboxOpen');$paste"><i class="mbri-edit" aria-hidden="true"></i><span>Paste</span></div>
<div class="sepr"></div>
<div title="Export"  onclick="this.parentElement.classList.remove('toolboxOpen');$export"><i class="mbri-redo" aria-hidden="true"></i><span>Export</span></div>
<div title="Import"  onclick="this.parentElement.classList.remove('toolboxOpen');$import"><i class="mbri-undo" aria-hidden="true"></i><span>Import</span></div>
</div>
  
  <div class="maincontreal">
  
  
sss;
echo $str;
/* <div class="toolboxR toolbox $openE">
  <span class="explorer">
	 <div class="inner">
	   <div class="expheader" onclick="this.parentElement.parentElement.parentElement.classList.toggle('OpenExplorer');">Explorer</div>
	   <ul class="expbody">
		 <!-- <li>
		 <a class="hoverable" onclick="this.parentElement.classList.toggle('closesub')"><i class="fa fa-caret-right" aria-hidden="true"></i><span>Student</span></a>
		 <ul>
		   <li><a class="hoverable" href="javascript:Page.OpenByTabName('psetting',true)"><span class="imgcont"><img src="Files/MenuImages/mngcourse.png" /></span><span>Bio Data</span></a></li>
		 </ul>
		 </li> -->
		 $menustr
	   </ul>
	 </div>
  </span>
   <div id="{$ids}_userloginbox"  class ="sel no head" title=""  onclick="this.parentElement.classList.toggle('toolboxOpen')">
   <div class="headinner">
<img  id="{$ids}_userloginboximg"  src="" alt="" /><span id="{$ids}_userloginboximgn"></span>
</div>
   <div class="opener" ><i class="fa fa-chevron-left" aria-hidden="true"></i></div>
   
   </div>
   

<div title="Explorer" class="explorerbtn" onclick="this.parentElement.classList.toggle('OpenExplorer');"><i class="fa fa-clone" aria-hidden="true"></i><span>Explorer</span></div>

   <div title="Home" onclick="this.parentElement.classList.remove('toolboxOpen');Page.MinimizeAll()"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></div>


<div title="Close" onclick="this.parentElement.classList.remove('toolboxOpen');Page.Close('$id')"><i class="fa fa-close" aria-hidden="true"></i><span>Close</span></div>

<div title="Reload All" onclick="this.parentElement.classList.remove('toolboxOpen');Page.Open('$url',$tabind,'$grpName','$tabname','$tabdisname',true)"><i class="fa fa-refresh" aria-hidden="true"></i><span>Reload</span></div>

<div title="Info" onclick="this.parentElement.classList.remove('toolboxOpen');ToolBox.NoFunc()"><i class="fa fa-info-circle" aria-hidden="true"></i><span>Info</span></div>
<div title="Switch User"  onclick="this.parentElement.classList.remove('toolboxOpen');ToolBox.NoFunc()"><i class="fa fa-users" aria-hidden="true"></i><span>Switch</span></div>
<div title="Logout"  onclick="this.parentElement.classList.remove('toolboxOpen');Login.Logout()"><i class="fa fa-power-off" aria-hidden="true"></i><span>Logout</span></div>
<div title="Lock" onclick="this.parentElement.classList.remove('toolboxOpen');Lock.Show()"><i class="fa fa-key" aria-hidden="true"></i><span>Lock</span></div>

  </div> */
}

function _Page(){
	global $jscript;
	global $grpName;
	//$jscript = str_replace("'","\'",$jscript);
	echo '<div id="'.$grpName.'_autorun" style="display:none">
        '.$jscript.'
  </div>';
	echo "</div>";
	$grpName = "";
	$jscript = "";
}


$GroupBoxStyle = array();
function GroupBox($atrrValStr = ""){
	global $GroupBoxStyle;
	global $tabbodygrpbxcnt;
	$sticky = trim(PopValue("sticky",$atrrValStr));
	if($sticky == "true"){
		$sticky = "sticky";
	}else{
		$sticky = "";
	}
	$atrrValStr = "class=grpbx ep-animate-opacity $sticky ,".$atrrValStr;
	$tabbodygrpbxcnt++;
	 $id = GetValue("id",$atrrValStr);
	if(trim($id) == ""){
		   $id = "grpbx".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	   $logo = trim(PopValue("logo",$atrrValStr));
	  
	   if($logo != ""){
         $logo = _Icon($logo);
	   } 
	   
	  
	   //grpbxtitle
	   $tit = GetValue("title",$atrrValStr);
	   $titdiv = "";
	   if(trim($tit) != ""){
		    $titdiv = "<div class=\"grpbxtitle\" title=\"{$tit}\" onclick=\"this.parentElement.parentElement.classList.toggle('grpbxhide')\"  id=\"{$id}_title\" >{$logo} <span>{$tit}</span></div><div style=\"clear:both\"></div>";
			$titdiv .= __Box("class=grpbxline,style=height:1px; width:100%; margin:auto; background-color:#FFFFFF;margin-bottom:4px");
			$titdiv .= ___Box();
		    $atrrValStr =RemoveAtrr("title",$atrrValStr);
	   }
	    $style = GetValue("style",$atrrValStr);
	   $GroupBoxStyle = ELemDataArray($style ,";",":");
	   $size = GetValue("size",$atrrValStr);
	  // if(trim($size) == ""){$size = 1}
	   if(trim($size) != ""){
		   if(trim($size) == "auto"){
			$atrrValStr .=", style=width:100%;box-sizing:border-box";
			$GroupBoxStyle["width"] = "100%;box-sizing:border-box";
		   }else{
			$sizearr = explode("*",$size);
			$sizeC = (int)$sizearr[0] == 0?1:(int)$sizearr[0];
			$width = (290 * $sizeC)+(($sizeC - 1) * 10);
			$atrrValStr .=", style=width:{$width}px";
			$GroupBoxStyle["width"] = "{$width}px";
			if(isset($sizearr[1])){
			  $sizeR = (int)$sizearr[1] == 0?1:(int)$sizearr[1];
			  $height = (400 * $sizeR)+(($sizeR - 1) * 10);
			  $atrrValStr .=";min-height:{$height}px";
			  $GroupBoxStyle["height"] = "{$height}px";
			}
		   }
		 
	   }
	  
	  if(!isset($GroupBoxStyle["height"])){
		  $GroupBoxStyle["height"] = "400px";
	  }
	  if(!isset($GroupBoxStyle["width"])){
		  $GroupBoxStyle["width"] = "290px";
	  }
	   
	   //$width = (int)$stylearr["width"];
	   //$curGBW = $width;
	$atrrValStr = ProcessAtrrVal($atrrValStr);
$str = <<<sss
<div $atrrValStr > <div class="grpbxinner"> $titdiv <div class="grpbxcont">
sss;
echo $str;
Hidden($id."_grpdata","");
}

function _GroupBox(){
	global $GroupBoxStyle;
	$GroupBoxStyle = array();
	echo "</div></div></div>"; 
}

function ResolveFunc($strfunc){
	$str = explode("(",$strfunc);
	return $str[0];
}

//Flatbutton
function FlatButton($atrrValStr = ""){
	global $currfrm;
 $id = GetValue("id",$atrrValStr);
	   if(trim($id) == ""){
		   $id = "flatbtn.".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	$txt = GetValue("text",$atrrValStr);
	   if(trim($txt) != ""){
		    $atrrValStr =RemoveAtrr("text",$atrrValStr);
			//$txt = str_replace(array('=',','),array('\=','\,'),$txt);
	   }
	   
	 $logo = GetValue("logo",$atrrValStr);
	 /* $oc = GetValue("onclick",$atrrValStr);
	   if(trim($txt) != ""){
		    $atrrValStr = RemoveAtrr("onclick",$atrrValStr);
			$atrrVa
	   }*/
	   $submit = GetValue("submit",$atrrValStr);
	   $atrrValStr = ProcessAtrrVal("class=flatbtn font $currfrm,".$atrrValStr);
	  // $atrrValStr = "class=flatbtn,".$atrrValStr;
	  $atrrValStr  = ($submit != "")?$atrrValStr ." onclick=_('frm_{$id}_sub').click()":$atrrValStr;
$str=<<<sss
<button $atrrValStr type="button" data-caption="$txt" ><div id="{$id}inner"><span class="flatbtnlogobx" ><i class="fa fa-{$logo} fa-fw"></i></span> <span id="{$id}_fbtntxt">$txt</span> <i class="fa fa-cog fa-spin fa-fw" ></i></div> </button>
<input type="hidden" id="frm_{$id}" value="{$currfrm}" name="frm_{$id}" />	

sss;
if($submit != ""){
	$str .= "<input type=\"submit\" id=\"frm_{$id}_sub\" value=\"{$currfrm}_sub\" name=\"frm_{$id}_sub\" style=\"display:none\" />";
}
global $TextBoxGroupOn;global $TextBoxGroupItemOn;
if($TextBoxGroupOn){
   echo $TextBoxGroupItemOn?$str:'<tr class=""  ><td style="padding:0px">'.$str.'</td></tr>'; 
}else{
echo $str;
}



}


//raw box
function __Box($atrrValStr = ""){
	$atrrValStr = ProcessAtrrVal($atrrValStr);
	return "<div {$atrrValStr} >";
}

if(!function_exists("Box")){
function Box($atrrValStr = ""){
	echo __Box($atrrValStr);
}
}

function ___Box(){
	return "</div>";
}

if(!function_exists("_Box")){
function _Box(){
	echo "</div>";
}
}

function ImageBox($atrrValStr = ""){
	$src = GetValue("src",$atrrValStr);
	   if(trim($src) != ""){
		    $atrrValStr =RemoveAtrr("src",$atrrValStr);
	   }else{
		 $src = $_POST['CORE']."general/TaquaLB/Elements/Images/defaultpassport.png";   
	   }
	   $id = GetValue("id",$atrrValStr);
	  
	    $atrrValStr = ProcessAtrrVal("class=imgbx $currfrm,".$atrrValStr);
  echo '<div '.$atrrValStr.'>
          <div class="Inner">
            <img id="'.$id.'_img" src="'.$src.'" alt="Invalid Passport" />
          </div>
        </div>';	
}

function AutoFit($padW,$padH,$width,$height,$margin = 0){
     $orientation = "";
  $Ratio = $width / $height;
  //determin if its landscape or portraite
if($height > $width){
	$orientation = "p";
	//check if height is greater than pad hight
	if($height >= $padH){
       $height = $padH - $margin;
	   //calculate new width
      $width = floor($Ratio * $height);
	  
	}
	if($width >= $padW){
          $width = $padW - $margin;
	      //calculate new width
          $height = floor($width / $Ratio);
		}
}else if($width > $height){
	$orientation = "l";
	//check if width is greater than pad width
	if($width >= $padW){
		$width = $padW - $margin;
		//claculate $height
		$height = floor($width / $Ratio);
 
	}

	if($height >= $padH){
          $height = $padH - $margin;
	      //calculate new width
          $width = floor($Ratio * $height);
		}
}
//if square
if($orientation == ""){
	//$style = GetValue("style",$atrrValStr);
   if($height >= $padH){
          $height = $padH - $margin;
	      //calculate new width
          $width = $height;
		 
		}

		 if($width >= $padW){
           $width = $padW - $margin;
		   $height = $width;
		  }
}
return array($width,$height,$orientation);
}

function ImagePad($atrrValStr = ""){
	global $GroupBoxStyle;
	global $currfrm;
	
	$id = GetValue("id",$atrrValStr);
	if(trim($id) == ""){
		   $id = "imgpad".rand();
		   $atrrValStr = "id={$id},".$atrrValStr;
	   }
	 $src = GetValue("src",$atrrValStr);
	 $rel = GetValue("rel",$atrrValStr);
	 $rdefault = $_POST['CORE']."general/TaquaLB/Elements/Images/imglogo.jpg";
	if(trim($src) == "" || !file_exists($rel.$src)){
      $src = $rdefault;
	 // $src2 = _PROOT_."epconfig/TaquaLB/Elements/Images/defaultpassport.png";
	} 
$maxSize = PopValue("maxsize",$atrrValStr);
$maxSize = (int)$maxSize;

	$atrrValStr = ProcessAtrrVal("class=imagepad greyShadow {$currfrm},".$atrrValStr);
	if(!isset($GroupBoxStyle["height"])){
		$GroupBoxStyle["height"] = "400px";
	}
	if(!isset($GroupBoxStyle["width"])){
		$GroupBoxStyle["width"] = "290px";
	}
  $padWr = (int)$GroupBoxStyle['width']  - 20;
  $padHr = (int)$GroupBoxStyle['height']  - 40;
  $padW = $padWr - 12 - 30;
  $padH = $padHr - 12 - 50;

 //$defaultimg = $src;
  list($width, $height, $type, $attr) = getimagesize($rel.$src);
  //$rw = $width; $rh = $height;
  //$sw = $width;
   list($width,$height,$orientation) = AutoFit($padW,$padH,$width,$height,10);
$rand = time();
  //echo $GroupBoxStyle['width'].' ; '.$GroupBoxStyle['height'];
  echo '<div '.$atrrValStr.' data-width="'.$padWr.'" data-height="'.$padHr.'"  data-default="'.$rdefault.'">
      <div class="imgpadcntr" >';
	  SmallButton("logo=image,id=loadimg,title=Select Image,onclick=_('$id').SetPadImage($maxSize)");
	  SmallButton("logo=camera,id=camimg,title=Capture Image,onclick=_('$id').GetPadFile()");
	  SmallButton("logo=file-image-o,id=clearimg,title=Clear Image,onclick=_('$id').ClearImagePad()");
	  echo ' </div>
	  <div class="imgpadload off" id="'.$id.'_load">'._Icon("cog fa-spin").'</div>
	 <img src="'.$src.'?'.$rand.'" style="width:'.$width.'px ;height: '.$height.'px" width="" height="" id="'.$id.'_image" alt="Image" />
	
  </div>';
}



function TextPad($atrrValStr = ""){
	global $currfrm;
	$txt = GetValue("text",$atrrValStr);
	   if(trim($txt) != ""){
		    $atrrValStr =RemoveAtrr("text",$atrrValStr);
	   }
	   $tit = GetValue("title",$atrrValStr);
	   if(trim($tit) != ""){
		    $atrrValStr =RemoveAtrr("title",$atrrValStr);
	   }
	   
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) != ""){
		   // $atrrValStr =RemoveAtrr("id",$atrrValStr);
	   }

	   $logo = GetValue("logo",$atrrValStr);
	   if(trim($logo) != ""){
		    $atrrValStr =RemoveAtrr("logo",$atrrValStr);
	   }else{
		   $logo = "pencil-square-o";
	   }
	    $atrrValStr = ProcessAtrrVal("class=imgbx $currfrm,".$atrrValStr);
		SubHeader(_Icon($logo).' '.$tit);
		//Text("text=$tit,style=display:block;font-weight:bold;color:#BBB;margin-top:15px;,id={$id}.title");
		$pre = ""; $post = "";
		global $TextBoxGroupOn; global $TextBoxGroupItemOn;
		if($TextBoxGroupOn && $TextBoxGroupItemOn == false){
			$pre = '<tr class=""  ><td>';
			$post = '</td></tr>';
		}
  echo $pre .'<div '.$atrrValStr.'>
          <div class="Inner">
            <textarea id="'.$id.'_pad">'.$txt.' </textarea>
          </div>
        </div>'.$post;
		
}

//load the textbox droupdown array from database, running the supplied sql statement
//depends on a conection object $dbo, created using taquaLB phplb
function TextBoxSQL($sql,$states = array()){
	global $dbo;
	//$states = array();
		 $statesrst =  $dbo->RunQuery($sql);
		 if(is_array($statesrst)){
			if($statesrst[1] > 0){
				while($st = $statesrst[0]->fetch_array()){
					$states[$st[0]] = $st[1];
				}
			}
		 }
		 return $states;
}

function DateBox($atrrValStr = ""){
	$tit = GetValue("title",$atrrValStr);
	   if(trim($tit) != ""){
		    $atrrValStr =RemoveAtrr("title",$atrrValStr);
	   }
	   $id = GetValue("id",$atrrValStr);
	   if(trim($id) != ""){
		    $atrrValStr =RemoveAtrr("id",$atrrValStr);
	   }else{
		   $id = "date".rand();
	   }
	   $yearRange = GetValue("range",$atrrValStr);
	   if(trim($yearRange) != ""){
		    $atrrValStr =RemoveAtrr("range",$atrrValStr);
	   }else{
		   $yearRange = date("Y")."-". ((int)date("Y") - 80);
	   }
	   $required = PopValue("required",$atrrValStr);
	   $pre = ""; $post = "";
	   global $TextBoxGroupOn;global $TextBoxGroupItemOn;
	   if($TextBoxGroupOn && $TextBoxGroupItemOn == false){
		$pre = '<tr class=""  ><td>';
		$post = '</td></tr>';
	}
	echo $pre;
  Box("id={$id}");
  SubHeader(_Icon("calendar")." ".$tit);
  //Text("text=$tit,style=display:block;font-weight:bold;color:#BBB;margin-top:15px,id={$id}.title");
		$daysarr = array();
		for($a=1; $a <= 31; $a++){
		  $daysarr[$a] = $a;
		}
		TextBox("title=Day,style=width:70px;margin-right:20px;display:inline-block,id={$id}.day,logo=sun-o,required=".$required,$daysarr);
		$montharr = array(1=>"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		TextBox("title=Month,style=width:80px;margin-right:20px;display:inline-block,id={$id}.month,logo=calendar-minus-o,required=".$required,$montharr);
		$yeararr = array();
		$yearRangearr = explode("-",$yearRange);
		$frm = (int)trim($yearRangearr[0]);
		$to = (int)trim($yearRangearr[1]);
		for($y = $frm;(($frm > $to && $y >= $to) || ($frm < $to && $y <= $to)); ($frm > $to)?$y--:$y++){
			$yeararr[$y] = $y;
		}
		TextBox("title=Year,style=width:80px;margin-right:;display:inline-block,id={$id}.year,logo=globe,required=".$required,$yeararr);
	_Box();
	echo $post;
}
if(!function_exists("ClearFloat")){
function ClearFloat(){
  Box("style=clear:both");_Box();	
}
}

if(!function_exists("Logo")){
function Logo($type = "", $style="",$onclick=""){
 	echo _Logo($type,$style,$onclick);
}
}

if(!function_exists("Icon")){
function Icon($type = "", $style="",$onclick=""){
 	echo _Logo($type,$style,$onclick);
}
}

if(!function_exists("_Icon")){
function _Icon($type = "", $style="",$onclick=""){
 	return _Logo($type,$style,$onclick);
}
}

if(!function_exists("_Logo")){
function _Logo($type = "",$style="",$onclick=""){
	//return 'class="fa fa-'.$type.'" aria-hidden="true" style="'.$style.'"';
	return '<i class="fa fa-'.$type.'" aria-hidden="true" style="'.$style.'" onclick="'.$onclick.'" ></i>';
}
}
//function to get dynamic parameter in a query string for spreadsheet columns
function GetQueryParamColumnID($querystr){
	//echo $querystr;
	//return;
	//return array("q",$querystr);
      $Params = array();
	  if(trim($querystr) != ""){
		  $fseen = -1;
		  for($d=0;$d<strlen($querystr);$d++){ //loop through each character
			  $char = substr($querystr,$d,1);
				  if($char == "?"){ //if seen
                     if($fseen > -1){ //if seen first
                             //get string inbetween
							  //alert(d);
							 $instr = substr($querystr,$fseen+1,$d-1-$fseen);
							 //add to param array
							 $Params[] = $instr;
							 $fseen = -1; //reset fseen to continue looking for another
						   }else{ //seen for the first time
							  
						   $fseen = $d;
						   }
				  }
			  
		  }
	  }
	  /*foreach($Params as $k=>$val){
        echo $k."=".$val;
	  }*/
	  
	  return $Params;
	}
function DataStringE($arr){
	$str = "";
	if(is_array($arr)){
	  foreach($arr as $key => $val){
		  $str .= $key."=".rawurlencode($val)."&";
	  }
	}
	return rtrim($str,"&");
}

//function to form spreadsheet datastring $dunp data 
//function SpreadSheetDataString($dump)
function DataArrayE($str,$elemstr = "&",$keyItem = "="){
	$str = trim($str);
	$rst = array();
	if($str != ""){
		$strarr = explode($elemstr,$str);
		for($a=0; $a<count($strarr) ; $a++){
			$strv = $strarr[$a];
			$stratrvallarr = explode($keyItem,$strv);
			if(count($stratrvallarr) == 2){
				$rst[trim($stratrvallarr[0])] = $stratrvallarr[1];
				
			}
			
		}
		
	}
	return $rst;
	
}
function SpreadSheet($attrval,$headers = array(),$dump = array(), $default = array()){
	/*function replaceSpc(&$item){
		$item = str_replace(" ","&nbsp;",$item);
	}*/
	global $dbo;
	//if query supplied
	if(is_string($dump)){
		
		$qrst = $dbo->RunQuery($dump);
		if(is_array($qrst) && $qrst[1] > 0){
			
			//$dump = $qrst[0]->fetch_all(MYSQLI_BOTH);
			$dump = $dbo->FetchAll($qrst[0]);
			//echo json_encode($dump);
		}else{
			//echo $qrst;
			$dump = $default;	
		}
	}
	//array_walk($headers,"replaceSpc");
	//$attrval = $attrval;
	$spshDataString = ""; //hold all spread sheet populated data (datastring)
	$displayCols = ""; //hold the columne names displayed at default and there num
	if(count($headers) == 0){
		$headers = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T");
	}
	//variable to hold all header and id for popup
	$popuphe = "";
	//form the displayed header element array
	 $tblid = GetValue("id",$attrval);
	 $cellfocus = GetValue("cellfocus",$attrval);
	 if($cellfocus != ""){
		 $attrval =RemoveAtrr("cellfocus",$attrval);
		 $cellfocus = RunFunction($cellfocus,"this");
	 }
	  $cellblur = GetValue("cellblur",$attrval);
	 if($cellblur != ""){
		 $attrval =RemoveAtrr("cellblur",$attrval);
		 $cellblur = RunFunction($cellblur,"this");
	 }
	 //cellkeypress
	 $cellkeypress = PopValue("cellkeypress",$attrval);
	 $trimtxt = PopValue("trimtext",$attrval);
	//echo $trimtxt;
	 if(trim($trimtxt) == ""){ 
      $trimtxt = array('<strong class="altColor">','</strong>');
	 }else{
	 $trimtxt = explode(";",$trimtxt);
	 }
	 $cellkeypress = $cellkeypress != ""?RunFunction($cellkeypress,"this"):"";

	 $rowdelete = strtolower(trim(PopValue("rowdelete",$attrval)));
	 $rowdelete = $rowdelete == ""?"true":$rowdelete;

	//$tblid = GetValue("id",$attrval);
	$popup = _PopUp("title=Select Fields,id={$tblid}_avFields"); 
	 $popup .= __Table("rowselect=false,style=width:100%;margin:auto,id=fields{$tblid},multiselect=true,onselect=SpreadSheet.AddColumnFromList,onunselect=SpreadSheet.RemoveColumnFromListPre");
	 $popup .= __THeader(array("ADD/REMOVE COLUMN"));
	$disheader = array();
	$actionFields = array(); //will hold the prefix char of fields that has prefix (*=Must always be displayed, #=Displayed but can be removed, -=Must Always be hidden)
	$headersec = array();
	$colind = 2;
	//Readonly
	$readonly = PopValue("readonly",$attrval);
			$readonlyarr = array();
			if($readonly != ""){
				if(strtolower(trim($readonly)) == "all"){
					foreach($headers as $k=>$v){
						$readonlyarr[] = ltrim($k,"*-#");
					}
				}else{
					$readonlyarr = explode(";",$readonly);
				}
			
			}

			//Readonly
	$disablecl = PopValue("disable",$attrval);
			$disableclarr = array();
			if($disablecl != ""){
				if(strtolower(trim($disablecl)) == "all"){
					foreach($headers as $k=>$v){
						$disableclarr[] = ltrim($k,"*-#");
					}
				}else{
			$disableclarr = explode(";",$disablecl);
				}
			}

//Global Column classes
$clclass = PopValue("columnclass",$attrval);
$globalcolumnclass = [];
if($clclass != ""){
	//get all set classes
	$globalcolumnclass =  $dbo->DataArray($clclass,";",":");
}



			$dependables = array(); //hold the columnid that requires another columnid to loads its data (Required as key, depending as value)
    $forcedependable = PopValue("dependables",$attrval);
	if($forcedependable != ""){
		$fdepArr = explode(";",$forcedependable);
		foreach($fdepArr as $fdep){
			$fdepBrekArr = explode(":",$fdep);
			if(count($fdepBrekArr) == 2){
               $dependables[$fdepBrekArr[0]] = $fdepBrekArr[1];
			}
		}
	}
	 $booleanFields = array();
	 $displayedindex = 0;
	 
	 foreach($headers as $opid => $txt){
		$genclass = "";
		 $fchar = substr(trim($opid),0,1);
		 $seld = ""; $iscalendar = false;$calendartype = "";
		 if(is_array($txt)){ //if it is a drop down
			   $textdis = $txt[0]; //set the display title 
			   $drpd = $txt[1]; //get the drop down data
			   //determin if the dropdown will allow multiple selection
			   $multisel = isset($txt[2]) && $txt[2] == true?'true':'false';
			   $encrdrpd = $drpd;
			   //check if drpdown is a query string (starts with #)
			   if(substr($drpd,0,1) == "#" || substr($drpd,0,1) == "@"){ //if query string or server script
				//encript the query for security reasons
				$prechar = substr($drpd,0,1);
				$encrdrpd = $prechar.$dbo->__(substr(str_replace('"','94!`32!asd234',$drpd),1),1,2,'"\'<>&%');
			  // echo $drpd;
			  //$query = substr($drpd,1);
			  //split to comfirm
                //get requiered column ids
				$ReqColmn = GetQueryParamColumnID($drpd);
                 if(count($ReqColmn) > 0){ //if required cell found
                  //$ReqColmn = count($ReqColmn) > 1?implode("~",$ReqColmn)
				  foreach($ReqColmn as $requ){
					  $dependant = ltrim($opid,"#");
					  $dependant = ltrim($dependant,"*");
					  $dependables[$requ] = isset($dependables[$requ])?$dependables[$requ]."~".$dependant:$dependant;
				  }
				 }
				}else if(substr($drpd,0,1) == "."){ //if field general class is set
					$genclass = substr($drpd,1);
					$dependant = ltrim($opid,"#");
					    $dependant = ltrim($dependant,"*");
					//check if no global class set
					if(!isset($globalcolumnclass[$dependant])){
						$globalcolumnclass[$dependant] = $genclass;
					}
					$drpd = "";$encrdrpd = "";

			   }else{//check special field
                    if($drpd == "_CALENDAR_" || $drpd == "_CALENDAR_RANGE_"){
						$calendartype  = $drpd;
					  $iscalendar = true;
					  $drpd = "";$encrdrpd = "";
			          $multisel = 'false';
					}
					
			   }
		   }else{
               $textdis = $txt;
			   $drpd = "";$encrdrpd = $drpd;
			   $multisel = 'false';
		   }
		   //$textdis = str_replace(" ","&nbsp;",$textdis);
		   $ropid = ltrim(ltrim($opid,"*"),"#");
		   $editable[$ropid] = "true";
		   $disabled[$ropid] = "false";
		   if(in_array($ropid,$readonlyarr)){ //if in array
              $editable[$ropid] = "false";
		   }
		   if(in_array($ropid,$disableclarr)){ //if in array
             $editable[$ropid] = "false";
			  $disabled[$ropid] = "true";

		   }
		   $calendar[$ropid] = $iscalendar?"true":"false";
		   $calendartypes[$ropid] = $calendartype == "_CALENDAR_RANGE_"?"true":"false";
		   
		 if($fchar == "#" || $fchar == "*" || $fchar == "-" ){ //if displayed
		   $opid = substr(trim($opid),1);
		   $actionFields[$opid] = $fchar; //keep the prefix for later use
			$dd=  '<button type="button" id="'.$opid.'_headerbtn" class="altBgColor2 ep-hover-scale headerbtn" style="width:auto; height:auto;color:#FFF" title="Sort" onclick="SpreadSheet.SortTable(\''.$tblid.'\',this.parentElement.parentElement,this)" data-order="0"><i class="fa fa-sort" aria-hidden="true" style=""></i></button>';
			if(is_string($drpd) && count(explode("|",$drpd)) == 2){ //swicher
				$dd .=  '<button type="button" id="'.$opid.'_headerbtn2" class="altBgColor2 ep-hover-scale headerbtn2" style="width:auto; height:auto; color:#FFF" title="Turn All On" onclick="SpreadSheet.SwitchAll(\''.$tblid.'\',this)" data-toggle="1"><i id="'.$opid.'_headerbtn2_i" class="fa fa-toggle-on" aria-hidden="true" style=""></i></button>';
			}
			$ishidden = ($fchar == "-")?"true":"false";
		   $disheader[$opid] = '<div id="'.$opid.'_inner" data-dropdown="'.$encrdrpd.'" data-cellheader="'.$textdis.'" data-editable="'.$editable[$opid].'" data-multi="'.$multisel.'" data-calendar="'.$calendar[$opid].'" data-calender-range="'.$calendartypes[$ropid].'" data-rowdelete="'.$rowdelete.'" data-ishidden="'.$ishidden.'" data-disable="'.$disabled[$opid].'" data-class="'.$genclass.'" data-column = "'.($displayedindex + 1).'" class="headerinner" >'.$textdis.$dd.'<input type="hidden" id="h_'.$opid.'" value="'.$tblid.'_rw_1_'.($colind+1).'" />'.'</div>';
		   
		   //if field is to be hidden
		   if($fchar == "-"){
			$disheader[$opid] = array($disheader[$opid],"display:none"); 
		   }
		  // $disheader[$opid] = $txt.'<input type="hidden" id="h_'.$opid.'" value="'.$colind.'" /><input type="hidden" id="u_'.$tblid.'_rw_1_'.($colind+1).'" value="'.$opid.'" />';
		   $headersec[$opid."."] = '<span style="" class="ssheaderdwn_'.$tblid.'" >'.$textdis.'</span>';

		   //if field is to be hidden
		   if($fchar == "-"){
			$headersec[$opid."."] = array($headersec[$opid."."],"display:none"); 
		   }
		   $seld = ",selected=1";
		   $headerinfoarr[$opid] = array("dropdown"=>$drpd,"cellheader"=>$textdis,"editable"=>$editable[$opid],"index"=>$displayedindex,"multi"=>$multisel,"iscalendar"=>$iscalendar);
		   //add columnnum of each column to sprshtdatastring
          $displayCols .= $opid . "=" . ($displayedindex + 1). "&";
		   //echo $opid ." => ";print_r($headerinfoarr[$opid]); echo "<br />";
		   $displayedindex++;
		   //$headerinfoarr[$opid] 
		 }else{ //if no prefix that is, hidden at default
			$actionFields[$opid] = "";
		 }
		 if($fchar != "*" && $fchar != "-"){ //if it is not a fixed column, add to column popup
		 $datacolumn = $fchar == "#"?$displayedindex:0; //if displayed set its column number in the popup list item
		$popuphe .= __TRecord(array($opid=>'<div id="'.$opid.'_innerpop" data-dropdown="'.$encrdrpd.'" data-cellheader="'.$textdis.'" data-editable="'.$editable[$opid].'" data-multi="'.$multisel.'" data-rowdelete="'.$rowdelete.'" data-disable="'.$disabled[$opid].'" data-calendar="'.$calendar[$opid].'" data-calender-range="'.$calendartypes[$ropid].'" data-column = "'.$datacolumn.'">'.$textdis.'</div>'),"id={$opid}".$seld.",userid=true"); 
		 }
		$colind++; 
	 }
	 $displayCols = rtrim($displayCols,"&");
	 $popup .= $popuphe;
	 $popup .= ___Table();
	$popup .= __PopUp();

	$alowclear = PopValue("allowclear",$attrval);
	
	
	//$headersec = $header;
	///$header2 = $headers;
	//$headersec = $disheader;
	
	array_unshift($disheader,"<div id=\"removeRw_{$tblid}\" style=\"width:auto; height:auto;\" title=\"Clear All\" class=\"altColor ep-hover-scale\" onclick=\"_('$tblid').ClearSpreadSheet('$alowclear')\">"._Icon("square-o")."</div>");
	
	array_unshift($headersec,"<div id=\"shownm_{$tblid}\" style=\"width:auto; height:auto;\" data-status=\"0\" title=\"Load Sheet\" class=\"altColor2 ep-hover-scale\" onclick=\"\">"._Icon("upload")."</div>");
	$dynamicColumn = PopValue("dynamiccolumn",$attrval);
	$popcolfunc = $dynamicColumn == "" || $dynamicColumn == "true"?"_('{$tblid}_avFields').PopIn()":"MessageBox.Show('Column Insertion NOT ALLOWED')";
	array_push($disheader,"$popup <div id=\"addCln_{$tblid}\" class=\"altColor2 ep-hover-scale\" style=\"width:auto; height:auto;\" title=\"Add/Remove Field\" onclick=\"$popcolfunc\">"._Icon("columns")."</div>");
	$dynamicRow = PopValue("dynamicrow",$attrval);
	$poprowfunc = $dynamicRow == "" || $dynamicRow == "true"?"SpreadSheet.AddRow(_('$tblid'))":"MessageBox.Show('Row Insertion NOT ALLOWED')";
	array_push($headersec,"<div style=\"position:absolute;width:30px;height:auto;border:solid thin #CCC;background-color:#FFF;margin-top:-10px;padding:3px;opacity:0;visibility:hidden\" contenteditable=\"true\" id=\"addMultiRw_{$tblid}\">1</div><div id=\"addRw_{$tblid}\" style=\"width:auto; height:auto;\" title=\"Add Row\" class=\"altColor2 ep-hover-scale\" onclick=\"$poprowfunc\" ondblclick=\"_('addMultiRw_{$tblid}').FadeIn()\">"._Icon("indent")."</div>");
	
	
	$onselect = GetValue("onselect",$attrval);
	if($onselect != ""){
		$attrval = RemoveAtrr("onselect",$attrval);
	}else{
		$onselect = "SpreadSheet.CellFocus()";
	}

	$onchange = PopValue("onchange",$attrval); //for popup cells only
	if(trim($onchange) != ""){ //if onchange set
	   //use only the function name, cause user parameter not allowed, when called the current cell will be sent
	   $onchange = explode("(",$onchange);
	   $onchange = $onchange[0];
	}

	$onswitchchange = PopValue("onswitchchange",$attrval); //for popup cells only
	if(trim($onswitchchange) != ""){ //if onchange set
	   //use only the function name, cause user parameter not allowed, when called the current cell will be sent
	   $onswitchchange = explode("(",$onswitchchange);
	   $onswitchchange = ";".$onswitchchange[0];
	}
	
	
	$dependablesDataStr = EscapeString(DataStringE($dependables));
	//print_r($dependablesDataStr);
//	echo $dependablesDataStr;
	//echo DataStringE($dependables) ;
	//echo print_r($editable);
	$minrow = PopValue("minrow",$attrval);
	$minrow = trim($minrow) == ""?25:(int)$minrow; //minimum number of rows
	$dumprowcount = count($dump); //total datarow
	$dumprowcount = $dumprowcount > $minrow?$dumprowcount:$minrow; //use the highest (datarow and minrow) to acommodate all data
	$dumprowcount = $dumprowcount < 1?25:$dumprowcount; //if total row is less than 1 i.e minrow is for only empty spreadsheet(minrow = -1) use 25(default)
	//echo $displayCols;

	//echo $_SERVER['DOCUMENT_ROOT'];
	$case = PopValue("case",$attrval);
	$case = $case == ""?"uppercase":$case;
   Table($attrval.",onselect=$onselect,data-dependables=".$dependablesDataStr.",data-maxdatarow=".count($dump).",data-maxdiscolumn=".$displayedindex.",data-onchange=".$onchange.",data-displaycolumn=".EscapeString($displayCols).",data-case=".$case.",data-rowdelete=".$rowdelete.",data-allowclear=".$alowclear.",data-dynamicrow=$dynamicRow");
   $spshDataString = "SheetID=".rawurldecode($tblid)."&MaxDataRow=".rawurldecode(count($dump));
		        THeader($disheader,"userid=true");
				$rwcounter = 0;
				$cnterStart = PopValue("rownumstart",$attrval);
				$cnterStart = trim($cnterStart) == ""?0:(int)$cnterStart - 1;
				$useridseen = false;
				$rword = PopValue("moverow",$attrval); //get if row reorder is set
				if(trim($rword) == "")$rword = PopValue("rowmove",$attrval);
		        for($s=1;$s<=$dumprowcount;$s++){
					//banner class and text
					$isbanner = "";
					$bannerText = "";
					//$recarr = array($s);
					$cnt = 0;
					$colcounter = 0;
					foreach($disheader as $b=>$h){
						$action = "";
						if($cnt==0){
							//$cnt = count($headersec);
							$nRwCnt = $rwcounter + 2;
							$recarr[$b] = "<div style=\"position:relative\"><div class=\"clearcell greyShadow altColor2\" title=\"Add Banner\" onclick=\"SpreadSheet.ToggleBanner($nRwCnt,'$tblid','$alowclear')\">"._Icon('tags')."</div><div class=\"deletecell greyShadow altColor\" title=\"Delete Row\" onclick=\"SpreadSheet.DeleteRow($nRwCnt,'$tblid')\">"._Icon('trash')."</div><div style=\"padding:0px\" id=\"{$tblid}_rw_{$nRwCnt}_0_sn\">".($cnterStart+$s)."</div></div>";
							$cnt++;
							continue;
						}else if($cnt == count($disheader) - 1){
							//$logo = isset($dump[$rwcounter]["error"])?$dump[$rwcounter]["error"]:" ";
							$logo = "&nbsp;";
							if(isset($dump[$rwcounter]["logo"])){
								$logo = $dump[$rwcounter]["logo"];
								$err = substr($logo,0,1);
								$errcol = "";
								if($err == "#"){//error color
                				 $errcol = "altColor";
								 	$logo = substr($logo,1);
								}else if($err == "*"){
                					$errcol = "altColor2";
								$logo = substr($logo,1);
								}
								$actionicon = isset($dump[$rwcounter]["Action"])?$dump[$rwcounter]["Action"]:"";
								$logo = _Icon($logo." ".$errcol." ep-hover-scale","",$actionicon);
								// $logo = _Icon($logo." ".$errcol." ep-hover-scale","","");
								// $action = "onclick=".$actionicon;
							}
							$info = isset($dump[$rwcounter]["info"])?$dump[$rwcounter]["info"]:"";
							//$action = isset($dump[$rwcounter]["Action"])?'onclick="'.$dump[$rwcounter]["Action"].'"':"";
							
							
							$rwmvctr = trim($rword) == "true"?"<div style=\"position:relative;float: right;right: -20px\"><div class=\"clearcell greyShadow altColor2\" title=\"Move Up\" onclick=\"SpreadSheet.MoveRow(this.parentElement.parentElement.parentElement.parentElement,-1)\">"._Icon('chevron-up')."</div><div class=\"deletecell greyShadow altColor2\" title=\"Move Down\" onclick=\"SpreadSheet.MoveRow(this.parentElement.parentElement.parentElement.parentElement,1)\">"._Icon('chevron-down')."</div></div><div style=\"clear:right\"></div>":"";
							$recarr[$b] = "<div style=\"padding:0px\" title=\"$info\" class=\"\" $action >".$logo.$rwmvctr."</div>";
							$cnt++;
							continue;
						}
						$celldata = isset($dump[$rwcounter][$colcounter])?$dump[$rwcounter][$colcounter]:"";
						if($colcounter == 0){ //if first col get all the row details
							if(isset($dump[$rwcounter]["ID"])){ //if user define id set
								$rwid = $dump[$rwcounter]["ID"];
								$useridseen = true;
							}else{//if user defined id not set
								//check if atleast one user id already set
								$rwid = $useridseen?"":$rwcounter;
							}
							//$rwid = isset($dump[$rwcounter]["ID"])?$dump[$rwcounter]["ID"]:$rwcounter; //set the user define id
							$rwro = isset($dump[$rwcounter]["readonly"])?$dump[$rwcounter]["readonly"]:"false"; //set the readonly field
							$rwdi = isset($dump[$rwcounter]["disable"])?$dump[$rwcounter]["disable"]:"false"; //set the disable field
							$rwbanner = isset($dump[$rwcounter]["banner"])?$dump[$rwcounter]["banner"]:"#";
							if($rwbanner != "#"){
								$isbanner = "isbanner";
					            $bannerText = $rwbanner;
							}
							
							//determine if rw is a banner (# - not banner)
							$spshDataString .= "&".($rwcounter + 1)."_ID"."=".rawurlencode($rwid)."&".($rwcounter + 1)."_readonly"."=".rawurlencode($rwro)."&".($rwcounter + 1)."_disable"."=".rawurlencode($rwdi)."&".($rwcounter + 1)."_deleted"."=false"."&".($rwcounter + 1)."_position"."=".($rwcounter + 1)."&".($rwcounter + 1)."_banner"."=".rawurlencode($rwbanner);
							

						}
						$dataval = true; //indicate if drop down is a dataArray else a boolean
						$cellattrstr = "";
						$celldisabled = "";
						$cellreadonly = "";
						$cellstyle = "";
						$cellclass = isset($globalcolumnclass[$b])?$globalcolumnclass[$b]:"";
						if(is_array($celldata)){ //if attribute set for the cell
							$cellattrstr = $celldata[1];
							$celldisabled = PopValue('disabled',$cellattrstr);
							$cellreadonly = PopValue('readonly',$cellattrstr);
							$cellstyle = PopValue('style',$cellattrstr);
							$cellclass = PopValue('class',$cellattrstr);
							$celldata = $celldata[0];
						}
						$celldata .= "";
						if($celldata != ""){
							//add to spreadsheet datastring 
							$spshDataString .= "&".($rwcounter + 1)."_".($colcounter + 1)."=".rawurlencode($celldata);
						}else{
							//$celldata = " ";
						}
						$celldataVal = $celldata;
						$headerinfo = $headerinfoarr[$b];
						//if($)
						//$recarr[$b] = "";
						$drpdwn = $headerinfo['dropdown'];
						if($celldata != ""){
							
							if($drpdwn != ""){
								$charind = substr($drpdwn,0,1);
								if($charind == "#" || $charind == "@"){ //if query string set
								 $drpdwn = substr($drpdwn,1);
                                  $params = GetQueryParamColumnID(rawurldecode($drpdwn));
								 // echo count($params);
								 //print_r($params);
								  if(count($params) > 0){
									  //$replacearr = array();
									   //echo $drpdwn . "<br />";
                                     foreach($params as $columnID){
										 //get the coloum cell dumb value
                                         //get column index 
										//isset()
										 $ind = $headerinfoarr[$columnID]['index'];
										// echo $columnID."=".$ind." ; ";
										 $dumpvalue = isset($dump[$rwcounter][$ind])?$dump[$rwcounter][$ind]:"";
										 //echo $dumpvalue;
										 if($dumpvalue !== ""){ //if required value found
										 $str = "?".$columnID."?";
										 //echo $str;
                                           $drpdwn = str_replace($str,$dumpvalue,$drpdwn); //subtitute the value in query 
										 }
										//str_re
										 //echo $dumpvalue;
									 }
								  }
                                  
								  if($charind == "@"){ //if script type
									//echo $dump[$rwcounter][$headerinfoarr[$params[0]]['index']];
									//the elements folder
									$qarr = explode(" ",trim($drpdwn));
									
								  if(count($qarr) >= 2){
									
									   $scr = $qarr[0];$qarr[0] = "";
									$func = $qarr[1];$qarr[1] = "";
									
									if(file_exists(__DIR__."/../../../".$scr)){
										
									 $datastr = $qarr > 1?trim(implode(" ",$qarr)):"";
			 
									 $dataarr = $dbo->DataArray($datastr); //
									 //include script
									 				 
									 require_once __DIR__."/../../../".$scr;
									 //exit("kkk");
									 if(function_exists($func)){
										
									 $knw = call_user_func($func,$dataarr);
									 	
									 if($knw !== FALSE){
										
										 if($knw != ""){
											//echo "ddd";
											 $fchar = substr($knw,0,1); //reset fchar in case new str formed
											if($fchar =="#"){ //if query string returned
												$charind = "#";
												$drpdwn = substr($knw,1);
											}else{ //if data string returned
												$drpdwnarr = $dbo->DataArray($knw);
											}
											//echo $knw;
										 }
										 
									 }
									 
									 }
									 
									 
									}
								  }
								   
								  }

								 // echo $drpdwn."<br />";
								 if($charind == "#"){
									 global $dbo; //Run the Query 
								  $rstqr = $dbo->RunQuery($drpdwn);

								  $drpdwnarr = array(); //hold the popup list itemes in array 
                                  if(is_array($rstqr)){
									  //echo $rstqr[1];
									  if($rstqr[1] > 0){
										  //full the popuplist itemes array 
										  while($qrst = $rstqr[0]->fetch_array()){
											  $drpdwnarr[$qrst[0]] = $qrst[1]; 
										  }
									  }
								  }
								 }
								 
								  
								  
								}else{ //datastring set
								$drpdwnarr = DataArrayE($drpdwn);
								if(count($drpdwnarr) < 1){
									$swodispArr = explode("|",$drpdwn);
									if(count($swodispArr) == 2){ //boolean field
                   $dataval = false;
									}
								}
								//$celldataVal = $celldata;
									//$dataval = true;
								}
								if($dataval){
									//check if multiple selection
									$celldataVal = trim($celldataVal);
                                   if(substr($celldataVal,0,1) == ":" && substr($celldataVal,strlen($celldataVal) - 1,1) == ":"){
									$celldataValarr = explode("::",trim($celldataVal,":"));
									$celldata = [];
									foreach($celldataValarr as $celldataValm){
										if(isset($drpdwnarr[$celldataValm])){
											$celldata[] = rawurldecode($drpdwnarr[$celldataValm]);
										}
									}
									if(count($celldata) == 0){
										$celldataVal = "";$celldata="";
									}
								   }else{
									//check if dumpvalue exist in list
								    if(isset($drpdwnarr[$celldataVal])){
										$celldata = rawurldecode($drpdwnarr[$celldataVal]);
									}else{
										$celldataVal = "";$celldata="";
									}
								   }
								
								   $celldata = is_array($celldata)?implode(",",$celldata):$celldata;
									
								}else{ //boolean value
								  $swcont = $colcounter + 1;
								  //$rwdi
								  if((trim($celldisabled) == "" || $celldisabled == "false") && $rwdi == "true")$celldisabled = "true";
								  
																	 $celldata =  _Switcher("id=???_sw,state=$celldataVal,style=width:auto;margin:2px,ontext=".$swodispArr[0].",offtext=".$swodispArr[1].",onchange=SpreadSheet.SwicthChange$onswitchchange,disabled=$celldisabled,class=$cellclass, data-value=$celldataVal,data-column=$swcont");
																	 //$spshDataString .= "&".($rwcounter + 2)."_".($colcounter + 1)."=0";
								  // $celldata =  "aaa";
								}
								
							}
							
						}else{ //if nocell value send
                            //check if a boolean field 
							$drpdwnarr = DataArrayE($drpdwn);
								if(count($drpdwnarr) < 1){
									$swodispArr = explode("|",$drpdwn);
									if(count($swodispArr) == 2){ //boolean field
									$dataval = false;
									  $swcont = $colcounter + 1;
									  if(($celldisabled == "" || $celldisabled == "false") && $rwdi == "true")$celldisabled = "true";
                                   $celldata =  _Switcher("id=???_sw,state=0,style=width:auto;margin:2px,ontext=".$swodispArr[0].",offtext=".$swodispArr[1].",onchange=SpreadSheet.SwicthChange$onswitchchange,disabled=$celldisabled,class=$cellclass, data-value=0,data-column=$swcont");
									}
								}
						}
						
						$rwdisable = isset($dump[$rwcounter]["readonly"])?$dump[$rwcounter]["readonly"]:"";
						$rwdisablereal = isset($dump[$rwcounter]["disable"])?$dump[$rwcounter]["disable"]:""; //if disabled
						//$editable[$b] = $editable[$b] == "false" || $rwdisable == "true"?"false":"true";
						//$bgco = $editable[$b] == "false" || $rwdisable == "true"?";background-color:#F1F1F1":"";
                        $bgco = "";
						if($editable[$b] == "false" || $rwdisable == "true" || $rwdisablereal == "true"  || $disabled[$b] == "true" || trim($cellreadonly) == "true" || trim($celldisabled) == "true"){
							if($rwdisablereal == "true" || $disabled[$b] == "true" || trim($celldisabled) == "true" ){ //if disabled
							$bgco = ";color:#777";
							}
							$editabel = "false";
						}else{
							
							$editabel = "true";
						}

						//set the calender class
$calendarCl = ""; $caltype = "";
if($calendar[$b] == "true"){
	$calendarCl = "Calendar";
$caltype = $calendartypes[$b];

}
        //echo $b . " = ".$calendarCl." ";
						//html
						//echo $celldata;
						//print_r($trimtxt);
						$atribtdataval = str_replace($trimtxt,"",$celldataVal);
						
						//$celldisabled
						$cont = $dataval?'<div style="width:calc(100% - 8px);text-transform:'.$case.'; padding:4px;min-height:1em'.$bgco.';" contenteditable="'.$editabel .'"  id="???_edit" onkeyup="SpreadSheet.KeyPress(this,event);'.$cellkeypress.'" onfocus="this.spellcheck = true;SpreadSheet.CellSelect(this);'.$cellfocus.'" onblur= "this.spellcheck = false;SpreadSheet.CellUuSelect(this);'.$cellblur.'" class="'.$calendarCl.' '.$cellclass.'" data-range="'.$caltype.'" data-value="'.$atribtdataval.'" data-column="'.($colcounter + 1).'">'.$celldata.'</div>':$celldata;
						//check if hidden
						$sty=($actionFields[$b] == "-")?"display:none;":"";
					   $recarr[$b] = array($cont,$sty."padding:0px".$bgco.';'.$cellstyle);
					   	$cnt++;
						   $colcounter++;
					}
					$sel = "";
					/*if($s == 1 || $s == 2){
						$sel = ",selected=2";
					}*/
					//contenteditable=true,onkeypress=SpreadSheet.KeyPress(this\,event)
					
					TRecord($recarr,"cellheader=1:".count($disheader).",userid=true,class=$isbanner,title=$bannerText","style=padding:0px");
					$rwcounter++;
					$editabel = "true";
				}
				THeader($headersec,"id=lstrw,userid=true,rowid={$tblid}_lstrw");
				echo '<input type="hidden" id="'.$tblid.'_cellfocus" value="'.$cellfocus.'" />'; //will be used by spreadsheet javascript object to determin the cellfocus and blur function
				echo '<input type="hidden" id="'.$tblid.'_cellblur" value="'.$cellblur.'" />';
				echo '<input type="hidden" id="'.$tblid.'_cellkeypress" value="'.$cellkeypress.'" />';
				echo '<input type="hidden" id="'.$tblid.'_datastring" value="'.$spshDataString.'" />';
		   _Table();
		   
}

function _PopUp($atrrVal = ""){
	
	$tit = GetValue("title",$atrrVal);
	   if(trim($tit) != ""){
		    $atrrVal =RemoveAtrr("title",$atrrVal);
	   }
	   
	   $id = GetValue("id",$atrrVal);
	   if(trim($id) == ""){
		    $id = "popup".date("Ymdhis");
			$atrrVal = "id=".$id.",".$atrrVal;
	   }
	   
	   $atrrVal = ProcessAtrrVal("class=popup,".$atrrVal);
	  // $ss = $atrrVal;
	$tm = _Icon("times");
$str=<<<sss
<div $atrrVal >
   <div class="inner">
      <div class="tit"> $tit </div> 
      <div class="cls" onclick="_('$id').PopOut()"> $tm </div>  
	  <div style="clear:both"></div>
	  <div class="cont">
sss;
return $str;
}

function __PopUp(){
	return " </div>
	</div>
</div>";
}

function Info($title,$info,$logo = "info-circle", $colorClass = "altColor2"){
  Box("class=defaultTabText");
          Box();Icon("$logo fa-3x $colorClass");_Box();
          Box();echo $title;_Box();  
          Box();echo $info;_Box();  
        _Box(); 
}

function SubHeader($txt){
	$txt = str_replace(",","\,",str_replace("=","\=",$txt));
	Text("text=$txt,style=display:block;font-weight:bold;color:#777;margin-top:12px;font-size:0.7em");
}
function _NL(){
	return "<br />";
}
function NL(){
	echo _NL();
}

function EscapeString($str){
	return str_replace(array(",","="),array("\,","\="),$str);
}

if(!function_exists("SearchBox")){
//generic search box
function SearchBox($atrrVal){
 StudentSearchBox($atrrVal);
}
}

//function student search
function StudentSearchBox($atrrVal){
	//$atrrVal .= ",style=width:290px;height:400px";
	$logo = PopValue("logo",$atrrVal);
	$grpbx = PopValue("groupbox",$atrrVal);
	$grpbx = $grpbx == ""?"true":$grpbx;
	$id = GetValue("id",$atrrVal);
	   if(trim($id) == ""){
		    $id = "ssb".date("Ymdhis");
			$atrrVal = "id=".$id.",".$atrrVal;
	   }
	$title = GetValue("title",$atrrVal);
	$style = GetValue("style",$atrrVal);
	$onselect = GetValue("onselect",$atrrVal);//onunselect
	$onunselect = GetValue("onunselect",$atrrVal);
	//$scopearr = array("student"=>"","candidate"=>"p","all"=>"a");
	$param = GetValue("param",$atrrVal);
	//$para = trim($scope) == ""?"student":$scope;
	//$pre = $scopearr[$scope];
	StartJavaScript("obj_{$id} = new SSB('{$id}');");
	$script = trim(PopValue("script",$atrrVal));
	$script = $script == ""?$_POST['CORE']."cportal/Pages/Scripts/Gen/searchbox.php":$script;
	$tbdescr = trim(PopValue("info",$atrrVal));
	$tbdescr = $tbdescr == ""?"Search Student by Name or Registration Number":$tbdescr;
	$dom = trim(PopValue("domain",$atrrVal));
	$dom = $dom == ""?"studentinfo_tb":$dom;
	$crit = trim(PopValue("criteria",$atrrVal));
	//$crit = $crit == ""?"RegNo:Reg.No;JambNo;CONCAT(SurName,' ',FirstName,' ',OtherNames):Name":$crit;
	$img = trim(PopValue("img",$atrrVal));
	$img = $img == ""?"Passport":$img;
	$dir = trim(PopValue("dir",$atrrVal));
	$dir = $dir == ""?"":$dir;
	$ext = trim(PopValue("ext",$atrrVal));
	$TNText = trim(PopValue("thumbnailtext",$atrrVal));
	$TNTitle = trim(PopValue("thumbnailtitle",$atrrVal));
	$UserAction = trim(PopValue("action",$atrrVal));
	$UserActionLogo = trim(PopValue("actionlogo",$atrrVal));
	$UserTitle = trim(PopValue("actiontitle",$atrrVal));
	$sticky = PopValue("sticky",$atrrVal);
	//$criter = PopValue("creteria",$atrrVal);
	//$criter = trim($criter) == ""?""
	if($grpbx == "true")GroupBox("title=$title,id={$id}grp,style={$style},size=1,logo={$logo},sticky=$sticky");
	     Hidden($id."onselect",$onselect);Hidden($id."onunselect",$onunselect);Hidden($id."param",$param);Hidden($id."_engineScript",$script);Hidden($id."domain",$dom);Hidden($id."criteria",$crit);Hidden($id."img",$img);Hidden($id."dir",$dir);Hidden($id."ext",$ext);Hidden($id."thumbnailtext",$TNText);Hidden($id."thumbnailtitle",$TNTitle);
         /* TextBox("title=Search Criterial,style=width:270px,logo=filter,onchange=obj_{$id}.Search,id={$id}searchCriterial"
	   ,array(
	   "regsc"=>"Registration Number",
	   "namesc"=>"Name",
	   "imgsc"=>"Registration Number (Passport)"));*/
	   $tbdescr = EscapeString($tbdescr);
TextBoxGroup();
	   TextBox("title=Search,style=width:250px,id={$id}searchtxt,textchange=obj_{$id}.Search,logo=search,info=$tbdescr");
	   TextBoxGroupItem();
	   Box("style=margin-top:5px;margin-left:10px");
		 $tbltxt = _Icon('table');
		 Radio("group={$id}distype,id={$id}_crtlb,checked=true,text=List,style=margin-right:10px,check=obj_{$id}.RadioChange");Radio("group={$id}distype,id={$id}_crimgl,checked=false,text=Thumbnail,check=obj_{$id}.RadioChange");
	   _Box();
	   _TextBoxGroupItem();
	_TextBoxGroup();
	   Box("id={$id}searchloadbx,style=opacity:0;visibility:hidden;height:200px;overflow:auto; margin-top:10px;position:absolute;z-index:1;background: center no-repeat;width:270px;text-align:center");
	  // echo "ss";
	    Box("style=margin-top:100px; display:block; width:100%; height:30px; margin-top:120px;color:#666");
	      Icon("sync fa-spin","");
		 _Box();
	   _Box();
	    Box("id={$id}moreloading,style=opacity:0;visibility:hidden;height:20px;overflow:auto; margin-top:260px;position:absolute;z-index:2;background: center no-repeat rgba(225\,225\,225\,.9);width:278px;text-align:center;font-size:0.8em");
	      Icon("cog fa-spin","");echo " Loading More";
	   _Box();
	   Box("id={$id}searchrst,class=SSBcont,style=opacity:0,onscroll=obj_{$id}.SearchBoxSrolled()");
		  
	    _Box();
		Box("id={$id}totsearch,style=margin-left:10px;margin-top:5px;font-weight:bold;color:rgba(0\,0\,0\,.2);font-size:1.3em;float:left");
		    echo "Empty Set";
		_Box();
		Box("id={$id}refreshsearch, title=Reload,class=SSBbuttons altBgColor2 card-1, onclick=obj_{$id}.ReSearch(),style=border-radius:0px 3px 3px 0px;margin:5px 0px");
		    //echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
			echo '<i class="fa fa-sync " aria-hidden="true" style="margin-top:5px; font-size:1.3em"></i>';
		_Box();
		Box("id={$id}deselectsearch, title=Clear Selection,class=SSBbuttons altBgColor2 card-1, onclick=obj_{$id}.ClearSelect(),style=border-radius:3px 0px 0px 3px;margin:5px 0px");
		    //echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
			echo '<i class="fa fa-eraser " aria-hidden="true" style=" margin-top:5px; font-size:1.3em"></i>';
		_Box();
		if($UserAction != ""){
			$UserTitle = $UserTitle == ""?"":$UserTitle;
			Box("id={$id}_action,title=$UserTitle,style=border-radius:3px;margin:5px 5px 0px 0px,class=SSBbuttons  greenGradient card-1, onclick={$UserAction}");
				//echo '<img src="TaquaLB/Elements/Images/reload.png" width="30" height="30" alt="Reload" onclick="Student.BioData.Search()" />';
				$UserActionLogo = $UserActionLogo == ""?"cog":$UserActionLogo;
			echo '<i class="fa fa-'.$UserActionLogo.'" aria-hidden="true" style=" margin-top:5px; font-size:1.3em"></i>';
		_Box();
		}
		ClearFloat();  
		if($grpbx == "true") _GroupBox();
}

function _Hidden($id,$val = ""){
	return '<input type="hidden" id="'.$id.'" value="'.$val.'" />';
}
if(!function_exists("Hidden")){
function Hidden($id,$val = ""){
  echo _Hidden($id,$val);
}
}

//thumbnail object 
$curthumbNGroup = "";
$curthumbSelFunc = "";
$curthumbUnSelFunc = "";
function __ThumbNailBox($atrrVal = ""){
	global $curthumbNGroup;
	global $curthumbSelFunc;
	global $curthumbUnSelFunc;
	$id = GetValue("id",$atrrVal);
	if(trim($id) == ""){
		$id = "thumbn_".time();
		$atrrVal = "id=".$id.",".$atrrVal;
	}
	$curthumbSelFunc = trim(PopValue("onselect",$atrrVal));
	$curthumbUnSelFunc = trim(PopValue("onunselect",$atrrVal));
	$curthumbNGroup = $id;
   $atrrValStr = ProcessAtrrVal("class=ThumbNailBox,".$atrrVal);
   return '<div '.$atrrValStr.'>';
}

function ___ThumbNailBox(){
	global $curthumbNGroup;
	global $curthumbSelFunc;
	global $curthumbUnSelFunc;
   $curthumbNGroup = "";
   $curthumbSelFunc = "";
   $curthumbUnSelFunc = "";
   return '</div>';
}

function ThumbNailBox($atrrVal = ""){
	echo __ThumbNailBox($atrrVal);
}

function _ThumbNailBox(){
	echo ___ThumbNailBox();
}

function _ThumbNail($atrrVal = ""){
	global $curthumbSelFunc;
	global $curthumbUnSelFunc;
	global $curthumbNGroup;
	$passp = trim(PopValue("src",$atrrVal));
	$mainfolder = trim(PopValue("dir",$atrrVal));
	$title = PopValue("title",$atrrVal);
	$txt = PopValue("text",$atrrVal);
	$base = PopValue("base",$atrrVal);
	$mainfolder = $mainfolder == ""?"cportal/":$mainfolder;
	$path = "";
	$defaultpth = $base == ""?"../../../../":$base;
	if($passp == ""){
		$passp = $_POST['CORE']."general/TaquaLB/Elements/Images/imglogosm.jpg";
		list($w,$h) = array(65,43);
	}else{
       /* $sartstr = substr($passp,0,3);
	   if($sartstr == "../"){ //out of main folder
         $passptest = $defaultpth.ltrim($passp,"../");
	   }else{
		   $passptest = $defaultpth.$mainfolder.$passp;
		   
	   } */
	   $passptest = $defaultpth.$passp;
	   if(file_exists($passptest)){
         list($width, $height, $type, $attr) = getimagesize($passptest);
	// list($width, $height, $type, $attr) = getimagesize("../../../../epconfig/UserImages/Student/777777777AD.jpg");
          list($w,$h,$o) = AutoFit(75,80,$width,$height,10);
	   }else{
		$passp = $_POST['CORE']."general/TaquaLB/Elements/Images/imglogosm.jpg";
		list($w,$h) = array(65,43);
	  }
	}
	$onselect = $curthumbSelFunc != ""?$curthumbSelFunc:"null";
	$onunselect = $curthumbUnSelFunc != ""?$curthumbUnSelFunc:"null";
	//$atrrVal = ProcessAtrrVal($atrrVal);
	$str = __Box("class=ThumbNail class_$curthumbNGroup,title=$title,onclick=ThumbNail.Select(this\,{$onselect}\,{$onunselect}),data-group=$curthumbNGroup,".$atrrVal);
	$str .= __Box("class=ImgBox");
	$str .= '<img src="'.$passp.'?'.rand().'" style="width:'.$w.'px;height:'.$h.'px " alt="'.$title.'" /> ';
	$str .= ___Box();
	$str .= __Box("class=TextBox");
		$str .= $txt;
	$str .= ___Box();
	$str .= ___Box();
	return $str;
}

function ThumbNail($atrrVal = ""){
	echo _ThumbNail($atrrVal);
}

//function to upload file 
function Upload($filename,$destination){
	if($_FILES[$filename]){ //get passport
    $fileTmpLoc = $_FILES[$filename]["tmp_name"];
    if($fileTmpLoc){
        if(!move_uploaded_file($fileTmpLoc, $destination)){ //upload file
            return false;
        }else{
          return true;
        }
    }
}
return false;
}

function PrintDropDown($id,$dropitems,$title,$numeric = false){
	$cnt = 0;
	
	$html = "";
	$max = count($dropitems) > 6?6:count($dropitems);
	$maxh = $max * 41;
	$maxh = $maxh == 41?0:$maxh; //if only one dont display dropdown
	if($max > 0){
		$drpdwn = $maxh > 0?_Icon("chevron-down"):"<span>pt</span>"; //if no dropdown dont
		//display down arrow
		$readonly = $maxh > 0?'readonly="readonly"':""; //if no dropdown dont
		$onblur = $numeric ? 'onblur=PDFPrinter.Display.ConvertToNumber(this)':'';
		foreach($dropitems as $key=>$item){
			$cnt++;
			$logotxt = explode("~",$item);
			$logo = _Icon($logotxt[0]);
			$txt = $logotxt[1];
			if($cnt == 1){ //if first
              $html .= '<div class="selectbox" title="'.$title.'">
        <div class="logo"  id="'.$id.'_logo" onclick="_(\''.$id.'_inp\').focus()"> '.$logo.' </div>
		<input class="content" '.$onblur.' '.$readonly.' id="'.$id.'_inp" value="'.$txt.'" />
		<div class="dropdown" onclick="_(\''.$id.'_inp\').focus()"> '.$drpdwn.' </div>
		<div style="clear:both"></div>
		<div class ="dropdowncont" style="max-height:'.$maxh.'px">
		   <div class="selectbox" onclick="PDFPrinter.Display.DropSelect(\''.$id.'\',\''.$key.'\',\''.$txt.'\',\''.$logotxt[0].'\')"  id="'.$id.'_drpdwn_'.$key.'">
			<div class="logo"> '.$logo.' </div>
			<div class="content"> '.$txt.' </div>
			<div style="clear:both"></div>
	       </div>
		<input type="hidden" id="'.$id.'_val" value="'.$key.'" />
		';
			}else{
			$html .= '<div class="selectbox" onclick="PDFPrinter.Display.DropSelect(\''.$id.'\',\''.$key.'\',\''.$txt.'\',\''.$logotxt[0].'\')" id="'.$id.'_drpdwn_'.$key.'">
			<div class="logo"> '.$logo.' </div>
			<div class="content"> '.$txt.' </div>

			<div style="clear:both"></div>
	       </div>';
			}
			
		}
        if($cnt > 0){
			$html .= '</div>
	  </div>';
		}
	}
	echo $html;
}
function SubTitle($title){
	echo '<div class="grptitle">'.$title.'</div>';
}
function ButtonPrint($id,$txt,$onclick="",$logo="",$title="",$stylee=""){
	$logo = _Icon($logo);
	$str = ""; $style='padding-right:0px;';
	if(trim($txt) != ""){
   $str = '<div class="txt">'.$txt.'</div>';
   $style = '';
	 }
	 $style .= $stylee;
	 if(trim($style) != "")$style = 'style="'.$style.'"';
  echo '<div title="'.$title.'" class="btnbox" '.$style.' id="'.$id.'" onclick="'.$onclick.'" >
   <div class="logo" id="'.$id.'_btnlogo">'.$logo.' </div>';
 echo $str;  

   echo '<div style="clear:both"></div>
   </div>';
}
function AddPrinterPreview(){
	$id = "taquaPdfPrinter";
$logo = _Icon("cogs");
$pappers = _Icon("file");
$drpdwn = _Icon("chevron-down");
$clspanel = _Icon("chevron-left");
$tm = _Icon("times");
$shwset = _Icon("cogs");
$loadin = _Icon("cog fa-spin");
echo '<div class="pdfprinter" id="'.$id.'" style="opacity:0;visibility:hidden">
    <div class="clsbtn" title="Close"  onclick="PDFPrinter.Display.Close()">'.$tm.'</div>
	<div class="shwbtn" title="Show Settings" onclick="_(\''.$id.'\').classList.remove(\'hidepnl\')">'.$shwset.'</div>
   <div class="panel" id="pdfprintpnl">
     <div class="cont">
      <div class="title"><span class="cls" title ="Hide"  onclick="_(\''.$id.'\').classList.add(\'hidepnl\')" >'.$clspanel.'</span><span>'.$logo.'</span> Print <span>PDF</span></div>
	  ';
SubTitle("Paper");
PrintDropDown("paperPrint",array("A4"=>"file-text~A4","Letter"=>"file-text~Letter","Legal"=>"file-text~Legal","A2"=>"file-text~A2","A3"=>"file-text~A3","Executive"=>"file-text~Executive"),"Paper Type");//Letter, Legal, Executive, Folio

//Demy, Royal
PrintDropDown("paperorien",array("P"=>"file fa-flip-horizontal~Portrait","L"=>"file fa-rotate-270~Landscape"),"Orientation");
SubTitle("Font Size");
PrintDropDown("fontsizee",array("11"=>"text-width~10"),"Font Size",true);
SubTitle("Margin");
PrintDropDown("marginL",array("window-maximize fa-fw fa-rotate-90~4"),"Margin Left",true);
PrintDropDown("marginT",array("window-maximize  fa-fw fa-flip-vertical~4"),"Margin Top",true);
PrintDropDown("marginR",array("window-maximize  fa-fw fa-rotate-270~4"),"Margin Right",true);
PrintDropDown("marginB",array("window-maximize  fa-fw~16"),"Margin Bottom",true);
echo "<input type=\"hidden\" id=\"PdfPrinterUrl\" value=\"\" />";
echo "<input type=\"hidden\" id=\"PdfPrinterData\" value=\"\" />";
//PdfPrinterData
//Hidden("PdfPrinterData","");
ButtonPrint("resetbss","","PDFPrinter.Reset()","history","Reset");
ButtonPrint("printrelod","","PDFPrinter.Preview()","sync","Reload");
ButtonPrint("dwnloadff","","PDFPrinter.Download()","download","Download");
//set the default
ButtonPrint("pdfprinttempbtn","??txt??","??action??","??logo??","??title??","display:none");
echo '<div id="pdfPrintActionBtn">';

echo '</div>';
//echo '<div class="footer"> EDUPORTA </div>';
echo ' </div> </div>';
//the iframe object container to load the printout
//../epconfig/TaquaLB/Elements/Script/pdfprintredirect.php 
//http://localhost.com/epdevelop/cportal/Reports/Exams/resultsheet.php?rstudstudy=5&rstudfac=1&rstuddept=3&rstudprog=3&rstudlvl=1&semest=1&sestb=1&rcourse=10
echo '<div class="docContainer" id="pdfprintdocCont">
<div class="loadingbx hide" id="pdfPrinterloading" ><div id="pdfprintloadintxt"></div></div>
  <iframe id="pdfPrintIframe" src=""  ></iframe>
  
</div>
<div style="clear:both"></div>
<iframe id="pdfPrintIframedl" src="" ></iframe>
';

echo '</div>';

}

function AddOptionBox(){
	//echo "hhh";
  echo '<div id="OptionBx" style="opacity:0;z-index:-1">
   <div id="OptionBxMain"  class="" style="opacity:1">
     <div id="OptionTitleCont">
	   <div><div id="OptionTitle" class="altColor2"></div> <div id="OptionClose"><i onclick="OptionBox.Close()" class="fa fa-times altColor"></i></div> <div style="clear:both"></div></div>';
	   Line();
	   echo '<div id="OptionTitleHTML"></div>
	 </div>
	 <div id="OptionBxBody" class="">
        
	 </div>
   </div><div id="OptionBxSampleObjects" style="display:none">';
TextBoxGroup();
TextBox('title={{title}},style=width:250px;{{style}},id={{id}},logo={{logo}},type={{type}}');
_TextBoxGroup();
  echo '</div>
 <div id="OptionBxSampleTextArea" style="display:none">';
TextBoxGroup();
TextBox('title={{title}},style=width:250px;{{style}},id={{id}},logo={{logo}},type=multiline');
_TextBoxGroup();
  echo '</div> 
  <div id="OptionBxSampleSwitch" style="display:none">';
TextBoxGroup();
Switcher("id={{id}},state=1,text={{title}},style=width:100%;font-size:1.1em,info={{info}},ontext=Visible,offtext=Disabled,align=right,showstate=false");
_TextBoxGroup();
  echo '</div>
  </div>';

}

//function to insert a line into the page 22-5-17 #1
function _Line($atrrVal = ""){
	$style = trim(PopValue("style",$atrrVal));
	return '<hr style="'.$style.'" class="GenLine" />';
}
if(!function_exists ("Line")){
	function Line($atrrVal = ""){
	echo _Line($atrrVal);
}
}


//function to insert a note into the page 22-5-17 #1
function __Note($atrrVal = "style=font-size:12px"){
	$atrrValStr = ProcessAtrrVal("class=gennote,".$atrrVal);
	global $TextBoxGroupOn; global $TextBoxGroupItemOn;
		  if($TextBoxGroupOn){

			  return $TextBoxGroupItemOn?'<div '.$atrrValStr.'>':'<tr class=""  ><td>'.'<div '.$atrrValStr.'>'; 
		  }
	return '<div '.$atrrValStr.'>';
}
function Note($atrrVal = "style=font-size:12px"){
	echo __Note($atrrVal);
}

function ___Note(){
	global $TextBoxGroupOn; global $TextBoxGroupItemOn;
		  if($TextBoxGroupOn){
			return $TextBoxGroupItemOn?'</div>':'</div>'.'</td></tr>';
		  }
	return '</div>';
}
function _Note(){
	echo ___Note();
}

//LogoButton
function _LogoButton($attrValStr = ""){
   $logo = PopValue("logo",$attrValStr);
   if(trim($logo) == "")$logo = "cog";
  // $style = PopValue("style",$attrValStr);
   $cls = PopValue("class",$attrValStr);
   $text = PopValue("text",$attrValStr);
   $attrValStr = ProcessAtrrVal($attrValStr);
   return '<button class="bbtn '.$cls.'" '.$attrValStr.' type="button"><i class="fa fa-'.$logo.'"></i> '.$text.'</button>';
}

function LogoButton($attrValStr = ""){
	echo _LogoButton($attrValStr);
}
if(!function_exists('UploadFile')){
	function UploadFile($tbname,$filename,$ext=""){
	if(trim($tbname) == "" || trim($filename) == "")return false;
	//$filename = strtolower($filename);
	//$gatewayname trim(str_replace($gatewayname," ","_");
	if(isset($_FILES[$tbname."_file"])){
			$fileTmpLoc = $_FILES[$tbname."_file"]["tmp_name"]; // File in the PHP tmp folder
			if ($fileTmpLoc) { // if file not chosen
					$uname = $_FILES[$tbname."_file"]["name"];
					$fext = pathinfo($uname,PATHINFO_EXTENSION);
					if(trim($ext) != "" && trim(strtolower($fext)) != trim(strtolower($ext)))return false;
					if(trim($ext) == "")$ext = $fext;
					$dir = pathinfo($filename,PATHINFO_DIRNAME);
					//return $dir;
					//$dir = "epconfig/Gateways/";
				 //$fn = "UserImages/Student/{$regfile}.jpg";
				 if(!is_dir($dir))mkdir($dir,0777,TRUE);
				 if(move_uploaded_file($fileTmpLoc, $filename.".".$ext)){
						 return $filename.".".$ext; //return filename from the root directory
				 } else {
						// echo "#Operation Aborted: Cannot Upload Payment Receipt";
						 //exit('{"Message":"#Operation Aborted: File Upload Failed"}');
						 return false;
				 }
			}else{
					return false;
				// echo "#Operation Aborted:Payment Receipt not Found";
						 //exit("#Operation Aborted:Payment Receipt not Found"); 
			}

 }
 return false;
}
}

function DefaultBox($attr=""){
	$logo = trim(PopValue("logo",$attr));
	$logo = $logo == ""?"info-circle":$logo;
	$text = PopValue("text",$attr);
	$lclass = PopValue("logoclass",$attr);
	$lclass = $lclass == ""?"altColor2":$lclass;
	$style = trim(PopValue("style",$attr));
  $style = "width:100%;".$style;
	Box($attr.",style=".$style);
   Box("class=defaultTabText");
   Box();Icon("$logo fa-3x $lclass");_Box();
   //Box();echo"MONITOR STUDENT REGISTRATION PROCESS";_Box();  
   Box();echo $text;_Box();  
 _Box();
 _Box(); 
}

function SheetDatabindCast($val,$dataType){
	if($dataType == "int")return (int)$val;
	if($dataType == "float")return (float)$val;
	return "'".$val."'";
}

function SheetDatabind($data,$tb,$fieldArray,$Req=[],$keyIndex=-1,$keyRelation="",$deletecond="1=1"){
	//$keyRelation=>table.field
	global $dbo;
	$gradesprsheet = is_array($data)?$data:$dbo->DataArray($data);
	$keyIndex = $keyIndex < 0?key($fieldArray):$keyIndex;
	//return $keyIndex.' Data row';
	$Req = count($Req) < 1?array_keys($fieldArray):$Req;
$gradesprsheet_query = "";

if(!isset($gradesprsheet['MaxDataRow']) || (int)$gradesprsheet['MaxDataRow'] < 1){
	//delete all record
	if(isset($gradesprsheet['SheetID']))$gradesprsheet_query = "DELETE FROM $tb WHERE $deletecond;";
}else{ //if data exist
 $keydbname = isset($fieldArray[$keyIndex])?$fieldArray[$keyIndex]:key($fieldArray);
 $keydbnamearr = explode(" ",trim($keydbname));
 $keydatatype = "int";
 if(count($keydbnamearr) > 1 && ($keydbnamearr[0] == "int" || $dbfiledarr[0] == "float" || $keydbnamearr[0] == "string")){
	$keydatatype = $keydbnamearr[0];
	array_shift($keydbnamearr);
	$keydbname = implode(" ",$keydbnamearr);
 }

 //make sure that the keyname does not contain default value
 $keydbnamebr = explode(" || ",$keydbname);
 $keydbname = $keydbnamebr[0];

 //loop through all data
 for($rw = 1; $rw <= (int)$gradesprsheet['MaxDataRow']; $rw++){
	
		 $keycell = $rw.'_'.$keyIndex;
		 
		 $allclear = true;
		 $anyclear = false;
						 //check if user clear the row
							foreach($Req as $ind){
								 if($ind == $keyIndex)continue; //keys are excluded
								 if(!isset($gradesprsheet[$rw.'_'.$ind]) || $gradesprsheet[$rw.'_'.$ind] == ""){
		 $anyclear = true;continue;
								 }else{
										$allclear = false;
								 }
		 
							}
		 //form data set part
	$setpart = "";
	
	foreach($fieldArray as $colind=>$dbfield){
if($colind == $keyIndex)continue; //dont update the id
$dbfiledarr = explode(" ",trim($dbfield));
$datatype = "string";
$defaultval = "''";
if(count($dbfiledarr) > 1 && ($dbfiledarr[0] == "int" || $dbfiledarr[0] == "float" || $dbfiledarr[0] == "string")){
	$datatype = $dbfiledarr[0];
	array_shift($dbfiledarr);
	$dbfield = implode(" ",$dbfiledarr);
	//$defaultval = $datatype == "string"?"":0;
}

//get the default
$dbfieldarrdef = explode(" || ", $dbfield);
$dbfield = $dbfieldarrdef[0];
array_shift($dbfieldarrdef);
	$defaultval = implode(" || ",$dbfieldarrdef);

//SheetDatabindCast($val,$dataType)
$defaultcond = (isset($gradesprsheet[$rw.'_'.$colind]) && trim($gradesprsheet[$rw.'_'.$colind]) != '') || (isset($gradesprsheet[$rw.'_'.$colind]) && trim($defaultval) == '');
	 $gradesprsheet[$rw.'_'.$colind] = $defaultcond?SheetDatabindCast($gradesprsheet[$rw.'_'.$colind],$datatype):$defaultval;
	 $gradesprsheet[$rw.'_'.$colind] = trim($gradesprsheet[$rw.'_'.$colind]) == ''?"''":$gradesprsheet[$rw.'_'.$colind];
	 $setpart .= "`$dbfield` = ".$gradesprsheet[$rw.'_'.$colind].",";
	}
	
	$setpart = rtrim($setpart,",");
	
		//check if the keyindex is set
		if(isset($gradesprsheet[$keycell]) && (int)$gradesprsheet[$keycell] > 0){ //if not new entering
			
		 $keydbval = $gradesprsheet[$keycell];
		 if($keydatatype == "string")$keydbval = "'".$keydbval."'";
			 //perform update
			 //$cleard = true;
		 
			 
//if all clear or deleted
if($allclear || (isset($gradesprsheet[$rw.'_deleted']) && $gradesprsheet[$rw.'_deleted'] == "true")){
	//return $keyRelation;
$del = true;
if($keyRelation != ""){
	$tableField = explode(".",$keyRelation);
	if(count($tableField) > 1){
    $rtable = $tableField[0];
		$rfield = $tableField[1];
		//check if related records exist
		$ckre = $dbo->Select($rtable,$rfield,$rfield."=".$keydbval);
    if(is_array($ckre) && $ckre[1] > 0){
			$del = false;
			//return "select $rfield from $rtable where ".$rfield."=".$keydbval;
		}
	}
}
if($del)$gradesprsheet_query .= "DELETE FROM $tb WHERE $keydbname = $keydbval;";
	//
}else{
	//if any of the required field not set, return (invalid entering)
	if($anyclear)return "INVALID ENTERING: Required Column Must be Supplied";
	
 
 $gradesprsheet_query .= "UPDATE $tb SET $setpart WHERE $keydbname = $keydbval;";
//update

}
				
		}else{ //if new entering, perform insert
     
		 //if no entering (required field) or deleted just ignore
		 if($allclear || (isset($gradesprsheet[$rw.'_deleted']) && $gradesprsheet[$rw.'_deleted'] == "true"))continue;
//if any of the required field not set, return (invalid entering)
if($anyclear)return "INVALID ENTERING: Required Column Must be Supplied";
if((int)$gradesprsheet[$keycell] == 0){
//perform insert
$gradesprsheet_query .= "INSERT INTO $tb SET $setpart ;";
}

		}
 }
}
//return $gradesprsheet_query;
//return $gradesprsheet_query;
if(trim($gradesprsheet_query) == "")return "No Update Performed";
$dump = $dbo->Connection->multi_query($gradesprsheet_query);
	 if(!$dump){
		 return "Server Error: ".$dbo->Connection->error;
	 }else{
			 do {
					 /* store first result set */
													 if ($result = $dbo->Connection->store_result()) {
															 /*while ($row = $result->fetch_row()) {
																	 printf("%s\n", $row[0]);
															 }*/
															 $result->free();
													 }
													 /* print divider */
													 if ($dbo->Connection->more_results()) {
															 //printf("-----------------\n");
													 }
											 } while ($dbo->Connection->next_result());
											 return true;
									 }
//return $gradesprsheet_query;
}

function SheetToArray($data,$keyIndex = -1,$Values = 1,$gluestr = "~"){
	global $dbo;
	$datas = $dbo->DataArray($data);
 
	if(!isset($datas['MaxDataRow']) || (int)$datas['MaxDataRow'] < 1){
		return [];
	}
 $rtnarr = [];
 $Values = is_array($Values)?$Values:[$Values];
 //return $datas;
 for($rw = 1; $rw <= (int)$datas['MaxDataRow']; $rw++){
		$valstr = "";
		foreach($Values as $colind){
			 if(!isset($datas[$rw.'_'.$colind]))continue;
			 $valstr .= $datas[$rw.'_'.$colind].$gluestr;
		}
		$valstr = rtrim($valstr,$gluestr);
		if($keyIndex  < 0){
		 $rtnarr[] = $valstr;
		}else{
		 $rtnarr[$datas[$rw.'_'.$keyIndex]] = $valstr;
		}
 }
 return $rtnarr;
}

$optioncnt = 0;

//Object for options
function OptionGrid(){
	echo '<div class="w3-row-padding ep-animate-opacity editor-grid editor">';
 }

 function _OptionGrid(){
	 global $optioncnt;
	 $optioncnt = 0;
	 echo '</div>';
 }

 function Option($attr=""){
	 global $optioncnt;
	 $optioncnt++;
	 $id = trim(PopValue("id",$attr));
	 $id = $id == ""?"op".$optioncnt:$id;
	$descr = PopValue("descr",$attr);
	 $label = PopValue("label",$attr);
	 $onfocus = PopValue("onfocus",$attr);
	 
	 echo '<div class="m6 w3-col editor-grid-col editor-bx">
	 <div class="editor-text ep-animate-opacity editor editor-bx">';
	 Check("id={$id}_check,style=vertical-align:middle"); 
	 echo '<div  contenteditable ="true" style="display:inline-block; width:calc(100% - 75px); vertical-align:middle;margin:0px 10px;font-weight:bold" id="'.$id.'_label" > '.$label.' </div>';
	 echo '</div>
	 <div id="'.$id.'_ansCont" class=" editor-selectable ep-animate-opacity editor editor-bx" style="margin-bottom:5px"></div>
	 </div>';
	 //
}

function CleanText($text){
	return str_replace([',','='],['\,','\='],$text);
}

function DropDownLine($attr="",$options=[]){
	$id = PopValue("id",$attr);
	if(trim($id) == "")$id="ddl_".time();
	 $onselect = PopValue("onselect",$attr);
	 $onedit = PopValue("onedit",$attr);
	 if(trim($onselect) == "")$onselect="";
	 if(trim($onedit) == "")$onedit="";
	 $selected = PopValue("selected",$attr);
	 $theme = PopValue("theme",$attr);
	 if(strtolower($theme) != "error" && strtolower($theme) != "ok"){
		$theme = "";
	 }
	// $onfocus = PopValue("onfocus",$attr);
	$optionstr = "";
	$selectmk = "";
	$selectkey = "";
	$first = true;
	$seenselected = false;
	$actionitemclass = "";
	foreach($options as $key=>$val){
		$isselect = "";
		if($first){
			$selectmk = $val;
			$selectkey = $key;
			$first = false;
			$isselect = "isselect_first";
		}
		$itonselect = trim($onselect) == ""?"":$onselect."('".$key."')";
		$itonedit = trim($onedit) == ""?"":$onedit."('".$key."');";
		
		if($selected == $key){
			$selectmk = $val;
			$selectkey = $key;
			$isselect = "isselect";
			$seenselected = true;
		}
		if($key == '0'){
			$actionitemclass = "isactionitem";
		}
		$optionstr .= '<div id="'.$id.'_'.$key.'" class="dropdownitem '.$isselect.' '.$actionitemclass.'" onclick="DropDownLine.DropSelect(this);'.$itonselect.'" oncontextmenu="'.$itonedit.'return false" data-value="'.$key.'">'.$val.'</div>';
		
	}
	 //if non selected
	  //select the first one
	$optionstr = str_replace("isselect_first",!$seenselected?"isselect":"",$optionstr);
	
	echo '<div class="dropdownline" id="'.$id.'">
		  <div class="line"></div>
		  <div class="droppdown card-1 dropdownline-line-obj '.$theme.'" onclick="DropDownLine.Drop(this)">
			 <div class="dropdowndisplay dropdownline-line-obj"><span class="dropdownline-line-obj displaytxt"  data-value="'.$selectkey.'">'.$selectmk.'</span> <i class="downarrow fa fa-chevron-down dropdownline-line-obj"></i></div>
			 <div style="clear:right"></div>
			 <div class="dropdowncont card-2 ep-animate-opacity" style="display:none;">';
				
			 echo $optionstr;

			 echo '</div>
		  </div>
		  <div class="line"></div>
	</div>';
}

function DropDownLineLogoItem($text="",$logo="list-alt"){
	return "<i class='fa fa-$logo' style='font-size:1.3em;vertical-align:middle;display:inline-block'></i> <span style='vertical-align:middle;margin-left:4px;display:inline-block'>$text</span>";
}

function TitleLine($attr=""){
	$Title = PopValue("text",$attr);
	$theme = PopValue("theme",$attr);
	if(strtolower($theme) != "error" && strtolower($theme) != "ok"){
	   $theme = "";
	}
	$attr = ProcessAtrrVal($attr);
	echo '<div style="clear:both"></div>
	<div class="dropdownline" '.$attr.'>
		  <div class="line"></div>
		  <div class="droppdown card-1-1 '.$theme.'" style="text-align:center">'.$Title.'</div>
		  <div class="line"></div>
	</div>';
}

$cardlistcnt = 0;
$curid = "";
$keys = [];
$cards =[];
// Student Card List Box
function __CardList($attr=""){
	global $curid;
	global $keys;
	global $cardlistcnt;
	global $cards;
	$cardlistcnt = 0;
$curid = "";
$keys = [];$cards = [];
	$TotList = PopValue("total",$attr);
	$id = PopValue('id',$attr);
	$action = PopValue('action',$attr);
if(trim($id) == "")$id="simgcard_".time();
	$curid = $id;
	return '<div class="studcardbx card-1 fadeIn animated faster">
	<div class="studcardsearchbx">
		<div class="studcardseach">
			<label for="'.$id.'"><i class="fa fa-search"></i></label>
			<input type="text" placeholder="Search List" oninput="CardList.Filter(this)" name="'.$id.'" id="'.$id.'">
			<button class="altColor"  type="button" onclick="CardList.Empty(this)"><i class="fa fa-trash"></i></button>
			<button class="altColor2"  type="button" onclick="'.$action.'"><i class="fa fa-plus"></i></button>
		</div>';
	
}

function _Card($data){
	global $curid;
	global $cardlistcnt;
	global $keys;
	global $cards;
	$data = array_merge(["Image"=>"","Text1"=>"","Text2"=>"","Text3"=>"","key"=>""],$data);
	if(!isset($data['key']) || trim($data['key']) == "")$data['key'] = $curid."_".$cardlistcnt;
	$keys[$data['key']] = $data;
	$cards[] = '<div class="instudcardbx">
 <input type="hidden" value="'.$data['key'].'" />
 <div class="studcardimg"><img src="'.$data['Image'].'" class="card-1-1" alt="List Image"></div>
 <div class="studcardcont">
	 <div class="studname">'.$data['Text1'].'</div>
	 <div class="studprogramme">'.$data['Text2'].'</div>
	 <div class="studlevelclass altColor2">'.$data['Text3'].'</div>
 </div>
 <div class="studcardremove"><button type="button" onclick="CardList.Delete(this,\''.$data['key'].'\',\''.$curid.'\')"><i class="fa fa-trash altColor"></i></button></div>
</div>';
$cardlistcnt++;
}

function ___CardList(){
	global $curid;
	global $cardlistcnt;
	global $keys;
	global $cards;
	$TotList = count($cards);

$tt = ((int)$TotList > 0)?$TotList.' / '.$TotList.' displayed':'';
  $mk = '
	  <div class="studcardsearchrpt altBgColor2Fade card-3" id="'.$curid.'_countbx">
		  '.$tt.'
	  </div>
  </div>
  <div class="studcarddetbx" id="'.$curid.'_cardbx">
	
 ';
 $mk .= implode('',$cards);
$mk .= ' </div>
<div id="'.$curid.'_data" style="display:none">'.json_encode($keys).'</div>
</div>';
$curid = "";
$keys = [];
$cards = [];
$cardlistcnt = 0;
return $mk;
}

function CardList($attr){
	echo __CardList($attr);
}

function Card($data){
	echo _Card($data);
}

function _CardList(){
	echo ___CardList();
}

function HomeDisplay($action=[]){
	$txt = !isset($action['text']) || trim($action['text']) == ""?"Welcome":$action['text'];
	$id = !isset($action['id']) || trim($action['id']) == ""?time()."_".mt_rand(100000,99999):$action['id'];
	// $txt = ?"Welcome":$action['text'];

	//No Exam Selected
Box('id='.CleanText($id).',style=display:flex;height: 100%;justify-content: center;align-items: center;,class=fadeIn animated faster');
echo '<div style="text-align:center">';
if(isset($action['logo']) && trim($action['logo']) != "")echo '<img src="'.$action['logo'].'" class="homedisimg" />';
echo '<div class="homedistext">'.$txt.'</div>';
if(isset($action['onclick']) && trim($action['onclick']) != ""){
	$action['value'] = isset($action['value']) && trim($action['value']) != ""?$action['value']:"Start";
	$action['icon'] = isset($action['icon']) && trim($action['icon']) != ""?$action['icon']:"thumbs-up";
	LogoButton('onclick='.CleanText($action['onclick']).',type=button,title='.CleanText($action['value']).',class=success card-1,style=border-radius:5px;padding:13px 15px;color:#fff;margin:3px,logo='.CleanText($action['icon']).',text='.CleanText($action['value']));
}

echo '</div>';
_Box();
}



?>