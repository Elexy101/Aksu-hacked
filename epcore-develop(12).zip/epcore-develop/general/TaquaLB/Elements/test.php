<?php
 require_once("../Ajax/CGI/PHP/config.php");
/*require_once("Elements.php");
require_once("../../GenScript/PHP/getinfo.php");
include("../Ajax/CGI/PHP/PDF/mpdf60/mpdf.php");
 include("Script/pdf.php");*/
 LoadFile("pdfprint","../../../");
 //$sfdf = new mPDF();
//echo "aaa";

 $pdf = new PDFPrinter();
 
 $pdf->WaterMarkText("CONFIDENTIAL",0.1);
 
 $pdf->Banner("Testing",array("LogoSize"=>"100px*100px","Style"=>"font-size:0.8em"));
 //$pdf->FooterNote("Testing");
 $pdf->WaterMarkImage($pdf->logo,0.06);
 $pdf->Panel("");
    $pdf->InfoBox(0.5);
      $pdf->Image(_CONFIGDIR_."UserImages/Student/16_SCT_MTH_NC_0010.jpg?31988","width:100%;height:100%");
    $pdf->_InfoBox();

    $pdf->InfoBox(0.5);
      $pdf->Image(_CONFIGDIR_."UserImages/Student/16_SCT_MTH_NC_0010.jpg?31988","width:100%;height:100%");
    $pdf->_InfoBox();

    $pdf->InfoBox(1);
      $pdf->InfoTitle("Texting");
      $pdf->Info("Name:","Yommy");
      $pdf->Info("Name:","Yommy");
      $pdf->Info("Name:","Yommy");
    $pdf->_InfoBox();

    $pdf->InfoBox(2);
      $pdf->InfoTitle("Texting");
      $pdf->Info("Name:","Yommy");
      $pdf->Info("Name:","Yommy");
      $pdf->Info("Name:","Yommy");
    $pdf->_InfoBox();

 $pdf->_Panel();

 $pdf->Table();

  $pdf->TableHead(array("SN","NAME","DEPARTMENT","COURSE CODE","CA","EXAM","TOTAL"));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  $pdf->TableRow(array(1,'kejemilobi abayomi','computer science','COM 111',23,24,45));
  

 $pdf->_Table();

$pdf->Dump("<div>Using Dump</div>");

$pdf->Finish();

?>