<?php
require_once "../../../../../api/engine/parameter.php";
//if(!isset($_POST['FileName']))(exit("#Filename not Found"));
$upload = Uploader("../TempFile/",$_POST['FileName']);
if(isset($upload['Failed'][$_POST['FileName']]))exit("#".$upload['Failed'][$_POST['FileName']]);
if(!isset($upload['Success'][$_POST['FileName']]))exit("#File Not Found");
//remove the ../
//$file = trim($upload['Success'][$_POST['FileName']]);
//exit(ltrim($file,"."));
$upload['Success'][$_POST['FileName']] = ltrim($upload['Success'][$_POST['FileName']],".");
echo $upload['Success'][$_POST['FileName']];

?>