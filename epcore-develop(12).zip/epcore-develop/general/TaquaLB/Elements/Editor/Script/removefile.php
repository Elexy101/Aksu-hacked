<?php
if(!isset($_POST['URL']) || trim($_POST['URL']) == "" || !isset($_POST['SubDir']) || trim($_POST['SubDir']) == "")exit("#Removing File Failed: Invalid Parameter Supplied");
$Files = explode(";",$_POST['URL']);
foreach($Files as $fn){
    unlink("../../../../../../../".$_POST['SubDir'].$fn);
}

?>