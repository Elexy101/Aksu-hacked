<?php
if(!isset($_POST['SubDir']))exit("#Invalid Parameter");
require_once "../../../../../api/engine/parameter.php";
function TrimStr($str){
    return ltrim($str,".");
}
//if(!isset($_POST['FileName']))(exit("#Filename not Found"));
$upload = Uploader("../../../../../../../".$_POST['SubDir']."Files/Temp/");
if(count($upload['Failed']) > 0)exit("#Error Loading File");
if(count($upload['Success']) < 1)exit("#File Not Found");
//remove the ../
//$file = trim($upload['Success'][$_POST['FileName']]);
//exit(ltrim($file,"."));
$FNames = array_values($upload['Success']);
//$FNames = implode(";",array_map("TrimStr",$FNames));
$FName = explode($_POST['SubDir'],$FNames[0]);
echo $FName[1];

?>