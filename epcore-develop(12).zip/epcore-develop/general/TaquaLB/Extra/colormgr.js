// JavaScript Document
//alert('color');
var ColorMgr = new function(){
	this.Generate = function(WhiteBlack){
		cl = ColorMgr.RandomGen;
		/*var RGB = [0,0,0];
		if(WhiteBlack){
			R = Math.ceil((Math.random() * 255));
			G = Math.ceil((Math.random() * 255));
			B = Math.ceil((Math.random() * 255));
		}else{
			R = Math.floor((Math.random() * 255));
			G = Math.floor((Math.random() * 255));
			B = Math.floor((Math.random() * 255));
		}*/
		var RGB = [cl(),cl(),cl()];
		var minc = RGB[0]; 
		for(var s=1; s<RGB.length; s++){
			if(minc > RGB[s]){
				minc = RGB[s];
			}
		}
		var subval = minc - 6;
		
		var RGBtxt = [RGB[0]-subval, RGB[1]-subval, RGB[2]-subval];
		//return [RGB,RGBtxt];
		return "rgba("+RGB[0]+", "+RGB[1]+", "+RGB[2]+", 1.00);rgba("+RGBtxt[0]+", "+RGBtxt[1]+", "+RGBtxt[2]+", 1.00)";
	}
	
	this.RandomGen = function(){
		var c = Math.floor((Math.random() * 255));
		while(c < 100  || c > 230){
			c = Math.floor((Math.random() * 255));
		}
		return c;
	}
	
}