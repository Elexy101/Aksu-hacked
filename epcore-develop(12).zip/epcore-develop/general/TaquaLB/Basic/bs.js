_d = (typeof _d=="undefined")?document:_d; //document abbr throughout the script
_UND = "undefined"; //'undefined' string abbr
_Sec = 1000; //Seconds
_Min = _Sec * 60; //Minute
_Hour = _Min * 60; //Hour
_Day = _Hour * 24; //Day
_Week = _Day * 7; //Week
_Month = _Week * 4; //~Month
_Year = _Day * 365;//~Year

 //Show/Hide ID object (Show or Hide)
 //----------------------------------------
 //This function displays or hides the element
function SHs(ID,Show,display){
	//ID - Holds the Element or its id - Required
	//Show - Holds which operation to perform on the Element (1 => Show, Not 1 => Hide) - Required
	//display - Holds the Element CSS display value ('block','inline','inline-block','table' e.t.c) - Default = 'block' (true = 'block', false = 'inline')
	display = (typeof display == _UND || display === true)?"block":(display === false)?"inline":display; //handles the default setting of display argurment
	var elem = RP(ID); //RP - Make Sure the ID is an element (cos ID can either be an element or the element ID)
	if(elem == null)return; //if cannot get the element stop operation
	if (Show == 1){ //if to display
		elem.style.display = display; //set the css display attribute of the element to its display type
	}else{
		//if to hide, set to none
		elem.style.display = 'none';
	}
}

//function to display awesome font
//----------------------------------------
var Icon = function(type){
	//type - holds the font awesome icone name
	//Form the markup and return it as string
  return '<i class="fa fa-'+type+'" aria-hidden="true"></i>';	
}
//String Prototype for Icon function
String.prototype.Icon = function(){return Icon(this.toString())}

//function to return the actual type of supplied object
//----------------------------------------
//main advantage is, it checks array and return as array type not conventional javascript object type
function CheckType(obj){
	//obj - Holds the object/Element to Check Type - Required
	if(typeof obj == _UND || obj == null) return null; //if obj is null or not supplied return null
	//Check if obj is not a string and can have children 
	if (typeof obj != "string" && typeof obj.length != "undefined" ){
		try{ //Check if it is an array, by running native array function on the Obj. if no error occur, return 'array' else return the type of the element/Argurment
			var a = obj.sort();
			var b = obj.slice(0);
			return "array"
		}catch(e){
			return typeof obj;
		}
	}else{ 
		return typeof obj;
	}
}

//Specific Function that checks type using the CheckType function
//----------------------------------------
//IsArray return true if obj is array 
var IsArray = function(obj){return (CheckType(obj) == "array")?true:false;}
//IsString return true if obj is string
var IsString = function(obj){return (CheckType(obj) == "string")?true:false;}
//IsNumber return true if obj is numeric
var IsNumber = function(obj){return (CheckType(obj) == "number")?true:false;}
//IsObject return true if obj is object
var IsObject = function(obj){return (CheckType(obj) == "object")?true:false;}
//IsFunction return true if obj is a function
var IsFunction = function(obj){return (CheckType(obj) == "function")?true:false;}
//IsNull return true if obj is null
var IsNull = function(obj){return (obj == null)?true:false;}
var Null = IsNull; //Nickname - Null can also be used to check if null

//check if sent value is a valid phone number
//----------------------------------------
var _CheckPhoneNum = function(number){
	//number - the number to check its validity
	if(IsString(number)){ //if is sent as a string
		//trim out special phone prefix
		number = number.TrimLeft(["+","-"]); //TrimLeft function trim leading character
		//Check if all character is a digit
		for(var s=0; s <number.length; s++){ //loop through all characters
			var char = number[s]; //get current character
			//if(typeof parseInt(char) == "NaN"){
				if(isNaN(parseInt(char))){ //check if not an integer number
					return false; //return false; meaning not a valid phone number
				}
			//}
		}
		//check if number is between 6 to 15 digit(Can be modified to cater for any range) - idea => it will be beter if it is dynamic user defined
		if(number.length > 5 && number.length < 16){
			return true;
		}else{
			return false;
		}
	}else if(IsNumber(number)){ //if argument sent is a numeric
		//convert to string and rerun the function on it
		return _CheckPhoneNum(number.toString());
	}
}
//check if phone number (NickName)
var IsPhoneNumber = function(obj){
	//obj - holds user sent string or object
	if(IsObject(obj)){//check if sent argument is an object
		 //Object.Text() - Get or Set the innerHTML or TextContent or Value of the Object
		if(obj.Text() != ""){
			//use the textContent or innerHTML of the object and check if valid phone number
			return _CheckPhoneNum(obj.Text());
		}else{
		   return false;	
		}
		
	}else{
		return _CheckPhoneNum(obj);
	
		
	}
}

//check if sent value is a valid Email Address
//----------------------------------------
_CheckEmail = function(obj){
	//obj - holds the user sent email string
	//var regexp = /^((\w|\-)+\@(\w|\-)+\.\w{2,3})$|^((\w|\-)+\@(\w|\-)+\.\w{2,3}\.[a-z]{2})$/;
	var regexp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
					var test = regexp.test(obj);//test if sent email string matches the email regexp 
					return test;
	
}

//check if email, accept more argument type
var IsEmail = function(obj){
	//obj - holds user sent string or object
	if(IsObject(obj)){ //check if sent argument is an object
		   //Object.Text() - Get or Set the innerHTML or TextContent or Value of the Object
			if(obj.Text() != ""){
				//use the textContent or innerHTML of the object and check if valid email address
				return _CheckEmail(obj.Text());
			}else{
			   return false;	
			}
			
		}else{
			return _CheckEmail(obj);
		}
}

//Checks if Children exist
var HasItem = function(obj){
	if(IsArray(obj)){
		// alert(obj.length);
		return (obj.length > 0)?true:false;
	}else if(IsString(obj)){
		return !IsEmpty(obj);
		//obj.childNodes.length
	}else{
		if(IsSet(obj.childNodes)){
			return (obj.childNodes.length > 0)?true:false;
		}else if(IsSet(obj.length)){
		 return (obj.length > 0)?true:false;
		}else{
			return false;
		}
	}
}
//Checks if an item exists inside an array
var _ArrObjExist = function(arr,obj,funct){
	for(s in arr){
		if(IsSet(funct)){
			if(funct(arr[s],obj)){
				return {"Exist":true,"Index":s};
			}
		}else{
		  if(arr[s] == obj){
			  return {"Exist":true,"Index":s};
		  }
		}
	}
   return {"Exist":false,"Index":-1};	
}

/*var _CharExist = function(str,char){
	if(IsSet(str) && IsSet(char)){
		if(str.length == 1 && str == char){
			return {"Exist":true,"Index":0}
		}else if(str.length > 1){
			var strarr = str.ToArray();
			return strarr.InArray(char);
		}
	}
	return {"Exist":false,"Index":-1};
}*/

Array.prototype.InArray = function(obj,funct){return _ArrObjExist(this,obj,funct)}
Array.prototype.IndexOf = function(obj,funct){return _ArrObjExist(this,obj,funct).Index}

function PerformSH(obj,sh,inl){
	inl = (isset(inl))?inl:true;
	if(IsArray(obj)){
		obj.Walk(function(k,v,s){SHs(v,s[0],s[1]);},[sh,inl]);
	}else{
		SHs(obj,sh,inl);
	}
}
//Object.prototype.type = function(){return type(this)};

//string object prototyping to perform Showing/Hideing operation by object ID(the string)
String.prototype.Show = function(inl){PerformSH(this.toString(),1,inl)}; 
String.prototype.Hide = function(inl){PerformSH(this.toString(),0,inl)};
//array object prototyping to perform Showing/Hideing operation by object ID(the string)
Array.prototype.Show = function(inl){PerformSH(this,1,inl)}; 
Array.prototype.Hide = function(inl){PerformSH(this,0,inl)};
//object prototyping to perform Showing/Hideing operation on object (the string)
Object.prototype.Show = function(inl){PerformSH(this,1,inl)}; 
Object.prototype.Hide = function(inl){PerformSH(this,0,inl)};


 //The visibility of an element
 //----------------------------------------
function Visible(obj,Show){
	
	if(IsArray(obj)){ //if it is an array, perform the operation on all item of the array
		obj.Walk(function(k,v,s){vis(v,s);},Show);
	}else{ //if not array, perform on the element only
         vis(obj,Show);
	}
	
}

//real code that controls visibility
function vis(obj,Show){
//alert(Show);	
  var elem = RP(obj); //Return the element
  if(IsNull(elem) || !isset(elem.style))return;
  if (Show == 1){ 
	  elem.style.visibility = 'visible';
  }else{
	  elem.style.visibility = 'hidden';
  }	
	
}


//Array.prototype.
//string object prototyping to perform Apear/disapear operation by object ID(the string)
String.prototype.Appear = function(){Visible(this.toString(),1)}; 
String.prototype.Disappear = function(){Visible(this.toString(),0)};
//array object prototyping to perform Showing/Hideing operation by object ID(the string)
Array.prototype.Appear = function(){Visible(this,1)}; 
Array.prototype.Disappear = function(){Visible(this,0)};
//object prototyping to perform Showing/Hideing operation on object (the string)
Object.prototype.Appear = function(){Visible(this,1)}; 
Object.prototype.Disappear = function(){Visible(this,0)};

//Get Element(s) Functions
//---------------------------------------

//function get elements by ClassName, TagName or Name (Multiple Element Selector)
var GetBy = function(By, value){
	//By - The parameter we are using to get elemet (c=>ClassName, t=>TagName, n=>Name)
	switch (By){
	  case "c": //Classname
	  return document.getElementsByClassName(value);
	  break;
	  case "t": //TagName
	  return document.getElementsByTagName(value);	
	  break;
	  case "n": //Name
	  return document.getElementsByName(value);	
	  break;
		
	}
	
}

//----------------------------------------------------------------------
//get element by className or by tag names
var GetElemBy = function(arg,by){
	by = (IsNull(by))?"c":by;
	if (arg.length == 1){ //if only one parameters sent
		 //check the type of single parameter sent
		 if (IsString(arg[0])){ 
			 var className = arg[0]; //get the string (ClassName,TagName or Name)
			 objs = GetBy(by,className); //get the elements by supplied method
			 if(HasItem(objs)){ //if elements found
				 return AddtoArray(objs,by);
			 }else{
				return null; 
			 }
		 }else{
			  var obj = arg[0];
			 //check if it is not an array or class
			 if (!IsArray(arg[0])){// if it does not contain subelement
			     //return back the object
				 return obj;
			 }else{
				//use all the classname and get all elements into an array
				//from a comprehensive array, incase there are nexted array
				return AddtoArray(obj,by);
			 }
		 }
		//if multiple parameters 
	 }else if (arg.length > 1){
		 return AddtoArray(arg,by);
	 }else{
		return null; 
	 }
}
//get elements by className
function _c(){
	return GetElemBy(arguments);
}
//get elements by TagName
function _t(){return GetElemBy(arguments,"t");}
//get elements by Name
function _n(){return GetElemBy(arguments,"n");}


//Function to form a Comprehensive Super array of elements
function AddtoArray(classNamearr,by){
	//by represent the javascript function type to get element
	//get all the classname and get elements into an array
				//var arrelem = new Array(classNamearr.length);
				var genarr = new Array();
				//var totlenght = genarr.length; //set the current pointer to the next available space of the genarr
				 for (var i = 0; i < classNamearr.length; i++){
					 if(IsObject(classNamearr[i])){
						genarr.push(classNamearr[i]);
					// totlenght = genarr.length;
					 continue;
					 }
					 if(IsArray(classNamearr[i])){ //if item is an array run this function with the current item, is it array(parameter)?. merge the returned array with the array to form an updated array
					     var rtnarr = AddtoArray(classNamearr[i],by);
						 genarr = (HasItem(rtnarr))?genarr.concat(rtnarr):genarr;
					 }else if(IsString(classNamearr[i])){ //if item is a string,
					   var objs = GetBy(by,classNamearr[i]); //get the array of elements
					   //if a new set of objects is gotten
					   if(HasItem(objs)){
						 for(var w = 0; w < objs.length; w++){ //move through the elements and add them to the general array (arrelem)
							 genarr.push(objs[w]); //add element to array
							 //w+totlenght calculates the new location for insertion in the general array
						 }
					   }
					 }
					 //totlenght = genarr.length; //reset the new array starting key specifier
					 //make sure the totlenght is equal to the length of the general array currently so that subsequent looping key calculation will start from the general array length (the next available array slot)
				 }
				 return (genarr.length == 1)?genarr[0]:genarr;
	
}

function _Walk(elemarr,funct,passval){
	//passval is a parameter that will be passed into the funct function while calling it (optional)
	if(IsNull(elemarr))return;
	if(IsObject(elemarr)){ //if elemarr is an object  and it has children pass the current child into the supplied function (funct)
		if(elemarr.childNodes.length != "undefined"){
			for(var i=0; i<elemarr.childNodes.length; i++){
		     funct(i,elemarr.childNodes[i],passval);
			}
		}else{
			return;
		}
	}else if(IsArray(elemarr)){ //if elemarr is an array pass the each item of the array to the supplied function;
	  for(var i=0; i<elemarr.length; i++){
		  funct(i,elemarr[i],passval);
	  }
	}else if(IsString(elemarr)){ //if elemarr is string pass each character
	  for(var i=0; i<elemarr.length; i++){
		  funct(i,elemarr.charAt(i),passval);
	  }
	}else{ 
	   return;	
	}
}

//function walk(elemarr,funct,passval){_Walk(elemarr,funct,passval)}
walk = _Walk;
Array.prototype.Walk = function(func,passVal){walk(this,func,passVal);}
Object.prototype.Walk = function(func,passVal){walk(this,func,passVal);}
String.prototype.Walk = function(func,passVal){walk(this.toString(),func,passVal);}

//Get element by ID-------------------------------------------------
 var otherfunc = [_n,_t,_c]; 
 
 function _(){	 
    
	 if (arguments.length == 1){
		if(IsNull(arguments[0]))return null;
		 //check the type of single parameter sent
		 if (IsArray(arguments[0]) || IsString(arguments[0])){


				 return Element4rmArr(arguments[0]); 
		 }else{
			return arguments[0];  
		 }
		 
		//if multiple parameters 
	 }else if ( arguments.length > 1){
		 return Element4rmArr(arguments); 
	 }else{
		return null; 
	 }
	 	 
 }
 
 
 
 var Element4rmArr = function(arr){
	 var arrelem = new Array();
	             //var len = 0;
				 if(IsString(arr)){
					  arr = arr.Trim();
					 return performGetElem(arr);
					
				 }
				 for (var i = 0; i < arr.length; i++){ //loop trough array of item
					 if(IsString(arr[i])){ //if item type is string get the element by ID and add it to the array otherfunc
					arr[i] = arr[i].Trim();
					// var rst = document.getElementById(arr[i]);
					  arrelem = performGetElem(arr[i],arrelem);  
					 }else if(IsObject(arr[i])){ //if item is an object add it to the array
						arrelem.push(arr[i]);
					 }else if(IsArray(arr[i])){ // if is an array run this samen function to loop throug it and get all element. then concatinate the return array with the current to form updated one
						arrelem = arrelem.concat(Element4rmArr(arr[i]));
						//len = arrelem.length - 1;
					 }else{ //if type is none of the above add null to array
						//arrelem.push(null); 
					 }
					// len++;
				 }
	return (arrelem.length == 1)?arrelem[0]:arrelem;
 }
 
 /*//function to perform the subtraction operation sending array of operands elements/string in which the first is the main value while others are to be subtracted from main
 var RemoveElement = function(arrelems){
	 
	 var mainelem = _(arrelems[0]);
	 
	 //check if main element if object
	 if(IsNull(mainelem))return null;
	 //get for other element
	 var pyherarr = new Array(arrelems.length - 1);
	 for(var d=1; d <arrelems.length; d++){
		 pyherarr[d-1] = arrelems[d];
	 }
	 var otherelem = _(pyherarr);
	 
	 //if no other element exist, return back the main element(s)
	 if(IsNull(otherelem))return mainelem;
	
	 var rstarr = new Array();
	 if(IsArray(mainelem)){//if the main elemenet is an array of elements
	   for(var a=0; a < mainelem.length; a++){
		   var curel = mainelem[a];
		    
		   var include = checkelement(curel,otherelem);
		   if(include == true){ //check if element is to be added or ignored
				 rstarr[rstarr.length] =  curel; //add to the resulting element array
			 }
	   }
	 // alert(IsEmpty(rstarr));
	   if(IsEmpty(rstarr)){ //if result array is empty
		   return null;
	   }else{
	      return rstarr;
	   }
	 }else{ //if main element is an object
		  include = checkelement(mainelem,otherelem);
		if(include == true){ //check if element is to be added or ignored
			return mainelem; //add to the resulting element array
		}else{
			return null; //if found
		}
	 }
 }*/
 
 
 
 //function to perform the subtraction operation sending array of operands (string) in which the first is the main value while others are to be subtracted from main
 //Limitation = if an element exit in even operands (e.g 3, 5, 7 operands) it will not be removed
 var RemoveElement = function(arrelems){
	 //alert(arrelems.length);
	 var mainelem = _(arrelems[0]); //the first operand
	 
	 var startpointer = 0;
	 var rstelem = null;
	 //check if main element if object
	
	 //get for other element
	// var pyherarr = new Array(arrelems.length - 1);
	//all intersection
	//var allint = _(arrelems.join("&"));
	//loop trough the remaining strings of the array to perform a subtract operation with the first.
	//result of the first operation of the loop is set to first, so that the operation can be down with the next
	 for(var d=1; d <arrelems.length; d++){
		 
		 
		 /* var nstr = arrelems[d]; //get the next operand
		 var nelem = _(nstr); //get its elements
		  if(IsNull(mainelem)){ //if current main is null
		    //set main to subtractin elemenet
			 mainelem = nelem;
			 continue
		  }
		  
		 if(IsArray(mainelem)){//if the main elemenet is an array of elements
	        for(var a=0; a < mainelem.length; a++){
			   var curel = mainelem[a];
			   if(IsNull(curel))continue;//if checking object is null ignore and go to next object
			   var include = checkelement(curel,nelem);
			   if(include.Exist == true){ //check if element exist
					 nelem = include.NewArray; //reset the lookup array to updated array
					 mainelem[a] = null; //set the current object to null
					 continue;
			   }
			}
			if(d+1 < arrelems.length){ //if not last operand combine the remaining elements in the of the two operand as mainelem for next subtraction 
				mainelem = FormRst(mainelem,nelem);
			}
		 }else{ //if main element is an object
			  include = checkelement(mainelem,nelem);
			if(include.Exist == true){ //check if element is to be added or ignored
			    nelem = include.NewArray;
				mainelem = FormRst(null,nelem); //add to the resulting element array
			}else{
				 mainelem = FormRst(mainelem,nelem);
			}
		 }*/
		 
		 //new pertern
		 //////////////////////////////
		 var union = FormRst(mainelem,_(arrelems[d])); //get the union of the first and second
		 var int = FormAND([mainelem,_(arrelems[d])]); //get the intersection of the first and second
		
		 //subtract the intersection from the union and set as first
		  mainelem = ExactRemove(union,int);
		 //alert(mainelem);
		 //////////////////////////
		  
	 }
	 
return mainelem;
	 
 }
 
 function ExactRemove(bigset,smallset){
	 if(IsArray(smallset)){ //if smallset is an array, loop through it and check if exist in big set
		 for(var s=0; s<smallset.length; s++){
			 var currelem = smallset[s];
			 if(!IsArray(bigset)){
				 if(bigset = currelem)return null;
			 }else{
				 
				 var checkext = bigset.InArray(currelem);
				 if(checkext.Exist){ //if exist in big set array
				// alert("seen");
					bigset[checkext.Index] = null; //set the element to null in bigarray
				 }
			 }
		 }
	 }else{ //if smallset is an object
		if(!IsArray(bigset)){
				 if(bigset = smallset)return null;
			 }else{
				 var checkext = bigset.InArray(smallset);
				 if(checkext.Exist){ //if exist in big set array
					bigset[checkext.Index] = null; //set the element to null in bigarray
				 }
			 } 
	 }
	 //alert("Normal: "+bigset);
	// alert("Exact: "+bigset.Exact());
	 return (IsArray(bigset))?bigset.Exact():bigset;
 }
 
  //function to check if current element exist in otherselement
 var checkelement = function(curel,otherelem){
	      if(IsArray(otherelem)){ //if the subtracting element is more than one i.e an array
		   var include = {Exist:false,NewArray:otherelem};
			 //loop through all other elements and compare each element with current main element
			  var existw =  otherelem.InArray(curel);
				 if(existw.Exist == true){ //if current element exist in main element, set indicator to ignore the element
					otherelem[existw.Index] = null; //remove it from the arraylist
					include = {Exist:true,NewArray:otherelem};
				 }
			
			 return include;
		   }else{//if the subtracting element is one i.e an object
			   if(curel != otherelem){
				   return {Exist:false,NewArray:otherelem};
				 // rstarr[rstarr.length] =  curel; //add to the resulting element array
			   }else{
				   return {Exist:true,NewArray:null};
			   }
		   }
 }
 
/* //function to check if current element exist in otherselement
 var checkelement = function(curel,otherelem){
	      if(IsArray(otherelem)){ //if the subtracting element is more than one i.e an array
		   var include = true;
			 //loop through all other elements and compare each element with current main element
			 for(var r=0; r<otherelem.length ; r++){
				 var curothers = otherelem[r];
				 if(curothers == curel){ //if current element exist in main element, set indicator to ignore the element
					 include = false;
					 break;
				 }
			 }
			 return include;
		   }else{//if the subtracting element is one i.e an object
			   if(curel != otherelem){
				   return true;
				 // rstarr[rstarr.length] =  curel; //add to the resulting element array
			   }else{
				   return false
			   }
		   }
 }*/
 
 
 //function to form the new resulting array
 var FormRst = function(mainelem,nelem){
	 var arrays = [mainelem,nelem];
	 var rstarr = new Array();
	for(var q=0; q < arrays.length; q++){
	 if(IsArray(arrays[q])){
	   for(var y=0; y < arrays[q].length; y++){
		   var it = arrays[q][y];
		   if(!IsNull(it)){
			   if(!rstarr.InArray(it).Exist)rstarr[rstarr.length] = it;
		   }
	   }
	 }else if(!IsNull(arrays[q])){
		 if(!rstarr.InArray(arrays[q]).Exist)rstarr[rstarr.length] = arrays[q];
	 }
	}
	if(rstarr.length == 0){
		return null;
	}else if(rstarr.length == 1){
		return rstarr[0];
	}else{
		return rstarr;
	}
 }
 
 //function to perform the AND logical operation (intersection)
 function FormAND(items){
	 
	 if(IsArray(items)){ //if items to perform AND on is an array
		 if(items.length == 0)return null; //if no element exist in item array return null
		 if(items.length < 2){ //if only one element exist
			return _(items[0]); //return the get result of the element
		 }else{ //if more than one element exits
			 var first = _(items[0]); //get the first element and get the resulting element(s)
			 var second = _(items[1]);//get the second element and get the resulting element(s)
			// alert(items[0] + "="+first.name+ " " +items[1] + "="+second.length);
			 if((IsArray(first) && !IsArray(second)) || (IsArray(first) && IsArray(second) && first.length > second.length)){//if first item is greater than second, swap them (for optimization)
				 var temp = first;
				 first = second;
				 second = temp;
				 //alert("swaped");
			 }
			 
			 var newarr = new Array(); //array to hold the AND operation result of the first and second element
			 //alert(IsArray(first));
			 if(IsArray(first)){ //if the first item is an array, check one by one if its element exist in second item
			 
				 for(var h=0; h<first.length; h++){
					 var curfirst = first[h];//get individual element
					 if(IsArray(second)){ //if the second item is an array
						 var conf = second.InArray(curfirst); //check if current firse element, exist in second array
						 if(conf.Exist){ //if exist add to new array
						  newarr[newarr.length] = curfirst;
						 }
					 }else{ //if second item is not an array
						 if(curfirst == second){ //check if current first is the second item, if exist add to new array
							 newarr[newarr.length] = curfirst; 
						 }
					 }
					 //objclnarr.InArray(className);
	//if(clsnCheck.Exist){
				 }
			 }else{// if first item is not an array
			 
				 var curfirst = first;//get individual element
					 if(IsArray(second)){ //if the second item is an array
						 var conf = second.InArray(curfirst); //check if current firse element, exist in second array
						 if(conf.Exist){ //if exist add to new array
						  newarr[newarr.length] = curfirst;
						 }
					 }else{ //if second item is not an array
						 if(curfirst == second){ //check if current first is the second item, if exist add to new array
							 newarr[newarr.length] = curfirst; 
						 }
					 }
				 
			 }
			 //form the new item array to continue AND operation on
			 if(newarr.length > 0){ //if AND eleemnt exist
				 items[0] = newarr;
				 items[1] = null;
				// alert(items);
				 items = items.Exact(); //make array be exclusive value elements, i.e all element with no value are removed
				 //alert(items);
				 if(items.length <2){ //if one element remaining, return it (the AND operation result)
					return  _(items[0]);
				 }else{ //if items still remains, continue AND operation
					return  FormAND(items);
				 }
			 }else{
				 return null;
			 }
			 
			 
		 }
	 }else{
		 return _(items);
	 }
	 
 }
 
 //this function tries to get the element by the id if not exist tries get by classname else return none;
 var performGetElem = function(str,arrelem){
	 /* If arrelem is sent insert the newly goten element if it is one or concatinate array of elements if new elements are more than one */
	 /*Executing addition first signifies that subtraction has higher prority than addition in order*/
	
	 
	 
	 //break for subtraction/exemption operation
	  var sstrarr = str.Trim().split("~");
	 if(sstrarr.length > 1){
		 
		 var rtnelem = RemoveElement(sstrarr);
		 if(IsNull(arrelem) && !IsNull(rtnelem))return rtnelem; /*if no currently elements are gotten (i.e arrelem is not sent) 
								                                    return the result like that */
		  if(!IsNull(arrelem) && IsNull(rtnelem))return arrelem;
		  if(IsNull(arrelem) && IsNull(rtnelem))return null;															
		 if(IsArray(rtnelem)){ //if rst is an array concatinate with existing array of element
			 arrelem = arrelem.concat(rtnelem);
			 
		 }else{ //if not an array add to an existin array elements
			 arrelem.push(rtnelem); 
		 }
		 
		 //return the newly formed array
		 return arrelem;
	 }
	 
	 //breack down to perform the AND operation
	 var astrarr = str.Trim().split("&");
	 astrarr = astrarr.Exact();
	 if(astrarr.length > 1){
		
		 return FormAND(astrarr);
	 }
	 
	  //break string down to determin if it is multiple search
	 var nstrarr = str.Trim().split(" ");
	 nstrarr = nstrarr.Exact();
	 if(nstrarr.length > 1){
		 return Element4rmArr(nstrarr);
	 }
	 
	 
	 
	
	 
	 var rst = null;
	 if(str.substr(0,1) == "."){ //class selector
       rst = document.querySelectorAll(str);
	 }else if(str.substr(0,1) == "#"){
      rst = document.querySelector(str);
	 }else{
	  rst = document.getElementById(str);
	 }
	
					   if(IsNull(rst)){ //if no element exit with that ID try other posibilities (By Classname, By Tagname )
					    //alert('sss');
					       for(var q=0;q<otherfunc.length;q++){ // move through array of functions of alternate options
							   rst = otherfunc[q](str);// perform the alternate lookup  
							   if(!IsNull(rst)){ //if element or elements are founf
								   if(IsNull(arrelem))return rst; /*if no currently elements are gotten (i.e arrelem is not sent) 
								                                    return the result like that */
								  // if(IsArray(rst)){ //if rst is an array concatinate with existing array of element
									   return FormRst(arrelem,rst);
									   
								  // }else{ //if not an array add to an existin array elements
									   //arrelem.push(rst); 
								  // }
								   //return the newly formed array
								   //return arrelem;
								  // break;
							   }
						   }
						   //after moving checking through all posible options and no elements found
						  if(IsNull(arrelem))return rst; //if no existing array return the null rst
						  //if there exit an existing array return the array back because no elements found for all possible optons
						  return arrelem;
						//if(IsNull(rst))arrelem.push(rst) ;   
					   }else{ //if element is found by ID
						    if(IsNull(arrelem))return rst; //if no elements current exist return the gotten element
							//if some elements exits before add the new element to the array of elements and return the newly formed array
							return FormRst(arrelem,rst);
						   /*arrelem.push(rst);
						   return arrelem;*/
					   }
					   
 }
 
 //function to resolve array, making sure all element of the array contain valid value
 var ArrayExact = function(arrayobj){
	 if(IsArray(arrayobj)){
		 var rtnarr = new Array();
		 //if(typeof num == "undefined"){
		   for(var f in arrayobj){
			  var val =  arrayobj[f];
			  if(!IsNull(val) && ((IsString(val) && !IsEmpty(val)) || (!IsString(val)) )){
				  if(IsNumber(f)){
				  rtnarr[rtnarr.length] = val;
				  }else{
				  rtnarr[f] = val;	
				  }
			  }
		   }
		 /*}else{
			 for(var ff=0; ff<arrayobj.length; ff++){
				 var val =  arrayobj[ff];
				 
				if(!IsNull(val)){
					alert(val);
					rtnarr[rtnarr.length] = val;
				}
			 }
		 }*/
		 return rtnarr;
	 }else{
		return arrayobj; 
	 }
 }
 
 Array.prototype.Exact = function(num){return ArrayExact(this,num)}
 
 
 //function to confirmly check an object classname
 var CheckClassName = function(obj,classname){
	 //var rtn = false; //default return value
	 if(IsString(obj)){ //if object classname sent is a string
	 //alert(obj);
		 var classarr = obj.split(" ");//break down to get individual class names
		 if(IsArray(classarr)){ //check if the break down is an array
			classarr = classarr.Exact(); //make sure no empty element exist in the array
			for(var s=0; s<classarr.length; s++){//loop through all the element of the array
				var clsnme = classarr[s].Trim(); //get individual classname
				if(clsnme == classname.Trim()){//compare with the compare classname
					return true; //if exist return true
				}
			}
		 }else{ //else is breack down is not an array
			if(obj.toString().Trim() == classname.Trim()){//compare the classnames
				return true;
			}
		 }
	 }else if(IsArray(obj)){//if object classname is an array
		 //loop through all the element and perform check
		 for(var v=0; v<obj.length; v++){
			 var elemobj = obj[v];
			return CheckClassName(elemobj,classname);
		 }
	 }else if(IsObject(obj)){
		 var clssname = obj.className;
		return CheckClassName(clssname,classname);
	 }
	 return false
 }
 
 Object.prototype.ClassNameIs = function(classname){return CheckClassName(this,classname)}
  String.prototype.ClassNameIs = function(classname){return CheckClassName(this.toString(),classname)}
  Array.prototype.ClassNameIs = function(classname){return CheckClassName(this,classname)}
  
  

 //----------------------------------------------------------------------

 //return object styles
  function _Style(){	
  //alert(arguments);
    var obj = null;
	/*if(obj == null){
		return null;
	}*/
	if(arguments.length > 1){
		 var arrelem = new Array(arguments.length);
		 for (i = 0; i < arguments.length; i++){
			 arrelem[i] = _(arguments[i]).style;
		 }
		 obj = arrelem;
	}else if(IsString(arguments[0])){
		obj = _(arguments[0]).style;
	}
	
	return obj;
  }
  function _CssToArray(css){
	  
	   var currRulearr = new Array()
	   if(css.Trim() != ""){
		  
		  var cssarr = css.Trim().split(";");
		  for (var s=0; s < cssarr.length ; s++){
			   if(cssarr[s].Trim() == ""){
				  continue; 
			   }
			  
			  var rulearr = cssarr[s].split(":");
			  if(rulearr.length == 2){
				  
				  currRulearr[rulearr[0]] = rulearr[1];
			  }
			  // alert(currRulearr);
		  }
		  
		  
	  }
	  return currRulearr;
  }
  String.prototype.CssToArray = function(){return _CssToArray(this.toString())}
  
  function _CssToString(cssarr){
	  var cssStr = "";
	  if(!IsArray(cssarr))return "";
	  for(var atr in cssarr){
		  if(IsString(cssarr[atr])){
			 cssStr +=  atr + ":" + cssarr[atr] + ";"; 
		  }
	  }
	  return cssStr;
  }
  Array.prototype.CssToString = function(){return _CssToString(this)}
  
  function _SetStyle(obj, styl){
	  if(IsNull(obj) || !IsSet(obj) || IsEmpty(styl) || IsNumber(obj))return;
	    if(!IsObject(obj))return;//alert(obj);
	 var currRulearr =  obj.style.cssText.CssToArray();
	 //alert(currRulearr.length);
	 /*for(var a in currRulearr){
		 alert(a + " = " +currRulearr[a]);
	 }*/
	  //if there is cureently css style set for the object load into an array
	 //obj.style.cssText
	/*  if(!HasItem(currRulearr)){
		 obj.style.cssText = styl; 
	  }else{*/
		  var newRulearr = styl.CssToArray();
		  //if(HasItem(newRulearr)){
			for(atrn in newRulearr){
				currRulearr[atrn] = newRulearr[atrn];
			}
		 // }
		 obj.style.cssText = currRulearr.CssToString();  
		 //alert(obj.style.cssText);
	 // }
	  //alert()
	 /* var rulearr = styl.split(";");
	  if(!HasItem(rulearr))return;*/
	  /*rulearr.Walk(function(k,v,obj){
		   if(IsString(v)){
			   styval = v.split("=");
			   obj.style[styval[0]] = styval[1];
		   }
		  },obj);*/
		  //document.getElementById().style.cssText
  }
  
 // var setstyle = function(obj, styl){SetStyle(obj, styl);}
  
  Object.prototype.SetStyle = function(styl){_SetStyle(this,styl)}
  String.prototype.SetStyle = function(styl){_(this.toString()).SetStyle(styl)}
  Array.prototype.SetStyle = function(styl){this.Walk(function(k,v,styl){
	   v.SetStyle(styl) 
	  },styl)}
 


//set opacity-------------------------------------
function _SO(obj,op){ //the initial setopacity function call - check if type of obj is array loop trough all item to set opacity
	if(IsArray(obj)){
		obj.Walk(function(k,v,obj){
			_SOStr(v,op);	
			},this);
	}else{
         _SOStr(obj,op);  
	}
}

function _SOStr(str,op){ /*real function that perform the setting - if str(the object sent) is still an array perform _SO() function on it so that it can loop throug all items to set their opacity, else if type of object is object then set the opacity as required*/
		var obj = _(str);
		if(IsNull(obj))return;
		if(IsArray(obj) && HasItem(obj)){
			_SO(obj,op);
		}else if(IsObject(obj)){
			obj.style.filter = 'alpha(opacity=' +  (op * 100) + ')'; //IE
		    obj.style.opacity = op;//Others
		}
}
  Object.prototype.SetOpacity = function(op){_SO(this,op)}
  Array.prototype.SetOpacity = function(op){_SO(this,op)}
  String.prototype.SetOpacity = function(op){_SO(this.toString(),op)}
  
var SO = _SO; //backword compatibility

//get opacity
/*function GO(obj){
	var obj = RP(obj);
	if(obj.style.opacity){
		alert('opacity = '+obj.style.opacity);
		
	}else{
		alert('opacityIE = '+obj.style.filter);
	}
}*/

//Togle Show/Hide Element (Toggle Show/Hide)-----------------------------
function _TSH(ID,Func){
	var elem = _(ID);
	if(IsNull(elem))return;
	if(IsArray(elem)){
		elem.Walk(function(k,v,obj){
		if(IsNull(v))return;
		   if(IsArray(v) || IsString(v)){
			   _TSH(v,Func);
		   }else if(IsObject(v)){
			   _TSHReal(v,Func);
		   }
		},Func);
	}else if(IsObject(elem)){
		_TSHReal(elem,Func);
	}
	
}

function _TSHReal(elem,Func){
	var state = elem.style.display;
	if (state == 'none'){
		elem.style.display = 'block';
		if(IsSet(Func) && IsSet(Func.ShowAction))Func.ShowAction(elem);
	}else{
		elem.style.display = 'none';
		if(IsSet(Func) &&  IsSet(Func.HideAction))Func.HideAction(elem);
	}
}

  Object.prototype.ToggleShowHide = function(Func){_TSH(this,Func)}
  Array.prototype.ToggleShowHide = function(Func){_TSH(this,Func)}
  String.prototype.ToggleShowHide = function(Func){_TSH(this.toString(),Func)}

var TSH = _TSH; //backword compatibility
//----------------------------------------------------------------------
var _ToArr = function(obj){
	
	if(IsNull(obj))return;
	
	var newarr = new Array();
	if(IsString(obj)){
		
		for(var s=0 ; s<obj.length; s++){
		  newarr.push(obj[s]);	
		}
	}else if(IsNumber(obj)){
		
		obj = obj.toString();
		for(var s=0 ; s<obj.length; s++){
			var digit = obj[s];
			if(digit != "."){
				digit = Number(digit);
			}
		  newarr.push(digit);	
		}
		
	}else if(IsArray(obj)){
		newarr = obj;
	}else{
		if(IsSet(obj.childNodes)){
			for(var w=0; w<obj.childNodes.length ; w++){
		     newarr.push(obj.childNodes[w]);
	        }
		}else if(IsSet(obj.length)){
			for(var w=0; w<obj.length ; w++){
		     newarr.push(obj[w]);
	        }
			
		}
		
	}
	
	
	return newarr;
}

Object.prototype.ToArray = function(){return _ToArr(this)}
Array.prototype.ToArray = function(){return _ToArr(this)}
String.prototype.ToArray = function(){return _ToArr(this.toString())}
Number.prototype.ToArray = function(){return _ToArr(parseFloat(this))}

//Resolve ID return string id value
function _GetId(){
	
	if(arguments.length < 1)return;
	if(arguments.length == 1){
	 ID = _(arguments[0]);	
	}else{
	 ID = _(arguments.ToArray());
	}
	
	
	if(IsNull(ID))return '';
	if(IsArray(ID)){
	 return FormarrID(ID);
	}else if(IsObject(ID)){
		return ID.id;
	}
	return '';
}



var FormarrID = function(arrobj){

			var arrid = new Array();
		    for(var w=0; w<arrobj.length; w++){
				var obj = arrobj[w];
				if(IsArray(obj)){
					arrid.concat(FormarrID(obj));
				}else{
					var id = (!IsSet(obj.id))?'':obj.id;
					arrid.push(id);
				}
			}
			return arrid;
		}


var RID = _GetId; //backward compatibility
Object.prototype.GetId = function(){return _GetId(this)}
Array.prototype.GetId = function(){return _GetId(this)}
String.prototype.GetId = function(){return _GetId(this.toString())}

//function to return element if parameter is either the elemnt or ID (Resolve Parameter)
function RP(parameter){
	if(typeof(parameter) == "object"){
		return parameter;
	}else if(typeof(parameter) == "string"){
		return _(parameter);
	}
}
//------------------------------------------------------------------------------

//Resolve Value- get the numeric value of a value containimg unit
function _RVal(val){
	if(IsString(val)){
		var rst= parseFloat(val);
		return (isNaN(rst))?0:rst;
	}else if(IsArray(val)){
		var newarr = new Array();
		for(var q=0; q<val.length; q++){
			var rval = _RVal(val[q]);
			if(IsArray(rval)){
				newarr.concat(rval);
			}else{
				newarr.push(rval);
			}
		}
		return newarr;
	}else if(IsObject(val)){
		var txt = val.GetText();
		if(!IsEmpty(txt)){
		   return _RVal(txt); 	
		}else{
			return 0;
		}
	}else{
		return val;
	}
}
RVal = _RVal;
String.prototype.ToNumber = function(){return _RVal(this.toString());}
Object.prototype.ToNumber = function(){return _RVal(this);}
Array.prototype.ToNumber = function(){return _RVal(this);}
Number.prototype.ToNumber = function(){return this;}

//Resolve Value- get the numeric value of a value containimg unit  (%)
function RValOneU(val){
	
	if (parseFloat(val)){
		//alert(val);
		return parseFloat(val);
	}else{
	
	return Number(val.substr(0,val.length-1));
	}
}

//function to clear the content of an object
var _Clear = function(){
	if(!HasItem(arguments))return; //if no argument
	if(arguments.length == 1){//one argument sent
		if(IsString(arguments[0])){
			//if is string get the object or objects
			var obj = _(arguments[0]);
			
			if(IsNull(obj))return;
			_Clear(obj); //perform the same function on the object or objects
		}else if(IsArray(arguments[0])){ //if array sent
			arguments[0].Walk(function(k,v){ //move through each object of the array and perform the function on them
				   _Clear(v);
				});
			
	     }else if(IsObject(arguments[0])){ //if it is object
			 var obj = arguments[0];
			if(IsSet(obj.value)){ //if it is an input object clear the value
				obj.value = "";
			}else if(IsSet(obj.textContent)){ //if ti is a textcontent object clear the text content
				obj.textContent = "";
			}
		}
	}else{
		//if multiple argument is sent, convert it to an array and run the clear function on it
		_Clear(arguments.ToArray());
		
	}
	
}
String.prototype.Clear = function(){_Clear(this.toString())}
Object.prototype.Clear = function(){_Clear(this)}
Array.prototype.Clear = function(){_Clear(this)}



