<?php if(!isset($libset)){require_once("../../Ajax/CGI/PHP/phplb.php");$bkmov="../../../../";}else{$bkmov="../../";} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Load Image</title>
</head>
<?php

$dbo = new DbFunctions();
//if an upload is sent
if(isset($_FILES['tImageFile'])){
	$rf = trim(@$_POST['tRootFolder']) == ""?"":@$_POST['tRootFolder']."/"; //hold the root folder of the javascript call(subdomain folder), so as to properlly resolve the upload folder directry in this script, Incase TaquaLB folder is imediately outside its user script folder(subdomain) or in d domain root folder with the user script subdomain folder - case use in edupota system (Note- Root folder is required if the TaquaLB is placed outside the folder where it is called)
	$rimgdir = trim($_POST['tImageDir']);
	$trimmed = "";
	//resolve the user supplied upload directory to be accessible from this script, cos the user supplied directory will be relative to the user script subdomain folder(incase subdomain is used)
	if($rf != "" && substr($rimgdir,0,3) == "../"){ //check if user is accessessing folder outside its subdomain folder, when a Root folder is sent
	  $rimgdir = substr($_POST['tImageDir'],3); //remove the back movement(../), cos the LB is already outside
	  $trimmed = "../"; //keep the trimmed back path str
	  $rf = ""; //clear the root folder, cos the dir is outside the root folder
	}
	//***********LIMITATION***************//
	//the TaquaLB folder is assumed to be in another folder, that why we need to move 4 times backword to get to the root (../../../../)//
	/*$libFolderRel = trim($_POST['tLibFolderRel']);
	if($libFolderRel != ""){
		$folders = explode("/",$libFolderRel);
		
	}*/
	$dbo->FileDir = (isset($_POST['tImageDir']) && !empty($_POST['tImageDir']))?$bkmov.$rf.$rimgdir:"Files/"; //set the upload folder
	$size = (isset($_POST['tImageSize']) && !empty($_POST['tImageSize']))?$_POST['tImageSize']:100000; //set the max size
	$_POST['tImageFilename'] = trim($_POST['tImageFilename']);
	$filename = (isset($_POST['tImageFilename']) && !empty($_POST['tImageFilename']))?$_POST['tImageFilename']:true;
	$ext = trim($_POST['tImageExt']);
	$rst = $dbo->UploadFile("tImageFile",$size,$filename,true,$ext); //upload the file
	if($rst['Success']){ //if the uploaded succesffully
		//$val = "1~".ltrim($rst['Filename'],"../../../"); //set concatinated response value (sucessCode~filename)
				$val = "1~".$trimmed.str_replace(array($bkmov,$rf),"",$rst['Filename']); //set concatinated response value (sucessCode~filename)

	}else{
		$val = "0~".$rst['Error']."~".$rst['ErrorText'];//set concatinated response value (sucessCode~error code)
	}
}else{
	$val = ""; //meaning it this page is loaded for file upload button click
}

?>
<body>

<form action="" method="post" enctype="multipart/form-data" name="tImageUpload">
<input type="file" name="tImageFile" id="tImageFile" onchange="document.getElementById('tImageSubmit').click()" />
<input type="submit" name="tImageSubmit" id="tImageSubmit" />
<input type="hidden" name="tImageStatus" id="tImageStatus" value="<?php echo $val   ?>"  />
<input type="hidden" name="tImageDir" id="tImageDir" value="<?php echo @$_GET['dir']   ?>"  />
<input type="hidden" name="tImageSize" id="tImageSize" value="<?php echo @$_GET['maxSize']   ?>"  />
<input type="hidden" name="tImageFilename" id="tImageFilename" value="<?php echo @$_GET['fn']   ?>"  />
<input type="hidden" name="tImageExt" id="tImageExt" value="<?php echo @$_GET['ext']   ?>"  />
<input type="hidden" name="tRootFolder" id="tRootFolder" value="<?php echo @$_GET['rf']   ?>"  />
<!--<input type="hidden" name="tLibFolderRel" id="tLibFolderRel" value="<?php //echo @$_GET['libBaseRelatice']   ?>"  />-->
</form>
</body>
</html>