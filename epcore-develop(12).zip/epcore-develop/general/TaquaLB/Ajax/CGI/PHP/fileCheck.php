<?php
$filename = trim(@$_POST['filename']);
$rf = trim(@$_POST['rf']) == ""?"":@$_POST['rf']."/";
if($filename == ""){
	echo "##";
	exit;
}
$trimmed = "";
$rfname = $filename;
if($rf != "" && substr($filename,0,3) == "../"){
	$rfname = substr($filename,3);
	$trimmed = "../";
	$rf = "";
}
$filnameExtarr = explode("~",$rfname);
$filename = $filnameExtarr[0];
if(file_exists("../../../../../".$rf.$filename)){
 echo $trimmed.$filename;	
}else{
	$rrr  = "";
	if(count($filnameExtarr) > 1){
	  for($d = 1; $d < count($filnameExtarr); $d++){
		  $split = explode(".",$filename);
		  $filename = $split[0].$filnameExtarr[$d];
		 //$rrr .= print_r($filename);
		  if(file_exists("../../../../../".$rf.$filename)){
			  echo $trimmed.$filename;
			  exit;
		  }
	  }
	  //echo $rrr;
	  echo "##";
	}else{
	echo "##";		
	}

}



?>