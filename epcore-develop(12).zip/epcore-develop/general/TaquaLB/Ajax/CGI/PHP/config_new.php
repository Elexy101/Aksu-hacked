<?php
date_default_timezone_set("Africa/Lagos");
//$ee_TaquaLBBaseUrl = "../../../../epconfig/";
  require_once($TaquaLBRoot."epengine/epengine.php");
  $EpEngine = new EduportaEngine($TaquaLBRoot."conf2.txt");
  if($EpEngine->ErrorCode > 0){
	  exit($EpEngine->Error);
  }
?>