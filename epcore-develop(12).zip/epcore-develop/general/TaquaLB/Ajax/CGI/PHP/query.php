<?php
header('Content-type: text/xml');
require("ConnObj.php");

if(!isset($_POST['query']) || empty($_POST['query']) ){
	reportError("query not found");
}
$query = $_POST['query'];
if($dbo->Connected == false){
	reportError($dbo->ConnectStatus);
}
$rst = $dbo->RunQuery(trim($query));
if(is_array($rst)){
	//reportError(mysql_fetch_array($rst[0]));
	echo $dbo->toXML($rst);
}else{	
	reportError($rst);

}



?>