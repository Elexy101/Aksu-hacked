<?php
header('Content-type: text/plain');
date_default_timezone_set("Africa/Lagos");
$d=(int)$_POST['d'];$m=(int)$_POST['m'];$y=(int)$_POST['y'];$i=(int)$_POST['i'];$h=(int)$_POST['h'];$s=(int)$_POST['s'];
$dt = mktime($h,$i,$s,$m,$d,$y);
$now = time();
$df = $dt - $now;
if($df > 0){
echo date("H#i#s#m#d#y",$df);
}else{
	echo "#";
}

?>