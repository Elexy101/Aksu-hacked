<?php
 include("phplb.php");
 //error declaration **********************************
 define('ERR_CONNSTR',"01: No Connection String Found");
 define('ERR_CONNSTR2',"02: Invalid Connection String");
 define('ERR_QUERY',"03: No sql statement specified");
 define('ERR_DB',"04: No sql statement specified");
 //*******************************************************
 
 //function to form the error xml string
 function reportError($cnst){
	echo "<error>
	          <errorCode>0</errorCode>
			  <errorName>{$cnst}</errorName>
	      </error>"; 
		   exit();
 }
 
 //function to get connection parameter
 function getParameter($paramName){
	 global $conarr; // the array that hold all parameter breakdown
	// $paramarr = array("server"=>0,"user"=>1,"db"=>2,"pw"=>3);
	 foreach($conarr as $paramstr){
		  $serverNamearr = explode("=",$paramstr);
		 if(count($serverNamearr) == 2 && strtolower(trim($serverNamearr[0])) == $paramName){
			return trim($serverNamearr[1]); 
		 }
	 }
	 reportError(ERR_CONNSTR2);
 } 
 
 
 $constr = @$_POST['connStr'];// get the connection string
 
 
 if($constr == "" || $constr == NULL){ //if no connection string found report error
	 reportError(ERR_CONNSTR);
 }
 $conarr = explode(";",$constr); //breakdown the connection string to get individual connection paramiters
 
 if(count($conarr) < 3 ){
	 reportError(ERR_CONNSTR2);
 }
 
//get each parameter value calling the getParameter Function (uses the $conarr)
 $serverName = getParameter("server");
 $user = getParameter("user");
 $db = getParameter("db");
 $pw = getParameter("pw");
 
  $phpf = new RphpFunctions;
  $dbo = new DbFunctions($serverName,$user,$pw,$db);
  

?>