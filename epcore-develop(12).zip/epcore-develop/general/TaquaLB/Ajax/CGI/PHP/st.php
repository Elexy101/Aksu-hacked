<?php
header('Content-type: text/plain');
date_default_timezone_set("Africa/Lagos");
  $format = $_POST['fmt'];
  $dt = new DateTime;
  echo $dt->format($format);
?>