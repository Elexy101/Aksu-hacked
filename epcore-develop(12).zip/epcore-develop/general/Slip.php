<?php
ini_set("memory_limit","-1");
if(!isset($_GET['SubDir'])){
    exit("Config Directory Not Set");
}
$configdir = "../../../".urldecode($_GET['SubDir']);
// a third party script to connect to printout Slips
include("config.php"); //the configuration object (connection parameters)
require_once "TaquaLB/Elements/Elements.php";
require_once "getinfo.php";
require_once $configdir.$dbo->Config['Require']."PDF/mpdf60/mpdf.php";
require_once "TaquaLB/Elements/Script/pdf.php";
//include("../../epconfig/GenScript/PHP/getinfo.php");//hold basic functions to perform some common database operations or request
//LoadFile("pdfprint","../../");
$pagefolder = $_GET['folder']; //represent the slip folder name in epconfig
$file = isset($_GET['file'])?$_GET['file']:"Slip.php"; //represent the slip folder name in epconfig
//$qrpath = ""; //the path to the qr image generator
//$qrpath = _SUBROOT_ ."Admin/qrcoderedirect.php?id=".urlencode(_CURURL_);
$pdf = new PDFPrinter();
$pdf->SetBasePath($configdir."Files/");

//check if custom slip set
$basedir = (file_exists($configdir."Slip/".$pagefolder."/$file"))?$configdir:"";
include($basedir."Slip/".$pagefolder."/$file");

?>